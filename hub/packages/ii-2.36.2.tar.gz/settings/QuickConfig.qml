import qs
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Io
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.ii.kit
import qs.modules.common.functions
import qs.modules.ii.barM3
import qs.modules.common.m3

ContentPage {
    id: root
    settingsPageIndex: 0
    settingsPageName: Translation.tr("Home")
    readonly property bool isOverlayPage: GlobalStates.settingsOverlayOpen ?? false
    // nothing open on arrival: Home is the hero, the day's switches and a way into each part (his 10-29: no wall of rows)
    property string activeSection: ""
    property string captureFolderTarget: "recordings"
    property bool showManualNotificationFilter: false
    property bool showManualVisualizerFilter: false
    readonly property string effectiveRecordingPath: {
        const configured = String(Config.getNestedValue("screenRecord.savePath", ""))
        return configured.length > 0 ? configured : Directories.videosPath
    }
    readonly property string effectiveScreenshotPath: Directories.screenshotsPath

    function _normalizedAppKey(value): string {
        return String(value ?? "").toLowerCase().replace(/[^a-z0-9]/g, "")
    }

    function _uniqueApps(values): var {
        const out = []
        const seen = ({})
        for (const raw of values ?? []) {
            const value = String(raw ?? "").trim()
            const key = root._normalizedAppKey(value)
            if (!key || seen[key]) continue
            seen[key] = true
            out.push(value)
        }
        return out
    }

    function _containsApp(values, candidate): bool {
        const key = root._normalizedAppKey(candidate)
        return key.length > 0 && (values ?? []).some(value => root._normalizedAppKey(value) === key)
    }

    function _setAppMembership(path, values, candidate, enabled): void {
        const clean = String(candidate ?? "").trim()
        if (!clean) return
        let next = root._uniqueApps(values)
        const key = root._normalizedAppKey(clean)
        next = next.filter(value => root._normalizedAppKey(value) !== key)
        if (enabled) next.push(clean)
        Config.setNestedValue(path, next)
        // App filters are low-frequency, user-curated policy. Settings runs in
        // its own process, so do not leave these edits waiting on the normal
        // deferred config timer where an immediate close/restart can discard
        // the last toggle before it reaches disk.
        Config.flushWrites()
    }

    function _notificationIcon(appName): string {
        const groups = Notifications.groupsByAppName ?? ({})
        const group = groups[appName] ?? []
        const icon = String(group[0]?.appIcon ?? "")
        if (icon.length > 0) return icon
        const entry = AppSearch.lookupDesktopEntry(appName)
        return String(entry?.icon ?? AppSearch.guessIcon(appName) ?? "")
    }

    readonly property var notificationFilterCandidates: {
        const blocked = Config.options?.notifications?.blockedApps ?? []
        const names = root._uniqueApps([...(Notifications.appNameList ?? []), ...blocked])
        return names.map(name => ({
            key: name,
            label: name,
            icon: root._notificationIcon(name),
            selected: root._containsApp(blocked, name),
            detected: (Notifications.appNameList ?? []).some(value => root._normalizedAppKey(value) === root._normalizedAppKey(name))
        }))
    }

    function _visualizerStreamKey(node): string {
        const props = node?.properties ?? {}
        return String(props["application.process.binary"]
            || props["application.id"]
            || props["application.name"]
            || node?.name || "").trim()
    }

    readonly property var visualizerFilterCandidates: {
        const blocked = Config.options?.appearance?.cava?.blockedApps ?? []
        const out = []
        const seen = ({})
        for (const node of MprisController.mixerAppNodes ?? []) {
            const key = root._visualizerStreamKey(node)
            const normalized = root._normalizedAppKey(key)
            if (!normalized || seen[normalized]) continue
            seen[normalized] = true
            out.push({
                key: key,
                label: MprisController.streamDisplayName(node) || key,
                icon: MprisController.streamIconName(node),
                selected: root._containsApp(blocked, key),
                active: MprisController.streamIsActive(node),
                detected: true
            })
        }
        for (const value of blocked) {
            const normalized = root._normalizedAppKey(value)
            if (!normalized || seen[normalized]) continue
            seen[normalized] = true
            const entry = AppSearch.lookupDesktopEntry(value)
            out.push({
                key: value,
                label: entry?.name ?? value,
                icon: entry?.icon ?? AppSearch.guessIcon(value),
                selected: true,
                active: false,
                detected: false
            })
        }
        return out
    }

    function openCaptureFolderDialog(target: string): void {
        root.captureFolderTarget = target
        captureFolderDialog.open()
    }

    SettingsHome {}

    // The page's parts as M3 Expressive tiles, each mark its own shape; one opens its rows under them, again shuts them.
    ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        StyledText {
            Layout.leftMargin: SettingsMaterialPreset.tilePaddingX
            text: Translation.tr("More")
            font.pixelSize: SettingsMaterialPreset.subheaderSize
            font.weight: Font.Medium
            color: SettingsMaterialPreset.subheaderColor
        }
        GridLayout {
            Layout.fillWidth: true
            columns: width >= 760 ? 3 : 2
            columnSpacing: 8
            rowSpacing: 8
            Repeater {
                model: [
                    { name: Translation.tr("Wallpaper"), icon: "format_paint", value: "wallpaper", shape: MaterialShape.Shape.Cookie9Sided, role: 0 },
                    { name: Translation.tr("Bar & screen"), icon: "screenshot_monitor", value: "screen", shape: MaterialShape.Shape.Pentagon, role: 2 },
                    { name: Translation.tr("Gaming"), icon: "sports_esports", value: "game", shape: MaterialShape.Shape.Clover4Leaf, role: 1 },
                    { name: Translation.tr("Capture"), icon: "photo_camera", value: "capture", shape: MaterialShape.Shape.Sunny, role: 0 },
                    { name: Translation.tr("Filters"), icon: "filter_alt", value: "filters", shape: MaterialShape.Shape.Gem, role: 2 },
                    { name: Translation.tr("Actions"), icon: "bolt", value: "actions", shape: MaterialShape.Shape.Flower, role: 1 }
                ]
                RippleButton {
                    id: part
                    required property var modelData
                    readonly property bool open: root.activeSection === part.modelData.value
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    implicitHeight: 56
                    pressScaleEnabled: false
                    buttonRadius: part.open ? 18 : 28
                    toggled: part.open
                    colBackground: SettingsMaterialPreset.tileColor
                    colBackgroundHover: SettingsMaterialPreset.tileHoverColor
                    colBackgroundToggled: Appearance.colors.colPrimaryContainer
                    colBackgroundToggledHover: ColorUtils.mix(Appearance.colors.colPrimaryContainer, Appearance.colors.colOnPrimaryContainer, 0.92)
                    colRipple: SettingsMaterialPreset.tilePressColor
                    colRippleToggled: ColorUtils.mix(Appearance.colors.colPrimaryContainer, Appearance.colors.colOnPrimaryContainer, 0.88)
                    Accessible.role: Accessible.Button
                    Accessible.name: part.modelData.name
                    onClicked: root.activeSection = part.open ? "" : part.modelData.value
                    Behavior on buttonRadius {
                        enabled: Appearance.animationsEnabled
                        NumberAnimation { duration: Appearance.animationCurves.expressiveFastSpatialDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: Appearance.animationCurves.expressiveFastSpatial }
                    }
                    contentItem: RowLayout {
                        spacing: 12
                        MaterialShapeWrappedMaterialSymbol {
                            Layout.leftMargin: 8
                            implicitSize: 40
                            shape: part.modelData.shape
                            text: part.modelData.icon
                            iconSize: 20
                            // three tonal roles in turn, so the eye tells the parts apart by colour before reading
                            color: part.open ? Appearance.colors.colPrimary
                                : [Appearance.colors.colPrimaryContainer, Appearance.colors.colSecondaryContainer, Appearance.colors.colTertiaryContainer][part.modelData.role]
                            colSymbol: part.open ? Appearance.colors.colOnPrimary
                                : [Appearance.colors.colOnPrimaryContainer, Appearance.colors.colOnSecondaryContainer, Appearance.colors.colOnTertiaryContainer][part.modelData.role]
                        }
                        StyledText {
                            Layout.fillWidth: true
                            text: part.modelData.name
                            font.pixelSize: Math.round(14 * Appearance.fontSizeScale)
                            font.weight: Font.Medium
                            color: part.open ? Appearance.colors.colOnPrimaryContainer : SettingsMaterialPreset.labelColor
                            elide: Text.ElideRight
                        }
                        MaterialSymbol {
                            Layout.rightMargin: 12
                            text: "expand_more"
                            iconSize: 20
                            rotation: part.open ? 180 : 0
                            color: part.open ? Appearance.colors.colOnPrimaryContainer : SettingsMaterialPreset.supportingColor
                            Behavior on rotation {
                                enabled: Appearance.animationsEnabled
                                NumberAnimation { duration: Appearance.animationCurves.expressiveFastSpatialDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: Appearance.animationCurves.expressiveFastSpatial }
                            }
                        }
                    }
                }
            }
        }
    }

    // Kept for search: a result inside a part opens it through here; the tiles above are what people see.
    SettingsTaskNavigator {
        visible: false
        icon: "bolt"
        title: ""
        description: ""
        summary: ""
        currentValue: root.activeSection
        onSelected: value => root.activeSection = value
        searchAliases: ({
            "wallpaper & colors": "wallpaper",
            "capture locations": "capture",
            "app filters": "filters"
        })
        options: [
            { displayName: Translation.tr("Wallpaper"), icon: "format_paint", value: "wallpaper" },
            { displayName: Translation.tr("Bar & screen"), icon: "screenshot_monitor", value: "screen" },
            { displayName: Translation.tr("Game mode"), icon: "sports_esports", value: "game" },
            { displayName: Translation.tr("Capture"), icon: "photo_camera", value: "capture" },
            { displayName: Translation.tr("Filters"), icon: "filter_alt", value: "filters" },
            { displayName: Translation.tr("Actions"), icon: "bolt", value: "actions" }
        ]
    }

    FilePickerDialog {

        selectFolder: true
        id: captureFolderDialog
        title: root.captureFolderTarget === "screenshots"
            ? Translation.tr("Select screenshots folder")
            : Translation.tr("Select recordings folder")
        currentFolder: `file://${root.captureFolderTarget === "screenshots"
            ? root.effectiveScreenshotPath : root.effectiveRecordingPath}`
        onAccepted: {
            const path = FileUtils.trimFileProtocol(String(selectedFolder))
            Config.setNestedValue(root.captureFolderTarget === "screenshots"
                ? "regionSelector.savePath" : "screenRecord.savePath", path)
        }
    }

    SettingsNativeDialogGuard {
        dialog: captureFolderDialog
        dialogKey: "quick-capture-folder"
    }
    // Deferred in both modes: entering the page must never kick off directory-wide
    // thumbnail generation. The user asks for the grid explicitly.
    property bool quickGridLoaded: false

    Component.onCompleted: {
        Wallpapers.load()
    }

    // Wallpaper selection
    SettingsTaskLoader {
        requested: root.activeSection === "wallpaper"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "wallpaper"
        expanded: true
        icon: "format_paint"
        title: Translation.tr("Wallpaper & Colors")
        Layout.fillWidth: true

        SettingsGroup {
            ConfigSpinBox {
                icon: "palette"
                text: Translation.tr("Wallpaper color strength") + " (%)"
                value: Math.round((Config.options?.appearance?.wallpaperTheming?.colorStrength ?? 1.0) * 100)
                from: 60
                to: 180
                stepSize: 5
                property bool _ready: false
                Component.onCompleted: _ready = true
                onValueModified: {
                    if (!_ready) return;
                    Config.setNestedValue("appearance.wallpaperTheming.colorStrength", value / 100)
                    if (ThemeService.isAutoTheme)
                        Quickshell.execDetached([Directories.wallpaperSwitchScriptPath, "--noswitch"])
                }

                StyledToolTip {
                    text: Translation.tr("Controls how vivid wallpaper-derived accent colors are. 100% keeps the default balance; higher values produce richer accents.")
                }
            }

            // ── Options strip ──
            ConfigRow {
                SettingsSwitch {
                    buttonIcon: "ev_shadow"
                    text: Translation.tr("Transparency")
                    checked: Config.options?.material?.style?.transparency?.enable ?? false
                    onCheckedChanged: {
                        Config.setNestedValue("material.style.transparency.enable", checked)
                    }
                    StyledToolTip {
                        text: Translation.tr("Might look ass. Unsupported.")
                    }
                }

                SettingsSwitch {
                    buttonIcon: "palette"
                    text: Translation.tr("Colors only")
                    checked: Config.options?.appearance?.wallpaperTheming?.colorsOnlyMode ?? false
                    onCheckedChanged: {
                        Config.setNestedValue("appearance.wallpaperTheming.colorsOnlyMode", checked)
                        if (!checked)
                            Config.setNestedValue("appearance.wallpaperTheming.previewSourcePath", "")
                    }
                    StyledToolTip {
                        text: Translation.tr("Use any thumbnail as the theme source while keeping the current wallpaper")
                    }
                }
            }

            // ── Wallpaper browser ──
            ContentSubsection {
                title: Translation.tr("Quick select")

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    RowLayout {
                        Layout.fillWidth: true

                        // Folder breadcrumb
                        RowLayout {
                            spacing: 4
                            MaterialSymbol {
                                text: "folder"
                                font.pixelSize: Appearance.font.pixelSize.small
                                color: Appearance.colors.colSubtext
                            }
                            StyledText {
                                Layout.fillWidth: true
                                elide: Text.ElideMiddle
                                font.pixelSize: Appearance.font.pixelSize.smaller
                                text: FileUtils.trimFileProtocol(Wallpapers.effectiveDirectory)
                                color: Appearance.colors.colSubtext
                            }
                        }

                        Item { Layout.fillWidth: true }

                        RippleButtonWithIcon {
                            buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.full
                            materialIcon: "folder_open"
                            mainText: Translation.tr("Current folder")
                            onClicked: {
                                const currentPath = Config.options?.background?.wallpaperPath ?? "";
                                if (currentPath && currentPath.length) {
                                    Wallpapers.setDirectory(FileUtils.parentDirectory(currentPath));
                                } else {
                                    Wallpapers.setDirectory(Wallpapers.defaultFolder.toString());
                                }
                            }
                            StyledToolTip {
                                text: Translation.tr("Switch to the folder containing the current wallpaper")
                            }
                        }
                        RippleButtonWithIcon {
                            buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.full
                            materialIcon: "apps"
                            mainText: Translation.tr("Selector")
                            onClicked: {
                                Config.setNestedValue("wallpaperSelector.selectionTarget", "main")
                                if (Config.options?.background?.multiMonitor?.enable && multiMonitorPanel.selectedMonitor) {
                                    Config.setNestedValue("wallpaperSelector.targetMonitor", multiMonitorPanel.selectedMonitor)
                                }
                                Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "wallpaperSelector", "toggle"]);
                            }
                            StyledToolTip {
                                text: Translation.tr("Open the full wallpaper selector overlay")
                            }
                        }
                    }

                    // Backdrop selection mode indicator
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: visible ? bdModeRow.implicitHeight + 12 : 0
                        visible: multiMonitorPanel.visible && multiMonitorPanel.backdropViewActive
                        radius: Appearance.rounding.small
                        color: Appearance.inirEverywhere
                            ? Qt.rgba(Appearance.inir.colAccent.r, Appearance.inir.colAccent.g, Appearance.inir.colAccent.b, 0.15)
                            : Qt.rgba(Appearance.colors.colTertiary.r, Appearance.colors.colTertiary.g, Appearance.colors.colTertiary.b, 0.15)
                        border.width: 1
                        border.color: Appearance.inirEverywhere
                            ? Qt.rgba(Appearance.inir.colAccent.r, Appearance.inir.colAccent.g, Appearance.inir.colAccent.b, 0.3)
                            : Qt.rgba(Appearance.colors.colTertiary.r, Appearance.colors.colTertiary.g, Appearance.colors.colTertiary.b, 0.3)

                        RowLayout {
                            id: bdModeRow
                            anchors.fill: parent
                            anchors.margins: 6
                            spacing: 6
                            MaterialSymbol {
                                text: "blur_on"
                                font.pixelSize: Appearance.font.pixelSize.normal
                                color: Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colTertiary
                            }
                            StyledText {
                                Layout.fillWidth: true
                                text: Translation.tr("Selecting backdrop wallpaper")
                                font.pixelSize: Appearance.font.pixelSize.small
                                color: Appearance.inirEverywhere ? Appearance.inir.colOnLayer1 : Appearance.colors.colOnLayer1
                            }
                            MaterialSymbol {
                                text: "close"
                                font.pixelSize: Appearance.font.pixelSize.normal
                                color: Appearance.colors.colSubtext
                                MouseArea {
                                    anchors.fill: parent
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: multiMonitorPanel.backdropViewActive = false
                                }
                            }
                        }

                        Behavior on Layout.preferredHeight {
                            enabled: Appearance.animationsEnabled
                            animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                        }
                    }

                    Rectangle {
                        id: placeholderCard
                        Layout.fillWidth: true
                        Layout.preferredHeight: quickGridDeferredContent.implicitHeight + 24
                        opacity: root.quickGridLoaded ? 0 : 1
                        visible: opacity > 0
                        scale: root.quickGridLoaded ? 0.96 : 1
                        radius: Appearance.rounding.normal
                        Behavior on Layout.preferredHeight { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveExit.duration; easing.type: Appearance.animation.elementMoveExit.type; easing.bezierCurve: Appearance.animation.elementMoveExit.bezierCurve } }
                        Behavior on opacity { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveExit.duration; easing.type: Appearance.animation.elementMoveExit.type; easing.bezierCurve: Appearance.animation.elementMoveExit.bezierCurve } }
                        Behavior on scale { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveExit.duration; easing.type: Appearance.animation.elementMoveExit.type; easing.bezierCurve: Appearance.animation.elementMoveExit.bezierCurve } }
                        color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                             : Appearance.inirEverywhere ? Appearance.inir.colLayer0
                             : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                             : Appearance.colors.colLayer0
                        border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                            : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
                        border.color: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
                                   : Appearance.inirEverywhere ? Appearance.inir.colBorder
                                   : Appearance.colors.colLayer0Border

                        ColumnLayout {
                            id: quickGridDeferredContent
                            anchors.fill: parent
                            anchors.margins: 12
                            spacing: 10

                            StyledText {
                                Layout.fillWidth: true
                                text: Translation.tr("Quick wallpaper thumbnails are loaded on demand.")
                                wrapMode: Text.WordWrap
                                color: Appearance.colors.colOnLayer0
                                font.pixelSize: Appearance.font.pixelSize.normal
                                font.weight: Font.Medium
                            }

                            StyledText {
                                Layout.fillWidth: true
                                text: Translation.tr("Load them only when you actually need the grid. The full selector button above stays available.")
                                wrapMode: Text.WordWrap
                                color: Appearance.colors.colSubtext
                                font.pixelSize: Appearance.font.pixelSize.small
                            }

                            RippleButtonWithIcon {
                                buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.full
                                materialIcon: "image"
                                mainText: Translation.tr("Load quick grid")
                                onClicked: root.quickGridLoaded = true
                            }
                        }
                    }

                    Item {
                        id: quickGridHost
                        Layout.fillWidth: true
                        Layout.preferredHeight: quickGridLoader.active && quickGridLoader.item ? quickGridLoader.item.implicitHeight : 0
                        clip: true
                        Behavior on Layout.preferredHeight { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve } }

                        Loader {
                            id: quickGridLoader
                            anchors.fill: parent
                            active: root.quickGridLoaded
                            asynchronous: true

                            sourceComponent: Rectangle {
                                id: gridCard
                                width: quickGridHost.width
                                height: implicitHeight
                                opacity: quickGridLoader.item ? 1 : 0
                                scale: quickGridLoader.item ? 1 : 0.95
                                Behavior on opacity { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve } }
                                Behavior on scale { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve } }
                                implicitHeight: {
                                    const itemCount = Wallpapers.folderModel?.count ?? 0
                                    if (itemCount === 0) return 120
                                    const cols = Math.max(1, Math.floor((width - 2 * Appearance.sizes.spacingSmall) / 110))
                                    const rows = Math.ceil(itemCount / cols)
                                    const cellH = ((width - 2 * Appearance.sizes.spacingSmall) / cols) * 0.67
                                    return Math.min(280, Math.max(120, rows * cellH + 2 * Appearance.sizes.spacingSmall))
                                }
                                radius: Appearance.rounding.normal
                                color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                                     : Appearance.inirEverywhere ? Appearance.inir.colLayer0
                                     : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                                     : Appearance.colors.colLayer0
                                border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                                    : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
                                border.color: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
                                           : Appearance.inirEverywhere ? Appearance.inir.colBorder
                                           : Appearance.colors.colLayer0Border
                                clip: true

                                GridView {
                                    id: wallpaperGrid
                                    anchors.fill: parent
                                    anchors.margins: Appearance.sizes.spacingSmall
                                    model: Wallpapers.folderModelReady ? Wallpapers.folderModel : null
                                    Component.onCompleted: Wallpapers.generateThumbnail("large")

                                    add: Transition {
                                        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve }
                                        NumberAnimation { property: "scale"; from: 0.85; to: 1; duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve }
                                    }
                                    populate: Transition {
                                        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve }
                                        NumberAnimation { property: "scale"; from: 0.85; to: 1; duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve }
                                    }

                                    Connections {
                                        target: Wallpapers
                                        function onFolderChanged() {
                                            Wallpapers.generateThumbnail("large")
                                        }
                                    }

                                    // Responsive cell sizing - fill available width
                                    property int minCellWidth: 110
                                    property int columns: Math.max(1, Math.floor(width / minCellWidth))
                                    cellWidth: width / columns
                                    cellHeight: cellWidth * 0.67  // 3:2 aspect ratio

                                    interactive: contentHeight > height
                                    boundsBehavior: Flickable.StopAtBounds
                                    cacheBuffer: cellHeight * 2
                                    property int currentHoverIndex: -1
                                    ScrollBar.vertical: StyledScrollBar { policy: wallpaperGrid.interactive ? ScrollBar.AsNeeded : ScrollBar.AlwaysOff }

                                    delegate: Item {
                                        id: delegateItem
                                        required property int index
                                        required property bool fileIsDir
                                        required property string filePath
                                        required property string fileName
                                        required property url fileUrl

                                        width: wallpaperGrid.cellWidth
                                        height: wallpaperGrid.cellHeight

                                        QuickWallpaperItem {
                                            anchors.fill: parent
                                            fileModelData: ({
                                                filePath: delegateItem.filePath,
                                                fileName: delegateItem.fileName,
                                                fileIsDir: delegateItem.fileIsDir,
                                                fileUrl: delegateItem.fileUrl
                                            })
                                            isSelected: {
                                                if (delegateItem.fileIsDir) return false
                                                if (multiMonitorPanel.visible && multiMonitorPanel.backdropViewActive)
                                                    return delegateItem.filePath === multiMonitorPanel.backdropPath
                                                if (Config.options?.appearance?.wallpaperTheming?.colorsOnlyMode ?? false) {
                                                    const previewPath = Config.options?.appearance?.wallpaperTheming?.previewSourcePath ?? ""
                                                    return delegateItem.filePath === previewPath
                                                }
                                                const multiMon = (Config.options?.background?.multiMonitor?.enable ?? false) && multiMonitorPanel.selectedMonitor
                                                const currentWallpaperPath = Config.options?.background?.wallpaperPath ?? ""
                                                return delegateItem.filePath === (multiMon
                                                    ? (WallpaperListener.effectivePerMonitor[multiMonitorPanel.selectedMonitor]?.path ?? currentWallpaperPath)
                                                    : currentWallpaperPath)
                                            }
                                            isHovered: delegateItem.index === wallpaperGrid.currentHoverIndex

                                            onEntered: wallpaperGrid.currentHoverIndex = delegateItem.index
                                            onExited: if (wallpaperGrid.currentHoverIndex === delegateItem.index) wallpaperGrid.currentHoverIndex = -1
                                            onActivated: {
                                                if (delegateItem.fileIsDir) {
                                                    Wallpapers.setDirectory(delegateItem.filePath);
                                                } else if (multiMonitorPanel.visible && multiMonitorPanel.backdropViewActive) {
                                                    const multiMon = Config.options?.background?.multiMonitor?.enable ?? false
                                                    if (multiMon && multiMonitorPanel.selectedMonitor) {
                                                        Wallpapers.updatePerMonitorBackdropConfig(delegateItem.filePath, multiMonitorPanel.selectedMonitor)
                                                    } else {
                                                        Config.setNestedValue("background.backdrop.wallpaperPath", delegateItem.filePath)
                                                    }
                                                    Config.setNestedValue("background.backdrop.useMainWallpaper", false)
                                                    Wallpapers.ensureVideoFirstFrame(delegateItem.filePath)
                                                } else if (Config.options?.appearance?.wallpaperTheming?.colorsOnlyMode) {
                                                    Wallpapers.applyColorsOnly(delegateItem.filePath, Appearance.m3colors.darkmode)
                                                } else {
                                                    const mon = (Config.options?.background?.multiMonitor?.enable ?? false) ? (multiMonitorPanel.selectedMonitor || "") : ""
                                                    Wallpapers.select(delegateItem.filePath, Appearance.m3colors.darkmode, mon);
                                                }
                                            }
                                        }
                                    }
                                }

                                MaterialPlaceholderMessage {
                                    anchors.centerIn: parent
                                    maximumWidth: 360
                                    shown: Wallpapers.folderModel.count === 0
                                    icon: "image"
                                    text: Translation.tr("No images found")
                                    explanation: Translation.tr("Add wallpapers to this folder or choose a different location")
                                    shape: MaterialShape.Shape.Bun
                                }
                            }
                        }
                    }
                }
            }
        }

        SettingsGroup {
            ConfigSwitch {
                buttonIcon: "monitor"
                text: Translation.tr("Per-monitor wallpapers")
                checked: Config.options?.background?.multiMonitor?.enable ?? false
                onCheckedChanged: {
                    Config.setNestedValue("background.multiMonitor.enable", checked)
                    if (!checked) {
                        const globalPath = Config.options?.background?.wallpaperPath ?? ""
                        if (globalPath) {
                            Wallpapers.apply(globalPath, Appearance.m3colors.darkmode)
                        }
                    }
                }
            }

            // Multi-monitor management panel
            ColumnLayout {
                id: multiMonitorPanel
                visible: Config.options?.background?.multiMonitor?.enable ?? false
                Layout.fillWidth: true
                spacing: Appearance.sizes.spacingSmall

                property string selectedMonitor: {
                    const primary = GlobalStates.primaryScreen
                    const primaryName = primary ? (WallpaperListener.getMonitorName(primary) ?? "") : ""
                    if (primaryName) return primaryName
                    const focused = WallpaperListener.getFocusedMonitor()
                    if (focused) return focused
                    const screens = Quickshell.screens
                    if (!screens || screens.length === 0) return ""
                    return WallpaperListener.getMonitorName(screens[0]) ?? ""
                }

                readonly property var selMonData: WallpaperListener.effectivePerMonitor[selectedMonitor] ?? { path: "", isVideo: false, isGif: false, isAnimated: false, hasCustomWallpaper: false }
                readonly property string selMonPath: selMonData.path || (Config.options?.background?.wallpaperPath ?? "")
                property bool backdropViewActive: false

                // Backdrop wallpaper data for stacked preview
                readonly property var iiBackdrop: Config.options?.background?.backdrop ?? {}
                readonly property bool backdropEnabled: iiBackdrop.enable ?? false
                readonly property string backdropPath: {
                    const useMain = iiBackdrop.useMainWallpaper ?? true;
                    if (!useMain) {
                        // Per-monitor backdrop takes priority
                        const perMonBd = selMonData.backdropPath ?? ""
                        if (perMonBd) return perMonBd
                        // Fall back to global backdrop
                        const globalBd = iiBackdrop.wallpaperPath || ""
                        if (globalBd) return globalBd
                    }
                    return selMonPath;
                }
                readonly property string backdropUrl: {
                    const p = backdropPath
                    if (!p) return ""
                    return p.startsWith("file://") ? p : "file://" + p
                }

                // Delayed color regeneration (waits for config file write before script reads)
                Timer {
                    id: colorRegenTimer
                    interval: 1000
                    onTriggered: Quickshell.execDetached([Directories.wallpaperSwitchScriptPath, "--noswitch"])
                }

                // Visual monitor layout
                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 220
                    radius: Appearance.rounding.normal
                    color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                         : Appearance.inirEverywhere ? Appearance.inir.colLayer0
                         : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                         : Appearance.colors.colLayer0
                    border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                        : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
                    border.color: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
                               : Appearance.inirEverywhere ? Appearance.inir.colBorder
                               : Appearance.colors.colLayer0Border

                    RowLayout {
                        anchors.centerIn: parent
                        spacing: Appearance.sizes.spacingSmall
                        height: parent.height - 24

                        Repeater {
                            model: Quickshell.screens

                            Item {
                                id: monitorStack
                                required property var modelData
                                required property int index

                                readonly property string monName: WallpaperListener.getMonitorName(modelData) ?? ""
                                readonly property var wpData: WallpaperListener.effectivePerMonitor[monName] ?? { path: "" }
                                readonly property string wpPath: wpData.path || (Config.options?.background?.wallpaperPath ?? "")
                                readonly property bool isSelected: monName === multiMonitorPanel.selectedMonitor
                                readonly property bool isGif: WallpaperListener.isGifPath(wpPath)
                                readonly property bool isVideo: WallpaperListener.isVideoPath(wpPath)
                                readonly property real aspectRatio: modelData.width / Math.max(1, modelData.height)
                                readonly property real cardHeight: parent.height - 16
                                property bool showingBackdrop: false

                                readonly property string backdropPath: {
                                    const bd = Config.options?.background?.backdrop ?? {}
                                    const useMain = bd.useMainWallpaper ?? true
                                    if (!useMain) {
                                        // Per-monitor backdrop takes priority
                                        const perMonBd = wpData.backdropPath ?? ""
                                        if (perMonBd) return perMonBd
                                        // Fall back to global backdrop
                                        const globalBd = bd.wallpaperPath || ""
                                        if (globalBd) return globalBd
                                    }
                                    return wpPath
                                }

                                onWpPathChanged: if (isVideo) Wallpapers.ensureVideoFirstFrame(wpPath)
                                onBackdropPathChanged: if (WallpaperListener.isVideoPath(backdropPath)) Wallpapers.ensureVideoFirstFrame(backdropPath)

                                Layout.preferredWidth: (cardHeight * aspectRatio) + (multiMonitorPanel.backdropEnabled ? 26 : 8)
                                Layout.preferredHeight: parent.height
                                Layout.alignment: Qt.AlignVCenter

                                // Backdrop card — peeks out to the RIGHT behind the main card
                                Rectangle {
                                    id: backdropPeekCard
                                    visible: multiMonitorPanel.backdropEnabled
                                    anchors.right: parent.right
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: monitorCard.width
                                    height: monitorCard.height
                                    radius: Appearance.rounding.small
                                    color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                                         : Appearance.inirEverywhere ? Appearance.inir.colLayer1
                                         : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                                         : Appearance.colors.colLayer1
                                    border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                                        : Appearance.inirEverywhere ? 1 : (monitorStack.showingBackdrop ? 2 : 1)
                                    border.color: monitorStack.showingBackdrop
                                        ? (Appearance.angelEverywhere ? (Appearance.angel?.colPrimary ?? Appearance.colors.colPrimary) : Appearance.inirEverywhere ? (Appearance.inir?.colAccent ?? Appearance.colors.colPrimary) : Appearance.colors.colPrimary)
                                        : (Appearance.angelEverywhere ? (Appearance.angel?.colCardBorder ?? Appearance.colors.colLayer0Border) : Appearance.inirEverywhere ? (Appearance.inir?.colBorder ?? Appearance.colors.colLayer0Border) : Appearance.colors.colLayer0Border)
                                    clip: true
                                    z: monitorStack.showingBackdrop ? 2 : 0
                                    opacity: monitorStack.showingBackdrop ? 1.0 : 0.6

                                    layer.enabled: true
                                    layer.smooth: true
                                    layer.effect: OpacityMask {
                                        maskSource: Rectangle {
                                            width: backdropPeekCard.width
                                            height: backdropPeekCard.height
                                            radius: backdropPeekCard.radius
                                        }
                                    }

                                    Behavior on opacity {
                                        enabled: Appearance.animationsEnabled
                                        animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                    }
                                    Behavior on z {
                                        enabled: Appearance.animationsEnabled
                                        animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                    }

                                    StyledImage {
                                        visible: !WallpaperListener.isVideoPath(monitorStack.backdropPath) && !WallpaperListener.isGifPath(monitorStack.backdropPath)
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: (!WallpaperListener.isVideoPath(monitorStack.backdropPath) && !WallpaperListener.isGifPath(monitorStack.backdropPath)) ? (monitorStack.backdropPath || "") : ""
                                        sourceSize.width: backdropPeekCard.width * 2
                                        sourceSize.height: backdropPeekCard.height * 2
                                        cache: true
                                    }
                                    AnimatedImage {
                                        visible: WallpaperListener.isGifPath(monitorStack.backdropPath)
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: WallpaperListener.isGifPath(monitorStack.backdropPath) ? monitorStack.backdropUrl : ""
                                        asynchronous: true
                                        cache: true
                                        playing: false
                                    }
                                    StyledImage {
                                        visible: WallpaperListener.isVideoPath(monitorStack.backdropPath)
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: {
                                            const ff = Wallpapers.videoFirstFrames[monitorStack.backdropPath]
                                            return ff ? (ff.startsWith("file://") ? ff : "file://" + ff) : ""
                                        }
                                        cache: true
                                        Component.onCompleted: Wallpapers.ensureVideoFirstFrame(monitorStack.backdropPath)
                                    }

                                    // Backdrop label
                                    Rectangle {
                                        visible: monitorStack.showingBackdrop
                                        anchors.top: parent.top
                                        anchors.left: parent.left
                                        anchors.margins: Appearance.sizes.spacingSmall
                                        width: bdLabelRow.implicitWidth + Appearance.sizes.spacingSmall * 2
                                        height: bdLabelRow.implicitHeight + 4
                                        radius: height / 2
                                        color: Qt.rgba(0, 0, 0, 0.65)
                                        Row {
                                            id: bdLabelRow
                                            anchors.centerIn: parent
                                            spacing: 3
                                            MaterialSymbol {
                                                text: "blur_on"
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                color: Appearance.colors.colOnLayer0
                                                anchors.verticalCenter: parent.verticalCenter
                                            }
                                            StyledText {
                                                text: Translation.tr("Backdrop")
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                color: Appearance.colors.colOnLayer0
                                                anchors.verticalCenter: parent.verticalCenter
                                            }
                                        }
                                    }

                                    MouseArea {
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                                        onClicked: {
                                            multiMonitorPanel.selectedMonitor = monitorStack.monName
                                            monitorStack.showingBackdrop = !monitorStack.showingBackdrop
                                            multiMonitorPanel.backdropViewActive = monitorStack.showingBackdrop
                                        }
                                    }

                                    // Selection border overlay
                                    Rectangle {
                                        anchors.fill: parent
                                        radius: parent.radius
                                        color: "transparent"
                                        visible: monitorStack.showingBackdrop && monitorStack.isSelected
                                        border.width: 2
                                        border.color: Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colPrimary
                                    }
                                }

                                // Main wallpaper card
                                Rectangle {
                                    id: monitorCard
                                    anchors.left: parent.left
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: monitorStack.cardHeight * monitorStack.aspectRatio
                                    height: monitorStack.cardHeight
                                    z: monitorStack.showingBackdrop ? 0 : 1

                                    radius: Appearance.rounding.small
                                    color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                                         : Appearance.inirEverywhere ? Appearance.inir.colLayer1
                                         : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                                         : Appearance.colors.colLayer1
                                    border.width: monitorStack.isSelected && !monitorStack.showingBackdrop
                                        ? (Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth : Appearance.inirEverywhere ? 1 : 2) : (Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth : Appearance.inirEverywhere ? 1 : 0)
                                    border.color: monitorStack.isSelected && !monitorStack.showingBackdrop
                                        ? (Appearance.angelEverywhere ? Appearance.angel.colPrimary : Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colPrimary)
                                        : (Appearance.angelEverywhere ? Appearance.angel.colCardBorder : Appearance.inirEverywhere ? Appearance.inir.colBorder : "transparent")
                                    clip: true

                                    layer.enabled: true
                                    layer.smooth: true
                                    layer.effect: OpacityMask {
                                        maskSource: Rectangle {
                                            width: monitorCard.width
                                            height: monitorCard.height
                                            radius: monitorCard.radius
                                        }
                                    }

                                    scale: monitorStack.isSelected ? 1.0 : (monCardMa.containsMouse ? 0.97 : 0.93)
                                    opacity: monitorStack.isSelected ? 1.0 : (monCardMa.containsMouse ? 0.95 : 0.8)
                                    Behavior on scale {
                                        enabled: Appearance.animationsEnabled
                                        animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                    }
                                    Behavior on opacity {
                                        enabled: Appearance.animationsEnabled
                                        animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                    }

                                    MouseArea {
                                        id: monCardMa
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        hoverEnabled: true
                                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                                        onClicked: (mouse) => {
                                            multiMonitorPanel.selectedMonitor = monitorStack.monName
                                            if (mouse.button === Qt.RightButton) {
                                                monitorStack.showingBackdrop = !monitorStack.showingBackdrop
                                                multiMonitorPanel.backdropViewActive = monitorStack.showingBackdrop
                                            } else {
                                                monitorStack.showingBackdrop = false
                                                multiMonitorPanel.backdropViewActive = false
                                            }
                                        }
                                    }

                                    // Static image
                                    StyledImage {
                                        visible: !monitorStack.isGif && !monitorStack.isVideo
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: (!monitorStack.isGif && !monitorStack.isVideo) ? (monitorStack.wpPath || "") : ""
                                        sourceSize.width: monitorCard.width * 2
                                        sourceSize.height: monitorCard.height * 2
                                        cache: true
                                    }

                                    // Video first-frame (frozen)
                                    StyledImage {
                                        visible: monitorStack.isVideo
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: {
                                            const ff = Wallpapers.videoFirstFrames[monitorStack.wpPath]
                                            return ff ? (ff.startsWith("file://") ? ff : "file://" + ff) : ""
                                        }
                                        cache: true
                                        Component.onCompleted: Wallpapers.ensureVideoFirstFrame(monitorStack.wpPath)
                                    }

                                    // GIF
                                    AnimatedImage {
                                        visible: monitorStack.isGif
                                        anchors.fill: parent
                                        fillMode: Image.PreserveAspectCrop
                                        source: {
                                            if (!monitorStack.isGif || !monitorStack.wpPath) return ""
                                            const p = monitorStack.wpPath
                                            return p.startsWith("file://") ? p : "file://" + p
                                        }
                                        asynchronous: true
                                        cache: true
                                        playing: false
                                    }

                                    // Media type badge
                                    Rectangle {
                                        visible: monitorStack.isVideo || monitorStack.isGif
                                        anchors.top: parent.top
                                        anchors.left: parent.left
                                        anchors.margins: Appearance.sizes.spacingSmall
                                        width: mediaBadgeRow.implicitWidth + Appearance.sizes.spacingSmall * 2
                                        height: mediaBadgeRow.implicitHeight + 4
                                        radius: height / 2
                                        color: Qt.rgba(0, 0, 0, 0.65)
                                        Row {
                                            id: mediaBadgeRow
                                            anchors.centerIn: parent
                                            spacing: 3
                                            MaterialSymbol {
                                                text: monitorStack.isVideo ? "movie" : "gif"
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                color: "white"
                                                anchors.verticalCenter: parent.verticalCenter
                                            }
                                            StyledText {
                                                text: WallpaperListener.mediaTypeLabel(monitorStack.wpPath)
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                color: "white"
                                                anchors.verticalCenter: parent.verticalCenter
                                            }
                                        }
                                    }

                                    // Bottom gradient with monitor name
                                    Rectangle {
                                        anchors.bottom: parent.bottom
                                        anchors.left: parent.left
                                        anchors.right: parent.right
                                        height: Math.max(monitorLabelCol.implicitHeight + 14, parent.height * 0.45)
                                        gradient: Gradient {
                                            GradientStop { position: 0.0; color: "transparent" }
                                            GradientStop { position: 0.55; color: Qt.rgba(0, 0, 0, 0.35) }
                                            GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.8) }
                                        }
                                        ColumnLayout {
                                            id: monitorLabelCol
                                            anchors.bottom: parent.bottom
                                            anchors.horizontalCenter: parent.horizontalCenter
                                            anchors.bottomMargin: Appearance.sizes.spacingSmall
                                            spacing: 0
                                            StyledText {
                                                Layout.alignment: Qt.AlignHCenter
                                                text: monitorStack.monName || ("Monitor " + (monitorStack.index + 1))
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                font.weight: Font.Medium
                                                color: "white"
                                            }
                                            StyledText {
                                                Layout.alignment: Qt.AlignHCenter
                                                text: monitorStack.modelData.width + "\u00d7" + monitorStack.modelData.height
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                                color: Qt.rgba(1, 1, 1, 0.6)
                                            }
                                        }
                                    }

                                    // Selected check badge
                                    Rectangle {
                                        visible: monitorStack.isSelected && !monitorStack.showingBackdrop
                                        anchors.top: parent.top
                                        anchors.right: parent.right
                                        anchors.margins: Appearance.sizes.spacingSmall
                                        width: Appearance.font.pixelSize.normal + 2
                                        height: width
                                        radius: width / 2
                                        color: Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colPrimary
                                        MaterialSymbol {
                                            anchors.centerIn: parent
                                            text: "check"
                                            font.pixelSize: Appearance.font.pixelSize.small
                                            color: Appearance.inirEverywhere ? Appearance.inir.colOnPrimary : Appearance.colors.colOnPrimary
                                        }
                                    }

                                    // Custom wallpaper dot
                                    Rectangle {
                                        visible: (monitorStack.wpData.hasCustomWallpaper ?? false) && !monitorStack.isSelected
                                        anchors.top: parent.top
                                        anchors.right: parent.right
                                        anchors.margins: 6
                                        width: 8; height: 8
                                        radius: 4
                                        color: Appearance.colors.colTertiary
                                    }

                                    // Selection border overlay (on top of image)
                                    Rectangle {
                                        anchors.fill: parent
                                        radius: parent.radius
                                        color: "transparent"
                                        border.width: monitorStack.isSelected ? 2 : 0
                                        border.color: Appearance.colors.colPrimary
                                        Behavior on border.width {
                                            enabled: Appearance.animationsEnabled
                                            animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Split preview showing all monitors
                Rectangle {
                    id: splitPreviewCard
                    Layout.fillWidth: true
                    implicitHeight: splitPreviewCol.implicitHeight
                    radius: Appearance.rounding.normal
                    color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                         : Appearance.inirEverywhere ? Appearance.inir.colLayer1
                         : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                         : Appearance.colors.colLayer1
                    border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                        : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
                    border.color: Appearance.angelEverywhere ? (Appearance.angel?.colCardBorder ?? Appearance.colors.colLayer0Border)
                               : Appearance.inirEverywhere ? (Appearance.inir?.colBorder ?? Appearance.colors.colLayer0Border)
                               : Appearance.colors.colLayer0Border
                    clip: true

                    ColumnLayout {
                        id: splitPreviewCol
                        anchors { left: parent.left; right: parent.right }
                        spacing: 0

                        // Split preview row — all monitors side by side
                        Item {
                            Layout.fillWidth: true
                            Layout.preferredHeight: 190
                            clip: true

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: Appearance.sizes.spacingSmall
                                spacing: Appearance.sizes.spacingSmall

                                Repeater {
                                    model: Quickshell.screens

                                    Rectangle {
                                        id: splitMonCard
                                        required property var modelData
                                        required property int index

                                        readonly property string monName: WallpaperListener.getMonitorName(modelData) ?? ""
                                        readonly property var wpData: WallpaperListener.effectivePerMonitor[monName] ?? { path: "" }
                                        readonly property string wpPath: wpData.path || (Config.options?.background?.wallpaperPath ?? "")
                                        readonly property bool isSelected: monName === multiMonitorPanel.selectedMonitor
                                        readonly property bool isGif: WallpaperListener.isGifPath(wpPath)
                                        readonly property bool isVideo: WallpaperListener.isVideoPath(wpPath)
                                        readonly property real aspectRatio: modelData.width / Math.max(1, modelData.height)

                                        onWpPathChanged: if (isVideo) Wallpapers.ensureVideoFirstFrame(wpPath)

                                        Layout.fillHeight: true
                                        Layout.preferredWidth: height * aspectRatio
                                        Layout.fillWidth: true

                                        radius: Appearance.rounding.small
                                        color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                                             : Appearance.inirEverywhere ? Appearance.inir.colLayer1
                                             : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                                             : Appearance.colors.colLayer1
                                        border.width: splitMonCard.isSelected
                                            ? (Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth : Appearance.inirEverywhere ? 1 : 2) : (Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth : Appearance.inirEverywhere ? 1 : 0)
                                        border.color: splitMonCard.isSelected
                                            ? (Appearance.angelEverywhere ? Appearance.angel.colPrimary : Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colPrimary)
                                            : (Appearance.angelEverywhere ? Appearance.angel.colCardBorder : Appearance.inirEverywhere ? Appearance.inir.colBorder : "transparent")
                                        clip: true

                                        scale: splitMonCard.isSelected ? 1.0 : 0.95
                                        opacity: splitMonCard.isSelected ? 1.0 : 0.75
                                        Behavior on scale {
                                            enabled: Appearance.animationsEnabled
                                            animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                        }
                                        Behavior on opacity {
                                            enabled: Appearance.animationsEnabled
                                            animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                        }

                                        MouseArea {
                                            anchors.fill: parent
                                            cursorShape: Qt.PointingHandCursor
                                            hoverEnabled: true
                                            onClicked: multiMonitorPanel.selectedMonitor = splitMonCard.monName
                                        }

                                        // Static image
                                        StyledImage {
                                            visible: !splitMonCard.isGif && !splitMonCard.isVideo
                                            anchors.fill: parent
                                            fillMode: Image.PreserveAspectCrop
                                            source: (!splitMonCard.isGif && !splitMonCard.isVideo) ? (splitMonCard.wpPath || "") : ""
                                            sourceSize.width: splitMonCard.width * 2
                                            sourceSize.height: splitMonCard.height * 2
                                            cache: true
                                            layer.enabled: true
                                            layer.smooth: true
                                            layer.effect: OpacityMask {
                                                maskSource: Rectangle {
                                                    width: splitMonCard.width
                                                    height: splitMonCard.height
                                                    radius: splitMonCard.radius
                                                }
                                            }
                                        }

                                        // GIF
                                        AnimatedImage {
                                            visible: splitMonCard.isGif
                                            anchors.fill: parent
                                            fillMode: Image.PreserveAspectCrop
                                            source: {
                                                if (!splitMonCard.isGif || !splitMonCard.wpPath) return ""
                                                const p = splitMonCard.wpPath
                                                return p.startsWith("file://") ? p : "file://" + p
                                            }
                                            asynchronous: true
                                            cache: true
                                            playing: false
                                            layer.enabled: true
                                            layer.smooth: true
                                            layer.effect: OpacityMask {
                                                maskSource: Rectangle {
                                                    width: splitMonCard.width
                                                    height: splitMonCard.height
                                                    radius: splitMonCard.radius
                                                }
                                            }
                                        }

                                        // Video first-frame (frozen)
                                        StyledImage {
                                            visible: splitMonCard.isVideo
                                            anchors.fill: parent
                                            fillMode: Image.PreserveAspectCrop
                                            source: {
                                                const ff = Wallpapers.videoFirstFrames[splitMonCard.wpPath]
                                                return ff ? (ff.startsWith("file://") ? ff : "file://" + ff) : ""
                                            }
                                            cache: true
                                            layer.enabled: true
                                            layer.smooth: true
                                            layer.effect: OpacityMask {
                                                maskSource: Rectangle {
                                                    width: splitMonCard.width
                                                    height: splitMonCard.height
                                                    radius: splitMonCard.radius
                                                }
                                            }
                                            Component.onCompleted: Wallpapers.ensureVideoFirstFrame(splitMonCard.wpPath)
                                        }

                                        // Bottom gradient overlay with monitor name
                                        Rectangle {
                                            anchors.bottom: parent.bottom
                                            anchors.left: parent.left
                                            anchors.right: parent.right
                                            height: Math.max(splitMonLabel.implicitHeight + 12, parent.height * 0.4)
                                            gradient: Gradient {
                                                GradientStop { position: 0.0; color: "transparent" }
                                                GradientStop { position: 0.5; color: Qt.rgba(0, 0, 0, 0.35) }
                                                GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.75) }
                                            }

                                            ColumnLayout {
                                                id: splitMonLabel
                                                anchors.bottom: parent.bottom
                                                anchors.horizontalCenter: parent.horizontalCenter
                                                anchors.bottomMargin: Appearance.sizes.spacingSmall
                                                spacing: 0
                                                StyledText {
                                                    Layout.alignment: Qt.AlignHCenter
                                                    text: splitMonCard.monName || ("Monitor " + (splitMonCard.index + 1))
                                                    font.pixelSize: Appearance.font.pixelSize.smaller
                                                    font.weight: Font.Medium
                                                    color: "white"
                                                }
                                                StyledText {
                                                    Layout.alignment: Qt.AlignHCenter
                                                    text: {
                                                        const custom = splitMonCard.wpData.hasCustomWallpaper ?? false
                                                        return custom ? Translation.tr("Custom") : Translation.tr("Global")
                                                    }
                                                    font.pixelSize: Appearance.font.pixelSize.smaller
                                                    color: Qt.rgba(1, 1, 1, 0.6)
                                                }
                                            }
                                        }

                                        // Selected indicator
                                        Rectangle {
                                            visible: splitMonCard.isSelected
                                            anchors.top: parent.top
                                            anchors.right: parent.right
                                            anchors.margins: Appearance.sizes.spacingSmall
                                            width: Appearance.font.pixelSize.normal + 2
                                            height: width
                                            radius: width / 2
                                            color: Appearance.inirEverywhere ? Appearance.inir.colAccent : Appearance.colors.colPrimary
                                            MaterialSymbol {
                                                anchors.centerIn: parent
                                                text: "check"
                                                font.pixelSize: Appearance.font.pixelSize.small
                                                color: Appearance.inirEverywhere ? Appearance.inir.colOnPrimary : Appearance.colors.colOnPrimary
                                            }
                                        }

                                        // Media badge
                                        Rectangle {
                                            visible: splitMonCard.isVideo || splitMonCard.isGif
                                            anchors.top: parent.top
                                            anchors.left: parent.left
                                            anchors.margins: Appearance.sizes.spacingSmall
                                            width: splitBadgeRow.implicitWidth + Appearance.sizes.spacingSmall * 2
                                            height: splitBadgeRow.implicitHeight + 4
                                            radius: height / 2
                                            color: Qt.rgba(0, 0, 0, 0.65)
                                            Row {
                                                id: splitBadgeRow
                                                anchors.centerIn: parent
                                                spacing: 3
                                                MaterialSymbol {
                                                    text: splitMonCard.isVideo ? "movie" : "gif"
                                                    font.pixelSize: Appearance.font.pixelSize.smaller
                                                    color: "white"
                                                    anchors.verticalCenter: parent.verticalCenter
                                                }
                                                StyledText {
                                                    text: WallpaperListener.mediaTypeLabel(splitMonCard.wpPath)
                                                    font.pixelSize: Appearance.font.pixelSize.smaller
                                                    color: "white"
                                                    anchors.verticalCenter: parent.verticalCenter
                                                }
                                            }
                                        }

                                        // Selection border overlay (on top of image)
                                        Rectangle {
                                            anchors.fill: parent
                                            radius: parent.radius
                                            color: "transparent"
                                            border.width: splitMonCard.isSelected ? 2 : 0
                                            border.color: Appearance.colors.colPrimary
                                            Behavior on border.width {
                                                enabled: Appearance.animationsEnabled
                                                animation: NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Controls section for selected monitor
                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.margins: 12
                            Layout.topMargin: 10
                            Layout.bottomMargin: 12
                            spacing: Appearance.sizes.spacingSmall

                            // Wallpaper path
                            StyledText {
                                Layout.fillWidth: true
                                elide: Text.ElideMiddle
                                font.pixelSize: Appearance.font.pixelSize.smaller
                                color: Appearance.colors.colSubtext
                                opacity: 0.7
                                text: multiMonitorPanel.selMonPath ? FileUtils.trimFileProtocol(multiMonitorPanel.selMonPath) : Translation.tr("No wallpaper set")
                            }

                            // Primary action row: Change (wide) + Random + Reset
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Appearance.sizes.spacingSmall

                                RippleButtonWithIcon {
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: 3
                                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                                    materialIcon: "wallpaper"
                                    mainText: Translation.tr("Change")
                                    colBackground: Appearance.zzzEverywhere ? Appearance.zzz.sticker : Appearance.colors.colPrimaryContainer
                                    colBackgroundHover: Appearance.zzzEverywhere ? Appearance.colors.colPrimaryHover : Appearance.colors.colPrimaryContainerHover
                                    colRipple: Appearance.zzzEverywhere ? Appearance.colors.colPrimaryActive : Appearance.colors.colPrimaryContainerActive
                                    mainContentComponent: Component {
                                        StyledText {
                                            text: Translation.tr("Change")
                                            font.pixelSize: Appearance.font.pixelSize.small
                                            color: Appearance.zzzEverywhere ? Appearance.zzz.onSticker : Appearance.colors.colOnPrimaryContainer
                                            Behavior on color {
                                                enabled: Appearance.animationsEnabled
                                                ColorAnimation { duration: Appearance.animation.elementMoveFast.duration }
                                            }
                                        }
                                    }
                                    onClicked: {
                                        const mon = multiMonitorPanel.selectedMonitor
                                        if (mon) {
                                            Config.setNestedValue("wallpaperSelector.selectionTarget", "main")
                                            Config.setNestedValue("wallpaperSelector.targetMonitor", mon)
                                            Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "wallpaperSelector", "toggle"])
                                        }
                                    }
                                }
                                RippleButtonWithIcon {
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: 2
                                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                                    materialIcon: "shuffle"
                                    mainText: Translation.tr("Random")
                                    onClicked: {
                                        const mon = multiMonitorPanel.selectedMonitor
                                        if (mon) {
                                            Wallpapers.randomFromCurrentFolder(Appearance.m3colors.darkmode, mon)
                                        }
                                    }
                                    StyledToolTip {
                                        text: Translation.tr("Set a random wallpaper from the current folder for this monitor")
                                    }
                                }
                                RippleButtonWithIcon {
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: 2
                                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                                    materialIcon: "restart_alt"
                                    mainText: Translation.tr("Reset")
                                    onClicked: {
                                        const mon = multiMonitorPanel.selectedMonitor
                                        if (!mon) return
                                        const globalPath = Config.options?.background?.wallpaperPath ?? ""
                                        if (globalPath) {
                                            Wallpapers.select(globalPath, Appearance.m3colors.darkmode, mon)
                                        }
                                    }
                                    StyledToolTip {
                                        text: Translation.tr("Reset this monitor to use the global wallpaper")
                                    }
                                }
                            }

                            // Secondary row: Apply all + Change backdrop
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Appearance.sizes.spacingSmall

                                RippleButtonWithIcon {
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: 1
                                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                                    materialIcon: "select_all"
                                    mainText: Translation.tr("Apply to all")
                                    onClicked: {
                                        const globalPath = Config.options?.background?.wallpaperPath ?? ""
                                        if (globalPath) {
                                            Wallpapers.apply(globalPath, Appearance.m3colors.darkmode)
                                        }
                                    }
                                    StyledToolTip {
                                        text: Translation.tr("Apply the global wallpaper to all monitors")
                                    }
                                }
                                RippleButtonWithIcon {
                                    Layout.fillWidth: true
                                    Layout.preferredWidth: 1
                                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                                    materialIcon: "blur_on"
                                    mainText: Translation.tr("Change backdrop")
                                    visible: multiMonitorPanel.backdropEnabled
                                    onClicked: {
                                        Config.setNestedValue("wallpaperSelector.selectionTarget", "backdrop")
                                        Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "wallpaperSelector", "toggle"])
                                    }
                                    StyledToolTip {
                                        text: Translation.tr("Change the backdrop wallpaper (used for overview/blur)")
                                    }
                                }
                            }

                            // Derive theme colors from backdrop
                            ConfigSwitch {
                                visible: multiMonitorPanel.backdropEnabled
                                buttonIcon: "palette"
                                text: Translation.tr("Derive theme colors from backdrop")
                                checked: Config.options?.appearance?.wallpaperTheming?.useBackdropForColors ?? false
                                onCheckedChanged: {
                                    Config.setNestedValue("appearance.wallpaperTheming.useBackdropForColors", checked)
                                    // Always regenerate — script reads useBackdropForColors from config
                                    colorRegenTimer.restart()
                                }
                            }
                        }
                    }
                }

                // Info bar
                RowLayout {
                    Layout.fillWidth: true
                    Layout.topMargin: 2
                    spacing: 4

                    MaterialSymbol {
                        text: "info"
                        font.pixelSize: Appearance.font.pixelSize.smaller
                        color: Appearance.colors.colSubtext
                        opacity: 0.5
                    }
                    StyledText {
                        Layout.fillWidth: true
                        font.pixelSize: Appearance.font.pixelSize.smaller - 1
                        color: Appearance.colors.colSubtext
                        opacity: 0.5
                        text: Translation.tr("%1 monitors detected").arg(WallpaperListener.screenCount) + "  ·  " + Translation.tr("Ctrl+Alt+T targets focused output")
                        wrapMode: Text.WordWrap
                    }
                }
            }
        }
    }
        }
    }

    SettingsTaskLoader {
        requested: root.activeSection === "screen"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "screen"
        expanded: true
        icon: "screenshot_monitor"
        title: Translation.tr("Bar & screen")

        SettingsGroup {
            ConfigRow {
                ContentSubsection {
                    title: Translation.tr("Bar position")
                    ConfigSelectionArray {
                        currentValue: ((Config.options?.material?.bar?.bottom ?? false) ? 1 : 0) | ((Config.options?.material?.bar?.vertical ?? false) ? 2 : 0)
                        onSelected: newValue => {
                            Config.setNestedValue("material.bar.bottom", (newValue & 1) !== 0)
                            Config.setNestedValue("material.bar.vertical", (newValue & 2) !== 0)
                        }
                        options: [
                            {
                                displayName: Translation.tr("Top"),
                                icon: "arrow_upward",
                                value: 0 // bottom: false, vertical: false
                            },
                            {
                                displayName: Translation.tr("Left"),
                                icon: "arrow_back",
                                value: 2 // bottom: false, vertical: true
                            },
                            {
                                displayName: Translation.tr("Bottom"),
                                icon: "arrow_downward",
                                value: 1 // bottom: true, vertical: false
                            },
                            {
                                displayName: Translation.tr("Right"),
                                icon: "arrow_forward",
                                value: 3 // bottom: true, vertical: true
                            }
                        ]
                    }
                }
                ContentSubsection {
                    title: Translation.tr("Bar style")

                    ConfigSelectionArray {
                        currentValue: Config.options?.material?.bar?.cornerStyle ?? 0
                        onSelected: newValue => {
                            // HUG mode (0) is incompatible with Angel style — revert to Float
                            if (newValue === 0 && Appearance.angelEverywhere) {
                                Config.setNestedValue("material.bar.cornerStyle", 1);
                                return;
                            }
                            Config.setNestedValue("material.bar.cornerStyle", newValue);
                        }
                        options: [
                            {
                                displayName: Translation.tr("Hug"),
                                icon: "line_curve",
                                previewKind: "hug",
                                value: 0
                            },
                            {
                                displayName: Translation.tr("Float"),
                                icon: "page_header",
                                previewKind: "float",
                                value: 1
                            },
                            {
                                displayName: Translation.tr("Rect"),
                                icon: "toolbar",
                                previewKind: "rect",
                                value: 2
                            },
                            {
                                displayName: Translation.tr("Card"),
                                icon: "branding_watermark",
                                previewKind: "card",
                                value: 3
                            }
                        ]
                    }
                }
            }

            ConfigRow {
                ContentSubsection {
                    title: Translation.tr("Screen round corner")

                    ConfigSelectionArray {
                        currentValue: Config.options?.appearance?.fakeScreenRounding ?? 0
                        onSelected: newValue => {
                            Config.setNestedValue("appearance.fakeScreenRounding", newValue)
                        }
                        options: [
                            {
                                displayName: Translation.tr("No"),
                                icon: "close",
                                value: 0
                            },
                            {
                                displayName: Translation.tr("Yes"),
                                icon: "check",
                                value: 1
                            },
                            {
                                displayName: Translation.tr("When not fullscreen"),
                                icon: "fullscreen_exit",
                                value: 2
                            }
                        ]
                    }
                }

                ContentSubsection {
                    title: Translation.tr("Wallpaper mode")

                    ConfigSelectionArray {
                        currentValue: Config.options?.background?.backdrop?.hideWallpaper ? 1 : 0
                        onSelected: newValue => {
                            Config.setNestedValue("background.backdrop.hideWallpaper", newValue === 1);
                        }
                        options: [
                            {
                                displayName: Translation.tr("Normal"),
                                icon: "image",
                                value: 0
                            },
                            {
                                displayName: Translation.tr("Backdrop only"),
                                icon: "blur_on",
                                value: 1
                            }
                        ]
                    }

                }
            }
        }
    }
        }
    }

    SettingsTaskLoader {
        requested: root.activeSection === "game"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "game"
        expanded: true
        icon: "sports_esports"
        title: Translation.tr("Game Mode")

        SettingsGroup {
            SettingsSwitch {
                buttonIcon: "fullscreen"
                text: Translation.tr("Auto-detect fullscreen")
                checked: Config.options?.gameMode?.autoDetect ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.autoDetect", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Automatically enable Game Mode when apps go fullscreen")
                }
            }

            SettingsSwitch {
                buttonIcon: "animation"
                text: Translation.tr("Disable animations")
                checked: Config.options?.gameMode?.disableAnimations ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableAnimations", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Turn off UI animations when Game Mode is active")
                }
            }

            SettingsSwitch {
                buttonIcon: "blur_on"
                text: Translation.tr("Disable effects")
                checked: Config.options?.gameMode?.disableEffects ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableEffects", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Turn off blur and shadows when Game Mode is active")
                }
            }

            SettingsSwitch {
                buttonIcon: "graphic_eq"
                text: Translation.tr("Disable audio visualizers")
                checked: Config.options?.gameMode?.disableVisualizers ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableVisualizers", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Stop Cava and hide audio visualizers while Game Mode is active")
                }
            }

            SettingsSwitch {
                buttonIcon: "desktop_windows"
                text: Translation.tr("Disable Niri animations")
                checked: Config.options?.gameMode?.disableNiriAnimations ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableNiriAnimations", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Turn off compositor animations when Game Mode is active")
                }
            }

            SettingsSwitch {
                visible: GameMode.discoverOverlayInstalled
                buttonIcon: "visibility_off"
                text: Translation.tr("Disable Discover overlay")
                checked: Config.options?.gameMode?.disableDiscoverOverlay ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableDiscoverOverlay", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Stop discover-overlay while Game Mode is active")
                }
            }

            SettingsSwitch {
                buttonIcon: "density_small"
                text: Translation.tr("Minimal mode")
                checked: Config.options?.gameMode?.minimalMode ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.minimalMode", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Make panels transparent and hide backgrounds for maximum performance")
                }
            }

            SettingsSwitch {
                buttonIcon: "notifications_off"
                text: Translation.tr("Suppress notifications")
                checked: Config.options?.gameMode?.suppressNotifications ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.suppressNotifications", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Hide notification popups while Game Mode is active")
                }
            }
        }
    }
        }
    }

    SettingsTaskLoader {
        requested: root.activeSection === "capture"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "capture"
        expanded: true
        icon: "photo_camera"
        title: Translation.tr("Capture locations")

        SettingsGroup {
            NoticeBox {
                Layout.fillWidth: true
                materialIcon: "folder"
                text: Translation.tr("Recordings and iNiR screenshots can use different folders. These paths are also available in Tools for detailed capture settings.")
            }

            ContentSubsection {
                title: Translation.tr("Recordings")

                StyledText {
                    Layout.fillWidth: true
                    text: Directories.shortHomePath(root.effectiveRecordingPath)
                    color: Appearance.colors.colOnLayer1
                    elide: Text.ElideMiddle
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Appearance.sizes.spacingSmall

                    RippleButtonWithIcon {
                        Layout.fillWidth: true
                        materialIcon: "folder_open"
                        mainText: Translation.tr("Open folder")
                        onClicked: ShellExec.openDirectory(root.effectiveRecordingPath, Translation.tr("Open recordings folder"))
                    }

                    RippleButtonWithIcon {
                        Layout.fillWidth: true
                        materialIcon: "drive_file_move"
                        mainText: Translation.tr("Change folder")
                        onClicked: root.openCaptureFolderDialog("recordings")
                    }
                }
            }

            ContentSubsection {
                title: Translation.tr("Screenshots")

                StyledText {
                    Layout.fillWidth: true
                    text: Directories.shortHomePath(root.effectiveScreenshotPath)
                    color: Appearance.colors.colOnLayer1
                    elide: Text.ElideMiddle
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: Appearance.sizes.spacingSmall

                    RippleButtonWithIcon {
                        Layout.fillWidth: true
                        materialIcon: "folder_open"
                        mainText: Translation.tr("Open folder")
                        onClicked: ShellExec.openDirectory(root.effectiveScreenshotPath, Translation.tr("Open screenshots folder"))
                    }

                    RippleButtonWithIcon {
                        Layout.fillWidth: true
                        materialIcon: "drive_file_move"
                        mainText: Translation.tr("Change folder")
                        onClicked: root.openCaptureFolderDialog("screenshots")
                    }
                }
            }
        }
    }
        }
    }

    SettingsTaskLoader {
        requested: root.activeSection === "filters"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "filters"
        expanded: true
        icon: "filter_alt"
        title: Translation.tr("App filters")

        SettingsGroup {
            ContentSubsection {
                title: ""

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    MaterialShapeWrappedMaterialSymbol {
                        shape: MaterialShape.Shape.ClamShell
                        text: "notifications_off"
                        iconSize: Appearance.font.pixelSize.large
                        implicitSize: 44
                        color: M3Palette.primaryContainer
                        colSymbol: M3Palette.primary
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1

                        StyledText {
                            text: Translation.tr("Notifications")
                            color: M3Palette.surfaceForeground
                            font.pixelSize: Appearance.font.pixelSize.normal
                            font.weight: Font.DemiBold
                        }
                        StyledText {
                            Layout.fillWidth: true
                            text: Translation.tr("iNiR learns senders from notification history. Block an app here and it is rejected before history, sound, counters and popups.")
                            color: M3Palette.surfaceVariantForeground
                            font.pixelSize: Appearance.font.pixelSize.smaller
                            wrapMode: Text.WordWrap
                        }
                    }
                }

                Flow {
                    Layout.fillWidth: true
                    spacing: 6
                    visible: (Config.options?.notifications?.blockedApps ?? []).length > 0

                    Repeater {
                        model: Config.options?.notifications?.blockedApps ?? []

                        InputChip {
                            required property string modelData
                            text: modelData
                            chipIcon: "notifications_off"
                            onRemoved: root._setAppMembership(
                                "notifications.blockedApps",
                                Config.options?.notifications?.blockedApps ?? [],
                                modelData, false)
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: notifCandidateColumn.implicitHeight
                    radius: Appearance.rounding.normal
                    color: "transparent"

                    ColumnLayout {
                        id: notifCandidateColumn
                        anchors.fill: parent
                        spacing: 6

                        RowLayout {
                            Layout.fillWidth: true
                            Layout.leftMargin: 4
                            Layout.rightMargin: 4

                            StyledText {
                                Layout.fillWidth: true
                                text: root.notificationFilterCandidates.length > 0
                                    ? Translation.tr("Recent notification senders")
                                    : Translation.tr("No notification senders detected yet")
                                color: Appearance.colors.colSubtext
                                font.pixelSize: Appearance.font.pixelSize.smaller
                            }
                            StyledText {
                                visible: root.notificationFilterCandidates.length > 0
                                text: Translation.tr("%1 found").arg(root.notificationFilterCandidates.length)
                                color: Appearance.colors.colSubtext
                                font.pixelSize: Appearance.font.pixelSize.smaller
                            }
                        }

                        Repeater {
                            model: root.notificationFilterCandidates

                            Rectangle {
                                required property var modelData
                                Layout.fillWidth: true
                                implicitHeight: 60
                                radius: Appearance.rounding.normal + 2
                                color: modelData.selected
                                    ? ColorUtils.mix(M3Palette.surfaceContainer, M3Palette.primaryContainer, 0.68)
                                    : notifHover.hovered
                                        ? M3Palette.surfaceContainerHigh
                                        : M3Palette.surfaceContainer
                                border.width: modelData.selected ? 1 : 0
                                border.color: modelData.selected
                                    ? ColorUtils.transparentize(M3Palette.primary, 0.55)
                                    : "transparent"

                                Behavior on color {
                                    enabled: Appearance.animationsEnabled
                                    ColorAnimation { duration: Appearance.animation.elementMoveFast.duration }
                                }

                                HoverHandler { id: notifHover }

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 12
                                    anchors.rightMargin: 12
                                    spacing: 12

                                    Rectangle {
                                        Layout.preferredWidth: 40
                                        Layout.preferredHeight: 40
                                        radius: Appearance.rounding.full
                                        color: modelData.selected
                                            ? M3Palette.primaryContainer
                                            : M3Palette.secondaryContainer

                                        Image {
                                            anchors.centerIn: parent
                                            width: 24; height: 24
                                            source: Quickshell.iconPath(modelData.icon, "application-x-executable")
                                            sourceSize.width: 46; sourceSize.height: 46
                                            fillMode: Image.PreserveAspectFit
                                        }
                                    }

                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 0
                                        StyledText {
                                            Layout.fillWidth: true
                                            text: modelData.label
                                            color: modelData.selected
                                                ? M3Palette.primaryContainerForeground
                                                : M3Palette.surfaceForeground
                                            font.pixelSize: Appearance.font.pixelSize.normal
                                            font.weight: modelData.selected ? Font.DemiBold : Font.Medium
                                            elide: Text.ElideRight
                                        }
                                        RowLayout {
                                            spacing: 4
                                            MaterialSymbol {
                                                text: modelData.selected ? "block" : "check_circle"
                                                iconSize: 13
                                            color: modelData.selected
                                                ? M3Palette.primaryContainerForeground
                                                : M3Palette.surfaceVariantForeground
                                            }
                                            StyledText {
                                                text: modelData.selected
                                                    ? Translation.tr("Blocked")
                                                    : Translation.tr("Allowed")
                                            color: modelData.selected
                                                ? M3Palette.primaryContainerForeground
                                                : M3Palette.surfaceVariantForeground
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                            }
                                        }
                                    }

                                    StyledSwitch {
                                        checked: modelData.selected
                                        onToggled: root._setAppMembership(
                                            "notifications.blockedApps",
                                            Config.options?.notifications?.blockedApps ?? [],
                                            modelData.key, checked)
                                    }
                                }
                            }
                        }
                    }
                }

                SettingsFold {
                    glyph: "add"
                    text: Translation.tr("App not listed?")
                    open: root.showManualNotificationFilter
                    onClicked: {
                        root.showManualNotificationFilter = !root.showManualNotificationFilter
                        if (root.showManualNotificationFilter)
                            notificationManualApp.forceActiveFocus()
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6
                    visible: root.showManualNotificationFilter

                    MaterialTextField {
                        id: notificationManualApp
                        Layout.fillWidth: true
                        placeholderText: Translation.tr("Exact app or service name")
                    }
                    RippleButtonWithIcon {
                        materialIcon: "add"
                        mainText: Translation.tr("Add")
                        enabled: notificationManualApp.text.trim().length > 0
                        onClicked: {
                            root._setAppMembership("notifications.blockedApps",
                                Config.options?.notifications?.blockedApps ?? [],
                                notificationManualApp.text, true)
                            notificationManualApp.text = ""
                            root.showManualNotificationFilter = false
                        }
                    }
                }
            }

            ContentSubsection {
                title: ""

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 10

                    MaterialShapeWrappedMaterialSymbol {
                        shape: MaterialShape.Shape.Clover4Leaf
                        text: "graphic_eq"
                        iconSize: Appearance.font.pixelSize.large
                        implicitSize: 44
                        color: M3Palette.secondaryContainer
                        colSymbol: M3Palette.secondaryContainerForeground
                    }

                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        StyledText {
                            text: Translation.tr("Visualizer sources")
                            color: M3Palette.surfaceForeground
                            font.pixelSize: Appearance.font.pixelSize.normal
                            font.weight: Font.DemiBold
                        }
                        StyledText {
                            Layout.fillWidth: true
                            text: Translation.tr("Audio apps are detected live from PipeWire. Enable a filter to exclude that app from visualizers; with no filters enabled, iNiR follows the active player automatically.")
                            color: M3Palette.surfaceVariantForeground
                            font.pixelSize: Appearance.font.pixelSize.smaller
                            wrapMode: Text.WordWrap
                        }
                    }
                }

                Flow {
                    Layout.fillWidth: true
                    spacing: 6
                    visible: (Config.options?.appearance?.cava?.blockedApps ?? []).length > 0

                    Repeater {
                        model: Config.options?.appearance?.cava?.blockedApps ?? []

                        InputChip {
                            required property string modelData
                            text: modelData
                            chipIcon: "graphic_eq"
                            onRemoved: root._setAppMembership(
                                "appearance.cava.blockedApps",
                                Config.options?.appearance?.cava?.blockedApps ?? [],
                                modelData, false)
                        }
                    }
                }

                Rectangle {
                    Layout.fillWidth: true
                    implicitHeight: vizCandidateColumn.implicitHeight
                    radius: Appearance.rounding.normal
                    color: "transparent"

                    ColumnLayout {
                        id: vizCandidateColumn
                        anchors.fill: parent
                        spacing: 6

                        RowLayout {
                            Layout.fillWidth: true
                            Layout.leftMargin: 4
                            Layout.rightMargin: 4
                            StyledText {
                                Layout.fillWidth: true
                                text: root.visualizerFilterCandidates.length > 0
                                    ? Translation.tr("Detected audio apps")
                                    : Translation.tr("Play audio in an app and it will appear here")
                                color: Appearance.colors.colSubtext
                                font.pixelSize: Appearance.font.pixelSize.smaller
                            }
                            StyledText {
                                visible: root.visualizerFilterCandidates.length > 0
                                text: Translation.tr("Live")
                                color: Appearance.colors.colPrimary
                                font.pixelSize: Appearance.font.pixelSize.smaller
                            }
                        }

                        Repeater {
                            model: root.visualizerFilterCandidates

                            Rectangle {
                                required property var modelData
                                Layout.fillWidth: true
                                implicitHeight: 60
                                radius: Appearance.rounding.normal + 2
                                color: modelData.selected
                                    ? ColorUtils.mix(M3Palette.surfaceContainer, M3Palette.secondaryContainer, 0.68)
                                    : vizHover.hovered
                                        ? M3Palette.surfaceContainerHigh
                                        : M3Palette.surfaceContainer
                                border.width: modelData.selected ? 1 : 0
                                border.color: modelData.selected
                                    ? ColorUtils.transparentize(M3Palette.secondaryContainerForeground, 0.65)
                                    : "transparent"

                                Behavior on color {
                                    enabled: Appearance.animationsEnabled
                                    ColorAnimation { duration: Appearance.animation.elementMoveFast.duration }
                                }

                                HoverHandler { id: vizHover }

                                Rectangle {
                                    visible: modelData.active
                                    anchors.left: parent.left
                                    anchors.leftMargin: 4
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: 4
                                    height: 28
                                    radius: 2
                                    color: M3Palette.primary
                                }

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 12
                                    anchors.rightMargin: 12
                                    spacing: 12

                                    Rectangle {
                                        Layout.preferredWidth: 40
                                        Layout.preferredHeight: 40
                                        radius: Appearance.rounding.full
                                        color: modelData.active
                                            ? M3Palette.primaryContainer
                                            : modelData.selected
                                                ? M3Palette.secondaryContainer
                                                : M3Palette.secondaryContainer
                                        Image {
                                            anchors.centerIn: parent
                                            width: 24; height: 24
                                            source: Quickshell.iconPath(modelData.icon, "application-x-executable")
                                            sourceSize.width: 46; sourceSize.height: 46
                                            fillMode: Image.PreserveAspectFit
                                        }
                                    }

                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 0
                                        StyledText {
                                            Layout.fillWidth: true
                                            text: modelData.label
                                            color: modelData.selected
                                                ? M3Palette.secondaryContainerForeground
                                                : M3Palette.surfaceForeground
                                            font.pixelSize: Appearance.font.pixelSize.normal
                                            font.weight: modelData.selected ? Font.DemiBold : Font.Medium
                                            elide: Text.ElideRight
                                        }
                                        RowLayout {
                                            spacing: 4
                                            MaterialSymbol {
                                                text: modelData.selected ? "filter_alt"
                                                    : modelData.active ? "graphic_eq" : "radio_button_checked"
                                                iconSize: 13
                                                color: modelData.selected ? M3Palette.secondaryContainerForeground
                                                    : modelData.active ? M3Palette.primary
                                                    : M3Palette.surfaceVariantForeground
                                            }
                                            StyledText {
                                                text: modelData.selected
                                                    ? Translation.tr("Filtered out")
                                                    : modelData.active
                                                        ? Translation.tr("Playing now")
                                                        : modelData.detected
                                                            ? Translation.tr("Detected")
                                                            : Translation.tr("Saved source")
                                                color: modelData.selected ? M3Palette.secondaryContainerForeground
                                                    : modelData.active ? M3Palette.primary
                                                    : M3Palette.surfaceVariantForeground
                                                font.pixelSize: Appearance.font.pixelSize.smaller
                                            }
                                        }
                                    }

                                    StyledSwitch {
                                        checked: modelData.selected
                                        onToggled: root._setAppMembership(
                                            "appearance.cava.blockedApps",
                                            Config.options?.appearance?.cava?.blockedApps ?? [],
                                            modelData.key, checked)
                                    }
                                }
                            }
                        }
                    }
                }

                SettingsFold {
                    glyph: "add"
                    text: Translation.tr("Audio app not listed?")
                    open: root.showManualVisualizerFilter
                    onClicked: {
                        root.showManualVisualizerFilter = !root.showManualVisualizerFilter
                        if (root.showManualVisualizerFilter)
                            visualizerManualApp.forceActiveFocus()
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 6
                    visible: root.showManualVisualizerFilter
                    MaterialTextField {
                        id: visualizerManualApp
                        Layout.fillWidth: true
                        placeholderText: Translation.tr("Exact process, app ID or service name")
                    }
                    RippleButtonWithIcon {
                        materialIcon: "add"
                        mainText: Translation.tr("Add")
                        enabled: visualizerManualApp.text.trim().length > 0
                        onClicked: {
                            root._setAppMembership("appearance.cava.blockedApps",
                                Config.options?.appearance?.cava?.blockedApps ?? [],
                                visualizerManualApp.text, true)
                            visualizerManualApp.text = ""
                            root.showManualVisualizerFilter = false
                        }
                    }
                }
            }
        }
    }
        }
    }

    // Quick Actions
    SettingsTaskLoader {
        requested: root.activeSection === "actions"
        sourceComponent: Component {
    SettingsCardSection {
        settingsTaskSection: "actions"
        expanded: true
        icon: "bolt"
        title: Translation.tr("Quick Actions")

        SettingsGroup {
            RowLayout {
                Layout.fillWidth: true
                spacing: Appearance.sizes.spacingSmall

                RippleButtonWithIcon {
                    Layout.fillWidth: true
                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                    materialIcon: "refresh"
                    mainText: Translation.tr("Reload shell")
                    onClicked: Quickshell.execDetached(["bash", Quickshell.shellPath("scripts/restart-shell.sh")])
                }

                RippleButtonWithIcon {
                    Layout.fillWidth: true
                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                    materialIcon: "terminal"
                    mainText: Translation.tr("Open config")
                    onClicked: Qt.openUrlExternally(`${Directories.config}/illogical-impulse/config.json`)
                }

                RippleButtonWithIcon {
                    Layout.fillWidth: true
                    buttonRadius: Appearance.zzzEverywhere ? Appearance.zzz.controlRadius : Appearance.rounding.small
                    materialIcon: "keyboard"
                    mainText: Translation.tr("Shortcuts")
                    onClicked: Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "cheatsheet", "toggle"])
                }
            }

            SettingsSwitch {
                buttonIcon: "notifications_active"
                text: Translation.tr("Show reload toasts")
                checked: Config.options?.reloadToasts?.enable ?? true
                onCheckedChanged: Config.setNestedValue("reloadToasts.enable", checked)
                StyledToolTip {
                    text: Translation.tr("Show toast notifications when Quickshell or Niri config reloads.\nErrors are always shown.")
                }
            }

            SettingsSwitch {
                buttonIcon: "sports_esports"
                text: Translation.tr("Hide reload toasts in Game Mode")
                checked: Config.options?.gameMode?.disableReloadToasts ?? true
                onCheckedChanged: {
                    Config.setNestedValue("gameMode.disableReloadToasts", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Automatically suppress reload toasts when Game Mode is active")
                }
            }

            SettingsSwitch {
                visible: CompositorService.isNiri
                buttonIcon: "help"
                text: Translation.tr("Confirm before closing windows")
                checked: Config.options?.closeConfirm?.enabled ?? false
                onCheckedChanged: {
                    Config.setNestedValue("closeConfirm.enabled", checked)
                }
                StyledToolTip {
                    text: Translation.tr("Show a confirmation dialog when closing windows with Super+Q")
                }
            }
        }
    }
        }
    }

}
