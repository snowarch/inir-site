import qs.modules.common
import qs.modules.common.widgets
import QtQuick
import QtQuick.Controls as QQC
import QtQuick.Controls.Material
import QtQuick.Controls

/**
 * Material 3 styled TextArea (filled style)
 * https://m3.material.io/components/text-fields/overview
 */
TextArea {
    cursorDelegate: TextCursor {}
    id: root
    QQC.ContextMenu.menu: null
    QQC.ContextMenu.onRequested: position => TextEditMenu.open(root, position)
    Material.theme: Material.System
    Material.accent: Appearance.regaliaEverywhere ? "transparent" : Appearance.colors.colPrimary
    Material.primary: Appearance.colors.colPrimary
    Material.background: Appearance.regaliaEverywhere ? "transparent" : Appearance.colors.colLayer1
    Material.foreground: Appearance.regaliaEverywhere ? Appearance.regalia.onColor : Appearance.colors.colOnSurface
    Material.containerStyle: Material.Filled
    renderType: Text.QtRendering

    // Integración con buscador global de Settings
    property bool enableSettingsSearch: true
    property int settingsSearchOptionId: -1

    function _findSettingsContext() {
        var page = null;
        var sectionTitle = "";
        var groupTitle = "";
        var p = root.parent;
        while (p) {
            if (!page && p.hasOwnProperty("settingsPageIndex")) {
                page = p;
            }
            if (p.hasOwnProperty("title")) {
                if (!sectionTitle && p.hasOwnProperty("icon")) {
                    sectionTitle = p.title;
                } else if (!groupTitle && !p.hasOwnProperty("icon")) {
                    groupTitle = p.title;
                }
            }
            p = p.parent;
        }
        return { page: page, sectionTitle: sectionTitle, groupTitle: groupTitle };
    }

    function focusFromSettingsSearch() {
        // Expand parent CollapsibleSection if collapsed
        var p = root.parent;
        while (p) {
            if (p.hasOwnProperty("expanded") && p.hasOwnProperty("collapsible")) {
                p.expanded = true;
                break;
            }
            p = p.parent;
        }
        root.forceActiveFocus();
    }

    Component.onCompleted: {
        if (!enableSettingsSearch)
            return;
        if (typeof SettingsSearchRegistry === "undefined")
            return;
        if (!SettingsSearchRegistry.dynamicRegistrationEnabled)
            return;

        var ctx = _findSettingsContext();
        var page = ctx.page;
        var sectionTitle = ctx.sectionTitle;
        var label = root.placeholderText || ctx.groupTitle || sectionTitle;

        settingsSearchOptionId = SettingsSearchRegistry.registerOption({
            control: root,
            pageIndex: page && page.settingsPageIndex !== undefined ? page.settingsPageIndex : -1,
            pageName: page && page.settingsPageName ? page.settingsPageName : "",
            section: sectionTitle,
            label: label,
            description: "",
            keywords: []
        });
    }

    Component.onDestruction: {
        if (typeof SettingsSearchRegistry !== "undefined") {
            SettingsSearchRegistry.unregisterControl(root);
        }
    }

    selectedTextColor: Appearance.regaliaEverywhere ? Appearance.regalia.primaryPlateInk : Appearance.colors.colOnSecondaryContainer
    selectionColor: Appearance.regaliaEverywhere ? Appearance.regalia.primaryPlate : Appearance.colors.colSecondaryContainer
    placeholderTextColor: Appearance.regaliaEverywhere ? Appearance.regalia.onMuted : Appearance.colors.colOnLayer1

    background: Item {
        implicitHeight: 56

        RegaliaControlFace {
            anchors.fill: parent
            visible: Appearance.regaliaEverywhere
            fillColor: root.activeFocus
                ? Appearance.regalia.controlPlateHover
                : Appearance.regalia.controlPlate
            radius: Appearance.regalia.roundSmall
            hovered: root.hovered && !root.activeFocus
        }

        Rectangle {
            anchors.fill: parent
            visible: !Appearance.regaliaEverywhere
            color: Appearance.editorialEverywhere
                ? (root.activeFocus ? Appearance.editorial.inputFocus : root.hovered ? Appearance.editorial.inputHover : Appearance.editorial.input)
                : Appearance.colors.colLayer1
            topLeftRadius: Appearance.editorialEverywhere ? Appearance.rounding.small : 4
            topRightRadius: Appearance.editorialEverywhere ? Appearance.rounding.small : 4
            bottomLeftRadius: Appearance.editorialEverywhere ? Appearance.rounding.small : 0
            bottomRightRadius: Appearance.editorialEverywhere ? Appearance.rounding.small : 0
            border.width: Appearance.editorialEverywhere ? (root.activeFocus ? 2 : 1) : 0
            border.color: Appearance.editorialEverywhere
                ? (root.activeFocus ? Appearance.editorial.focusRing : root.hovered ? Appearance.editorial.edge : Appearance.editorial.rule) : "transparent"
            Behavior on color { enabled: Appearance.animationsEnabled; ColorAnimation { duration: Appearance.animation.elementMoveFast.duration } }
            Behavior on border.color { enabled: Appearance.animationsEnabled; ColorAnimation { duration: Appearance.animation.elementMoveFast.duration } }

            Rectangle {
                anchors {
                    left: parent.left
                    right: parent.right
                    bottom: parent.bottom
                }
                visible: !Appearance.editorialEverywhere
                height: 1
                color: root.focus ? Appearance.colors.colPrimary :
                    root.hovered ? Appearance.colors.colOutline : Appearance.colors.colOutlineVariant

                Behavior on color {
                    animation: ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
            }
        }
    }

    font {
        family: Appearance.font.family.main
        pixelSize: Appearance?.font.pixelSize.normal ?? 16
        hintingPreference: Font.PreferNoHinting
        variableAxes: Appearance.font.variableAxes.main
    }
    wrapMode: TextEdit.Wrap

    TextInputContextMenu {
        target: root
    }
}
