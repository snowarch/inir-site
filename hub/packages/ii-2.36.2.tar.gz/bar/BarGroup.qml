import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.modules.ii.pill
import QtQuick
import QtQuick.Layouts

Item {
    id: root
    readonly property alias islandSurface: islandSurface
    property bool nativeBlurActive: false
    property var screen: null
    property bool vertical: false
    property bool spectrumEnabled: false
    property var spectrumPoints: []
    property real spectrumCeiling: 1000
    property string spectrumType: "bars"
    property real spectrumOpacity: 0.35
    property real spectrumFillRatio: 0.6
    property string spectrumBarsOrigin: "bottom"
    property real spectrumDensity: 12
    property real spectrumGap: 2
    property int spectrumSmoothing: 2
    property string spectrumWaveMode: "fill"
    property real spectrumLineWidth: 2
    property real spectrumEdgeInset: 6
    property real spectrumEdgeSoftness: 0.36
    property string spectrumFrequencyProfile: "flat"
    property real spectrumAccentStrength: 0.7
    property real spectrumOrganicSensitivity: 0.32
    property real spectrumOrganicPulse: 0.42
    property real spectrumOrganicMotionSpeed: 0.8
    property real spectrumOrganicIdleMotion: 0
    property real spectrumOrganicGlow: 0.18
    property bool spectrumOrganicEdgeAura: false
    property real spectrumOrganicBaseRadius: 0.36
    property Item spectrumDomain: null
    // Islands: the capsule needs real breathing room around content (matches
    // the edge islands' inner padding); classic groups keep the tight fit and
    // bare chips (no surface of their own) don't pad like a capsule.
    property real padding: islandStyle && !bare ? 12
        : Appearance.regaliaEverywhere && !bare ? Appearance.regalia.tilePadding : 8
    readonly property bool cardStyleEverywhere: (Config.options?.material?.dock?.cardStyle ?? false) && (Config.options?.material?.sidebar?.cardStyle ?? false) && (Config.options?.material?.bar?.cornerStyle === 3)
    // Islands bar appearance: each group is its own floating surface.
    // Works in both horizontal and vertical bar modes.
    readonly property bool islandStyle: (Config.options?.material?.bar?.appearanceStyle ?? "classic") === "islands"
    // Bare: no surface of its own — for groups that live INSIDE another island
    // (e.g. the weather chip in an edge island) so cards never nest.
    property bool bare: false
    property bool clipContent: false
    readonly property bool zzzPlate: false
    implicitWidth: vertical ? Appearance.sizes.baseVerticalBarWidth : (gridLayout.implicitWidth + padding * 2)
    implicitHeight: vertical ? (gridLayout.implicitHeight + padding * 2) : Appearance.sizes.baseBarHeight
    // Natural content width regardless of any implicitWidth override, so the bar
    // can size a pill to its content without a binding loop.
    readonly property real contentWidth: gridLayout.implicitWidth + padding * 2
    // True when the group has no visible children (Qt layouts exclude
    // visible:false items, so an all-hidden zone reports ~0 inner width). Lets
    // callers collapse the pill entirely instead of showing a ghost background.
    readonly property bool empty: gridLayout.implicitWidth < 1
    readonly property real elasticSlack: {
        let slack = 0
        for (const child of gridLayout.children)
            if (child.visible && child.Layout.fillWidth && isFinite(child.Layout.maximumWidth))
                slack += Math.max(0, child.implicitWidth - child.Layout.minimumWidth)
        return slack
    }
    readonly property real minimumContentWidth: Math.max(0, contentWidth - elasticSlack)
    default property alias items: gridLayout.children

    readonly property real _spectrumX: {
        const geometryDependency = root.x + root.y + root.width + root.height
            + (root.parent?.x ?? 0) + (root.parent?.width ?? 0)
        if (!root.spectrumDomain || !(root._spectrumSpan > 0))
            return 0
        const position = root.mapToItem(root.spectrumDomain, 0, 0)
        return root.vertical ? position.y : position.x
    }
    readonly property real _spectrumSpan: root.vertical
        ? (root.spectrumDomain?.height ?? 0) : (root.spectrumDomain?.width ?? 0)
    readonly property real _spectrumStartRatio: !root.spectrumDomain
        ? 0
        : Math.max(0, Math.min(1, root._spectrumX / Math.max(1, root._spectrumSpan)))
    readonly property real _spectrumEndRatio: !root.spectrumDomain
        ? 1
        : Math.max(root._spectrumStartRatio,
            Math.min(1, (root._spectrumX + (root.vertical ? root.height : root.width)) / Math.max(1, root._spectrumSpan)))

    // El fondo de cada grupo de la barra ahora sale del molde compartido
    // (PanelSurface) en vez de dibujarse a mano. Misma pinta que antes, pero
    // controlada desde un solo lugar → cambiar PanelSurface cambia toda la barra.
    PanelSurface {
        id: background
        anchors {
            fill: parent
            topMargin: root.vertical ? 0 : 4
            bottomMargin: root.vertical ? 0 : 4
            leftMargin: root.vertical ? 4 : 0
            rightMargin: root.vertical ? 4 : 0
        }
        visible: !root.islandStyle && !root.bare
        cardStyle: root.cardStyleEverywhere
        borderless: Appearance.regaliaEverywhere ? false
            : !root.islandStyle && (Config.options?.material?.bar?.borderless ?? false)
        radiusOverride: Appearance.regaliaEverywhere ? Appearance.regalia.roundSmall : -1
        elevation: Appearance.regaliaEverywhere ? 2 : 1
        editorialGlassMaterial: Appearance.editorialEverywhere && Appearance.editorial.glassActive
        // En zzz la barra mantiene su contorno unificado; los grupos quedan transparentes.
        zzzChamfer: false
    }

    // Islands wear the Ricelin pill card in EVERY global style — picking the
    // islands bar is an explicit opt-in to that dialect, so the zzz "groups
    // stay transparent" doctrine (which left the centre groups naked over the
    // wallpaper) does not apply here.
    BarIslandSurface {
        id: islandSurface
        readonly property int inset: Config.options?.material?.bar?.islands?.inset ?? 4
        anchors {
            fill: parent
            topMargin: root.vertical ? 0 : inset
            bottomMargin: root.vertical ? 0 : inset
            leftMargin: root.vertical ? inset : 0
            rightMargin: root.vertical ? inset : 0
        }
        visible: root.islandStyle && !root.bare
        glassEnabled: true
        nativeBlurActive: root.nativeBlurActive
        screen: root.screen
        compactShadow: !root.vertical

        AudioVisualizerLayer {
            anchors.centerIn: parent
            width: root.vertical && root.spectrumType !== "organic"
                ? islandSurface.height : islandSurface.width
            height: root.vertical && root.spectrumType !== "organic"
                ? islandSurface.width : islandSurface.height
            rotation: root.vertical && root.spectrumType !== "organic" ? 90 : 0
            active: root.spectrumEnabled && islandSurface.visible
            threadedRendering: true
            points: active ? root.spectrumPoints : []
            normalizationCeiling: active ? root.spectrumCeiling : 100
            visualizerType: root.spectrumType
            spectrumOpacity: root.spectrumOpacity
            fillRatio: root.spectrumFillRatio
            spectrumColor: Appearance.colors.colPrimary
            sampleStartRatio: root._spectrumStartRatio
            sampleEndRatio: root._spectrumEndRatio
            barsOrigin: root.spectrumBarsOrigin
            pixelsPerBar: root.spectrumDensity
            barSpacing: root.spectrumGap
            smoothing: root.spectrumSmoothing
            waveMode: root.spectrumWaveMode
            lineWidth: root.spectrumLineWidth
            edgeInset: root.spectrumEdgeInset
            edgeSoftness: root.spectrumEdgeSoftness
            frequencyProfile: root.spectrumFrequencyProfile
            accentStrength: root.spectrumAccentStrength
            organicSensitivity: root.spectrumOrganicSensitivity
            organicPulse: root.spectrumOrganicPulse
            organicMotionSpeed: root.spectrumOrganicMotionSpeed
            organicIdleMotion: root.spectrumOrganicIdleMotion
            organicGlow: root.spectrumOrganicGlow
            organicOpacity: root.spectrumOpacity
            organicEdgeAura: root.spectrumOrganicEdgeAura
            organicBaseRadius: root.spectrumOrganicBaseRadius
            topLeftRadius: islandSurface.radius
            topRightRadius: islandSurface.radius
            bottomLeftRadius: islandSurface.radius
            bottomRightRadius: islandSurface.radius
        }
    }

    Item {
        anchors.fill: parent
        clip: root.clipContent

        GridLayout {
            id: gridLayout
            columns: root.vertical ? 1 : -1
            // A group held narrower than its content lays it out in that width, so elastic modules
            // (media) give way before anything is clipped; only past that does it overflow, centred.
            width: root.vertical ? implicitWidth
                : Math.min(implicitWidth, Math.max(implicitWidth - root.elasticSlack, parent.width - root.padding * 2))
            anchors {
                verticalCenter: root.vertical ? undefined : parent.verticalCenter
                horizontalCenter: parent.horizontalCenter
                top: root.vertical ? parent.top : undefined
                bottom: root.vertical ? parent.bottom : undefined
                margins: root.padding
            }
            columnSpacing: 4
            rowSpacing: 12
        }
    }
}
