pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.modules.ii.sidebarRight

PanelSurface {
    id: root
    islandSkin: (Config.options?.material?.controlPanel?.style ?? "panel") === "island"
    Layout.fillWidth: true
    implicitHeight: slidersRow.implicitHeight + 12
    readonly property bool compactMode: Config.options?.material?.controlPanel?.compactMode ?? true

    readonly property bool inirEverywhere: Appearance.inirEverywhere
    readonly property bool auroraEverywhere: Appearance.auroraEverywhere

    property var screen: root.QsWindow.window?.screen ?? null
    property var brightnessMonitor: screen ? Brightness.getMonitorForScreen(screen) : null
    onVisibleChanged: if (visible) root.brightnessMonitor?.refresh()

    elevation: 1
    radiusOverride: islandSkin ? -1
        : inirEverywhere ? Appearance.inir.roundingNormal
        : Appearance.zzzEverywhere ? Appearance.zzz.panelRadius
        : Appearance.rounding.normal

    AngelPartialBorder { targetRadius: root.radiusOverride; coverage: 0.45; visible: Appearance.angelEverywhere && !root.islandSkin }

    QuickSliders {
        id: slidersRow
        anchors.fill: parent
        compactSurface: true
    }
}
