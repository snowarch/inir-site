import qs
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.services
import qs.services.deferred
import QtQuick
import Quickshell

AndroidQuickToggleButton {
    id: root
    
    name: Translation.tr("EasyEffects")

    toggled: EasyEffects.active
    buttonIcon: "graphic_eq"

    Component.onCompleted: {
        EasyEffects.fetchActiveState()
    }

    mainAction: () => {
        EasyEffects.toggle()
    }

    altAction: () => {
        ShellExec.execFishOrBashOneLiner(
            "flatpak run com.github.wwmm.easyeffects; or easyeffects",
            "flatpak run com.github.wwmm.easyeffects || easyeffects"
        )
        GlobalStates.sidebarRightOpen = false
    }

    StyledToolTip {
        text: Translation.tr("EasyEffects | Right-click to configure")
    }
}

