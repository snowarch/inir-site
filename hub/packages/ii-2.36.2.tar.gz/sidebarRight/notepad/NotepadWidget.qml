import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.services
import QtQuick
import QtQuick.Controls as QQC
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Io

Item {
    id: root
    property int margin: 10

    // Style tokens (5-style support)
    readonly property color colText: Appearance.angelEverywhere ? Appearance.angel.colText
        : Appearance.inirEverywhere ? Appearance.inir.colText : Appearance.colors.colOnLayer1
    readonly property color colTextSecondary: Appearance.angelEverywhere ? Appearance.angel.colTextSecondary
        : Appearance.inirEverywhere ? Appearance.inir.colTextSecondary : Appearance.colors.colSubtext
    readonly property color colCard: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
        : Appearance.inirEverywhere ? Appearance.inir.colLayer0
        : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
        : Appearance.colors.colLayer0
    readonly property color colBorder: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
        : Appearance.inirEverywhere ? Appearance.inir.colBorder : Appearance.colors.colLayer0Border
    readonly property int borderWidth: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
        : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
    readonly property real radius: Appearance.angelEverywhere ? Appearance.angel.roundingNormal
        : Appearance.inirEverywhere ? Appearance.inir.roundingNormal : Appearance.rounding.normal
    readonly property color colPrimary: Appearance.angelEverywhere ? Appearance.angel.colPrimary
        : Appearance.inirEverywhere ? Appearance.inir.colPrimary : Appearance.colors.colPrimary

    // Word count helper
    readonly property int wordCount: textArea.text.trim().length > 0
        ? textArea.text.trim().split(/\s+/).length : 0
    readonly property int tabCount: Notepad.tabs.length

    // When this widget gets focus (from BottomWidgetGroup.focusActiveItem),
    // move focus to the internal text area on the next event loop tick.
    onFocusChanged: (focus) => {
        if (focus) {
            Qt.callLater(() => textArea.forceActiveFocus())
        }
    }

    // Guards programmatic text loads (tab switch / external reload) so they
    // don't trigger the save timer and clobber the freshly-loaded tab.
    property bool _loadingTab: false

    function _loadActiveTab() {
        root._loadingTab = true
        textArea.text = Notepad.text
        root._loadingTab = false
    }

    // The TextArea.text binding to Notepad.text breaks the moment the user
    // types, so tab switches (currentTab change) and external reloads must be
    // reflected manually — otherwise the old tab's text leaks into the new tab.
    Connections {
        target: Notepad
        function onCurrentTabChanged() { root._loadActiveTab() }
        function onTabsChanged() {
            if (textArea.text !== Notepad.text) root._loadActiveTab()
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: root.margin
        spacing: 6

        // Header with title and stats
        RowLayout {
            Layout.fillWidth: true
            spacing: 8

            StyledText {
                text: Translation.tr("Notepad")
                font.pixelSize: Appearance.font.pixelSize.larger
                font.weight: Font.Medium
                color: root.colText
            }

            Item { Layout.fillWidth: true }

            // Stats badge
            Rectangle {
                scale: textArea.text.length > 0 ? 1 : 0
                visible: scale > 0
                Behavior on scale {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
                implicitWidth: statsRow.implicitWidth + 12
                implicitHeight: 22
                radius: 11
                color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                    : Appearance.inirEverywhere ? Appearance.inir.colLayer1
                    : Appearance.colors.colSecondaryContainer

                RowLayout {
                    id: statsRow
                    anchors.centerIn: parent
                    spacing: 6

                    StyledText {
                        text: root.wordCount + " " + (root.wordCount === 1 ? Translation.tr("word") : Translation.tr("words"))
                        font.pixelSize: Appearance.font.pixelSize.smallest
                        font.family: Appearance.font.family.numbers
                        color: Appearance.angelEverywhere ? Appearance.angel.colText
                            : Appearance.inirEverywhere ? Appearance.inir.colText
                            : Appearance.colors.colOnSecondaryContainer
                    }
                }
            }
        }

        // Tab bar
        RowLayout {
            Layout.fillWidth: true
            spacing: 4
            visible: root.tabCount > 1 || root.tabCount === 1 // Always show for discoverability

            Flickable {
                Layout.fillWidth: true
                implicitHeight: 28
                contentWidth: tabRow.implicitWidth
                clip: true
                boundsBehavior: Flickable.StopAtBounds

                Row {
                    id: tabRow
                    spacing: 4

                    Repeater {
                        model: Notepad.tabs
                        delegate: Rectangle {
                            id: tabPill
                            required property var modelData
                            required property int index
                            readonly property bool active: index === Notepad.currentTab
                            width: tabLabel.implicitWidth + (tabCount > 1 ? closeBtn.width + 16 : 16)
                            height: 26
                            radius: 13
                            color: active
                                ? (Appearance.angelEverywhere ? Appearance.angel.colPrimary
                                    : Appearance.inirEverywhere ? Appearance.inir.colPrimary
                                    : Appearance.colors.colPrimary)
                                : (tabMA.containsMouse
                                    ? (Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                                        : Appearance.inirEverywhere ? Appearance.inir.colLayer1Hover
                                        : Appearance.colLayer1Hover)
                                    : "transparent")
                            Behavior on color { enabled: Appearance.animationsEnabled; ColorAnimation { duration: Appearance.animation.elementMoveFast.duration } }

                            Row {
                                anchors.centerIn: parent
                                spacing: 4

                                StyledText {
                                    id: tabLabel
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: modelData.title || `Note ${index + 1}`
                                    font.pixelSize: Appearance.font.pixelSize.smaller
                                    font.weight: tabPill.active ? Font.Medium : Font.Normal
                                    color: tabPill.active
                                        ? (Appearance.angelEverywhere ? Appearance.angel.colOnPrimary
                                            : Appearance.inirEverywhere ? Appearance.inir.colOnPrimary
                                            : Appearance.colors.colOnPrimary)
                                        : root.colTextSecondary
                                    elide: Text.ElideRight
                                    maximumLineCount: 1
                                    width: Math.min(implicitWidth, 80)
                                }

                                // Close button (only when multiple tabs)
                                MaterialSymbol {
                                    id: closeBtn
                                    opacity: tabCount > 1 ? 1 : 0
                                    visible: opacity > 0
                                    Behavior on opacity {
                                        enabled: Appearance.animationsEnabled
                                        NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                                    }
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: "close"
                                    iconSize: 12
                                    color: tabPill.active
                                        ? (Appearance.angelEverywhere ? Appearance.angel.colOnPrimary
                                            : Appearance.inirEverywhere ? Appearance.inir.colOnPrimary
                                            : Appearance.colors.colOnPrimary)
                                        : root.colTextSecondary

                                    MouseArea {
                                        anchors.fill: parent
                                        anchors.margins: -4
                                        onClicked: Notepad.removeTab(tabPill.index)
                                    }
                                }
                            }

                            MouseArea {
                                id: tabMA
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                z: -1
                                onClicked: Notepad.switchTab(tabPill.index)
                            }
                        }
                    }
                }
            }

            // Add tab button
            NotepadToolButton {
                icon: "add"
                tooltipText: Translation.tr("New tab")
                onClicked: Notepad.addTab()
            }
        }

        // Toolbar
        RowLayout {
            Layout.fillWidth: true
            spacing: 4

            NotepadToolButton {
                icon: "content_copy"
                tooltipText: Translation.tr("Copy all")
                enabled: textArea.text.length > 0
                onClicked: {
                    Quickshell.execDetached(["wl-copy", textArea.text])
                    copiedToast.show()
                }
            }

            NotepadToolButton {
                icon: "content_paste"
                tooltipText: Translation.tr("Paste from clipboard")
                onClicked: clipboardProc.running = true
            }

            NotepadToolButton {
                icon: "select_all"
                tooltipText: Translation.tr("Select all")
                enabled: textArea.text.length > 0
                onClicked: textArea.selectAll()
            }

            Item { Layout.fillWidth: true }

            NotepadToolButton {
                icon: "delete"
                tooltipText: Translation.tr("Clear all")
                enabled: textArea.text.length > 0
                destructive: true
                onClicked: {
                    textArea.text = ""
                    Notepad.setTextValue("")
                }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            radius: Appearance.angelEverywhere ? Appearance.angel.roundingNormal : Appearance.rounding.normal
            color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                : Appearance.inirEverywhere ? Appearance.inir.colLayer0
                : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurface
                : Appearance.colors.colLayer0
            border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth
                : Appearance.inirEverywhere ? 1 : (Appearance.auroraEverywhere ? 0 : 1)
            border.color: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
                : Appearance.inirEverywhere ? Appearance.inir.colBorder : Appearance.colors.colLayer0Border
            clip: true

            ScrollView {
                id: scrollView
                anchors.fill: parent
                anchors.margins: 8
                ScrollBar.vertical.policy: ScrollBar.AsNeeded
                ScrollBar.horizontal.policy: ScrollBar.AlwaysOff

                TextArea {
                    cursorDelegate: TextCursor {}
                    id: textArea
                    QQC.ContextMenu.menu: null
                    QQC.ContextMenu.onRequested: position => TextEditMenu.open(textArea, position)
                    width: scrollView.availableWidth
                    wrapMode: TextArea.Wrap
                    renderType: Text.NativeRendering
                    font.pixelSize: Appearance.inirEverywhere ? Appearance.font.pixelSize.smaller : Appearance.font.pixelSize.small
                    color: Appearance.inirEverywhere ? Appearance.inir.colText : Appearance.colors.colOnLayer0
                    selectionColor: Appearance.angelEverywhere ? Appearance.angel.colPrimary
                        : Appearance.inirEverywhere ? Appearance.inir.colPrimary
                        : Appearance.colors.colSecondaryContainer
                    selectedTextColor: Appearance.angelEverywhere ? Appearance.angel.colOnPrimary
                        : Appearance.inirEverywhere ? Appearance.inir.colOnPrimary
                        : Appearance.colors.colOnSecondaryContainer
                    placeholderText: Translation.tr("Write your notes here...")
                    placeholderTextColor: Appearance.inirEverywhere ? Appearance.inir.colTextSecondary : Appearance.colors.colOutline
                    Component.onCompleted: text = Notepad.text
                    selectByMouse: true
                    persistentSelection: true
                    activeFocusOnTab: true
                    background: null

                    TextInputContextMenu {
                        target: textArea
                    }

                    Keys.onPressed: (event) => {
                        if ((event.modifiers & Qt.ControlModifier) && event.key === Qt.Key_S) {
                            Notepad.setTextValue(textArea.text)
                            event.accepted = true
                        }
                    }

                    onTextChanged: {
                        if (root._loadingTab) return
                        saveTimer.restart()
                    }

                    onCursorRectangleChanged: {
                        scrollView.ScrollBar.vertical.position = Math.max(0, Math.min(
                            (cursorRectangle.y - scrollView.height / 2) / contentHeight,
                            1 - scrollView.height / contentHeight
                        ))
                    }
                }
            }
        }
    }

    Timer {
        id: saveTimer
        interval: 800
        repeat: false
        onTriggered: {
            Notepad.setTextValue(textArea.text)
        }
    }

    // Clipboard paste process
    Process {
        id: clipboardProc
        command: ["wl-paste", "-n"]
        running: false
        stdout: SplitParser {
            splitMarker: ""
            onRead: data => {
                if (data && data.length > 0) {
                    const cursorPos = textArea.cursorPosition
                    textArea.insert(cursorPos, data)
                }
            }
        }
    }

    // Copied toast notification
    Rectangle {
        id: copiedToast
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 20
        implicitWidth: toastContent.implicitWidth + 20
        implicitHeight: 32
        radius: 16
        color: root.colPrimary
        opacity: 0
        visible: opacity > 0

        function show() {
            opacity = 1
            toastTimer.restart()
        }

        Behavior on opacity {
            enabled: Appearance.animationsEnabled
            NumberAnimation { duration: Appearance.animation.elementMoveFast.duration }
        }

        RowLayout {
            id: toastContent
            anchors.centerIn: parent
            spacing: 6

            MaterialSymbol {
                text: "check"
                iconSize: 14
                color: Appearance.angelEverywhere ? Appearance.angel.colOnPrimary
                    : Appearance.inirEverywhere ? Appearance.inir.colOnPrimary
                    : Appearance.colors.colOnPrimary
            }

            StyledText {
                text: Translation.tr("Copied!")
                font.pixelSize: Appearance.font.pixelSize.smaller
                color: Appearance.angelEverywhere ? Appearance.angel.colOnPrimary
                    : Appearance.inirEverywhere ? Appearance.inir.colOnPrimary
                    : Appearance.colors.colOnPrimary
            }
        }

        Timer {
            id: toastTimer
            interval: 1500
            onTriggered: copiedToast.opacity = 0
        }
    }

    // Toolbar button component
    component NotepadToolButton: Item {
        id: toolBtn
        required property string icon
        property string tooltipText: ""
        property bool destructive: false

        signal clicked()

        implicitWidth: 32
        implicitHeight: 28

        opacity: enabled ? 1 : 0.4

        Rectangle {
            anchors.fill: parent
            radius: Appearance.angelEverywhere ? Appearance.angel.roundingSmall
                : Appearance.inirEverywhere ? Appearance.inir.roundingSmall : Appearance.rounding.small
            color: {
                if (!toolBtn.enabled) return "transparent"
                if (toolBtnMA.containsPress)
                    return toolBtn.destructive
                        ? ColorUtils.transparentize(Appearance.colors.colError, 0.7)
                        : (Appearance.angelEverywhere ? Appearance.angel.colGlassCardActive
                         : Appearance.inirEverywhere ? Appearance.inir.colLayer1Active
                         : Appearance.colLayer1Active)
                if (toolBtnMA.containsMouse)
                    return toolBtn.destructive
                        ? ColorUtils.transparentize(Appearance.colors.colError, 0.85)
                        : (Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                         : Appearance.inirEverywhere ? Appearance.inir.colLayer1Hover
                         : Appearance.colLayer1Hover)
                return "transparent"
            }
            Behavior on color { enabled: Appearance.animationsEnabled; ColorAnimation { duration: Appearance.animation.elementMoveFast.duration } }

            MaterialSymbol {
                anchors.centerIn: parent
                text: toolBtn.icon
                iconSize: 18
                color: toolBtn.destructive && toolBtn.enabled
                    ? Appearance.colors.colError
                    : root.colTextSecondary
            }

            MouseArea {
                id: toolBtnMA
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: toolBtn.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
                onClicked: if (toolBtn.enabled) toolBtn.clicked()
            }

            StyledToolTip {
                visible: toolBtnMA.containsMouse && toolBtn.tooltipText !== ""
                text: toolBtn.tooltipText
            }
        }
    }
}
