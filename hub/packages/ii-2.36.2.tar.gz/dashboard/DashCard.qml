import QtQuick
import QtQuick.Layouts
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions

/**
 * Shared card surface for dashboard widgets. Optional icon+title header;
 * children land in the inner column. Style-dispatched like the controlPanel
 * section cards.
 */
Rectangle {
    id: root
    property string title: ""
    property string icon: ""
    property string headerActionIcon: ""
    property string headerActionTooltip: ""
    signal headerAction()
    default property alias content: inner.data

    // Appearance knobs (Settings › Dashboard › Appearance)
    readonly property bool compact: (Config.options?.material?.dashboard?.appearance?.density ?? "comfortable") === "compact"
    readonly property real cardOpacity: Math.max(0.3, Math.min(1, Config.options?.material?.dashboard?.appearance?.cardOpacity ?? 1))
    readonly property bool showTitle: Config.options?.material?.dashboard?.appearance?.showCardTitles ?? true
    readonly property real pad: editorialEverywhere ? Math.round(14 * Appearance.editorial.spacing) : (compact ? 8 : 12)

    readonly property bool inirEverywhere: Appearance.inirEverywhere
    readonly property bool auroraEverywhere: Appearance.auroraEverywhere
    readonly property bool zzzEverywhere: Appearance.zzzEverywhere
    readonly property bool editorialEverywhere: Appearance.editorialEverywhere
    // Editorial "ink field": paper/ink inversion reserved for the one focal
    // card of a composition; opt-in per card.
    property bool inkField: false
    readonly property bool _inkActive: editorialEverywhere && root.inkField
    readonly property color colText: _inkActive ? Appearance.editorial.paperOnInk
        : zzzEverywhere ? Appearance.zzz.ink
        : Appearance.angelEverywhere ? Appearance.angel.colText
        : inirEverywhere ? Appearance.inir.colText
        : auroraEverywhere ? Appearance.colors.colOnSurface
        : Appearance.colors.colOnLayer1
    readonly property color colSubtext: _inkActive ? ColorUtils.applyAlpha(Appearance.editorial.paperOnInk, 0.72)
        : zzzEverywhere ? Appearance.zzz.inkMuted
        : Appearance.angelEverywhere ? Appearance.angel.colTextSecondary
        : inirEverywhere ? Appearance.inir.colTextSecondary
        : Appearance.colors.colSubtext
    readonly property color colAccent: _inkActive
        ? ColorUtils.ensureReadable(Appearance.editorial.accent, Appearance.editorial.ink, 4.5)
        : zzzEverywhere ? Appearance.zzz.accent
        : Appearance.angelEverywhere ? Appearance.angel.colPrimary
        : inirEverywhere ? Appearance.inir.colPrimary
        : auroraEverywhere ? Appearance.colors.colPrimary
        : Appearance.colors.colPrimary

    Layout.fillWidth: true
    implicitHeight: contentColumn.implicitHeight + root.pad * 2

    radius: zzzEverywhere ? Appearance.zzz.panelRadius
        : Appearance.angelEverywhere ? Appearance.angel.roundingNormal
        : inirEverywhere ? Appearance.inir.roundingNormal : Appearance.rounding.normal
    color: {
        if (_inkActive)
            return Appearance.editorial.ink
        const base = zzzEverywhere ? Appearance.zzz.paper
            : Appearance.angelEverywhere ? Appearance.angel.colGlassCard
            : inirEverywhere ? Appearance.inir.colLayer1
            : auroraEverywhere ? Appearance.aurora.colSubSurface
            : Appearance.colors.colLayer1
        return zzzEverywhere || root.cardOpacity >= 1 ? base : ColorUtils.applyAlpha(base, root.cardOpacity * base.a)
    }
    Behavior on radius {
        enabled: Appearance.animationsEnabled
        NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
    }
    Behavior on color {
        enabled: Appearance.animationsEnabled
        ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }
    border.width: Appearance.angelEverywhere ? 0
        : zzzEverywhere ? 0 : editorialEverywhere ? 0 : 1
    border.color: _inkActive ? "transparent"
        : editorialEverywhere ? Appearance.editorial.rule
        : Appearance.angelEverywhere ? "transparent"
        : zzzEverywhere ? Appearance.zzz.hairline
        : inirEverywhere ? Appearance.inir.colBorder
        : ColorUtils.applyAlpha(Appearance.colors.colOnLayer1, 0.06)
    Behavior on border.color {
        enabled: Appearance.animationsEnabled
        ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }
    Behavior on border.width {
        enabled: Appearance.animationsEnabled
        NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }

    EditorialPaperStack {
        anchors.fill: parent
        visible: root._inkActive && Appearance.editorial.paperStack
        faceColor: Appearance.editorial.ink
        radius: root.radius
    }

    AngelPartialBorder { targetRadius: root.radius; coverage: 0.45 }

    // Glassy top-edge highlight: a faint light sheen down the upper third reads
    // as a translucent pane catching light. Pure overlay, no blur FBO — zero
    // GPU cost beyond one clipped gradient. Skipped for angel (own glass system).
    Rectangle {
        anchors.fill: parent
        radius: root.radius
        visible: !Appearance.angelEverywhere && !root.zzzEverywhere && !root.editorialEverywhere
        z: 0
        gradient: Gradient {
            GradientStop { position: 0.0; color: ColorUtils.applyAlpha(Appearance.colors.colOnLayer1, 0.05) }
            GradientStop { position: 0.35; color: "transparent" }
            GradientStop { position: 1.0; color: "transparent" }
        }
    }

    // Clean ZZZ plate: surface + a single left category accent bar. No per-card
    // ghost/tape/hatch — the bold ZZZ statement lives at panel level.
    ZzzGraphicPlate {
        anchors.fill: parent
        accentColor: root.colAccent
        frameLabel: ""
        frameIndex: ""
    }

    ColumnLayout {
        id: contentColumn
        anchors.fill: parent
        anchors.margins: root.pad
        spacing: root.editorialEverywhere ? Math.round(10 * Appearance.editorial.spacing) : (root.compact ? 6 : 8)

        RowLayout {
            visible: (root.title.length > 0 && root.showTitle) || root.headerActionIcon.length > 0
            Layout.fillWidth: true
            spacing: 8

            MaterialSymbol {
                visible: root.showTitle && root.icon.length > 0 && !root.zzzEverywhere
                text: root.icon
                iconSize: Appearance.font.pixelSize.larger
                color: root.colAccent
            }
            ZzzGlyphBadge {
                visible: root.showTitle && root.icon.length > 0 && root.zzzEverywhere
                symbol: root.icon
                accentColor: root.colAccent
                inkColor: Appearance.zzz.onAccent
                badgeSize: 26
            }
            StyledText {
                Layout.fillWidth: true
                visible: root.showTitle && root.title.length > 0
                text: root.zzzEverywhere ? root.title.toUpperCase() : root.title
                font.family: root.editorialEverywhere ? Appearance.font.family.title : Appearance.font.family.main
                font.pixelSize: root.editorialEverywhere ? Appearance.font.pixelSize.larger * Appearance.editorial.titleScale : Appearance.font.pixelSize.normal
                font.weight: root.zzzEverywhere ? Font.Black : root.editorialEverywhere ? Appearance.editorial.titleWeight : Font.Medium
                color: root.colText
                elide: Text.ElideRight
            }

            RippleButton {
                visible: root.headerActionIcon.length > 0
                implicitWidth: 30
                implicitHeight: 30
                buttonRadius: root.editorialEverywhere ? Appearance.rounding.small : Appearance.rounding.full
                colBackground: "transparent"
                colBackgroundHover: ColorUtils.applyAlpha(root.colAccent, 0.10)
                colRipple: ColorUtils.applyAlpha(root.colAccent, 0.16)
                onClicked: root.headerAction()
                contentItem: MaterialSymbol {
                    anchors.centerIn: parent
                    text: root.headerActionIcon
                    iconSize: Appearance.font.pixelSize.normal
                    color: root.colAccent
                }
                StyledToolTip { text: root.headerActionTooltip }
            }
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 1
            visible: root.editorialEverywhere && root.showTitle && root.title.length > 0
            color: root._inkActive ? ColorUtils.applyAlpha(root.colText, 0.34) : Appearance.editorial.rule
        }

        ColumnLayout {
            id: inner
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: root.editorialEverywhere ? Math.round(8 * Appearance.editorial.spacing) : 8

            // Center every card's content by default. A child that explicitly
            // fills width (lists, meters, calendars, full-bleed widgets) keeps
            // doing so and owns its own internal alignment; a child that doesn't
            // fill gets centered instead of hugging the left edge.
            Component.onCompleted: {
                for (let i = 0; i < inner.children.length; i++) {
                    const c = inner.children[i]
                    if (c.Layout && c.Layout.fillWidth !== true && c.Layout.fillHeight !== true && c.Layout.alignment === 0)
                        c.Layout.alignment = Qt.AlignHCenter | Qt.AlignVCenter
                }
            }
        }
    }
}
