pragma ComponentBehavior: Bound
import QtQuick
import Quickshell
import Quickshell.Services.SystemTray
import Quickshell.Widgets
import Qt5Compat.GraphicalEffects
import qs.services
import qs.modules.ii.barM3
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.modules.common.m3

MouseArea {
    id: root
    required property SystemTrayItem item
    property bool targetMenuOpen: false
    readonly property bool tintIcon: Config.options?.material?.bar?.m3?.tray?.monochromeIcons ?? true

    signal menuOpened(qsWindow: var)
    signal menuClosed()

    hoverEnabled: true
    acceptedButtons: Qt.LeftButton | Qt.RightButton
    implicitWidth: 20
    implicitHeight: 20
    onPressed: (event) => {
        switch (event.button) {
        case Qt.LeftButton:
            item.activate();
            break;
        case Qt.RightButton:
            if (item.hasMenu)
                if (menu.active && menu.item && typeof menu.item.close === "function")
                    menu.item.close();
                else
                    menu.open();
            break;
        }
        event.accepted = true;
    }
    onEntered: {
        tooltip.text = TrayService.getTooltipForItem(root.item);
    }

    Loader {
        id: menu
        function open() {
            menu.active = true;
        }
        active: false
        sourceComponent: SysTrayMenu {
            Component.onCompleted: this.open();
            trayItemMenuHandle: root.item.menu
            trayItemId: root.item.id
            anchor {
                window: root.QsWindow.window
                item: root
                gravity: Config.options.material.bar.vertical
                    ? (Config.options.material.bar.bottom ? Edges.Left : Edges.Right)
                    : (Config.options.material.bar.bottom ? Edges.Top : Edges.Bottom)
                edges: Config.options.material.bar.vertical
                    ? (Config.options.material.bar.bottom ? Edges.Left : Edges.Right)
                    : (Config.options.material.bar.bottom ? Edges.Top : Edges.Bottom)
                adjustment: Config.options.material.bar.vertical
                    ? PopupAdjustment.SlideY
                    : PopupAdjustment.SlideX
            }
            onMenuOpened: (window) => root.menuOpened(window);
            onMenuClosed: {
                root.menuClosed();
                menu.active = false;
            }
        }
    }

    IconImage {
        id: trayIcon
        source: root.item?.icon ?? ""
        anchors.centerIn: parent
        width: parent.width
        height: parent.height
    }

    Loader {
        active: root.tintIcon
        anchors.fill: trayIcon
        sourceComponent: Item {
            Desaturate {
                id: desaturatedIcon
                visible: false
                anchors.fill: parent
                source: trayIcon
                desaturation: 0.8
            }
            ColorOverlay {
                anchors.fill: desaturatedIcon
                source: desaturatedIcon
                color: ColorUtils.transparentize(M3Palette.pillInk("sysTray"), 0.9)
            }
        }
    }

    M3ToolTip {
        id: tooltip
        extraVisibleCondition: root.containsMouse
        alternativeVisibleCondition: extraVisibleCondition
        anchorEdges: (!Config.options.material.bar.bottom && !Config.options.material.bar.vertical) ? Edges.Bottom : Edges.Top
    }

}
