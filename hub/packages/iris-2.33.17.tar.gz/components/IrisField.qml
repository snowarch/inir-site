pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.iris.style

MaterialTextField {
    id: root

    enableSettingsSearch: false
    placeholderTextColor: "transparent"
    selectionColor: IrisStyle.accentContainer
    selectedTextColor: IrisStyle.inkOnAccentContainer
    font.family: IrisStyle.fontTitle
    font.pixelSize: IrisStyle.typeHeadline
    leftPadding: 14 * IrisStyle.density
    rightPadding: 14 * IrisStyle.density
    // Material insets the background for a floating label iRiS never shows, which drops the box below its text.
    topInset: 0
    bottomInset: 0
    // One line that scrolls to the cursor: Material's field wraps, which cut a long value (a user agent) in half.
    wrapMode: TextInput.NoWrap
    // At rest a long value reads from its start, not from where the cursor was left.
    onActiveFocusChanged: if (!root.activeFocus) root.cursorPosition = 0
    onTextChanged: if (!root.activeFocus) root.cursorPosition = 0

    // At rest a value too long for the box ends in an ellipsis, as a label would; editing shows the whole line.
    readonly property bool clipped: !root.activeFocus && root.text.length > 0 && root.contentWidth > root.width - root.leftPadding - root.rightPadding + 1
    color: root.clipped ? "transparent" : IrisStyle.text

    IrisText {
        anchors.left: parent.left
        anchors.leftMargin: root.leftPadding
        anchors.right: parent.right
        anchors.rightMargin: root.rightPadding
        anchors.verticalCenter: parent.verticalCenter
        visible: root.clipped || (root.text.length === 0 && root.placeholderText.length > 0)
        text: root.clipped ? root.text : root.placeholderText
        font.family: root.font.family
        font.pixelSize: root.font.pixelSize
        color: root.clipped ? IrisStyle.text : IrisStyle.subtext
        // A path keeps its last folder, the part that says which one it is.
        elide: /^~?\//.test(text) ? Text.ElideMiddle : Text.ElideRight
    }

    background: Rectangle {
        radius: IrisStyle.radiusSmall
        color: IrisStyle.field
        border.width: root.activeFocus ? 1 : 0
        border.color: IrisStyle.hairlineStrong
    }
}
