pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Shapes
import qs.modules.iris.style

Item {
    id: root

    required property var face
    property var time: new Date()
    property bool seconds: true
    property bool numerals: true
    property bool ticks: true
    property bool disc: false
    property bool daylight: false
    property string caption: ""

    readonly property real r: Math.min(width, height) / 2
    readonly property real cx: width / 2
    readonly property real cy: height / 2
    readonly property color ink: root.disc && root.daylight ? IrisStyle.inkOnAccent : root.face.ink
    readonly property color inkQuiet: IrisStyle.tertiaryOf(root.ink)
    readonly property color hand: root.face.highlight
    readonly property real hours: (root.time.getHours() % 12) + root.time.getMinutes() / 60
    readonly property real minutes: root.time.getMinutes() + (root.seconds ? root.time.getSeconds() / 60 : 0)
    readonly property real secondsValue: root.time.getSeconds()

    function point(angle: real, radius: real): point {
        const a = angle * Math.PI / 180
        return Qt.point(root.cx + Math.sin(a) * radius, root.cy - Math.cos(a) * radius)
    }
    function segment(angle: real, from: real, to: real): var {
        return [root.point(angle, from), root.point(angle, to)]
    }
    readonly property var minorTicks: {
        const list = []
        for (let i = 0; i < 60; ++i)
            if (i % 5 !== 0)
                list.push(root.segment(i * 6, root.r * 0.9, root.r * 0.96))
        return list
    }
    readonly property var majorTicks: {
        const list = []
        for (let i = 0; i < 12; ++i)
            list.push(root.segment(i * 30, root.r * (root.numerals ? 0.86 : 0.8), root.r * 0.96))
        return list
    }

    Rectangle {
        visible: root.disc
        anchors.centerIn: parent
        width: root.r * 2
        height: width
        radius: IrisStyle.capsule(width)
        color: root.daylight ? IrisStyle.text : root.face.fill
    }

    Shape {
        anchors.fill: parent
        visible: root.ticks
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeColor: root.inkQuiet
            strokeWidth: Math.max(1, root.r * 0.014)
            capStyle: ShapePath.RoundCap
            fillColor: "transparent"
            PathMultiline { paths: root.r > 40 ? root.minorTicks : [] }
        }
        ShapePath {
            strokeColor: IrisStyle.secondaryOf(root.ink)
            strokeWidth: Math.max(1.2, root.r * 0.026)
            capStyle: ShapePath.RoundCap
            fillColor: "transparent"
            PathMultiline { paths: root.majorTicks }
        }
    }

    Repeater {
        model: root.numerals ? 12 : 0
        Text {
            required property int index
            readonly property int hour: index === 0 ? 12 : index
            readonly property point at: root.point(index * 30, root.r * 0.68)
            x: Math.round(at.x - width / 2)
            y: Math.round(at.y - height / 2)
            text: hour
            color: index % 3 === 0 ? root.ink : IrisStyle.secondaryOf(root.ink)
            font.family: root.face.fontNumbers
            font.pixelSize: Math.max(8, Math.round(root.r * 0.2))
            font.weight: IrisStyle.weight(Font.DemiBold)
            font.features: ({ "tnum": 1 })
            renderType: Text.NativeRendering
        }
    }

    // Under the 12, as Apple's dial carries its city, unless the hour hand is up there: then over the 6, so the date
    // is never under it (fixed under the 12, 10 to 2 o'clock hid it; fixed under the centre, 4 to 8).
    readonly property bool hourUp: root.hours >= 9.5 || root.hours < 2.5
    Text {
        visible: root.caption.length > 0
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(root.cy + (root.hourUp ? 0.38 : -0.38) * root.r - height / 2)
        text: root.caption
        color: IrisStyle.secondaryOf(root.ink)
        font.family: root.face.fontMain
        font.pixelSize: Math.max(8, Math.round(root.r * 0.15))
        font.weight: IrisStyle.weight(Font.DemiBold)
        renderType: Text.NativeRendering
    }

    // Hands are bars turned about the centre: a tick only rotates them (one frame), where a Shape rebuilt its
    // geometry and asked for a second frame each time, two full redraws of the desktop a second.
    component Hand: Item {
        id: hand
        property real from
        property real to
        property real thickness
        property color color
        x: root.cx
        y: root.cy
        Rectangle {
            x: -hand.thickness / 2
            y: -hand.to - hand.thickness / 2
            width: hand.thickness
            height: hand.to - hand.from + hand.thickness
            radius: width / 2
            color: hand.color
            antialiasing: true
        }
    }
    Hand { rotation: root.hours * 30; to: root.r * 0.16; thickness: Math.max(1, root.r * 0.03); color: root.ink }
    Hand { rotation: root.minutes * 6; to: root.r * 0.16; thickness: Math.max(1, root.r * 0.03); color: root.ink }
    Hand { rotation: root.hours * 30; from: root.r * 0.16; to: root.r * 0.52; thickness: Math.max(2.4, root.r * 0.085); color: root.ink }
    Hand { rotation: root.minutes * 6; from: root.r * 0.16; to: root.r * 0.8; thickness: Math.max(2, root.r * 0.065); color: root.ink }
    Hand {
        visible: root.seconds
        rotation: root.secondsValue * 6
        from: -root.r * 0.16
        to: root.r * 0.86
        thickness: Math.max(1, root.r * 0.022)
        color: root.hand
    }

    Rectangle {
        anchors.centerIn: parent
        width: Math.max(4, root.r * 0.1)
        height: width
        radius: IrisStyle.capsule(width)
        color: root.seconds ? root.hand : root.ink
        Rectangle {
            anchors.centerIn: parent
            width: Math.max(1.5, parent.width * 0.4)
            height: width
            radius: IrisStyle.capsule(width)
            color: root.disc && root.daylight ? IrisStyle.text : root.face.knockout
        }
    }
}
