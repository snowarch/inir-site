pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import qs.services
import qs.services.deferred
import qs.modules.common.widgets
import qs.modules.iris.style

IrisWidgetFace {
    id: root
    designFace: IrisDesign.skin("widgetNews")

    readonly property int capacity: root.small ? 1 : root.medium ? 2 : 4
    readonly property var stories: {
        const all = Array.from(NewsService.articles ?? [])
        if (all.length === 0)
            return []
        const start = root.widget.headlineIndex % all.length
        return all.slice(start).concat(all.slice(0, start)).slice(0, root.capacity)
    }

    ColumnLayout {
        anchors.fill: parent
        spacing: root.dp(10)

        FaceHeader {
            face: root
            Layout.fillWidth: true
            glyph: "newspaper"
            text: Translation.tr("News")
            trailing: !Network.online && root.stories.length > 0 ? Translation.tr("Offline") : ""
            tint: root.accent
        }

        // No stories: what happened, centred in the room they would fill, and a way to try again; one grey line cut
        // at the edge read like a broken widget.
        Item {
            id: blankNews
            visible: root.stories.length === 0
            readonly property bool offline: !Network.online
            readonly property bool failed: !blankNews.offline && NewsService.lastError.length > 0 && !NewsService.loading
            Layout.fillWidth: true
            Layout.fillHeight: true
            FaceBlank {
                face: root
                anchors.centerIn: parent
                width: parent.width
                glyph: blankNews.offline ? "cloud_off" : blankNews.failed ? "sync_problem" : "newspaper"
                title: blankNews.offline ? Translation.tr("Offline")
                    : blankNews.failed ? Translation.tr("Headlines didn't load") : Translation.tr("Fetching headlines…")
                detail: blankNews.offline ? Network.offlineReason : blankNews.failed ? Translation.tr("The feed did not answer") : ""
                FaceChoice {
                    visible: blankNews.failed
                    Layout.alignment: Qt.AlignHCenter
                    Layout.topMargin: root.dp(4)
                    icon: "refresh"
                    label: Translation.tr("Try again")
                    onClicked: root.widget._fetch(true)
                }
            }
        }

        GridLayout {
            id: storyGrid
            visible: root.stories.length > 0
            Layout.fillWidth: true
            Layout.fillHeight: true
            columns: root.medium ? 2 : 1
            columnSpacing: root.dp(20)
            rowSpacing: root.dp(10)

            Repeater {
                model: root.stories
                ColumnLayout {
                    id: story
                    required property var modelData
                    required property int index
                    readonly property bool lead: story.index === 0
                    readonly property bool fills: true
                    // The large face's rows share its height, the lead twice the others: a band computed from the
                    // grid's own height fed back into it and the rows folded to their source lines.
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    Layout.minimumHeight: 0
                    Layout.preferredHeight: root.large ? 0 : -1
                    Layout.verticalStretchFactor: root.large && story.lead ? 2 : 1
                    Layout.preferredWidth: 1
                    Layout.maximumWidth: Number.POSITIVE_INFINITY
                    clip: true
                    spacing: root.dp(4)

                    Rectangle {
                        visible: !story.lead && root.large
                        Layout.fillWidth: true
                        Layout.preferredHeight: 1
                        Layout.bottomMargin: root.dp(2)
                        color: root.hairline
                    }
                    RowLayout {
                        Layout.fillHeight: false
                        visible: root.widget.showMeta || storyHover.hovered
                        Layout.fillWidth: true
                        spacing: root.dp(6)
                        FaceText {
                            face: root
                            visible: root.widget.showMeta
                            Layout.fillWidth: true
                            text: String(story.modelData.source ?? "")
                            color: story.lead || root.medium ? root.accent : root.inkSecondary
                            size: 10.5
                            weight: Font.DemiBold
                        }
                        Item { Layout.fillWidth: !root.widget.showMeta }
                        FaceText {
                            face: root
                            visible: root.widget.showMeta
                            text: NewsService.formatTime(story.modelData.timestamp)
                            color: root.inkTertiary
                            size: 10
                        }
                        MaterialSymbol {
                            visible: storyHover.hovered
                            text: "open_in_new"
                            iconSize: root.px(14)
                            color: openHover.hovered ? root.accent : root.inkTertiary
                            HoverHandler { id: openHover; cursorShape: Qt.PointingHandCursor }
                            TapHandler {
                                gesturePolicy: TapHandler.WithinBounds
                                onTapped: NewsService.openArticle(story.modelData)
                            }
                            Accessible.role: Accessible.Button
                            Accessible.name: Translation.tr("Open article")
                        }
                    }
                    FaceText {
                        id: title
                        face: root
                        Layout.fillWidth: true
                        Layout.fillHeight: story.fills
                        Layout.minimumHeight: 0
                        Layout.preferredHeight: story.fills ? 0 : -1
                        text: IrisFaceData.unwidowed(String(story.modelData.title ?? ""))
                        // Medium is a two-up: both stories weigh the same, side by side.
                        size: root.medium ? 14 : story.lead ? (root.small ? 16.5 : 20) : 13
                        font.family: story.lead && !root.medium ? IrisStyle.fontTitle : root.fontMain
                        weight: root.medium ? Font.DemiBold : story.lead ? Font.Bold : Font.Medium
                        wrapMode: Text.WordWrap
                        verticalAlignment: Text.AlignTop
                        lineHeight: 1.08
                        maximumLineCount: root.medium ? 4 : !story.lead ? 2 : root.small ? 4 : 3
                        color: openHover.hovered ? root.accent : root.ink
                    }
                    HoverHandler { id: storyHover }
                }
            }
        }
    }
}
