pragma ComponentBehavior: Bound

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Services.SystemTray
import Quickshell.Wayland
import qs
import qs.services
import qs.services.deferred
import qs.modules.common
import qs.modules.iris.background
import qs.modules.iris.control
import qs.modules.iris.field
import qs.modules.iris.frame
import qs.modules.iris.stage
import qs.modules.iris.lock
import qs.modules.iris.widgets
import qs.modules.iris.dock
import qs.modules.iris.edit
import qs.modules.iris.notificationPopup
import qs.modules.iris.palette
import qs.modules.iris.orbit
import qs.modules.iris.wallpaper
import qs.modules.iris.style
import qs.modules.iris.components as IrisParts
import qs.modules.iris.pieces
import qs.modules.iris.settings
import qs.modules.iris.state

Scope {
    id: root

    readonly property var options: Config.options?.iris?.bar ?? ({})
    readonly property string edge: IrisFrame.islandEdge
    readonly property int barHeight: Math.max(32, Math.round(Number(root.options?.height ?? 42) * IrisStyle.density))
    readonly property int restMargin: Math.max(0, Math.round(Number(root.options?.margin ?? 8) * IrisStyle.density))
    readonly property int outerMargin: (root.options?.notch ?? false) ? 0 : root.restMargin
    signal islandRequested(bool expanded, string page)
    signal pieceTapRequested(string kind)
    property bool pieceTapped: false
    property string editScreen: ""
    // The update overlay is Material's; under iRiS its details live in the New iNiR card.
    Connections {
        target: ShellUpdates
        function onOverlayOpenChanged(): void {
            if (!ShellUpdates.overlayOpen) return
            ShellUpdates.closeOverlay()
            if (!ShellUpdates.hasUpdate && !ShellUpdates.isUpdating) {
                GlobalStates.openSettingsAt("about", "")
                return
            }
            IrisState.bubbleCardRequest = ""
            IrisState.bubbleCardRequest = "shellUpdate"
        }
    }
    Connections {
        target: IrisState
        function onEditChanged(): void {
            if (IrisState.edit) root.editScreen = GlobalStates.focusedScreen?.name ?? ""
        }
    }

    /// iRiS bar and Island design. Available while the iRiS bar is enabled.
    ///
    /// ```bash
    /// inir iris open
    /// inir iris page desktop
    /// inir iris toggle
    /// inir iris dock toggle
    /// inir iris card toggle
    /// inir iris bubble right top-right
    /// inir iris appBubble kitty top-right
    /// inir iris pin right
    /// inir iris status
    /// inir iris close
    /// ```
    IpcHandler {
        target: "iris"
        /// Expand the island on the focused output
        function open(): void { GlobalStates.barOpen = true; root.islandRequested(true, "") }
        /// Expand the island on a page: `media`, `activity`, `desktop`, `tray` or `tools`, or step through its
        /// navigation with `next` / `prev` (the same path as scrolling over the navigation row)
        function page(name: string): void {
            if (!["media", "activity", "desktop", "shelf", "weather", "calendar", "vitals", "tray", "tools", "next", "prev"].includes(name)) return
            GlobalStates.barOpen = true
            root.islandRequested(true, name)
        }
        /// Collapse the island
        function close(): void { root.islandRequested(false, "") }
        /// `open`, `close` or `toggle` the Island's Shelf page (open on another page counts as closed)
        function shelf(action: string): string {
            if (!["open", "close", "toggle"].includes(action)) return "shelf takes open, close or toggle"
            if (action === "close") { root.islandRequested(false, ""); return "closed" }
            GlobalStates.barOpen = true
            root.islandRequested(true, action === "toggle" ? "shelf:toggle" : "shelf")
            return action
        }
        /// Expand or collapse the island on the focused output
        function toggle(): void {
            if (IrisState.islandExpanded) root.islandRequested(false, "")
            else { GlobalStates.barOpen = true; root.islandRequested(true, "") }
        }
        /// `open`, `close` or `toggle` the media bubble's floating card, or `pin` to keep it open
        function card(action: string): void {
            if (action === "pin") {
                Config.setNestedValue("iris.player.cardPinned", !(Config.options?.iris?.player?.cardPinned ?? false))
                return
            }
            const open = IrisState.bubbleCard?.kind === "media"
            if (action === "close" || (open && action !== "open")) { IrisState.bubbleCard = null; return }
            if (open) return
            IrisState.bubbleCardRequest = ""
            IrisState.bubbleCardRequest = "media"
        }
        /// iRiS themes, each a whole redesign of the family: `list`, `apply:<id>`, `save:<name>` (what you see now
        /// becomes a theme file), `import:<path>` (a shared `.json`), `export` or `export:<id>` (prints the theme as
        /// JSON to share) and `folder` (where theme files live, `~/.config/inir/iris/themes`)
        function theme(action: string): string {
            const verb = String(action).split(":")[0]
            const arg = String(action).slice(verb.length + 1)
            switch (verb) {
            case "list":
                return IrisThemes.all.map(entry => `${entry.id}\t${entry.name}${entry.id === IrisThemes.activeId ? (IrisThemes.modified ? "  (active, changed)" : "  (active)") : ""}`).join("\n")
            case "apply": {
                const found = IrisThemes.find(arg)
                if (!found) return "Unknown theme: see `inir iris theme list`"
                IrisThemes.apply(found)
                return found.name
            }
            case "colours": {
                const found = IrisThemes.find(arg)
                if (!found) return "Unknown theme: see `inir iris theme list`"
                IrisThemes.applyColours(found)
                return found.name
            }
            case "save":
                return IrisThemes.save(arg, "")
            case "import":
                if (arg.length === 0) return "import:<path to a theme .json>"
                IrisThemes.importFile(arg)
                return "Importing into " + IrisThemes.folder
            case "export": {
                const found = arg.length > 0 ? IrisThemes.find(arg)
                    : { id: IrisThemes.activeId, name: IrisThemes.active?.name ?? "My theme", values: IrisThemes.differences(IrisThemes.current()) }
                return found ? IrisThemes.exportText(found) : "Unknown theme"
            }
            case "folder":
                return IrisThemes.folder
            default:
                return "list | apply:<id> | colours:<id> | save:<name> | import:<path> | export[:<id>] | folder"
            }
        }
        /// Open iRiS Settings on a section: `general`, `appearance`, `motion`, `bar`, `bubbles`, `dock`, `desktop`,
        /// `windows`, `sidebars`, `controlCenter`, `spotlight`, `orbit`, `notifications`, `sound`, `capture`,
        /// `display`, `keyboard`, `battery`, `gaming`, `lock`, `player`, `anime`, `sources` or `system`; add
        /// `/<group>` to open that group, e.g. `bubbles/behaviour` or `lock/security`. It also takes `next`, `prev`,
        /// `back`, `forward` (the history), `search:<words>` and `open` (the first result), and `tune:open` /
        /// `tune:close` (every Fine-tune fold on the page)
        function settings(section: string): string {
            // An area for hardware this computer lacks is not in Settings: opening it fell to General without a word.
            if (section.split("/")[0] === "battery" && !Battery.available) {
                GlobalStates.openSettingsAt("iris", "display")
                return "No battery on this computer: opened Display & Input"
            }
            GlobalStates.openSettingsAt("iris", section)
            return ""
        }
        // Closes iRiS Settings in either host (over the desktop or a window); does nothing when it is closed.
        /// Close iRiS Settings in either host, over the desktop or as a window; a bare `inir settings` is a toggle
        function settingsClose(): string {
            const was = GlobalStates.settingsOverlayOpen
            GlobalStates.settingsOverlayOpen = false
            return was ? "closed" : "already closed"
        }
        /// Place an Island bubble (`left`, `right`, `utility`) or an extra bubble (`weather`, `notifications`,
        /// `controls`, `sound`, `mic`, `tools`, `media`, `visualizer`, `tray`): a zone (`top-left`, `top-right`,
        /// `left`, `right`, `bottom-left`, `bottom-right`), `edge:<top|bottom|left|right>` with an optional
        /// `:<fraction>` along that edge (e.g. `edge:top:0.3`), `x,y` fractions of the output, `island` (slots) or
        /// `off` (extras)
        function bubble(slot: string, place: string): string {
            const extra = IrisPieces.extraIds.includes(slot)
            if (!extra && !IrisPieces.slotIds.includes(slot)) return "Unknown bubble"
            const zones = IrisPieces.zones
            const path = IrisPieces.configPath(slot)
            const updates = {}
            if ((extra && place === "off") || (!extra && place === "island")) {
                updates[path + (extra ? ".enable" : ".place")] = extra ? false : "island"
            } else if (zones.includes(place)) {
                updates[path + ".place"] = place
            } else if (/^edge:(top|bottom|left|right)(:\d*\.?\d+)?$/.test(place)) {
                const parts = place.split(":")
                updates[path + ".place"] = "edge:" + parts[1]
                const along = Math.min(1, Number(parts[2] ?? 0.5))
                updates[path + (parts[1] === "top" || parts[1] === "bottom" ? ".fx" : ".fy")] = along
            } else {
                const m = String(place).match(/^(\d*\.?\d+),(\d*\.?\d+)$/)
                if (!m) return "Unknown place: a zone, x,y fractions, or island/off"
                updates[path + ".fx"] = Math.min(1, Number(m[1]))
                updates[path + ".fy"] = Math.min(1, Number(m[2]))
                updates[path + ".place"] = "free"
            }
            if (extra && place !== "off") updates[path + ".enable"] = true
            Config.setNestedValues(updates)
            return place
        }
        /// `reveal`, `hide` or `toggle` the iRiS Dock (revealed stays until hidden or an app is chosen)
        function dock(action: string): void {
            IrisState.dockShown = action === "reveal" ? true : action === "hide" ? false : !IrisState.dockShown
        }
        /// Open a Dock app's `windows` or `menu` by app id (e.g. `kitty windows`), `pin` to keep it in the Dock or
        /// unpin it (prints which), or `<any> close`
        function dockApp(appId: string, mode: string): string {
            if (mode === "close") { IrisState.dockMenuRequest = { appId: "", mode: "close" }; IrisState.dockShown = false; return "closed" }
            if (mode === "pin") {
                TaskbarApps.togglePin(appId)
                const lower = appId.toLowerCase()
                return (Config.options?.dock?.pinnedApps ?? []).some(p => String(p).toLowerCase() === lower) ? "pinned" : "unpinned"
            }
            if (mode !== "windows" && mode !== "menu") return "Unknown mode: windows, menu, pin or close"
            IrisState.dockMenuRequest = { appId: appId, mode: mode }
            return appId
        }
        // `position` counts the Dock's icons from 1, the separator included: landing before it pins, after it unpins.
        /// Move a Dock app to a position, counting icons from 1 with the separator between pinned and open apps (e.g.
        /// `firefox 2`): before the separator pins it, after it lines it up among the open apps
        function dockMove(appId: string, position: int): string {
            const ids = IrisDockOrder.entries.map(entry => entry.appId)
            const id = appId.toLowerCase()
            if (!ids.includes(id)) return "Not in the Dock: " + ids.filter(i => i !== "SEPARATOR").join(", ")
            const rest = ids.filter(i => i !== id)
            rest.splice(Math.max(0, Math.min(rest.length, position - 1)), 0, id)
            if (!IrisDockOrder.drop(id, rest)) return "Stays where it was: a pinned app with no window has no place among the open ones"
            return rest.join(" ")
        }
        /// Carry a Dock app out as a bubble of its own (e.g. `kitty right`): a zone, `x,y` fractions of the output,
        /// or `dock` to send it back
        function appBubble(appId: string, place: string): string {
            if (appId.length === 0) return "Unknown app"
            if (place === "dock" || place === "off") { IrisPieces.removeApp(appId); return "docked" }
            if (IrisPieces.zones.includes(place)) { IrisPieces.placeApp(appId, place, 0.5, 0.5); return place }
            const m = String(place).match(/^(\d*\.?\d+),(\d*\.?\d+)$/)
            if (!m) return "Unknown place: a zone, x,y fractions, or dock"
            IrisPieces.placeApp(appId, "free", Math.min(1, Number(m[1])), Math.min(1, Number(m[2])))
            return place
        }
        // The side panels and the Control Center by their iRiS names (the same paths as sidebarLeft,
        // sidebarRight and controlPanel), for keybinds that read as what they open.
        /// `open`, `close` or `toggle` the Focus panel (the left one), and say whether it is open
        function focus(action: string): string {
            if (action === "open") GlobalStates.openSidebarLeft("")
            else if (action === "close") GlobalStates.closeSidebarLeft()
            else if (action === "toggle" || action === "") GlobalStates.toggleSidebarLeft("")
            else return "Choose open, close or toggle"
            return GlobalStates.sidebarLeftOpen ? "open" : "closed"
        }
        /// `open`, `close` or `toggle` the Today panel (the right one), and say whether it is open
        function today(action: string): string {
            if (action === "open") GlobalStates.openSidebarRight("")
            else if (action === "close") GlobalStates.closeSidebarRight()
            else if (action === "toggle" || action === "") GlobalStates.toggleSidebarRight("")
            else return "Choose open, close or toggle"
            return GlobalStates.sidebarRightOpen ? "open" : "closed"
        }
        /// `open`, `close` or `toggle` the Control Center, and say whether it is open
        function controlCenter(action: string): string {
            if (action === "open") GlobalStates.controlPanelOpen = true
            else if (action === "close") GlobalStates.controlPanelOpen = false
            else if (action === "toggle" || action === "") GlobalStates.controlPanelOpen = !GlobalStates.controlPanelOpen
            else return "Choose open, close or toggle"
            return GlobalStates.controlPanelOpen ? "open" : "closed"
        }
        /// Keep the `left` (Focus) or `right` (Today) panel open beside windows, or stop
        function pin(side: string): void {
            if (side !== "left" && side !== "right") return
            const path = "iris.sidebars." + side + ".pinned"
            Config.setNestedValue(path, !(Config.getNestedValue(path, false)))
        }
        /// How the Island sits on its edge: `island`, `left`, `right`, `full` or `menubar` (top or bottom)
        function layout(name: string): string {
            if (!["island", "left", "right", "full", "menubar", "pods"].includes(name)) return "Unknown layout: island, left, right, full, menubar or pods"
            Config.setNestedValue("iris.bar.layout", name)
            return name
        }
        /// What the menu bar lays under its items: `transparent` (on the wallpaper) or `band`
        function strip(name: string): string {
            const value = name === "transparent" ? "clear" : name
            if (!["clear", "band"].includes(value)) return "Unknown strip: transparent or band"
            Config.setNestedValue("iris.bar.strip", value)
            return value === "clear" ? "transparent" : "band"
        }
        /// Move the Island to a screen edge: `top`, `bottom`, `left` or `right` (on a side edge it rests as an
        /// upright capsule and its pages grow inward)
        function edge(name: string): string {
            if (!IrisFrame.edges.includes(name)) return "Unknown edge: top, bottom, left or right"
            Config.setNestedValue("iris.bar.position", name)
            return name
        }
        /// Move the Dock: `auto` (opposite the Island), `top`, `bottom`, `left` or `right`
        function dockEdge(name: string): string {
            if (name !== "auto" && !IrisFrame.edges.includes(name)) return "Unknown edge: auto, top, bottom, left or right"
            Config.setNestedValue("iris.dock.position", name)
            return IrisFrame.dockEdge
        }
        /// What a full-width Island carries in a zone: `start`, `center` or `end`, then kinds joined by `+`
        /// (`island`, `workspaces`, `window`, `time` or a piece kind), or `none`
        function zone(name: string, kinds: string): string {
            const path = ({ start: "iris.bar.fullStart", center: "iris.bar.fullCenter", end: "iris.bar.fullEnd" })[name]
            if (!path) return "Unknown zone: start, center or end"
            const list = String(kinds).split(/[+\s]+/).filter(kind => kind.length > 0 && kind !== "none")
            Config.setNestedValue(path, list)
            return JSON.stringify(list)
        }
        /// Turn one of the Island's own pieces on or off: `weather`, `notifications`, `controls`, `sound`, `mic`,
        /// `tools`, `media`, `visualizer` or `tray`, plus `on`, `off` or `toggle`
        function barPiece(kind: string, action: string): string {
            if (!IrisPieces.extraIds.includes(kind)) return "Unknown piece"
            const current = Array.from(Config.options?.iris?.bar?.pieces ?? [])
            const on = current.includes(kind)
            const wanted = action === "on" ? true : action === "off" ? false : !on
            if (wanted === on) return on ? "on" : "off"
            const next = current.filter(entry => entry !== kind)
            if (wanted) next.push(kind)
            Config.setNestedValue("iris.bar.pieces", next)
            return wanted ? "on" : "off"
        }
        /// Arrange the Island's desktop page in place — move, remove and add its blocks: `on`, `off` or `toggle`
        function arrange(action: string): string {
            const wanted = action === "on" ? true : action === "off" ? false : !IrisState.arrange
            if (wanted) IrisState.islandPageRequest = "desktop"
            IrisState.arrange = wanted
            return wanted ? "on" : "off"
        }
        /// Customize iRiS on the shell itself: the Island grows a capsule (Themes, Look, Pieces, undo, Done) and
        /// whatever you click (a piece, the Island, the Dock) grows its own options: `on`, `off`, `toggle`, a sheet
        /// (`themes`, `pieces`, or a Look tab: `material`, `colour`, `type`, `motion`, `bodies`, `places`,
        /// `transients`, `desktop`), `island`, `dock` or a piece to inspect (`vitals`, `left`, `app:kitty`)
        function edit(action: string): string {
            if (action.startsWith("tab:")) {
                const targets = { pieces: "pieces", look: "material", motion: "motion", layout: "island" }
                const target = targets[action.slice(4)]
                if (!target) return "Unknown tab"
                IrisState.edit = true
                IrisState.editTarget = target
                return action
            }
            if (!["on", "off", "toggle", ""].includes(action)) {
                IrisState.edit = true
                if (IrisPieces.extraIds.includes(action)) IrisState.editSelection = "extra:" + action
                else if (IrisPieces.slotIds.includes(action) || IrisPieces.isApp(action)) IrisState.editSelection = action
                else IrisState.editTarget = action
                return action
            }
            const wanted = action === "on" ? true : action === "off" ? false : !IrisState.edit
            IrisState.edit = wanted
            return wanted ? "on" : "off"
        }
        // `studio <area>` opens Studio on an area, `studio search:<words>` with a search typed.
        /// Customize as a panel beside the screen (Studio): `on`, `off`, `toggle`, an area to open it on (`material`,
        /// `colour`, `type`, `motion`, `island`, `pieces`, `bodies`, `places`, `transients`, `dock`, `desktop`,
        /// `themes`) or `search:<words>` to open it with a search typed
        function studio(action: string): string {
            if (!["on", "off", "toggle"].includes(action)) {
                IrisState.studioTarget = action
                IrisState.studioOpen = true
                return action
            }
            const wanted = action === "on" ? true : action === "off" ? false : !IrisState.studioOpen
            IrisState.studioOpen = wanted
            return wanted ? "on" : "off"
        }
        /// Melt the Island into its edge (or into the Surround band): `on`, `off` or `toggle`
        function notch(action: string): string {
            const on = Config.options?.iris?.bar?.notch ?? false
            const wanted = action === "on" ? true : action === "off" ? false : !on
            Config.setNestedValue("iris.bar.notch", wanted)
            return wanted ? "on" : "off"
        }
        /// Close the shell around the screen with a band on every edge: `on`, `off` or `toggle`
        function surround(action: string): string {
            const on = Config.options?.iris?.surround?.enable ?? false
            const wanted = action === "on" ? true : action === "off" ? false : !on
            Config.setNestedValue("iris.surround.enable", wanted)
            return wanted ? "on" : "off"
        }
        /// Set iRiS accent: `blue`, `mint`, `rose`, `lilac` or `wallpaper`
        function accent(name: string): string {
            if (!["blue", "mint", "rose", "lilac", "wallpaper"].includes(name)) return "Unknown accent"
            Config.setNestedValue("iris.appearance.accent", name)
            return String(Config.options.iris.appearance.accent)
        }
        /// Open Spotlight with a query already typed, e.g. `firefox` or `12*7` (empty for suggestions); while it is
        /// open, replaces the query
        function spotlight(query: string): void {
            IrisState.spotlightQuery = query
            GlobalStates.searchOpen = true
        }
        /// Show or hide an online source in the wallpaper gallery: `wallhaven`, `live`, `konachan` or `yandere`, then
        /// `on`, `off` or `toggle`; returns the sources shown, in order
        function gallerySource(source: string, state: string): string {
            const known = ["wallhaven", "live", "konachan", "yandere"]
            if (!known.includes(source)) return "Unknown source: " + known.join(", ")
            const list = Array.from(Config.options?.iris?.wallpaper?.sources ?? ["wallhaven", "live"]).map(String)
            const on = state === "on" || (state === "toggle" && !list.includes(source))
            if (state !== "on" && state !== "off" && state !== "toggle") return "on, off or toggle"
            const next = list.filter(id => id !== source).concat(on ? [source] : [])
            Config.setNestedValue("iris.wallpaper.sources", next)
            return next.join(" ")
        }
        /// Open Orbit with a search already typed, e.g. `firefox` (empty for all the workspaces)
        function orbit(query: string): string {
            if (!(Config.options?.iris?.orbit?.enable ?? false)) return "Orbit is off: turn it on in Settings › Orbit or with inir iris set iris.orbit.enable true"
            IrisState.orbitQuery = query
            IrisState.orbitOpen = true
            return "open"
        }
        /// The corner each output's Orbit hot corner is on right now, as JSON (empty where Niri's own corner or the
        /// setting leaves none)
        function orbitCorner(): string { return JSON.stringify(IrisState.orbitCorners) }
        /// Close Orbit
        function orbitClose(): string {
            IrisState.orbitOpen = false
            return "closed"
        }
        /// Close Spotlight
        function spotlightClose(): string {
            GlobalStates.searchOpen = false
            return "closed"
        }
        /// Grow a bubble's own card: `weather`, `notifications`, `sound`, `mic`, `tools` or `tray` (from the bubble
        /// showing it, else the Island), or `close`
        function bubbleCard(kind: string): string {
            if (kind === "close") { IrisState.bubbleCard = null; return "closed" }
            if (!IrisPieces.cardIds.includes(kind)) return "Unknown card"
            if (IrisState.bubbleCard?.kind === kind) return kind
            IrisState.bubbleCardRequest = ""
            IrisState.bubbleCardRequest = kind
            return kind
        }
        /// Tap a piece the Island carries (`controls`, `sound`, `tray`, `notifications`, `weather`…) as a click
        /// would: its card or page grows from it, or says the focused screen's bar has no such piece
        function tap(kind: string): string {
            if (kind.length === 0) return "Which piece?"
            root.pieceTapped = false
            root.pieceTapRequested(kind)
            return root.pieceTapped ? kind : kind + " is not a piece on the focused screen's bar"
        }
        /// Open a floating bubble's own menu — what it opens, where it rests and how to put it away — by kind
        /// (`weather`, `sound`, …) or piece id (`app:kitty`)
        function bubbleMenu(kind: string): string {
            if (kind.length === 0) return "Which bubble?"
            IrisState.bubbleMenuRequest = ""
            IrisState.bubbleMenuRequest = kind
            return kind
        }
        /// Set how iRiS morphs: `direct`, `liquid`, `glide`, `snap`, `elastic` or `instant`
        function morph(name: string): string {
            if (!Object.keys(IrisStyle.morphStyles).includes(name)) return "Unknown morph style"
            Config.setNestedValue("iris.appearance.morph", name)
            return name
        }
        /// Publish a live activity into the Island from any script: `<action> <id> <value>` — `start <id> <title>`,
        /// `title`, `progress` (`0.4`, `40`, `40%` or `-1` for indeterminate), `detail`, `glyph` (a Material Symbol),
        /// `tint` (`blue`, `sky`, `teal`, `green`, `yellow`, `orange`, `red`, `pink`, `indigo`, `purple`, `lavender`,
        /// `gray`), `end <id> <detail>` (shows a done event and retires), `dismiss <id> -`, `clear all -`. Values
        /// cannot contain commas
        function activity(action: string, id: string, value: string): string {
            let result = null
            switch (action) {
            case "start": result = LiveActivities.start(id, value); break
            case "title": result = LiveActivities.setTitle(id, value); break
            case "progress": result = LiveActivities.setProgress(id, value); break
            case "detail": result = LiveActivities.setDetail(id, value); break
            case "glyph": result = LiveActivities.setGlyph(id, value); break
            case "tint": result = LiveActivities.setTint(id, value); break
            case "end": result = LiveActivities.end(id, value); break
            case "dismiss": LiveActivities.dismiss(id); return "dismissed"
            case "clear": LiveActivities.clear(); return "cleared"
            default: return "Unknown action: start, title, progress, detail, glyph, tint, end, dismiss, clear"
            }
            return result ? JSON.stringify(result) : "No activity " + id
        }
        /// Return the live activities scripts have published, as JSON
        function activities(): string {
            return JSON.stringify(LiveActivities.active)
        }
        /// Set any iRiS option by path, e.g. `iris.appearance.theme.pieceShape squircle` or `iris.bubbles.scale 120`
        /// (values are JSON when they parse)
        function set(path: string, value: string): string {
            if (!path.startsWith("iris.")) return "Only iris.* options"
            let parsed = value
            try { parsed = JSON.parse(value) } catch (error) {}
            Config.setNestedValue(path, parsed)
            return JSON.stringify(Config.getNestedValue(path, null))
        }
        /// How much the wallpaper shapes iRiS, `0`-`100`; any other word prints what was read from the wallpaper
        function adaptive(amount: string): string {
            const value = String(amount).trim().length > 0 ? Math.round(Number(amount)) : NaN
            if (isNaN(value)) return JSON.stringify({ strength: IrisMood.strength, luminance: IrisMood.luminance,
                contrast: IrisMood.contrast, colorfulness: IrisMood.colorfulness, colors: IrisMood.colors.length,
                sampled: IrisMood.sampled, glassTint: IrisStyle.glassTint, placeCovered: IrisStyle.placeCovered, placePlate: IrisStyle.placePlate })
            Config.setNestedValue("iris.appearance.adaptive", Math.max(0, Math.min(100, value)))
            return String(Math.max(0, Math.min(100, value)))
        }
        /// JSON with the colours iRiS resolved for the current look and the contrast of each text, accent and fill on
        /// the surface it sits on (worst case over glass), plus the ones below their target
        function tokens(): string { return JSON.stringify(IrisStyle.audit()) }
        // Every row iRiS Settings declares, as data: where it writes, whether it is offered now, and what it can take.
        // `<section>@<page>` lists 40 rows at a time (an IPC reply has a size limit); an empty list is the end.
        /// JSON with every row iRiS Settings declares in a section (`appearance`, `dock`...; empty for all): the
        /// paths it writes, whether it is shown now, whether the Design owns it, its value and choices.
        /// `<section>@<page>` lists 40 rows at a time, for sections too long for one reply
        function options(section: string): string {
            const page = section.includes("@") ? Number(section.split("@")[1]) : -1
            section = section.split("@")[0]
            // A widget row's value can be an object graph that never ends; it is named instead.
            const data = value => { try { return JSON.parse(JSON.stringify(IrisOptions.plain(value)) ?? "null") } catch (error) { return String(value) } }
            const rows = []
            for (const spec of IrisOptions.settings) {
                if (section.length > 0 && spec.section !== section) continue
                const row = { section: String(spec.section ?? ""), group: String(spec.group ?? ""), part: String(spec.part ?? ""),
                    label: String(spec.label ?? ""), kind: String(spec.kind ?? ""),
                    paths: spec.bundle ? Array.from(spec.bundle, path => String(path)) : spec.flags ? [String(spec.flags)] : spec.path ? [String(spec.path)] : [],
                    via: spec.widget ? "widget" : spec.widgetDesign ? "widgetDesign" : spec.niri ? "niri" : spec.kind === "icon" ? "icon" : spec.set ? "set" : spec.flags ? "flags" : spec.bundle ? "bundle" : "path",
                    tune: IrisOptions.fineTune(spec), mirror: Boolean(spec.mirror), visibleWhen: String(spec.visibleWhen ?? ""), showIf: Boolean(spec.showIf),
                    fallback: data(spec.fallback), min: spec.min, max: spec.max, step: spec.step }
                try {
                    row.shown = IrisOptions.shown(spec)
                    row.owned = (spec.bundle ?? (spec.path ? [String(spec.path)] : [])).some(path => IrisDesign.owns(String(path)))
                    row.current = data(IrisOptions.currentValue(spec))
                    row.choices = IrisOptions.choicesOf(spec).map(choice => choice.values ? { value: data(choice.value), values: data(choice.values) } : data(choice.value))
                } catch (error) {
                    row.error = String(error)
                }
                rows.push(row)
            }
            return JSON.stringify(page < 0 ? rows : rows.slice(page * 40, page * 40 + 40))
        }
        // Applies a value in memory only, as a Settings slider does while it is dragged; nothing is written to disk.
        // Returns the value it replaced, as JSON, so the caller can put it back.
        /// Apply a value in memory only, the way a Settings slider does while it is dragged; nothing is saved.
        /// Returns the value it replaced, as JSON, to put it back
        function preview(path: string, value: string): string {
            const was = JSON.stringify(IrisOptions.plain(Config.getNestedValue(path, null)))
            let parsed = value
            try { parsed = JSON.parse(value) } catch (error) {}
            Config.previewNestedValue(path, parsed)
            return was
        }
        // The active Design's control parts in every state, saved as one image (an absolute .png path).
        /// Draw every control the active Design skins, in each state a person reaches (rest, pointer, press,
        /// keyboard, inactive), and save it as one image at an absolute `.png` path
        function proof(path: string): string {
            if (!path.startsWith("/") || !path.endsWith(".png")) return "needs an absolute .png path"
            proofLoader.target = path
            proofLoader.active = true
            return "rendering " + path
        }
        /// The colour theme the shell and your apps wear: an id such as `catppuccin-mocha` or `iris-ink`, `auto` to
        /// follow the wallpaper, `list` for the ones iRiS shows, or `current` for the one in use
        function palette(id: string): string {
            const known = IrisOptions.colourThemeIds
            if (id === "list") return JSON.stringify(known)
            if (id === "current") return String(ThemeService.currentTheme)
            if (!known.includes(id) && !ThemePresets.presets.some(preset => preset.id === id))
                return "Unknown colour theme. `list` names the ones iRiS shows; `auto` follows the wallpaper"
            ThemeService.setTheme(id)
            return String(ThemeService.currentTheme)
        }
        /// Set the iRiS appearance preset: `iris`, `soft`, `round`, `crisp`, `angular` or `contrast`
        function preset(name: string): string {
            if (!Object.keys(IrisStyle.presets).includes(name)) return "Unknown preset"
            Config.setNestedValue("iris.appearance.preset", name)
            return String(Config.options.iris.appearance.preset)
        }
        /// Choose the glyph a piece wears: `controls`, `tools`, `focus`, `notifications`, `bluetooth`, `updates`,
        /// `anime` or `watching`, then a Material Symbol name (e.g. `inir iris icon controls settings`) or `reset` to
        /// go back to its own face
        function icon(piece: string, glyph: string): string {
            if (!IrisPieces.iconKinds.includes(piece))
                return "Unknown piece. One of: " + IrisPieces.iconKinds.join(", ")
            IrisPieces.setGlyph(piece, glyph === "reset" ? "" : glyph)
            const chosen = IrisPieces.chosenGlyph(piece)
            return chosen.length > 0 ? chosen : "default (" + IrisPieces.defaultGlyph(piece) + ")"
        }
        /// Arrange the Control Center in place (drag controls, resize them from a corner, add or take them out):
        /// `edit`, `done`, `toggle`, `undo`, `tab:<controls|layouts|panel>` to open the side library on that page,
        /// `expand:<display|system|devices|network|bluetooth|none>` to open the Control Center with that expansion
        /// unfolded, or a layout (`iris`, `discs`, `compact`, `glance`, `studio`, `everything`)
        function control(action: string): string {
            if (IrisControlOptions.presets.some(preset => preset.id === action)) {
                IrisControlOptions.applyPreset(action)
                return action
            }
            if (action === "undo") return IrisControlOptions.undo() ? "undone" : "nothing to undo"
            if (action.startsWith("expand:")) {
                const list = action.slice(7)
                if (!["display", "system", "devices", "network", "bluetooth", "none"].includes(list))
                    return "Unknown expansion. One of: display, system, devices, network, bluetooth, none"
                if (!GlobalStates.controlPanelOpen) {
                    IrisState.morphOwner = ""
                    GlobalStates.controlPanelOpen = true
                }
                IrisState.controlPickerRequest = ""
                IrisState.controlPickerRequest = list
                return list
            }
            const tab = action.startsWith("tab:") ? action.slice(4) : ""
            if (tab.length > 0 && !["controls", "layouts", "panel"].includes(tab))
                return "Unknown tab. One of: controls, layouts, panel"
            const wanted = tab.length > 0 || action === "edit" || action === "on" ? true
                : action === "off" || action === "done" ? false : !IrisState.controlEdit
            if (!wanted) {
                IrisState.controlEdit = false
                return "closed"
            }
            if (!GlobalStates.controlPanelOpen) {
                IrisState.morphOwner = ""
                GlobalStates.controlPanelOpen = true
            }
            IrisState.controlEdit = true
            if (tab.length > 0) IrisState.controlTab = tab
            return tab.length > 0 ? tab : "arranging"
        }
        /// Rehearse the lock screen (the real surface, editable, with nothing to unlock): `edit`, `done`, `toggle`,
        /// `page:<name>` to open the inspector on a page (`layouts`, `scene`, `type`, `clock`, `widgets`…),
        /// `widget:<key>` to put a desktop widget on the lock or take it off (`clock`, `weather`, `monthCalendar`…),
        /// `select:<key>` to select one on the lock and open its controls in the inspector (`select:<key>/look` for
        /// shape, material and opacity; `/arrange`, `/widget`), `select:<block>` to take a block (`clock`, `glance`,
        /// `media`, `activity`, `session`, `status`), `peek` and `unpeek` to see the lock without the handles, or a
        /// layout (`iris`, `centered`, `corner`, `minimal`)
        function lock(action: string): string {
            if (IrisLockOptions.presetOf(action)) {
                IrisLockOptions.applyPreset(action)
                return action
            }
            if (action.startsWith("widget:")) {
                const key = action.slice(7)
                if (!IrisFaceData.galleryEntries.some(entry => entry.key === key))
                    return "Unknown widget. One of: " + IrisFaceData.galleryEntries.map(entry => entry.key).join(", ")
                const screen = GlobalStates.focusedScreen?.name ?? ""
                IrisLockOptions.toggleWidget(screen, key)
                return IrisLockOptions.widgetShown(screen, key) ? key + " on the lock" : key + " off the lock"
            }
            if (action === "peek" || action === "unpeek") {
                IrisState.lockPeek = action === "peek"
                return action === "peek" ? "without handles" : "with handles"
            }
            if (action.startsWith("select:") && IrisLockOptions.blockIds.includes(action.slice(7))) {
                IrisState.lockEdit = true
                IrisState.lockSelection = action.slice(7)
                return action.slice(7) + " selected"
            }
            if (action.startsWith("select:")) {
                const [key, tab] = action.slice(7).split("/")
                const screen = GlobalStates.focusedScreen?.name ?? ""
                if (!IrisLockOptions.widgetShown(screen, key)) return key + " is not on the lock; add it with widget:" + key
                if (tab && !["widget", "look", "arrange"].includes(tab)) return "Unknown tab. One of: widget, look, arrange"
                IrisState.lockEdit = true
                IrisState.lockSelection = "widget:" + key
                IrisState.lockWidgetTab = ""
                IrisState.lockWidgetTab = tab ?? ""
                return key + " selected" + (tab ? " on " + tab : "")
            }
            if (action.startsWith("page:")) {
                const page = IrisLockOptions.groups.find(group => group.toLowerCase() === action.slice(5).toLowerCase())
                if (!page) return "Unknown page. One of: " + IrisLockOptions.groups.join(", ")
                IrisState.lockPage = page
                IrisState.lockEdit = true
                return page
            }
            const wanted = action === "edit" || action === "on" ? true
                : action === "off" || action === "done" ? false : !IrisState.lockEdit
            IrisState.lockEdit = wanted
            if (!wanted) IrisState.lockPeek = false
            return wanted ? "editing" : "closed"
        }
        /// Set the utility satellite: `tray`, `tools`, `sound`, `mic` or `none`
        function utility(name: string): string {
            if (!["tray", "tools", "sound", "mic", "none"].includes(name)) return "Unknown utility"
            Config.setNestedValue("iris.bar.auxiliary", name)
            return String(Config.options.iris.bar.auxiliary)
        }
        /// What the Continue bubble has in progress, or resume one of them: no argument lists them numbered with the
        /// episode and saved position, a number or part of a title resumes that show. Anything that matches nothing
        /// in progress starts a search instead. Only ani-cli can be pointed at one show; jerry and curd run their own
        /// picker
        function watch(which: string): string {
            const shows = AnimeWatch.shows ?? []
            const query = String(which ?? "").trim()
            if (query.length === 0) {
                if (!AnimeWatch.available) return "No anime CLI found (install ani-cli, jerry or curd)"
                if (AnimeWatch.busy)
                    return AnimeWatch.busyEpisode.length > 0 ? `${AnimeWatch.phase}: episode ${AnimeWatch.busyEpisode}` : AnimeWatch.phase
                if (shows.length === 0) return AnimeWatch.error.length > 0 ? AnimeWatch.error : "Nothing watched yet"
                return (AnimeWatch.error.length > 0 ? `${AnimeWatch.error}\n` : "") + shows.map((show, index) => {
                    const start = AnimeWatch.targetStartOf(show)
                    const at = start > 0.5 ? `  ${AnimeWatch.clock(start)} in` : ""
                    return `${index + 1}\t${show.title}\tep ${AnimeWatch.targetEpisodeOf(show)}${at}`
                }).join("\n")
            }
            if (AnimeWatch.busy) return `Already ${AnimeWatch.phase}: episode ${AnimeWatch.busyEpisode}`
            if (!AnimeWatch.canTarget)
                return AnimeWatch.available ? `${AnimeWatch.cli} chooses what to resume` : "No anime CLI found"
            const index = Number(query)
            const chosen = isFinite(index) && index >= 1 && index <= shows.length
                ? shows[index - 1]
                : shows.find(show => String(show.title).toLowerCase().includes(query.toLowerCase()))
            if (!chosen) {
                AnimeWatch.search(query)
                return `Searching: ${query}`
            }
            AnimeWatch.resume(chosen)
            return `${chosen.title} · ep ${AnimeWatch.targetEpisodeOf(chosen)}`
        }
        /// Answer whatever the Continue bubble is asking (which show, which episode, what next once one ends, which
        /// quality): no argument lists the options, a number or part of a label chooses one, `cancel` stops the run
        function watchPick(value: string): string {
            const query = String(value ?? "").trim()
            if (query === "cancel") {
                if (!AnimeWatch.running) return "Nothing to cancel"
                AnimeWatch.cancel()
                return "Cancelled"
            }
            if (!AnimeWatch.choosing) return AnimeWatch.busy ? AnimeWatch.phase : "Nothing to choose"
            const items = AnimeWatch.pickItems
            if (query.length === 0)
                return items.map(item => `${AnimeWatch.pickValue(item)}\t${AnimeWatch.betweenEpisodes ? AnimeWatch.actionLabel(AnimeWatch.pickValue(item)) : AnimeWatch.pickLabel(item)}`).join("\n")
            const found = items.find(item => AnimeWatch.pickValue(item) === query)
                ?? items.find(item => (AnimeWatch.betweenEpisodes ? AnimeWatch.actionLabel(AnimeWatch.pickValue(item)) : AnimeWatch.pickLabel(item)).toLowerCase().includes(query.toLowerCase()))
            if (!found) return `No option matches: ${query}`
            AnimeWatch.choose(AnimeWatch.pickValue(found))
            return AnimeWatch.pickLabel(found)
        }
        /// Run a desktop menu entry on the focused output as a click would: `wallpaper`, `wallpaperNext` (the round
        /// button on the wallpaper) or an action id such as `nextWallpaper`, `terminal`, `screenshot`
        function desktopAction(id: string): string {
            return IrisDesktopActions.run(id, NiriService.currentOutput || (Quickshell.screens[0]?.name ?? ""))
        }
        /// Open the desktop menu on the focused output at that point, in pixels; no point opens it in the middle
        function desktopMenu(x: string, y: string): string {
            const output = NiriService.currentOutput
            const screen = Quickshell.screens.find(s => s.name === output) ?? Quickshell.screens[0]
            const px = x.length > 0 ? Number(x) : (screen?.width ?? 0) / 2
            const py = y.length > 0 ? Number(y) : (screen?.height ?? 0) / 2
            if (!isFinite(px) || !isFinite(py)) return "Give x and y in pixels of the focused output"
            GlobalStates.familyDesktopMenuRequested(screen?.name ?? "", px, py)
            return `${screen?.name ?? ""} ${Math.round(px)} ${Math.round(py)}`
        }
        /// Close whichever iRiS or shell context menu is open
        function menuClose(): string {
            const menu = GlobalStates.activeContextMenu
            if (!menu) return "No menu open"
            menu.close ? menu.close() : (menu.active = false)
            return "closed"
        }
        /// Subtitles of the episode that is playing: `size+`, `size-` (kept for every episode), `delay+`, `delay-`,
        /// `delay0` (this episode), `off`, `track:<id>`, `file:<path>` to load one. No argument lists the tracks
        function watchSubs(command: string): string {
            if (AnimeWatch.phase !== "playing") return "No episode playing"
            const c = String(command ?? "").trim()
            if (c === "size+" || c === "size-") AnimeWatch.setSubtitleScale(AnimeWatch.subtitleScale + (c === "size+" ? 10 : -10))
            else if (c === "delay+" || c === "delay-") AnimeWatch.nudgeSubtitleDelay(c === "delay+" ? 0.1 : -0.1)
            else if (c === "delay0") AnimeWatch.resetSubtitleDelay()
            else if (c === "off") AnimeWatch.selectSubtitle(0)
            else if (c.startsWith("track:")) AnimeWatch.selectSubtitle(Number(c.slice(6)) || 0)
            else if (c.startsWith("file:")) AnimeWatch.addSubtitle(c.slice(5))
            else if (c.length > 0) return "Use size+ size- delay+ delay- delay0 off track:<n> file:<path>"
            return `size ${AnimeWatch.subtitleScale} %, delay ${AnimeWatch.subtitleDelay.toFixed(1)} s, track ${AnimeWatch.subtitleId}\n`
                + AnimeWatch.subtitles.map((t, i) => `${t.id}\t${AnimeWatch.subtitleLabel(t, i)}`).join("\n")
        }
        /// Jump inside the episode that is playing by seconds: `85` skips an opening, `-10` goes back
        function watchSeek(seconds: string): string {
            if (AnimeWatch.phase !== "playing") return "No episode playing"
            const value = Number(seconds)
            if (!isFinite(value) || value === 0) return "Seconds, e.g. 85 or -10"
            AnimeWatch.seekBy(value)
            return String(value)
        }
        /// Close the episode that is playing and start the `next` (default) or `previous` one without searching
        /// again. Its place is saved first
        function watchSkip(direction: string): string {
            const wanted = String(direction ?? "").trim() || "next"
            if (wanted !== "next" && wanted !== "previous") return "Use next or previous"
            if (AnimeWatch.phase !== "playing" && !AnimeWatch.betweenEpisodes) return "No episode playing"
            AnimeWatch.skip(wanted)
            return wanted
        }
        /// Measure how a Place opens, closes and reverses halfway, from the expanded Island: `spotlight`, `orbit`,
        /// `gallery`, `settings`, `focus`, `today` or `card` (the music card). Read the result with `motioned`
        function motion(target: string): string { return IrisParts.IrisMotionMeter.start(target) }
        /// The last `motion` measurement as JSON: frame pace, continuity, material, one surface, origin and a clean
        /// end, each passed or not, with the numbers behind them
        function motioned(): string { return JSON.stringify(IrisParts.IrisMotionMeter.result) }
        /// JSON with the Island, Dock, Control Center, Spotlight and side panel state, which edit modes, Settings or
        /// the wallpaper gallery hold the screen (`editing`, `settings`, `gallery`), plus the player the Island
        /// follows (title, position, length)
        function status(): string {
            return JSON.stringify({
                islandExpanded: IrisState.islandExpanded,
                islandShape: IrisState.islandShape,
                islandPage: IrisState.islandPage,
                accent: Config.options?.iris?.appearance?.accent ?? "blue",
                preset: IrisStyle.presetName,
                bubbleCard: IrisState.bubbleCard?.kind ?? "",
                utility: Config.options?.iris?.bar?.auxiliary ?? "tray",
                trayItems: SystemTray.items.values.length,
                dockShown: IrisState.dockShown,
                controlCenter: GlobalStates.controlPanelOpen,
                spotlight: GlobalStates.searchOpen,
                orbit: IrisState.orbitOpen,
                focus: { open: GlobalStates.sidebarLeftOpen, pinned: Config.options?.iris?.sidebars?.left?.pinned ?? false },
                today: { open: GlobalStates.sidebarRightOpen, pinned: Config.options?.iris?.sidebars?.right?.pinned ?? false },
                // Modes that take the screen over until someone closes them.
                editing: { lock: IrisState.lockEdit, customize: IrisState.edit, widgets: GlobalStates.widgetEditMode,
                    controlCenter: IrisState.controlEdit, island: IrisState.arrange },
                settings: GlobalStates.settingsOverlayOpen,
                gallery: GlobalStates.wallpaperLauncherOpen,
                media: MprisController.activePlayer ? {
                    player: MprisController.activePlayer.dbusName ?? "",
                    title: MprisController.titleOf(MprisController.activePlayer) ?? "",
                    playing: MprisController.activePlayer.isPlaying ?? false,
                    position: Math.round(MprisController.positionOf(MprisController.activePlayer) * 10) / 10,
                    length: Math.round(MprisController.lengthOf(MprisController.activePlayer) * 10) / 10,
                    players: MprisController.players.map(player => player.dbusName ?? "")
                } : null
            })
        }
    }

    function islandAllowed(screen: var): bool {
        const list = root.options?.screenList ?? []
        if (!list || list.length === 0) return true
        const matched = Quickshell.screens.filter(s => list.includes(s?.name ?? ""))
        return matched.length === 0 || list.includes(screen?.name ?? "")
    }

    LazyLoader {
        id: proofLoader
        property string target: ""
        active: false
        IrisParts.IrisDesignProof {
            target: proofLoader.target
            onDone: result => {
                console.info("[iris] proof: " + result)
                proofClose.start()
            }
        }
    }
    Timer { id: proofClose; interval: 0; onTriggered: proofLoader.active = false }

    Variants {
        model: Quickshell.screens

        delegate: LazyLoader {
            id: windowLoader
            required property var modelData
            property string loadedEdge: "top"
            readonly property bool loadedBottom: windowLoader.loadedEdge === "bottom"
            readonly property bool loadedVertical: windowLoader.loadedEdge === "left" || windowLoader.loadedEdge === "right"
            Component.onCompleted: windowLoader.loadedEdge = root.edge
            property bool recycling: false
            readonly property string requestedEdge: root.edge
            onRequestedEdgeChanged: windowLoader.recycle()
            // Rebuilt on shape changes: a ClippingRectangle does not re-mask when its corner structure changes.
            readonly property string shapeKey: String(Config.options?.iris?.surround?.enable ?? false)
            onShapeKeyChanged: windowLoader.recycle()
            function recycle(): void {
                windowLoader.recycling = true
                Qt.callLater(() => {
                    windowLoader.loadedEdge = windowLoader.requestedEdge
                    windowLoader.recycling = false
                })
            }
            activeAsync: !windowLoader.recycling

            component: Scope {
            // Declared first so its strips map before the chassis and sit below it (IrisWaveBlur).
            IrisWaveBlur {
                id: waveBlur
                screen: windowLoader.modelData
                nativeRaster: glassBlurRegion.nativeRaster
                active: barWindow.frameBlurred && !barWindow.overlaid && IrisFrame.musicActive
                shapes: barWindow.blurShapes
                edgeWave: framePulse.amplitudes
                waveClock: framePulse.phase
                smoothing: chassisField.smoothing
            }
            // Arranging the desktop on this output: the shelf and the widget's controls in a window of their own above
            // the chassis, which recedes into the card meanwhile. Kept until the shelf has played its exit.
            LazyLoader {
                id: editDeskLoader
                property bool lingering: false
                active: GlobalStates.widgetEditMode || editDeskLoader.lingering
                onActiveChanged: if (GlobalStates.widgetEditMode) editDeskLoader.lingering = true
                component: IrisEditDesk {
                    screen: windowLoader.modelData
                    onGone: editDeskLoader.lingering = false
                }
            }
            PanelWindow {
                id: barWindow
                readonly property bool expanded: islandLoader.item?.expanded ?? false
                readonly property bool pinned: islandLoader.item?.pinned ?? false
                screen: windowLoader.modelData
                // After the wave strips, so Niri stacks the chassis above them (it keeps mapping order).
                visible: waveBlur.ready
                color: "transparent"
                exclusionMode: ExclusionMode.Ignore
                exclusiveZone: 0
                WlrLayershell.namespace: "quickshell:iris-chassis"
                // Overlay Places lease this field only where it is seen: never over a fullscreen window (Top sits under it,
                // and Overlay recreates this surface above the Places that opened first).
                QtObject {
                    id: chassisShown
                    readonly property string screenName: barWindow.screen?.name ?? ""
                    readonly property bool shown: !barWindow.canvasSuppressed && !barWindow.overlaid && !barWindow.carded
                        && !(CompositorService.isNiri && GameMode.hasFullscreenOnOutput(chassisShown.screenName))
                    property string told: ""
                    function tell(): void {
                        if (chassisShown.told && chassisShown.told !== chassisShown.screenName) IrisFrame.showChassis(chassisShown.told, false)
                        chassisShown.told = chassisShown.screenName
                        IrisFrame.showChassis(chassisShown.screenName, chassisShown.shown)
                    }
                    onShownChanged: chassisShown.tell()
                    onScreenNameChanged: chassisShown.tell()
                    Component.onCompleted: chassisShown.tell()
                    Component.onDestruction: IrisFrame.showChassis(chassisShown.told, false)
                }
                // This chassis hosts arranging its output's desktop (the shelf, the Island's head): the shared toolbar
                // and library stay out of it.
                readonly property string hostedOutput: barWindow.screen?.name ?? ""
                Component.onCompleted: {
                    barWindow.applyTransform()
                    IrisParts.IrisMotionMeter.registerChassis(barWindow.hostedOutput, barWindow)
                    DesktopEditStage.setHost(barWindow.hostedOutput, true)
                }
                Component.onDestruction: {
                    IrisParts.IrisMotionMeter.registerChassis(barWindow.hostedOutput, null)
                    DesktopEditStage.setHost(barWindow.hostedOutput, false)
                }
                readonly property bool editHere: IrisState.edit
                    && (root.editScreen.length === 0 || barWindow.screen?.name === root.editScreen)
                // Arranging the desktop, the whole chassis (frame, Island, bubbles, Dock) recedes into the card with the
                // desktop under it: the screen as it will be, live, while the shelf's pages change it.
                readonly property var editCard: DesktopEditStage.cardFor(barWindow.screen?.name ?? "", barWindow.width, barWindow.height)
                readonly property bool carded: barWindow.editCard.p > 0
                readonly property bool presenting: barWindow.pinned || stage.cardPresent
                    || (controlCentreLoader.item?.present ?? false) || barWindow.editHere
                    || (dockLoader.item?.overFullscreen ?? false) || (dockLoader.item?.menuOpen ?? false)
                    || (spotlightLoader.item?.present ?? false) || (galleryLoader.item?.present ?? false)
                    || (orbitLoader.item?.present ?? false)
                // Niri keeps a fullscreen window above the Top layer, so the overview
                // over a game would show every other surface but this one.
                readonly property bool overviewOverFullscreen: CompositorService.isNiri && NiriService.inOverview
                    && GameMode.hasFullscreenOnOutput(barWindow.screen?.name ?? "")
                readonly property bool canvasSuppressed: barWindow.suppressed && !barWindow.presenting
                // Nothing of the chassis may cover, move or restack what sits still in it: continuous motion may
                // then draw in a surface of its own (LiveLayer) instead of repainting the whole output.
                readonly property bool liveCalm: !barWindow.presenting && !barWindow.expanded && !barWindow.overlaid
                    && !barWindow.canvasSuppressed && !IrisStyle.arriving && !(islandLoader.item?.morphing ?? false)
                    && (banners.fieldShapes ?? []).length === 0
                readonly property int liveLayer: WlrLayer.Top
                readonly property int liveEpoch: IrisState.chassisEpoch
                readonly property bool overlaid: ((islandLoader.item?.fullscreenCovered ?? false) && !barWindow.canvasSuppressed)
                    || barWindow.overviewOverFullscreen
                // Switching layers recreates the surface above the Dock's window, whose icons it would cover.
                onOverlaidChanged: if (!barWindow.overlaid) IrisState.chassisEpoch++
                WlrLayershell.layer: barWindow.overlaid ? WlrLayer.Overlay : WlrLayer.Top
                WlrLayershell.keyboardFocus: barWindow.pinned || stage.cardOpen || (controlCentreLoader.item?.morphOpen ?? false)
                    || (dockLoader.item?.menuOpen ?? false) || (spotlightLoader.item?.here && GlobalStates.searchOpen)
                    || (galleryLoader.item?.morphOpen ?? false) || (orbitLoader.item?.wanted ?? false)
                    ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
                anchors { left: true; right: true; top: true; bottom: true }
                readonly property bool suppressed: islandLoader.active
                    ? (islandLoader.item?.suppressed ?? false) : false

                readonly property bool islandAutoHide: IrisFrame.islandAutoHide && islandLoader.active
                readonly property bool islandWorkspaceEmpty: {
                    if (!(root.options?.revealOnEmpty ?? true) || !CompositorService.isNiri) return false
                    const active = (NiriService.allWorkspaces ?? []).find(ws => ws.output === barWindow.screen?.name && ws.is_active)
                    return active !== undefined && !(NiriService.windows ?? []).some(w => w.workspace_id === active.id)
                }
                property bool islandEdgeIntent: false
                readonly property bool islandWants: barWindow.expanded || barWindow.pinned || barWindow.editHere || GlobalStates.widgetEditMode
                    || (islandLoader.item?.feedback ?? false) || (islandLoader.item?.eventShown ?? false)
                    || (islandLoader.item?.morphing ?? false) || stage.cardPresent
                    || (controlCentreLoader.item?.present ?? false)
                readonly property bool islandRevealed: !barWindow.islandAutoHide
                    || barWindow.islandWorkspaceEmpty || barWindow.islandEdgeIntent || barWindow.islandWants
                // Off the edge the chassis is gone, but its fuse still reaches back onto
                // the screen and leaves a smudge where the Island used to melt in.
                readonly property bool islandTucked: islandLoader.tuck > islandLoader.hidden - 1
                readonly property bool pointerOnIslandBody: canvasHover.hovered
                    && [islandInput, menuStartInput, menuEndInput].some(area =>
                        canvasHover.point.position.x >= area.x && canvasHover.point.position.x < area.x + area.width
                        && canvasHover.point.position.y >= area.y && canvasHover.point.position.y < area.y + area.height)
                readonly property bool pointerNearIsland: islandEdgeHover.hovered || barWindow.pointerOnIslandBody
                onPointerNearIslandChanged: {
                    if (barWindow.pointerNearIsland) {
                        islandHideDelay.stop()
                        if (!barWindow.islandEdgeIntent) islandRevealDwell.restart()
                    } else {
                        islandRevealDwell.stop()
                        islandHideDelay.restart()
                    }
                }
                Timer { id: islandRevealDwell; interval: 110; onTriggered: barWindow.islandEdgeIntent = true }
                Timer { id: islandHideDelay; interval: 420
                    onTriggered: if (!barWindow.pointerNearIsland) barWindow.islandEdgeIntent = false }
                mask: barWindow.canvasSuppressed || barWindow.carded ? emptyRegion
                    : barWindow.pinned || stage.cardArmed || (controlCentreLoader.item?.armed ?? false)
                        || (dockLoader.item?.menuOpen ?? false) || (spotlightLoader.item?.armed ?? false)
                        || (galleryLoader.item?.armed ?? false) || (orbitLoader.item?.armed ?? false)
                        || (islandLoader.item?.morphing ?? false)
                        ? null : chassisRegion
                Region { id: emptyRegion }
                component PieceRegion: Region {
                    required property int index
                    readonly property var rect: stage.hitRects[index] ?? null
                    x: rect ? rect.x : 0
                    y: rect ? rect.y : 0
                    width: rect ? rect.width : 0
                    height: rect ? rect.height : 0
                }
                MouseArea {
                    anchors.fill: parent
                    enabled: dockLoader.item?.menuOpen ?? false
                    acceptedButtons: Qt.AllButtons
                    onPressed: dockLoader.item.closeMenu()
                }
                MouseArea {
                    anchors.fill: parent
                    enabled: barWindow.pinned
                    acceptedButtons: Qt.AllButtons
                    // Only a press off the Island closes it: one on its text or air fell through to here (10-25).
                    function inside(item: Item, x: real, y: real): bool {
                        return item.width > 0 && x >= item.x && x < item.x + item.width && y >= item.y && y < item.y + item.height
                    }
                    onPressed: mouse => {
                        if ([islandInput, extensionInput, menuStartInput, menuEndInput].some(item => inside(item, mouse.x, mouse.y))) return
                        islandLoader.item.expanded = false
                    }
                }
                Region {
                    id: chassisRegion
                    item: islandInput
                    Region { item: extensionInput }
                    Region { item: menuStartInput }
                    Region { item: menuEndInput }
                    Region {
                        readonly property rect area: islandLoader.item?.notchArea ?? Qt.rect(0, 0, 0, 0)
                        x: islandLoader.x + area.x
                        y: islandLoader.y + area.y
                        width: area.width
                        height: area.height
                    }
                    Region { item: islandEdgeStrip.armed ? islandEdgeStrip : null }
                    Region { item: dockLoader.item && !dockLoader.item.inputOff ? dockLoader.item.hitItem : null }
                    Region {
                        readonly property var rect: editLoader.item?.hitRect ?? null
                        x: rect?.x ?? 0
                        y: rect?.y ?? 0
                        width: rect?.width ?? 0
                        height: rect?.height ?? 0
                    }
                    Region {
                        readonly property var rect: editLoader.item?.sheetRect ?? null
                        x: rect?.x ?? 0
                        y: rect?.y ?? 0
                        width: rect?.width ?? 0
                        height: rect?.height ?? 0
                    }
                    Region {
                        readonly property var rect: editLoader.item?.inspectorRect ?? null
                        x: rect?.x ?? 0
                        y: rect?.y ?? 0
                        width: rect?.width ?? 0
                        height: rect?.height ?? 0
                    }
                    Region {
                        readonly property var rect: editLoader.item?.knobRect ?? null
                        x: rect?.x ?? 0
                        y: rect?.y ?? 0
                        width: rect?.width ?? 0
                        height: rect?.height ?? 0
                    }
                    Region {
                        readonly property var panel: (controlCentreLoader.item?.present ?? false)
                            ? controlCentreLoader.item.body : null
                        x: panel ? controlCentreLoader.x + panel.x : 0
                        y: panel ? controlCentreLoader.y + panel.y : 0
                        width: panel ? panel.width : 0
                        height: panel ? panel.height : 0
                    }
                    Region {
                        x: banners.hitRect?.x ?? 0
                        y: banners.hitRect?.y ?? 0
                        width: banners.hitRect?.width ?? 0
                        height: banners.hitRect?.height ?? 0
                    }
                    PieceRegion { index: 0 }
                    PieceRegion { index: 1 }
                    PieceRegion { index: 2 }
                    PieceRegion { index: 3 }
                    PieceRegion { index: 4 }
                    PieceRegion { index: 5 }
                    PieceRegion { index: 6 }
                    PieceRegion { index: 7 }
                    PieceRegion { index: 8 }
                    PieceRegion { index: 9 }
                    PieceRegion { index: 10 }
                    PieceRegion { index: 11 }
                    PieceRegion { index: 12 }
                    PieceRegion { index: 13 }
                    PieceRegion { index: 14 }
                    PieceRegion { index: 15 }
                    PieceRegion { index: 16 }
                    PieceRegion { index: 17 }
                    PieceRegion { index: 18 }
                    PieceRegion { index: 19 }
                    PieceRegion { index: 20 }
                    PieceRegion { index: 21 }
                    PieceRegion { index: 22 }
                    PieceRegion { index: 23 }
                }
                // Arriving, the chassis is scaled; the compositor's region follows geometry, not
                // transforms, so it waits for the arrival instead of blurring beside the bodies.
                readonly property var blurShapes: barWindow.canvasSuppressed || IrisStyle.arriving || barWindow.carded ? []
                    // The compositor's blur is all or nothing: a body joins it once half frosted, its tint carries the rest.
                    : (barWindow.fieldShapes ?? []).filter(shape => chassisField.glassOf(shape) === 2 && !(shape.frost < 0.5))
                readonly property bool frameBlurred: !barWindow.canvasSuppressed && !IrisStyle.arriving && !barWindow.carded
                    && IrisFrame.framed && chassisField.frameGlass === 2
                // The family grows inward: everything the chassis draws comes in from just past the
                // screen edges and settles; the transform is dropped at rest so nothing is resampled.
                Scale {
                    id: arrivalScale
                    origin.x: barWindow.width / 2
                    origin.y: barWindow.height / 2
                    xScale: 1 + 0.035 * (1 - IrisStyle.arrival)
                    yScale: 1 + 0.035 * (1 - IrisStyle.arrival)
                }
                // As a card the compositor's blur would sit beside the shrunk bodies: glass takes the wallpaper instead,
                // sampled where the desktop pixel lies, which is where the card shows it.
                Scale { id: cardScale; xScale: barWindow.editCard.s; yScale: barWindow.editCard.s }
                Translate { id: cardShift; x: barWindow.editCard.x; y: barWindow.editCard.y }
                // Set by hand: a Binding on the content item's transform list never reached it (qs-rs, 10-23).
                readonly property int transformKind: IrisStyle.arriving ? 1 : barWindow.carded ? 2 : 0
                onTransformKindChanged: barWindow.applyTransform()
                function applyTransform(): void {
                    if (!barWindow.contentItem) return
                    barWindow.contentItem.transform = barWindow.transformKind === 1 ? [arrivalScale]
                        : barWindow.transformKind === 2 ? [cardScale, cardShift] : []
                }
                Binding { target: barWindow.contentItem; property: "opacity"; value: Math.min(1, IrisStyle.arrival * 1.6) }
                IrisBlurRegion {
                    id: glassBlurRegion
                    window: barWindow
                    shapes: barWindow.blurShapes
                    beforeTake: () => islandLoader.item?.flushShapes?.()
                    framed: barWindow.frameBlurred
                    edgeWave: barWindow.overlaid ? Qt.vector4d(0, 0, 0, 0) : framePulse.amplitudes
                    waveClock: framePulse.phase
                    windowWidth: barWindow.width
                    windowHeight: barWindow.height
                }
                // Keep the area under a still pointer: Wayland sends no re-enter after a resize.
                Item {
                    id: islandInput
                    readonly property real liveWidth: Math.max(islandLoader.width, islandLoader.item?.inputWidth ?? 0)
                    // A resting menu bar takes input on its strip only; the notch has a region of its own.
                    readonly property bool strip: (islandLoader.item?.menubar ?? false) && !(islandLoader.item?.expanded ?? false)
                        && (islandLoader.item?.extensionArea.width ?? 0) <= 0
                    readonly property real liveHeight: strip ? islandLoader.item.stripHeight
                        : Math.max(islandLoader.height, islandLoader.item?.inputHeight ?? 0)
                    property real heldWidth: 0
                    property real heldHeight: 0
                    readonly property bool holding: canvasHover.hovered
                        && (heldWidth > liveWidth + 1 || heldHeight > liveHeight + 1)
                    function release(): void { heldWidth = liveWidth; heldHeight = liveHeight }
                    onLiveWidthChanged: heldWidth = canvasHover.hovered ? Math.max(heldWidth, liveWidth) : liveWidth
                    onLiveHeightChanged: heldHeight = canvasHover.hovered ? Math.max(heldHeight, liveHeight) : liveHeight
                    width: Math.max(liveWidth, heldWidth)
                    height: Math.max(liveHeight, heldHeight)
                    x: !windowLoader.loadedVertical ? islandLoader.x + (islandLoader.width - width) / 2
                        : windowLoader.loadedEdge === "right" ? islandLoader.x + islandLoader.width - width : islandLoader.x
                    y: windowLoader.loadedVertical ? islandLoader.y + (islandLoader.height - height) / 2
                        : windowLoader.loadedBottom ? islandLoader.y + islandLoader.height - height : islandLoader.y
                }
                Item {
                    id: extensionInput
                    readonly property rect area: islandLoader.item?.extensionArea ?? Qt.rect(0, 0, 0, 0)
                    x: islandLoader.x + extensionInput.area.x
                    y: islandLoader.y + extensionInput.area.y
                    width: extensionInput.area.width
                    height: extensionInput.area.height
                }
                Item {
                    id: menuStartInput
                    readonly property rect area: islandLoader.item?.menuStartArea ?? Qt.rect(0, 0, 0, 0)
                    x: islandLoader.x + area.x
                    y: islandLoader.y + area.y
                    width: area.width
                    height: area.height
                }
                Item {
                    id: menuEndInput
                    readonly property rect area: islandLoader.item?.menuEndArea ?? Qt.rect(0, 0, 0, 0)
                    x: islandLoader.x + area.x
                    y: islandLoader.y + area.y
                    width: area.width
                    height: area.height
                }
                // The Island itself is off the edge while hidden, so its own input area
                // cannot catch the pointer that is supposed to bring it back.
                Item {
                    id: islandEdgeStrip
                    readonly property bool armed: barWindow.islandAutoHide
                    readonly property real depth: Math.max(2, IrisFrame.band + 2)
                    readonly property real slack: Math.round(40 * IrisStyle.density)
                    readonly property real span: (windowLoader.loadedVertical ? islandLoader.height : islandLoader.width) + 2 * islandEdgeStrip.slack
                    width: windowLoader.loadedVertical ? islandEdgeStrip.depth : islandEdgeStrip.span
                    height: windowLoader.loadedVertical ? islandEdgeStrip.span : islandEdgeStrip.depth
                    x: windowLoader.loadedVertical
                        ? (windowLoader.loadedEdge === "right" ? barWindow.width - islandEdgeStrip.depth : 0)
                        : Math.round(islandLoader.x - islandEdgeStrip.slack)
                    y: windowLoader.loadedVertical ? Math.round(islandLoader.y - islandEdgeStrip.slack)
                        : (windowLoader.loadedBottom ? barWindow.height - islandEdgeStrip.depth : 0)
                    HoverHandler { id: islandEdgeHover }
                }
                HoverHandler {
                    id: canvasHover
                    property point last: Qt.point(-1, -1)
                    onHoveredChanged: if (!hovered) islandInput.release()
                    onPointChanged: {
                        const p = point.position
                        if (Math.abs(p.x - last.x) + Math.abs(p.y - last.y) > 2) {
                            last = p
                            islandInput.release()
                        }
                    }
                }

                Shortcut {
                    sequence: "Escape"
                    enabled: barWindow.expanded
                    onActivated: islandLoader.item.expanded = false
                }

                Shortcut {
                    sequence: "Escape"
                    enabled: barWindow.editHere
                    onActivated: if (!(editLoader.item?.fold() ?? false)) IrisState.edit = false
                }

                // Never coalesced: the field is the outline of what the items paint,
                // so a table that lands a turn later draws the rim and the shadow of
                // the shape the chassis had on the previous frame. Measured at 3 ms
                // per open/close for the whole chain — cheaper than one frame of lag.
                readonly property var fieldShapes: {
                    const dockBody = dockLoader.item?.bodyShape ?? null
                    const hung = (controlCentreLoader.item?.fieldShapes ?? [])
                        .concat(stage.fieldShapes)
                        .concat(editLoader.item?.fieldShapes ?? [])
                        .concat(Array.isArray(dockBody) ? dockBody : [])
                        .concat(banners.fieldShapes)
                        .concat(IrisFrame.placeShapesOn(barWindow.screen?.name ?? ""))
                    const bodies = hung.filter(shape => shape.joins === "island")
                    const island = barWindow.islandTucked ? [] : (islandLoader.item?.fieldShapes ?? []).map(shape => {
                        if (!shape.satellite) return shape
                        const reach = IrisStyle.fuse
                        const body = bodies.find(b => shape.x < b.x + b.width + reach && shape.x + shape.width > b.x - reach
                            && shape.y < b.y + b.height + reach && shape.y + shape.height > b.y - reach)
                        return body ? Object.assign({}, shape, { joins: [body.id].concat(Array.isArray(shape.joins) ? shape.joins.slice(1) : []) }) : shape
                    })
                    // Two bodies that meet the frame within reach of each other melt into one another too: joined to
                    // the frame alone, their fillets met in a cusp along the band (a side panel under a corner plate).
                    const framed = shape => (Array.isArray(shape.joins) ? shape.joins : [shape.joins]).length === 1
                        && (Array.isArray(shape.joins) ? shape.joins[0] : shape.joins) === "frame" && !!shape.id
                    const joined = island.concat(hung)
                    const all = joined.map(shape => {
                        if (!framed(shape)) return shape
                        let near = null, best = Infinity
                        for (const other of joined) {
                            if (other === shape || !framed(other)) continue
                            const dx = Math.max(0, other.x - shape.x - shape.width, shape.x - other.x - other.width)
                            const dy = Math.max(0, other.y - shape.y - shape.height, shape.y - other.y - other.height)
                            const gap = Math.hypot(dx, dy)
                            if (gap < Number(shape.fuse ?? 0) && gap < best) { best = gap; near = other }
                        }
                        return near ? Object.assign({}, shape, { joins: ["frame", near.id] }) : shape
                    })
                    if (all.length <= chassisField.capacity) return all
                    return all.filter(shape => !shape.paints)
                        .concat(all.filter(shape => shape.paints))
                        .slice(0, chassisField.capacity)
                }

                IrisField {
                    id: chassisField
                    anchors.fill: parent
                    compositorAllowed: !barWindow.carded
                    providesBackdrop: true
                    edgeWave: framePulse.amplitudes
                    waveClock: framePulse.phase
                    frameMusicLevel: framePulse.visibleLevel
                    shapes: barWindow.fieldShapes
                    opacity: barWindow.canvasSuppressed ? 0 : 1
                    visible: opacity > 0
                    Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(160); easing.type: IrisStyle.feedbackEasing } }
                }

                IrisFramePulse {
                    id: framePulse
                    active: IrisFrame.musicActive && !barWindow.canvasSuppressed
                }

                IrisParts.IrisSpring {
                    id: islandPlacement
                    surface: "island"
                    intent: "move"
                    to: islandLoader.layout === "left" ? 0 : islandLoader.layout === "right" ? 1 : 0.5
                }

                Loader {
                    id: islandLoader
                    z: 3
                    active: GlobalStates.barOpen && root.islandAllowed(barWindow.screen)
                    readonly property string layout: String(root.options?.layout ?? "island")
                    // Corner: welded, it sits in the corner itself (no margin along the edge, the wall-side room handed back).
                    readonly property bool corner: (islandLoader.layout === "left" || islandLoader.layout === "right") && !windowLoader.loadedVertical
                    readonly property real inset: IrisFrame.band + (islandLoader.corner && islandLoader.item
                        ? Math.round(root.outerMargin * (1 - Math.min(1, islandLoader.item.notchness))) : root.outerMargin)
                    readonly property real wallShift: !islandLoader.corner || !islandLoader.item ? 0
                        : islandLoader.layout === "left" ? -islandLoader.item.wallSlack : islandLoader.item.wallSlack
                    readonly property real edgeMargin: IrisFrame.band + (islandLoader.item
                        ? Math.round(root.restMargin * (1 - Math.min(1, islandLoader.item.notchness))) : root.outerMargin)
                    readonly property real along: islandPlacement.value
                        * ((windowLoader.loadedVertical ? parent.height - islandLoader.height : parent.width - islandLoader.width) - 2 * islandLoader.inset)
                    readonly property real hidden: (windowLoader.loadedVertical ? islandLoader.width : islandLoader.height)
                        + islandLoader.edgeMargin + Math.round(8 * IrisStyle.density)
                    property real tuck: barWindow.islandRevealed ? 0 : islandLoader.hidden
                    Behavior on tuck { NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
                    readonly property real tuckX: !windowLoader.loadedVertical ? 0
                        : windowLoader.loadedEdge === "right" ? islandLoader.tuck : -islandLoader.tuck
                    readonly property real tuckY: windowLoader.loadedVertical ? 0
                        : windowLoader.loadedBottom ? islandLoader.tuck : -islandLoader.tuck
                    x: Math.round((!windowLoader.loadedVertical ? islandLoader.inset + islandLoader.along + islandLoader.wallShift
                        : windowLoader.loadedEdge === "right" ? parent.width - islandLoader.width - islandLoader.edgeMargin : islandLoader.edgeMargin)
                        + islandLoader.tuckX)
                    y: Math.round((windowLoader.loadedVertical ? islandLoader.inset + islandLoader.along
                        : windowLoader.loadedBottom ? parent.height - islandLoader.height - islandLoader.edgeMargin : islandLoader.edgeMargin)
                        + islandLoader.tuckY)
                    width: item?.implicitWidth ?? (windowLoader.loadedVertical ? root.barHeight : 240)
                    height: item?.implicitHeight ?? (windowLoader.loadedVertical ? 240 : root.barHeight)
                    sourceComponent: IrisIsland {
                        id: island
                        targetScreen: barWindow.screen
                        onPieceActivated: (slot, kind, rect) => stage.activate(slot, kind, rect)
                        pointerHeld: islandInput.holding
                        availableWidth: (windowLoader.loadedVertical ? barWindow.height : barWindow.width) - (IrisFrame.band + root.outerMargin) * 2
                        availableAcross: barWindow.width - 2 * (IrisFrame.band + root.outerMargin) - root.barHeight - Math.round(24 * IrisStyle.density)
                        compactHeight: root.barHeight
                        edge: windowLoader.loadedEdge
                        screenOffsetY: 0
                        Connections {
                            target: root
                            function onPieceTapRequested(kind: string): void {
                                if (barWindow.screen?.name !== GlobalStates.focusedScreen?.name) return
                                const part = island.pieceItem(kind)
                                if (!part) return
                                root.pieceTapped = true
                                island.activatePiece(kind, part)
                            }
                            function onIslandRequested(open: bool, page: string): void {
                                if (!open || barWindow.screen?.name === GlobalStates.focusedScreen?.name) {
                                    if (open && (page === "next" || page === "prev")) {
                                        island.stepPage(page === "next" ? 1 : -1)
                                        return
                                    }
                                    if (open && page === "shelf:toggle") {
                                        const showing = island.expanded && island.effectivePage === "shelf"
                                        if (!showing) island.page = "shelf"
                                        island.pinned = !showing
                                        island.expanded = !showing
                                        return
                                    }
                                    if (open) island.page = page
                                    island.pinned = open
                                    island.expanded = open
                                }
                            }
                        }
                    }
                }

                // Above the banners and the Dock, under the Island it grows out of.
                Loader {
                    id: spotlightLoader
                    z: 2.5
                    anchors.fill: parent
                    anchors.margins: IrisFrame.band
                    active: Config.ready && GlobalStates.deferredPanelsReady
                        && (Config.options?.enabledPanels ?? []).includes("irisPalette")
                        && (Config.options?.iris?.modules?.palette ?? true)
                    asynchronous: true
                    sourceComponent: IrisPalette { screen: barWindow.screen }
                }

                // Resident like Spotlight: built on open it cost ~90 ms before the first frame and grew from outside the Island.
                Loader {
                    id: galleryLoader
                    z: 2.5
                    anchors.fill: parent
                    anchors.margins: IrisFrame.band
                    active: Config.ready && GlobalStates.deferredPanelsReady
                    asynchronous: true
                    sourceComponent: IrisWallpaperPicker { screen: barWindow.screen }
                }

                // A Place like Spotlight: resident, so it opens on a warm frame and grows from where the Island rests.
                Loader {
                    id: orbitLoader
                    z: 2.5
                    anchors.fill: parent
                    anchors.margins: IrisFrame.band
                    active: Config.ready && GlobalStates.deferredPanelsReady && (Config.options?.iris?.orbit?.enable ?? false)
                    asynchronous: true
                    sourceComponent: IrisOrbit { screen: barWindow.screen }
                }

                IrisBanners {
                    id: banners
                    z: 2
                    anchors.fill: parent
                    screenData: barWindow.screen
                    islandShapes: islandLoader.item?.fieldShapes ?? []
                }

                Loader {
                    id: dockLoader
                    z: 2
                    anchors.fill: parent
                    active: (Config.options?.iris?.dock?.enable ?? true) && GlobalStates.deferredPanelsReady
                    asynchronous: true
                    sourceComponent: IrisDock {
                        screen: barWindow.screen
                        onPieceActivated: (slot, kind, rect) => stage.activate(slot, kind, rect)
                        onPieceMenuRequested: (slot, kind, rect, menu) => {
                            menu.model = stage.pieceMenu(slot, kind, rect)
                            menu.requestOpen()
                        }
                    }
                }

                IrisStage {
                    id: stage
                    z: 2
                    anchors.fill: parent
                    modelData: barWindow.screen
                    suppressed: barWindow.canvasSuppressed
                }

                Loader {
                    id: editLoader
                    z: 4
                    anchors.fill: parent
                    // Kept until its recede has played out, set imperatively (read back into `active` it is a
                    // binding loop). A grace flag set from irisEditChanged lost the race with `active`, so
                    // Done unloaded the bar inside its own click and the next click went nowhere.
                    property bool lingering: false
                    onLoaded: editLoader.lingering = true
                    Connections {
                        target: editLoader.item
                        function onShownChanged(): void {
                            if (editLoader.item.shown) editLoader.lingering = true
                            else editRelease.restart()
                        }
                    }
                    Timer { id: editRelease; interval: 0; onTriggered: editLoader.lingering = editLoader.item?.shown ?? false }
                    active: barWindow.editHere || editLoader.lingering
                    sourceComponent: IrisEditBar { screenData: barWindow.screen; shapes: barWindow.fieldShapes.concat(stage.pieceShapes, islandLoader.item?.carriedShapes ?? [], dockLoader.item?.editShapes ?? []) }
                }

                Loader {
                    id: controlCentreLoader
                    z: 1
                    anchors.fill: parent
                    readonly property bool panelMode: IrisDesign.has("controlCenter") || String(Config.options?.iris?.controlCenter?.opens ?? "island") !== "island"
                    readonly property bool externalOpen: GlobalStates.controlPanelOpen
                        && (controlCentreLoader.panelMode || IrisState.morphOwner === "stage")
                    readonly property bool wanted: controlCentreLoader.externalOpen || stage.controlIntent
                    // Built once at idle in panel mode (or on first use) and kept, like the island's.
                    property bool resident: false
                    property Timer warm: Timer {
                        running: controlCentreLoader.panelMode && GlobalStates.deferredPanelsReady && !controlCentreLoader.resident
                        interval: 4000
                        onTriggered: controlCentreLoader.resident = true
                    }
                    onWantedChanged: if (controlCentreLoader.wanted) controlCentreLoader.resident = true
                    Component.onCompleted: if (controlCentreLoader.wanted) controlCentreLoader.resident = true
                    active: (Config.options?.iris?.modules?.controlCenter ?? true) && controlCentreLoader.resident
                    asynchronous: true
                    sourceComponent: IrisControlCenter { screenData: barWindow.screen }
                }
            }
            }
        }
    }
}
