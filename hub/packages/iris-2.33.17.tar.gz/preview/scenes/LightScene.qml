pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import qs.services
import qs.modules.common.widgets
import qs.modules.iris.style
import qs.modules.iris.frame
import qs.modules.iris.components
import qs.modules.iris.preview.parts

PreviewScene {
    id: lightRoot
    readonly property real naturalWidth: Math.round(620 * lightRoot.d)
    readonly property real naturalHeight: Math.round(290 * lightRoot.d)
    narrowest: Math.round(360 * lightRoot.d)
    lowest: Math.round(220 * lightRoot.d)
    readonly property string aura: String(lightRoot.opt("iris.appearance.aura", "subtle"))
    readonly property real reach: Number(lightRoot.opt("iris.appearance.theme.lightReach", 100))
    readonly property real glow: Number(lightRoot.opt("iris.appearance.theme.glow", 0))
    // The two bodies share what the frame gives: at a column's width their natural 236 px overran both edges and cut
    // Weather's words and Control Center's tiles. Without a caption under them (a compact hero) they sit centred.
    readonly property bool compact: lightRoot.preview.compact ?? false
    readonly property real gutter: Math.round(16 * lightRoot.d)
    readonly property real bodyWidth: Math.min(Math.round(236 * lightRoot.d), Math.floor((lightRoot.width - 3 * lightRoot.gutter) / 2))
    readonly property real bodyHeight: Math.min(Math.round(176 * lightRoot.d), lightRoot.height - 2 * lightRoot.gutter)
    readonly property real bodyY: lightRoot.compact ? Math.round((lightRoot.height - lightRoot.bodyHeight) / 2) : Math.round(26 * lightRoot.d)
    readonly property real side: Math.round((lightRoot.width - 2 * lightRoot.bodyWidth - lightRoot.gutter) / 2)
    property real t: 0
    Loop on t { running: lightRoot.playing }
    readonly property real grown: IrisFrame.islandBand + (lightRoot.bodyHeight - IrisFrame.islandBand) * lightRoot.t
    readonly property real wide: IrisFrame.islandBand * 2 + (lightRoot.bodyWidth - IrisFrame.islandBand * 2) * lightRoot.t

    LitBody {
        x: lightRoot.side + (lightRoot.bodyWidth - width) / 2
        y: lightRoot.bodyY
        width: lightRoot.wide
        height: lightRoot.grown
        restWidth: lightRoot.bodyWidth
        restHeight: lightRoot.bodyHeight
        progress: lightRoot.t
        light: IrisStyle.identity.sky
        ColumnLayout {
            anchors.fill: parent
            spacing: Math.round(2 * lightRoot.d)
            RowLayout {
                spacing: Math.round(6 * lightRoot.d)
                MaterialSymbol { text: "partly_cloudy_day"; fill: 1; iconSize: Math.round(18 * lightRoot.d); color: IrisStyle.identity.sky }
                IrisText { font.pixelSize: Math.round((voiceSize) / Math.max(1, IrisStyle.typeScale)); text: Translation.tr("Weather"); font.weight: IrisStyle.weight(Font.DemiBold) }
            }
            IrisText {
                text: "18°"
                font.family: IrisStyle.fontNumbers
                font.weight: IrisStyle.figureWeight
                font.pixelSize: Math.round((IrisStyle.typeDotL) / Math.max(1, IrisStyle.typeScale))
            }
            IrisText { text: Translation.tr("Partly cloudy"); color: IrisStyle.muted; font.pixelSize: Math.round((IrisStyle.typeMeta) / Math.max(1, IrisStyle.typeScale))}
            Item { Layout.fillHeight: true }
        }
    }
    LitBody {
        x: lightRoot.side + lightRoot.gutter + lightRoot.bodyWidth + (lightRoot.bodyWidth - width) / 2
        y: lightRoot.bodyY
        width: lightRoot.wide
        height: lightRoot.grown
        restWidth: lightRoot.bodyWidth
        restHeight: lightRoot.bodyHeight
        progress: lightRoot.t
        light: IrisStyle.wallpaperLight
        ColumnLayout {
            anchors.fill: parent
            spacing: Math.round(10 * lightRoot.d)
            RowLayout {
                spacing: Math.round(6 * lightRoot.d)
                MaterialSymbol { text: "tune"; iconSize: Math.round(18 * lightRoot.d); color: IrisStyle.text }
                IrisText { font.pixelSize: Math.round((voiceSize) / Math.max(1, IrisStyle.typeScale)); text: Translation.tr("Control Center"); font.weight: IrisStyle.weight(Font.DemiBold) }
            }
            RowLayout {
                spacing: Math.round(8 * lightRoot.d)
                Repeater {
                    model: ["wifi", "bluetooth", "dark_mode"]
                    Rectangle {
                        required property string modelData
                        required property int index
                        implicitWidth: Math.round(38 * lightRoot.d)
                        implicitHeight: implicitWidth
                        radius: IrisStyle.pieceRadius(implicitWidth)
                        color: index === 0 ? IrisStyle.accent : IrisStyle.fill
                        MaterialSymbol { anchors.centerIn: parent; text: parent.modelData; fill: 1; iconSize: Math.round(18 * lightRoot.d); color: parent.index === 0 ? IrisStyle.inkOnAccent : IrisStyle.text }
                    }
                }
            }
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: Math.round(26 * lightRoot.d)
                radius: IrisStyle.capsule(height)
                color: IrisStyle.fill
                Rectangle { width: parent.width * 0.62; height: parent.height; radius: height / 2; color: IrisStyle.fillActive }
            }
            Item { Layout.fillHeight: true }
        }
    }
    Caption {
        glyph: lightRoot.aura === "off" ? "light_off" : "light_mode"
        text: (lightRoot.aura === "off" ? Translation.tr("Light off")
            : (lightRoot.aura === "vivid" ? Translation.tr("Vivid") : Translation.tr("Subtle")) + " · " + Translation.tr("reach %1%").arg(Math.round(lightRoot.reach)))
            + " · " + (lightRoot.glow > 0 ? Translation.tr("shadows glow %1%").arg(Math.round(lightRoot.glow)) : Translation.tr("dark shadows"))
    }
}
