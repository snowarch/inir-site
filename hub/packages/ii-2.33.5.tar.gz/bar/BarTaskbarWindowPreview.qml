pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions

// Window preview tile for bar-embedded taskbar popup
// Matches DockWindowPreview behavior
Button {
    id: root

    required property var toplevel
    // Whether the preview is on screen: only then does the window stream.
    property bool live: false
    padding: 6
    Layout.fillHeight: true

    signal windowActivated()

    onClicked: {
        root.windowActivated()
        if (CompositorService.isNiri && root.toplevel?.niriWindowId) {
            NiriService.focusWindow(root.toplevel.niriWindowId)
        } else {
            root.toplevel?.activate()
        }
    }

    background: Rectangle {
        radius: Appearance.inirEverywhere ? (Appearance.inir?.roundingSmall ?? 8) : Appearance.rounding.small
        color: root.down
            ? ColorUtils.transparentize(Appearance.inirEverywhere ? Appearance.inir?.colPrimary ?? Appearance.colors.colPrimary : Appearance.colors.colPrimary, 0.7)
            : (root.hovered
                ? ColorUtils.transparentize(Appearance.inirEverywhere ? Appearance.inir?.colLayer2Hover ?? Appearance.colors.colSurfaceContainerHigh : Appearance.colors.colSurfaceContainerHigh, 0.5)
                : "transparent")

        Behavior on color {
            ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
        }
    }

    contentItem: ColumnLayout {
        spacing: 6

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: false
            spacing: 6

            IconImage {
                id: appIcon
                Layout.alignment: Qt.AlignVCenter
                source: {
                    const appId = root.toplevel?.appId ?? "";
                    const de = AppSearch.lookupDesktopEntry(appId);
                    const icon = de?.icon || AppSearch.guessIcon(appId);
                    const resolved = IconThemeService.smartIconName(icon, appId);
                    if (resolved.startsWith("/") || resolved.startsWith("file://")) {
                        return resolved.startsWith("file://") ? resolved : `file://${resolved}`;
                    }
                    return Quickshell.iconPath(resolved, "application-x-executable");
                }
                implicitSize: 16
                mipmap: true
                smooth: true
            }

            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true
                implicitHeight: closeButton.implicitHeight

                StyledText {
                    anchors.fill: parent
                    anchors.rightMargin: closeButton.visible ? closeButton.width + 4 : 0
                    text: root.toplevel?._sourceToplevel?.title
                        ?? root.toplevel?.title
                        ?? ""
                    elide: Text.ElideRight
                    font.pixelSize: Appearance.font.pixelSize.small
                    color: Appearance.inirEverywhere
                        ? (Appearance.inir?.colText ?? Appearance.colors.colOnLayer0)
                        : Appearance.colors.colOnLayer0
                    verticalAlignment: Text.AlignVCenter
                }
            }

            RippleButton {
                id: closeButton
                opacity: root.hovered ? 1 : 0
                visible: opacity > 0
                implicitWidth: 20
                implicitHeight: 20
                buttonRadius: Appearance.rounding.full
                Behavior on opacity {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
                colBackground: "transparent"
                colBackgroundHover: ColorUtils.transparentize(Appearance.colors.colError, 0.8)
                colRipple: ColorUtils.transparentize(Appearance.colors.colError, 0.6)

                onClicked: root.toplevel?.close()

                contentItem: MaterialSymbol {
                    text: "close"
                    iconSize: 14
                    color: root.hovered
                        ? Appearance.colors.colError
                        : (Appearance.inirEverywhere ? Appearance.inir?.colTextSecondary ?? Appearance.colors.colSubtext : Appearance.colors.colSubtext)
                }
            }
        }

        Item {
            id: previewArea
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: 4
            Layout.topMargin: 0
            implicitWidth: 140
            implicitHeight: 90

            readonly property int windowId: CompositorService.isNiri
                ? (root.toplevel?.niriWindowId ?? root.toplevel?.id ?? 0)
                : (root.toplevel?.id ?? 0)
            property string previewUrl: ""

            Rectangle {
                id: shimmerBg
                anchors.fill: parent
                radius: Appearance.rounding.small
                color: Appearance.inirEverywhere
                    ? (Appearance.inir?.colLayer1 ?? Appearance.colors.colSurfaceContainerLow)
                    : Appearance.colors.colSurfaceContainerLow
                visible: windowPreview.status !== Image.Ready && !liveShot.streaming

                Rectangle {
                    id: shimmer
                    width: parent.width * 0.4
                    height: parent.height
                    x: -width
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: "transparent" }
                        GradientStop { position: 0.5; color: ColorUtils.transparentize(Appearance.colors.colOnLayer0, 0.92) }
                        GradientStop { position: 1.0; color: "transparent" }
                    }

                    SequentialAnimation on x {
                        running: shimmerBg.visible
                        loops: Animation.Infinite
                        NumberAnimation {
                            from: -shimmer.width
                            to: shimmerBg.width
                            duration: 1200
                            easing.type: Easing.InOutQuad
                        }
                        PauseAnimation { duration: 400 }
                    }
                }
            }

            IconImage {
                anchors.centerIn: parent
                source: appIcon.source
                implicitSize: Math.min(48, parent.width * 0.4)
                opacity: windowPreview.status === Image.Ready || liveShot.streaming ? 0 : 0.7
                mipmap: true
                smooth: true

                Behavior on opacity {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
            }

            Image {
                id: windowPreview
                source: previewArea.previewUrl
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                smooth: true
                mipmap: true
                anchors.fill: parent
                anchors.margins: 2
                // The preview file is a full-resolution window capture; decoding it
                // natively for a thumbnail this size costs megabytes per hovered
                // window. 2x the drawn size keeps it crisp under mipmap.
                sourceSize.width: Math.max(1, Math.round(windowPreview.width * 2))
                sourceSize.height: Math.max(1, Math.round(windowPreview.height * 2))
                opacity: status === Image.Ready && !liveShot.streaming ? 1 : 0

                Behavior on opacity {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }

                layer.enabled: true
                layer.effect: OpacityMask {
                    maskSource: Rectangle {
                        width: windowPreview.width
                        height: windowPreview.height
                        radius: Appearance.rounding.small
                    }
                }
            }

            // The window itself, streamed over the still while the preview is open.
            ClippingRectangle {
                anchors.fill: windowPreview
                radius: Appearance.rounding.small
                color: "transparent"
                LiveWindowCapture {
                    id: liveShot
                    anchors.fill: parent
                    windowId: CompositorService.isNiri && previewArea.windowId > 0 ? previewArea.windowId : -1
                    active: root.live
                }
            }

            Connections {
                target: WindowPreviewService
                function onPreviewUpdated(updatedId: int): void {
                    if (updatedId === previewArea.windowId) {
                        previewArea.previewUrl = WindowPreviewService.getPreviewUrl(updatedId)
                    }
                }
                function onCaptureComplete(): void {
                    const url = WindowPreviewService.getPreviewUrl(previewArea.windowId)
                    if (url) previewArea.previewUrl = url
                }
            }

            Component.onCompleted: {
                Qt.callLater(() => {
                    const url = WindowPreviewService.getPreviewUrl(windowId)
                    if (url) previewUrl = url
                })
            }
        }
    }
}
