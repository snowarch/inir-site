import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import QtQuick
import QtQuick.Effects
import Quickshell
import Quickshell.Wayland

LazyLoader {
    id: root

    property Item hoverTarget
    property bool hoverActivates: true
    property bool closeOnOutsideClick: false
    property bool popupHovered: false
    default property Item contentItem
    property real popupBackgroundMargin: 0

    signal requestClose()

    active: root.hoverActivates && hoverTarget && (hoverTarget.containsMouse ?? hoverTarget.buttonHovered ?? false)
    onActiveChanged: {
        if (!root.active)
            root.popupHovered = false;
    }

    // Fullscreen transparent backdrop for Niri to detect clicks outside
    // (same pattern as ContextMenu / SysTrayMenu)
    // Color must be non-zero alpha so the compositor registers it as a surface,
    // but visually invisible — do not use "transparent" (alpha=0 breaks input)
    PanelWindow {
        id: clickOutsideBackdrop
        visible: root.active && root.closeOnOutsideClick
        color: Qt.rgba(0, 0, 0, 1/255)
        exclusiveZone: 0
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.namespace: "quickshell:popup-catcher"
        WlrLayershell.exclusionMode: ExclusionMode.Ignore
        anchors { top: true; bottom: true; left: true; right: true }
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.AllButtons
            onClicked: root.requestClose()
        }
    }

    component: PanelWindow {
        id: popupWindow
        color: "transparent"

        HoverHandler {
            id: popupHoverHandler
            onHoveredChanged: root.popupHovered = hovered
        }

        anchors.left: !(Config.options?.bar?.vertical ?? false) || ((Config.options?.bar?.vertical ?? false) && !(Config.options?.bar?.bottom ?? false))
        anchors.right: (Config.options?.bar?.vertical ?? false) && (Config.options?.bar?.bottom ?? false)
        anchors.top: (Config.options?.bar?.vertical ?? false) || (!(Config.options?.bar?.vertical ?? false) && !(Config.options?.bar?.bottom ?? false))
        anchors.bottom: !(Config.options?.bar?.vertical ?? false) && (Config.options?.bar?.bottom ?? false)

        implicitWidth: popupBackground.implicitWidth + Appearance.sizes.elevationMargin * 2 + root.popupBackgroundMargin
        implicitHeight: popupBackground.implicitHeight + Appearance.sizes.elevationMargin * 2 + root.popupBackgroundMargin

        readonly property real centeredLeft: {
            const margin = Appearance.sizes.elevationMargin
            const base = root.QsWindow?.mapFromItem(
                root.hoverTarget,
                ((root.hoverTarget?.width ?? 0) - popupBackground.implicitWidth) / 2,
                0
            ).x ?? margin
            const maxLeft = Math.max(margin,
                (popupWindow.screen?.width ?? popupBackground.implicitWidth)
                - popupBackground.implicitWidth - margin)
            return Math.max(margin, Math.min(base, maxLeft))
        }

        readonly property real centeredTop: {
            const margin = Appearance.sizes.elevationMargin
            const base = root.QsWindow?.mapFromItem(
                root.hoverTarget,
                0,
                ((root.hoverTarget?.height ?? 0) - popupBackground.implicitHeight) / 2
            ).y ?? margin
            const maxTop = Math.max(margin,
                (popupWindow.screen?.height ?? popupBackground.implicitHeight)
                - popupBackground.implicitHeight - margin)
            return Math.max(margin, Math.min(base, maxTop))
        }

        mask: Region {
            item: popupBackground
        }

        exclusionMode: ExclusionMode.Ignore
        exclusiveZone: 0
        margins {
            left: {
                if (!(Config.options?.bar?.vertical ?? false))
                    return popupWindow.centeredLeft
                return Appearance.sizes.verticalBarWidth
            }
            top: {
                if (!(Config.options?.bar?.vertical ?? false)) return Appearance.sizes.barHeight;
                return popupWindow.centeredTop
            }
            right: Appearance.sizes.verticalBarWidth
            bottom: Appearance.sizes.barHeight
        }
        WlrLayershell.namespace: "quickshell:popup"
        WlrLayershell.layer: WlrLayer.Overlay

        StyledRectangularShadow {
            target: popupBackground
        }

        Rectangle {
            id: popupBackground
            readonly property real margin: 10

            property bool _shown: false
            Component.onCompleted: _shown = true

            opacity: _shown ? 1 : 0
            scale: _shown ? 1.0 : 0.88
            transformOrigin: (Config.options?.bar?.bottom ?? false) ? Item.Bottom : Item.Top

            Behavior on opacity {
                enabled: Appearance.animationsEnabled
                NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
            }
            Behavior on scale {
                enabled: Appearance.animationsEnabled
                NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
            }
            anchors {
                fill: parent
                leftMargin: Appearance.sizes.elevationMargin + root.popupBackgroundMargin * (!popupWindow.anchors.left)
                rightMargin: Appearance.sizes.elevationMargin + root.popupBackgroundMargin * (!popupWindow.anchors.right)
                topMargin: Appearance.sizes.elevationMargin + root.popupBackgroundMargin * (!popupWindow.anchors.top)
                bottomMargin: Appearance.sizes.elevationMargin + root.popupBackgroundMargin * (!popupWindow.anchors.bottom)
            }
            implicitWidth: root.contentItem.implicitWidth + margin * 2
            implicitHeight: root.contentItem.implicitHeight + margin * 2
            color: Appearance.regaliaEverywhere ? Appearance.regalia.bg2
                : Appearance.angelEverywhere ? Appearance.angel.colGlassPopup
                : Appearance.inirEverywhere ? Appearance.inir.colLayer2
                : Appearance.colors.colSurfaceContainer
            radius: Appearance.regaliaEverywhere ? Appearance.regalia.roundNormal
                : Appearance.angelEverywhere ? Appearance.angel.roundingNormal
                : Appearance.inirEverywhere ? Appearance.inir.roundingNormal : Appearance.rounding.small
            children: [root.contentItem]

            border.width: Appearance.regaliaEverywhere ? 0 : 1
            border.color: Appearance.angelEverywhere ? Appearance.angel.colBorder
                : Appearance.inirEverywhere ? Appearance.inir.colBorder 
                : Appearance.colors.colLayer0Border
        }

        
    }
}
