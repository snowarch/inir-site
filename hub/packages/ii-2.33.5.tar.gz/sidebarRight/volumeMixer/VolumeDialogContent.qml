import qs
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs.modules.shared.overlay.sidebarRight.volumeMixer as SharedMixer

ColumnLayout {
    id: root
    required property bool isSink
    required property bool dialogShown
    // By name, so a row keeps its place between openings: PipeWire lists streams in the order they last reshuffled.
    readonly property list<var> appPwNodes: (isSink ? MprisController.mixerAppNodes : Audio.inputAppNodes).slice()
        .sort((a, b) => MprisController.streamDisplayName(a).localeCompare(MprisController.streamDisplayName(b)))
    readonly property list<var> devices: isSink ? Audio.outputDevices : Audio.inputDevices
    readonly property bool hasApps: appPwNodes.length > 0
    readonly property var currentDevice: isSink ? Audio.defaultSink : Audio.source
    spacing: 16

    // PipeWire reshuffles its nodes when a stream comes or goes, and the app list reads empty for a moment (measured
    // 2026-10-20: two apps, then none, then one, within 20 ms). The empty state waits for the list to stay empty, or it
    // flashes over the rows and fades out.
    property bool emptyShown: !hasApps
    onHasAppsChanged: {
        if (hasApps) {
            emptyShown = false
            emptyWait.stop()
        } else {
            emptyWait.restart()
        }
    }
    Timer {
        id: emptyWait
        interval: 300
        onTriggered: root.emptyShown = !root.hasApps
    }


    onDialogShownChanged: {
        if (!dialogShown && devicePopup.visible)
            devicePopup.close()
    }

    // Device selector button
    RippleButton {
        id: deviceButton
        Layout.fillWidth: true
        Layout.topMargin: 8
        implicitHeight: 48
        
        colBackground: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
            : Appearance.auroraEverywhere ? "transparent" : Appearance.colors.colLayer2
        colBackgroundHover: Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
            : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurfaceHover : Appearance.colLayer2Hover
        colRipple: Appearance.angelEverywhere ? Appearance.angel.colGlassCardActive
            : Appearance.auroraEverywhere ? Appearance.aurora.colSubSurfaceActive : Appearance.colLayer2Active
        buttonRadius: Appearance.rounding.normal

        contentItem: RowLayout {
            anchors {
                fill: parent
                leftMargin: 16
                rightMargin: 16
            }
            spacing: 12

            MaterialSymbol {
                text: root.isSink ? "speaker" : "mic"
                iconSize: 24
                color: Appearance.colors.colPrimary
            }

            StyledText {
                Layout.fillWidth: true
                text: Audio.friendlyDeviceName(root.currentDevice) || (root.isSink ? Translation.tr("Select output...") : Translation.tr("Select input..."))
                font.pixelSize: Appearance.font.pixelSize.normal
                elide: Text.ElideRight
            }

            MaterialSymbol {
                text: devicePopup.visible ? "expand_less" : "expand_more"
                iconSize: Appearance.font.pixelSize.normal
                color: Appearance.colSecondaryActionIcon
            }
        }

        // Opens on press; a press that just closed it (outside the popup) only closes.
        downAction: () => { if (devicePopup.visible) devicePopup.close(); else if (Date.now() - devicePopup.closedAt > 250) devicePopup.open() }
    }

    // Device selection popup
    Popup {
        id: devicePopup
        property double closedAt: 0
        onClosed: devicePopup.closedAt = Date.now()
        y: deviceButton.y + deviceButton.height + 4
        width: deviceButton.width
        height: Math.min(250, deviceList.contentHeight + 16)
        padding: 8

        background: Rectangle {
            color: Appearance.angelEverywhere ? Appearance.angel.colGlassPopup
                : Appearance.auroraEverywhere ? Appearance.aurora.colPopupSurface : Appearance.colors.colLayer2
            radius: Appearance.angelEverywhere ? Appearance.angel.roundingNormal : Appearance.rounding.normal
            border.width: Appearance.angelEverywhere ? Appearance.angel.cardBorderWidth : 1
            border.color: Appearance.angelEverywhere ? Appearance.angel.colCardBorder
                : Appearance.auroraEverywhere ? Appearance.aurora.colTooltipBorder : Appearance.colors.colOutlineVariant
        }

        ListView {
            id: deviceList
            anchors.fill: parent
            clip: true
            spacing: 4
            model: root.devices

            delegate: RippleButton {
                required property var modelData
                required property int index
                width: deviceList.width
                implicitHeight: 44

                property bool isSelected: modelData.id === root.currentDevice?.id

                colBackground: isSelected ? Appearance.colors.colPrimaryContainer : "transparent"
                colBackgroundHover: Appearance.colLayer2Hover
                colRipple: Appearance.colLayer2Active
                buttonRadius: Appearance.rounding.small

                contentItem: RowLayout {
                    anchors {
                        fill: parent
                        leftMargin: 12
                        rightMargin: 12
                    }
                    spacing: 8

                    MaterialSymbol {
                        text: isSelected ? "check" : (root.isSink ? "speaker" : "mic")
                        iconSize: Appearance.font.pixelSize.normal
                        color: isSelected ? Appearance.colors.colOnPrimaryContainer : Appearance.colSecondaryActionIcon
                    }

                    StyledText {
                        Layout.fillWidth: true
                        text: Audio.friendlyDeviceName(modelData)
                        font.pixelSize: Appearance.font.pixelSize.normal
                        elide: Text.ElideRight
                        color: isSelected ? Appearance.colors.colOnPrimaryContainer : Appearance.colors.colOnSurface
                    }
                }

                onClicked: {
                    if (root.isSink) Audio.setDefaultSink(modelData)
                    else Audio.setDefaultSource(modelData)
                    devicePopup.close()
                }
            }
        }
    }

    // Apps list
    DialogSectionListView {
        Layout.fillHeight: true
        topMargin: 14

        model: ScriptModel {
            values: root.appPwNodes
        }
        delegate: SharedMixer.VolumeMixerEntry {
            anchors {
                left: parent?.left
                right: parent?.right
            }
            required property var modelData
            node: modelData
            flat: true
            capture: !root.isSink
        }
        MaterialPlaceholderMessage {
            anchors.centerIn: parent
            maximumWidth: 320
            shown: root.emptyShown
            icon: "widgets"
            text: Translation.tr("No applications")
            explanation: root.isSink
                ? Translation.tr("Apps playing audio will appear here")
                : Translation.tr("Apps using the microphone will appear here")
            shape: MaterialShape.Shape.Clover4Leaf
        }
    }

    component DialogSectionListView: StyledListView {
        Layout.fillWidth: true
        Layout.topMargin: -22
        Layout.bottomMargin: -16
        Layout.leftMargin: -Appearance.rounding.large
        Layout.rightMargin: -Appearance.rounding.large
        topMargin: 12
        bottomMargin: 12
        leftMargin: 20
        rightMargin: 20

        clip: true
        spacing: 4
        animateAppearance: false
        // A mixer lists from the top. Holding the current row in the middle (a picker's strict range) pushed the first
        // app halfway down the dialog and the last one out of sight.
    }
}
