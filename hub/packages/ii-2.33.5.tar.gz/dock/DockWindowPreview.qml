pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions

Button {
    id: root

    required property var toplevel
    property real previewWidthConstraint: 200
    property real previewHeightConstraint: 110
    // Whether the preview is on screen: only then does the window stream.
    property bool live: false
    padding: 6
    Layout.fillHeight: true

    // Emitted BEFORE focus IPC so the popup can close instantly
    signal windowActivated()
    // Emitted when the user closes a window from the preview
    signal windowCloseClicked()

    onClicked: {
        root.windowActivated()
        if (CompositorService.isNiri && root.toplevel?.niriWindowId) {
            NiriService.focusWindow(root.toplevel.niriWindowId)
        } else {
            root.toplevel?.activate()
        }
    }

    background: Rectangle {
        id: background
        radius: Appearance.regaliaEverywhere ? Appearance.regalia.roundSmall
            : Appearance.inirEverywhere ? (Appearance.inir?.roundingSmall ?? 8) : Appearance.rounding.small
        color: Appearance.regaliaEverywhere ? "transparent"
            : root.down
                ? ColorUtils.transparentize(Appearance.inirEverywhere ? Appearance.inir?.colPrimary ?? Appearance.colors.colPrimary : Appearance.colors.colPrimary, 0.7)
                : (root.hovered
                    ? ColorUtils.transparentize(Appearance.inirEverywhere ? Appearance.inir?.colLayer2Hover ?? Appearance.colors.colSurfaceContainerHigh : Appearance.colors.colSurfaceContainerHigh, 0.5)
                    : "transparent")
        RegaliaControlFace {
            anchors.fill: parent
            visible: Appearance.regaliaEverywhere && (root.hovered || root.down)
            fillColor: root.down ? Appearance.regalia.controlPlateActive
                : Appearance.regalia.controlPlateHover
            radius: background.radius
        }

        // ZZZ console-plate identity: a hairline edge on interaction.
        border.width: Appearance.zzzEverywhere && (root.hovered || root.down) ? Appearance.zzz.borderThick : 0
        border.color: Appearance.zzz.hairlineStrong

        Behavior on color {
            ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
        }
    }

    contentItem: ColumnLayout {
        id: contentItem
        anchors.fill: parent
        anchors.margins: root.padding
        spacing: 6

        RowLayout {
            Layout.fillWidth: true
            Layout.fillHeight: false
            spacing: 6

            IconImage {
                id: appIcon
                Layout.alignment: Qt.AlignVCenter
                source: {
                    const appId = AppSearch.resolveWindowIdentity(root.toplevel);
                    const de = AppSearch.lookupDesktopEntry(appId);
                    const icon = de?.icon || AppSearch.guessIcon(appId);
                    const resolved = IconThemeService.smartIconName(icon, appId);
                    if (resolved.startsWith("/") || resolved.startsWith("file://")) {
                        return resolved.startsWith("file://") ? resolved : `file://${resolved}`;
                    }
                    return Quickshell.iconPath(resolved, "application-x-executable");
                }
                implicitSize: 16
                mipmap: true
                smooth: true
            }

            Item {
                id: appTitleContainer
                Layout.fillWidth: true
                Layout.fillHeight: true
                implicitHeight: closeButton.implicitHeight

                StyledText {
                    id: appTitleText
                    anchors.fill: parent
                    anchors.rightMargin: closeButton.visible ? closeButton.width + 4 : 0
                    text: root.toplevel?._sourceToplevel?.title
                        ?? root.toplevel?.title
                        ?? ""
                    elide: Text.ElideRight
                    font.pixelSize: Appearance.font.pixelSize.small
                    color: Appearance.inirEverywhere 
                        ? (Appearance.inir?.colText ?? Appearance.colors.colOnLayer0)
                        : Appearance.colors.colOnLayer0
                    verticalAlignment: Text.AlignVCenter
                }
            }

            RippleButton {
                id: closeButton
                opacity: root.hovered ? 1 : 0
                visible: opacity > 0
                implicitWidth: 20
                implicitHeight: 20
                buttonRadius: Appearance.rounding.full
                Behavior on opacity {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
                colBackground: "transparent"
                colBackgroundHover: ColorUtils.transparentize(Appearance.colors.colError, 0.8)
                colRipple: ColorUtils.transparentize(Appearance.colors.colError, 0.6)
                
                onClicked: {
                    root.windowCloseClicked()
                    if (CompositorService.isNiri && root.toplevel?.niriWindowId) {
                        NiriService.closeWindow(root.toplevel.niriWindowId)
                    } else {
                        root.toplevel?.close()
                    }
                }

                contentItem: MaterialSymbol {
                    text: "close"
                    iconSize: 14
                    color: root.hovered 
                        ? Appearance.colors.colError
                        : (Appearance.inirEverywhere ? Appearance.inir?.colTextSecondary ?? Appearance.colors.colSubtext : Appearance.colors.colSubtext)
                }
            }
        }

        Item {
            id: previewArea
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.margins: 4
            Layout.topMargin: 0
            implicitWidth: 140
            implicitHeight: 90

            // Prefer niriWindowId for Niri compositor
            readonly property int windowId: CompositorService.isNiri
                ? (root.toplevel?.niriWindowId ?? root.toplevel?.id ?? 0)
                : (root.toplevel?.id ?? 0)
            readonly property string previewUrl: WindowPreviewService.getPreviewUrl(windowId)
            property bool hasDisplayedPreview: false

            // Loading shimmer effect
            Rectangle {
                id: shimmerBg
                anchors.fill: parent
                radius: Appearance.regaliaEverywhere ? Appearance.regalia.roundSmall : Appearance.rounding.small
                color: Appearance.regaliaEverywhere ? Appearance.regalia.bg1
                    : Appearance.inirEverywhere
                        ? (Appearance.inir?.colLayer1 ?? Appearance.colors.colSurfaceContainerLow)
                        : Appearance.colors.colSurfaceContainerLow
                visible: true

                Rectangle {
                    id: shimmer
                    visible: !previewArea.hasDisplayedPreview
                        && previewArea.previewUrl.length === 0 && !liveShot.streaming
                    width: parent.width * 0.4
                    height: parent.height
                    x: -width
                    gradient: Gradient {
                        orientation: Gradient.Horizontal
                        GradientStop { position: 0.0; color: "transparent" }
                        GradientStop { position: 0.5; color: ColorUtils.transparentize(Appearance.colors.colOnLayer0, 0.92) }
                        GradientStop { position: 1.0; color: "transparent" }
                    }

                    SequentialAnimation on x {
                        running: shimmer.visible
                        loops: Animation.Infinite
                        NumberAnimation {
                            from: -shimmer.width
                            to: shimmerBg.width
                            duration: 1200
                            easing.type: Easing.InOutQuad
                        }
                        PauseAnimation { duration: 400 }
                    }
                }
            }

            // Preview image
            Image {
                id: windowPreview
                source: previewArea.previewUrl
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                retainWhileLoading: true
                smooth: true
                mipmap: true
                anchors.fill: parent
                anchors.margins: 2
                // The preview file is a full-resolution window capture; decoding it
                // natively for a thumbnail this size costs megabytes per hovered
                // window. 2x the drawn size keeps it crisp under mipmap.
                sourceSize.width: Math.max(1, Math.round(windowPreview.width * 2))
                sourceSize.height: Math.max(1, Math.round(windowPreview.height * 2))
                opacity: previewArea.previewUrl.length > 0 && !liveShot.streaming ? 1 : 0

                onStatusChanged: {
                    if (status === Image.Ready)
                        previewArea.hasDisplayedPreview = true
                }

                layer.enabled: true
                layer.effect: OpacityMask {
                    maskSource: Rectangle {
                        width: windowPreview.width
                        height: windowPreview.height
                        radius: Appearance.rounding.small
                    }
                }
            }

            // The window itself, streamed over the still while the preview is open.
            ClippingRectangle {
                anchors.fill: windowPreview
                radius: Appearance.rounding.small
                color: "transparent"
                LiveWindowCapture {
                    id: liveShot
                    anchors.fill: parent
                    windowId: previewArea.windowId || -1
                    active: root.live
                }
            }

        }
    }
}
