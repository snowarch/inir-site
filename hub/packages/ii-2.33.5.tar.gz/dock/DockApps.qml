import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.services
import Qt5Compat.GraphicalEffects
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Wayland

Item {
    id: root
    property bool _sortingConsumerAcquired: false

    // Debug logging gated behind QS_DEBUG env var (project convention)
    function _log(...args): void {
        if (Quickshell.env("QS_DEBUG") === "1") console.log("[DockDrag]", ...args);
    }

    property real maxWindowPreviewHeight: 200
    property real maxWindowPreviewWidth: 300
    property real windowControlsHeight: 30
    property real buttonPadding: 5
    property bool vertical: false
    property string dockPosition: "bottom"
    readonly property string surfaceDialect: Appearance.surfaceDialectFor(
        Config.options?.dock?.style === "island" ? "island" : "")
    readonly property bool zzzStyle: surfaceDialect === "zzz"
    readonly property bool inirStyle: surfaceDialect === "inir"
    readonly property bool pillStyle: Config.options?.dock?.style === "pill" && !zzzStyle
    readonly property bool macosStyle: Config.options?.dock?.style === "macos" && !zzzStyle

    // Propagated hovered index for neighbor magnify in macOS style
    property int macHoveredIndex: -1

    // Deferred reset — avoids the race where buttonHovered=false of the old
    // item arrives after buttonHovered=true of the new item.
    Timer {
        id: macHoverResetTimer
        interval: 32   // one frame — enough for the new hover to fire first
        repeat: false
        onTriggered: root.macHoveredIndex = -1
    }

    property Item lastHoveredButton
    property bool buttonHovered: false
    property bool contextMenuPending: false
    property Item contextMenuSourceButton: null
    property var pendingContextMenuModel: []
    property real contextMenuAnchorX: 0
    property real contextMenuAnchorY: 0
    property real contextMenuAnchorWidth: 1
    property real contextMenuAnchorHeight: 1
    readonly property bool contextMenuOpen: contextMenuPending || dockContextMenu.active
    property bool requestDockShow: dockPreviewPopup.visible || contextMenuOpen || dragActive

    // Track which button has its preview visible (for macOS hover persistence)
    readonly property Item previewAnchorItem: dockPreviewPopup.visible ? dockPreviewPopup.anchorItem : null

    // Flag to suppress the automatic click() that RippleButton fires after release.
    // Set true when a drag ends so the subsequent onClicked is ignored.
    property bool _suppressNextClick: false

    // Function to show the new preview popup (Waffle-style)
    function showPreviewPopup(appEntry: var, button: Item): void {
        // Respect hoverPreview setting
        if (Config.options?.dock?.hoverPreview === false || contextMenuOpen || dragActive)
            return
        dockPreviewPopup.show(appEntry, button)
    }

    function requestContextMenu(button: Item, model: var): void {
        if (!button || dragActive)
            return

        const anchorPoint = button.mapToItem(root, 0, 0)
        contextMenuAnchorX = anchorPoint.x
        contextMenuAnchorY = anchorPoint.y
        contextMenuAnchorWidth = Math.max(1, button.width)
        contextMenuAnchorHeight = Math.max(1, button.height)
        contextMenuSourceButton = button
        pendingContextMenuModel = model ?? []
        contextMenuPending = true

        // A hover preview is a separate xdg-popup. Unmap it before creating the
        // menu so Wayland never reparents the menu to the old popup grabber.
        dockPreviewPopup.close()
        if (dockContextMenu.active)
            dockContextMenu.active = false

        Qt.callLater(() => root._openPendingContextMenu())
    }

    function _openPendingContextMenu(): void {
        if (!contextMenuPending || dragActive || !contextMenuSourceButton) {
            contextMenuPending = false
            pendingContextMenuModel = []
            contextMenuSourceButton = null
            return
        }
        dockContextMenu.model = pendingContextMenuModel
        dockContextMenu.requestOpen()
        contextMenuPending = false
        Qt.callLater(() => {
            if (dockContextMenu.active)
                dockContextMenu.updateAnchor()
        })
    }

    function closeContextMenu(immediate: bool): void {
        contextMenuPending = false
        pendingContextMenuModel = []
        contextMenuSourceButton = null
        if (!dockContextMenu.active)
            return
        if (immediate)
            dockContextMenu.active = false
        else
            dockContextMenu.close()
    }

    Layout.fillHeight: !vertical
    Layout.fillWidth: vertical
    implicitWidth: listView.contentWidth
    implicitHeight: listView.contentHeight

    // ─── Drag & Drop State ───────────────────────────────────────────────
    readonly property bool dragEnabled: Config.options?.dock?.enableDragReorder ?? true
    property bool dragActive: false
    property int dragIndex: -1           // Index of item being dragged in dockItems
    property int dropTargetIndex: -1     // Index where the item would be dropped
    property string dragAppId: ""        // AppId of the item being dragged
    property real dragStartX: 0          // Mouse position at drag start (in listView coords)
    property real dragStartY: 0
    property real dragCurrentX: 0        // Current mouse position (in listView coords)
    property real dragCurrentY: 0

    // Retain the last drag offsets for a single frame after drop to avoid the reverse snap
    property bool dropSettlingActive: false
    property string dropSettleId: ""
    property int dropSettleIndex: -1
    property real dropSettleOffsetX: 0
    property real dropSettleOffsetY: 0

    // How far mouse must move during long-press before it's cancelled
    readonly property real dragThreshold: 18

    // Calculate displacement for each item during drag using actual delegate sizes
    function getDragDisplacement(itemIndex: int): real {
        if (!dragActive || dragIndex < 0 || dropTargetIndex < 0) return 0
        if (itemIndex === dragIndex) return 0 // Dragged item uses its own transform

        // Get the actual size of the dragged item from the ListView
        const draggedItem = listView.itemAtIndex(dragIndex)
        // Use actual delegate size; fallback matches DockButton.implicitHeight
        const step = draggedItem
            ? (vertical ? draggedItem.height : draggedItem.width) + listView.spacing
            : 50 + listView.spacing

        // Items between dragIndex and dropTargetIndex need to shift
        if (dragIndex < dropTargetIndex) {
            // Dragging right/down: items in (dragIndex, dropTargetIndex] shift left/up
            if (itemIndex > dragIndex && itemIndex <= dropTargetIndex) {
                return -step
            }
        } else if (dragIndex > dropTargetIndex) {
            // Dragging left/up: items in [dropTargetIndex, dragIndex) shift right/down
            if (itemIndex >= dropTargetIndex && itemIndex < dragIndex) {
                return step
            }
        }
        return 0
    }

    function startDrag(index: int, appId: string, globalX: real, globalY: real): void {
        if (!dragEnabled) return

        // Close any previews or context menus
        dockPreviewPopup.close()
        closeContextMenu(true)

        dragIndex = index
        dragAppId = appId
        dragStartX = globalX
        dragStartY = globalY
        dragCurrentX = globalX
        dragCurrentY = globalY
        dropTargetIndex = index
        dragActive = true
        _log(`START index=${index} appId=${appId} pos=(${globalX.toFixed(0)},${globalY.toFixed(0)})`)
    }

    function updateDrag(globalX: real, globalY: real): void {
        if (!dragActive || dragIndex < 0) return
        dragCurrentX = globalX
        dragCurrentY = globalY

        // Use actual delegate positions from the ListView for accurate hit-testing
        const count = dockItems.length
        if (count === 0) return

        let bestIndex = dropTargetIndex // Keep current if nothing found
        let bestDist = Infinity

        for (let i = 0; i < count; i++) {
            const item = listView.itemAtIndex(i)
            if (!item) continue

            // Get center position of the delegate in listView coordinates
            const midX = item.x + item.width / 2
            const midY = item.y + item.height / 2

            const dist = vertical
                ? Math.abs(globalY - midY)
                : Math.abs(globalX - midX)

            if (dist < bestDist) {
                bestDist = dist
                bestIndex = i
            }
        }

        // Skip separator as a drop target – snap to nearest non-separator neighbor
        if (bestIndex >= 0 && bestIndex < count && dockItems[bestIndex].appId === "SEPARATOR") {
            // Decide direction based on drag movement
            const movingForward = vertical ? (globalY > dragStartY) : (globalX > dragStartX)
            if (movingForward && bestIndex + 1 < count) bestIndex++
            else if (!movingForward && bestIndex - 1 >= 0) bestIndex--
        }

        if (dropTargetIndex !== bestIndex) {
            _log(`UPDATE dropTarget=${bestIndex} (was ${dropTargetIndex})`)
        }
        dropTargetIndex = bestIndex
    }

    function endDrag(): void {
        if (!dragActive) return

        // Keep the current drag offset so the item stays in place while the model reorders
        const draggedItem = dockItems[dragIndex]
        dropSettleId = draggedItem?.uniqueId ?? dragAppId
        dropSettleIndex = dragIndex
        // Keep offsets at zero so the item “stays put” with animations off
        dropSettleOffsetX = 0
        dropSettleOffsetY = 0
        dropSettlingActive = true

        _log(`END dragIndex=${dragIndex} dropTarget=${dropTargetIndex} reorder=${dragIndex !== dropTargetIndex}`)
        if (dragIndex >= 0 && dropTargetIndex >= 0 && dragIndex !== dropTargetIndex) {
            _applyReorder(dragIndex, dropTargetIndex)
        }

        _resetDragState(false)
        // Clear settle offsets on the next tick, after the model/layout updates
        dropSettleResetTimer.restart()
    }

    function cancelDrag(): void {
        _resetDragState(true)
    }

    function _resetDragState(clearDropSettle = true): void {
        dragActive = false
        dragIndex = -1
        dropTargetIndex = -1
        dragAppId = ""
        dragStartX = 0
        dragStartY = 0
        dragCurrentX = 0
        dragCurrentY = 0
        if (clearDropSettle) {
            dropSettleResetTimer.stop()
            dropSettlingActive = false
            dropSettleId = ""
            dropSettleIndex = -1
            dropSettleOffsetX = 0
            dropSettleOffsetY = 0
        }
    }

    Timer {
        id: dropSettleResetTimer
        interval: 2
        repeat: false
        onTriggered: {
            dropSettlingActive = false
            dropSettleId = ""
            dropSettleIndex = -1
            dropSettleOffsetX = 0
            dropSettleOffsetY = 0
        }
    }

    function _applyReorder(fromIdx: int, toIdx: int): void {
        const fromItem = dockItems[fromIdx]
        const toItem = dockItems[toIdx]

        if (!fromItem || !toItem) return

        const fromAppId = fromItem.originalAppId ?? fromItem.appId
        const toAppId = toItem.originalAppId ?? toItem.appId

        // Skip separator targets
        if (toAppId === "SEPARATOR" || fromAppId === "SEPARATOR") return

        const fromIsRunning = (fromItem.toplevels?.length ?? 0) > 0
        const toIsRunning = (toItem.toplevels?.length ?? 0) > 0
        let pinnedApps = [...(Config.options?.dock?.pinnedApps ?? [])]

        const fromIsPinned = fromItem.pinned
        const toIsPinned = toItem.pinned

        // Running-order drag is only authoritative in the separated running
        // section. In combined mode, pinned items must keep using pinnedApps so
        // their persistent identity/order is not replaced by ephemeral state.
        if (fromIsRunning && toIsRunning
                && (root.separatePinnedFromRunning || (!fromIsPinned && !toIsPinned))) {
            const fromRunningId = fromAppId.toLowerCase()
            const toRunningId = toAppId.toLowerCase()
            const fromRunningIdx = _runningAppOrder.indexOf(fromRunningId)
            const toRunningIdx = _runningAppOrder.indexOf(toRunningId)
            if (fromRunningIdx >= 0 && toRunningIdx >= 0) {
                const [moved] = _runningAppOrder.splice(fromRunningIdx, 1)
                const insertIdx = toRunningIdx
                _runningAppOrder.splice(insertIdx, 0, moved)
                root.rebuildDockItems()
            }
            return
        }

        if (fromIsPinned && toIsPinned) {
            // Both pinned: reorder within pinnedApps
            const realFromIdx = pinnedApps.findIndex(p => p.toLowerCase() === fromAppId.toLowerCase())
            const realToIdx = pinnedApps.findIndex(p => p.toLowerCase() === toAppId.toLowerCase())

            if (realFromIdx >= 0 && realToIdx >= 0) {
                const [moved] = pinnedApps.splice(realFromIdx, 1)
                pinnedApps.splice(realToIdx, 0, moved)
                Config.setNestedValue("dock.pinnedApps", pinnedApps)
            }
        } else if (!fromIsPinned && toIsPinned) {
            // Dragging a running (unpinned) app to pinned section → auto-pin at position
            const realToIdx = pinnedApps.findIndex(p => p.toLowerCase() === toAppId.toLowerCase())
            const insertIdx = toIdx < fromIdx ? realToIdx : realToIdx + 1
            pinnedApps.splice(insertIdx, 0, fromAppId)
            Config.setNestedValue("dock.pinnedApps", pinnedApps)
        } else if (fromIsPinned && !toIsPinned) {
            // Dragging a pinned app to running section → keep it pinned but move to end
            // (no-op for now, pinned order only affects pinned section)
        } else {
            // Both unpinned running apps: no persistent reorder (they're ephemeral)
        }
    }

    // ─── Dock Items Model ────────────────────────────────────────────────
    property var dockItems: []

    // Reactive per-app toplevel map keyed by uniqueId. DockAppButton reads this
    // instead of its modelData snapshot: ScriptModel matches items by uniqueId,
    // so a pinned app going open→closed keeps its delegate and the snapshot
    // would leave a stale running indicator/preview until an unrelated reorder.
    property var toplevelsByUniqueId: ({})

    // Opening order for currently running apps. Entries are removed when the
    // app has no windows, so a later open appends it to the end.
    property var _runningAppOrder: []

    // Direct reactive binding to Config - will automatically trigger when Config changes
    readonly property bool separatePinnedFromRunning: Config.options?.dock?.separatePinnedFromRunning ?? true
    onSeparatePinnedFromRunningChanged: {
        root.rebuildDockItems()
    }

    // Cache compiled regexes - only recompile when config changes
    property var _cachedIgnoredRegexes: []
    // Null forces the system ignore rules to be compiled on the first rebuild
    // even when the user has the default empty ignoredAppRegexes list.
    property var _lastIgnoredRegexStrings: null

    function _getIgnoredRegexes(): list<var> {
        const ignoredRegexStrings = Config.options?.dock?.ignoredAppRegexes ?? [];
        // Check if we need to recompile
        if (JSON.stringify(ignoredRegexStrings) !== JSON.stringify(_lastIgnoredRegexStrings)) {
            const systemIgnored = ["^$", "^portal$", "^x-run-dialog$", "^kdialog$", "^xembedsniproxy$", "^org.freedesktop.impl.portal.*"];
            const allIgnored = ignoredRegexStrings.concat(systemIgnored);
            _cachedIgnoredRegexes = allIgnored.map(pattern => new RegExp(pattern, "i"));
            _lastIgnoredRegexStrings = ignoredRegexStrings.slice();
        }
        return _cachedIgnoredRegexes;
    }

    // ─── Debounce Timer ─────────────────────────────────────────────────
    // Coalesces rapid toplevel/compositor signals into a single rebuild.
    Timer {
        id: rebuildTimer
        interval: 80
        repeat: false
        onTriggered: {
            if (root.enabled)
                root._doRebuildDockItems()
        }
    }

    function rebuildDockItems() {
        if (!root.enabled)
            return
        rebuildTimer.restart()
    }

    function _toplevelLiveKey(toplevel) {
        if (!toplevel) return ""
        if (toplevel._sourceKey !== undefined && toplevel._sourceKey !== null)
            return String(toplevel._sourceKey)
        return `${toplevel.appId || ""}::${toplevel.title || ""}`
    }

    // Skip model update when structure hasn't changed (same apps, order, toplevels).
    // Compare toplevels by stable identifier (sourceKey / appId+title) instead of
    // object reference — sortToplevels() on Niri builds fresh enriched objects on
    // every focus change, so reference comparison would always trigger a rebuild
    // and shake the dock layout for non-structural updates.
    function _dockItemsEqual(oldItems, newItems): bool {
        if (oldItems.length !== newItems.length) return false
        for (let i = 0; i < oldItems.length; i++) {
            const o = oldItems[i], n = newItems[i]
            if (o.uniqueId !== n.uniqueId || o.pinned !== n.pinned || o.section !== n.section) return false
            const oTL = o.toplevels, nTL = n.toplevels
            if (oTL.length !== nTL.length) return false
            for (let j = 0; j < oTL.length; j++) {
                if (root._toplevelLiveKey(oTL[j]) !== root._toplevelLiveKey(nTL[j])) return false
                if (!!oTL[j].activated !== !!nTL[j].activated) return false
            }
        }
        return true
    }

    function _doRebuildDockItems() {
        const pinnedApps = Config.options?.dock?.pinnedApps ?? [];
        const ignoredRegexes = _getIgnoredRegexes();
        const separatePinnedFromRunning = root.separatePinnedFromRunning;

        // Source of truth for what's actually open:
        //   • On Niri: CompositorService.sortedToplevels is built from niri's
        //     authoritative `windows` array, so we trust it absolutely—even when
        //     it's empty (means: no windows). Falling back to ToplevelManager
        //     would resurrect stale Wayland foreign-toplevel handles (ghosts) that
        //     don't release cleanly when an app closes (zen, electron, etc.).
        //   • Off Niri (Hyprland / others): use sorted when populated, fall back
        //     to ToplevelManager only as a last resort. There's no compositor-
        //     authoritative source to validate against on those.
        // Note: on Niri there is a sub-second startup gap where `isNiri` is
        // already true but `windows` (and therefore `sortedToplevels`) is
        // still empty. During that window the dock will be empty even if
        // ToplevelManager already lists handles for apps started before the
        // shell. That's intentional — trusting ToplevelManager during the
        // gap is what brings the ghost-toplevel bug back.
        const tmToplevels = ToplevelManager.toplevels.values;
        const sorted = CompositorService.sortedToplevels;
        const sortedHasItems = sorted && sorted.length > 0;
        const niriAuthoritative = CompositorService.isNiri;
        const allToplevels = niriAuthoritative
            ? (sorted ?? [])
            : (sortedHasItems ? sorted : tmToplevels);

        // Off-Niri ghost guard: when we use enriched `sorted` items, cross-check
        // them against the live ToplevelManager to drop entries that no longer
        // exist there. On Niri this is redundant (sortToplevels already drops
        // ghosts).
        const liveToplevelCounts = new Map();
        const crossCheck = sortedHasItems && !niriAuthoritative;
        if (crossCheck) {
            for (const tl of tmToplevels) {
                const key = root._toplevelLiveKey(tl);
                liveToplevelCounts.set(key, (liveToplevelCounts.get(key) ?? 0) + 1);
            }
        }

        // Build map of running apps (apps with open windows)
        const runningAppsMap = new Map();
        for (const toplevel of allToplevels) {
            if (!toplevel.appId) continue;
            if (toplevel.appId === "" || toplevel.appId === "null") continue;
            if (crossCheck) {
                const key = root._toplevelLiveKey(toplevel);
                const count = liveToplevelCounts.get(key) ?? 0;
                if (count <= 0) continue;
                liveToplevelCounts.set(key, count - 1);
            }
            const effectiveId = AppSearch.resolveWindowIdentity(toplevel);
            const lowerAppId = effectiveId.toLowerCase();

            if (ignoredRegexes.some(re => re.test(effectiveId))) {
                continue;
            }

            if (!runningAppsMap.has(lowerAppId)) {
                runningAppsMap.set(lowerAppId, {
                    appId: effectiveId,
                    toplevels: [],
                    pinned: false
                });
            }
            runningAppsMap.get(lowerAppId).toplevels.push(toplevel);
        }

        // Keep an order independent of focus and compositor layout changes.
        const currentRunning = new Set(runningAppsMap.keys());
        const runningOrder = root._runningAppOrder.filter(appId => currentRunning.has(appId));
        for (const [lowerAppId] of runningAppsMap) {
            if (!runningOrder.includes(lowerAppId))
                runningOrder.push(lowerAppId);
        }
        root._runningAppOrder = runningOrder;

        const values = [];
        let order = 0;

        if (!separatePinnedFromRunning) {
            // Combined mode keeps pinned apps as the canonical item even while
            // running. This preserves their configured desktop identity, pin
            // state and context actions instead of replacing them with a window
            // identity just because a window exists.
            for (const appId of pinnedApps) {
                const lowerAppId = appId.toLowerCase();
                const runningEntry = runningAppsMap.get(lowerAppId);
                if (!runningEntry && !AppSearch.lookupDesktopEntry(appId))
                    continue;
                values.push({
                    uniqueId: "app-" + lowerAppId,
                    appId: lowerAppId,
                    toplevels: runningEntry?.toplevels ?? [],
                    pinned: true,
                    originalAppId: appId,
                    section: "pinned",
                    order: order++
                });
                runningAppsMap.delete(lowerAppId);
            }

            if (values.length > 0 && runningAppsMap.size > 0) {
                values.push({
                    uniqueId: "separator",
                    appId: "SEPARATOR",
                    toplevels: [],
                    pinned: false,
                    originalAppId: "SEPARATOR",
                    section: "separator",
                    order: order++
                });
            }

            // Only unpinned running apps use first-open order in combined mode.
            const running = Array.from(runningAppsMap.entries())
                .sort((a, b) => root._runningAppOrder.indexOf(a[0])
                    - root._runningAppOrder.indexOf(b[0]));
            for (const [lowerAppId, entry] of running) {
                values.push({
                    uniqueId: "app-" + lowerAppId,
                    appId: lowerAppId,
                    toplevels: entry.toplevels,
                    pinned: false,
                    originalAppId: entry.appId,
                    section: "open",
                    order: order++
                });
            }
        } else {
            // NEW BEHAVIOR: Separate pinned-only from running apps
            // 1) Add ONLY pinned apps (without running windows) - left section
            for (const appId of pinnedApps) {
                const lowerAppId = appId.toLowerCase();
                // Only show pinned apps that don't have running windows
                if (!runningAppsMap.has(lowerAppId)) {
                    // Skip pinned apps with no desktop entry
                    if (!AppSearch.lookupDesktopEntry(appId))
                        continue;
                    values.push({
                        uniqueId: "app-" + lowerAppId,
                        appId: lowerAppId,
                        toplevels: [],
                        pinned: true,
                        originalAppId: appId,
                        section: "pinned",
                        order: order++
                    });
                }
            }

            // 2) Add separator if there are both pinned-only apps and running apps
            const hasPinnedOnly = values.length > 0;
            const hasRunning = runningAppsMap.size > 0;

            if (hasPinnedOnly && hasRunning) {
                values.push({
                    uniqueId: "separator",
                    appId: "SEPARATOR",
                    toplevels: [],
                    pinned: false,
                    originalAppId: "SEPARATOR",
                    section: "separator",
                    order: order++
                });
            }

            // 3) Add running apps (right section) - includes pinned apps that are also running
            const sortedRunningApps = [];
            for (const [lowerAppId, entry] of runningAppsMap) {
                sortedRunningApps.push({
                    lowerAppId: lowerAppId,
                    entry: entry
                });
            }
            // Add all running apps in first-open order.
            sortedRunningApps.sort((a, b) => {
                return root._runningAppOrder.indexOf(a.lowerAppId)
                    - root._runningAppOrder.indexOf(b.lowerAppId);
            });

            for (const {lowerAppId, entry} of sortedRunningApps) {
                values.push({
                    uniqueId: "app-" + lowerAppId,
                    appId: lowerAppId,
                    toplevels: entry.toplevels,
                    pinned: pinnedApps.some(p => p.toLowerCase() === lowerAppId),
                    originalAppId: entry.appId,
                    section: "running",
                    order: order++
                });
            }
        }

        // Always refresh the reactive toplevel map, even when the model
        // structure is unchanged — delegates bind to it for live window state.
        const tlMap = {}
        for (const v of values) tlMap[v.uniqueId] = v.toplevels
        root.toplevelsByUniqueId = tlMap

        // Skip update if the model structure is identical — avoids
        // ScriptModel churn and downstream binding re-evaluations.
        if (!_dockItemsEqual(dockItems, values)) {
            dockItems = values
        }
    }

    Connections {
        target: ToplevelManager.toplevels
        enabled: root.enabled
        function onValuesChanged() {
            root.rebuildDockItems()
        }
    }

    Connections {
        target: CompositorService
        enabled: root.enabled
        function onSortedToplevelsChanged() {
            root.rebuildDockItems()
        }
    }

    Connections {
        target: Config.options?.dock
        enabled: root.enabled
        function onPinnedAppsChanged() {
            root.rebuildDockItems()
        }
        function onIgnoredAppRegexesChanged() {
            root.rebuildDockItems()
        }
    }
    Connections {
        target: Config.options?.windows
        enabled: root.enabled
        function onAppIdentityRulesChanged() {
            root.rebuildDockItems()
        }
    }

    function syncSortingDemand(): void {
        if (root.enabled && !_sortingConsumerAcquired) {
            CompositorService.acquireSortingConsumer(root)
            _sortingConsumerAcquired = true
            rebuildDockItems()
        } else if (!root.enabled && _sortingConsumerAcquired) {
            rebuildTimer.stop()
            CompositorService.releaseSortingConsumer(root)
            _sortingConsumerAcquired = false
        }
    }

    onEnabledChanged: syncSortingDemand()
    Component.onCompleted: syncSortingDemand()
    Component.onDestruction: {
        if (_sortingConsumerAcquired)
            CompositorService.releaseSortingConsumer(root)
    }

    StyledListView {
        id: listView
        spacing: root.macosStyle ? 4 : (root.pillStyle ? 6 : 2)
        orientation: root.vertical ? ListView.Vertical : ListView.Horizontal
        anchors {
            top: root.vertical ? undefined : parent.top
            bottom: root.vertical ? undefined : parent.bottom
            left: root.vertical ? parent.left : undefined
            right: root.vertical ? parent.right : undefined
        }
        implicitWidth: contentWidth
        implicitHeight: contentHeight
        interactive: false // Dock should never flick/scroll — all items visible

        // Container resizes organically as apps enter/leave; the orientation-aware
        // delegate transitions below grow/shrink each item in place so the dock
        // never jump-cuts when an app opens or closes.
        Behavior on implicitWidth {
            enabled: Appearance.animationsEnabled
            animation: NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
        }
        Behavior on implicitHeight {
            enabled: Appearance.animationsEnabled
            animation: NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve }
        }

        // ─── Item entrance / exit transitions ───
        // The new/leaving item itself fades+scales in place. Neighbours are
        // intentionally NOT animated (no `displaced` / `move` transitions): the
        // user requested that other dock items don't slide when a new app opens
        // or closes. The container's implicitWidth Behavior above still smooths
        // the overall dock resize, so the layout shifts feel continuous without
        // visible per-item travel. Animations are also suppressed during a
        // manual reorder drag so they never fight the drag transforms.
        readonly property bool _animOk: Appearance.animationsEnabled && !root.dragActive

        add: Transition {
            enabled: listView._animOk
            NumberAnimation { properties: "opacity,scale"; from: 0; to: 1; duration: Appearance.animation.elementMoveEnter.duration; easing.type: Easing.BezierSpline; easing.bezierCurve: Appearance.animationCurves.emphasizedDecel }
        }
        remove: Transition {
            enabled: listView._animOk
            NumberAnimation { properties: "opacity,scale"; to: 0; duration: Appearance.animation.elementMoveExit.duration; easing.type: Appearance.animation.elementMoveExit.type; easing.bezierCurve: Appearance.animation.elementMoveExit.bezierCurve }
        }
        // Neighbour displacement deliberately disabled — see comment above.
        displaced: Transition {}
        addDisplaced: Transition {}
        removeDisplaced: Transition {}
        move: Transition {}
        moveDisplaced: Transition {}

        model: ScriptModel {
            objectProp: "uniqueId"
            values: root.enabled ? root.dockItems : []
        }

          delegate: DockAppButton {
              id: dockDelegate
              required property var modelData
              required property int index
              appToplevel: modelData
              appListRoot: root
              listIndex:   index
              vertical: root.vertical
              dockPosition: root.dockPosition

              anchors.verticalCenter: !root.vertical ? parent?.verticalCenter : undefined
              anchors.horizontalCenter: root.vertical ? parent?.horizontalCenter : undefined

              // Sin insets - el tamaño viene del DockButton
              topInset: 0
              bottomInset: 0
              leftInset: 0
              rightInset: 0

               // ─── macOS neighbor magnify propagation ──────────────────
               onButtonHoveredChanged: {
                   if (root.macosStyle) {
                       if (buttonHovered) {
                           macHoverResetTimer.stop()
                           root.macHoveredIndex = index
                       } else {
                           macHoverResetTimer.restart()
                       }
                   }
               }

            // ─── Drag & Drop Properties ──────────────────────────────
            readonly property bool isBeingDragged: root.dragActive && root.dragIndex === index
            readonly property bool isDropTarget: root.dragActive && root.dropTargetIndex === index && root.dragIndex !== index
            readonly property bool isDropSettling: !isBeingDragged && root.dropSettleId !== "" && root.dropSettleId === appToplevel?.uniqueId
            readonly property real dragDisplacement: root.getDragDisplacement(index)

            // Visual offset when being dragged
            property real _dragOffsetX: isBeingDragged ? (root.dragCurrentX - root.dragStartX) : 0
            property real _dragOffsetY: isBeingDragged ? (root.dragCurrentY - root.dragStartY) : 0

            // Apply displacement transform for non-dragged items during reorder
            transform: Translate {
                id: dockDelegateTranslate
                x: dockDelegate.isBeingDragged
                    ? (root.vertical ? 0 : dockDelegate._dragOffsetX)
                    : dockDelegate.isDropSettling
                        ? (root.vertical ? 0 : root.dropSettleOffsetX)
                        : (root.vertical ? 0 : dockDelegate.dragDisplacement)
                y: dockDelegate.isBeingDragged
                    ? (root.vertical ? dockDelegate._dragOffsetY : 0)
                    : dockDelegate.isDropSettling
                        ? (root.vertical ? root.dropSettleOffsetY : 0)
                        : (root.vertical ? dockDelegate.dragDisplacement : 0)

                Behavior on x {
                    enabled: Appearance.animationsEnabled && !root.dropSettlingActive && !dockDelegate.isBeingDragged && !dockDelegate.isDropSettling
                    NumberAnimation {
                        duration: Appearance.animation.elementResize.duration
                        easing.type: Appearance.animation.elementResize.type
                        easing.bezierCurve: Appearance.animation.elementResize.bezierCurve
                    }
                }
                Behavior on y {
                    enabled: Appearance.animationsEnabled && !root.dropSettlingActive && !dockDelegate.isBeingDragged && !dockDelegate.isDropSettling
                    NumberAnimation {
                        duration: Appearance.animation.elementResize.duration
                        easing.type: Appearance.animation.elementResize.type
                        easing.bezierCurve: Appearance.animation.elementResize.bezierCurve
                    }
                }
            }

            // Elevated z-order when dragging
            z: isBeingDragged ? 100 : 0

            // Scale effect when being dragged
            // Merge active-app highlight scale with drag elevation scale
            // (overrides the base DockAppButton scale property)
              scale: isBeingDragged ? 1.08
                   : (root.macosStyle ? 1.0
                       : (dockDelegate.appIsActive ? 1.05 : 1.0))

            // Dragged item lifts slightly; others dim just enough to signal drag mode
            opacity: isBeingDragged ? 0.8
                   : root.dragActive ? 0.85 : 1.0
            Behavior on opacity {
                enabled: Appearance.animationsEnabled
                NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
            }

            // ─── Insertion line at drop gap ───────────────────────────
            // Thin accent line centered in the gap that displacement opens.
            // Direction-aware: shows at the edge facing the gap so it
            // visually marks the exact insertion point.
            Rectangle {
                id: insertionLine
                visible: dockDelegate.isDropTarget && !dockDelegate.isSeparator
                z: 50

                // Which direction the item is being dragged
                readonly property bool forward: root.dragIndex >= 0
                    && root.dragIndex < root.dropTargetIndex

                // Horizontal dock → vertical line; vertical dock → horizontal line
                width: root.vertical ? (parent.width * 0.55) : 3
                height: root.vertical ? 3 : (parent.height * 0.55)
                radius: 1.5

                // Position: center the line in the spacing gap at the correct edge
                x: root.vertical
                    ? (parent.width - width) / 2
                    : (forward
                        ? parent.width + (listView.spacing - width) / 2
                        : -(listView.spacing + width) / 2)
                y: root.vertical
                    ? (forward
                        ? parent.height + (listView.spacing - height) / 2
                        : -(listView.spacing + height) / 2)
                    : (parent.height - height) / 2

                color: root.zzzStyle ? Appearance.zzz.tertiary
                     : root.inirStyle ? Appearance.inir.colPrimary
                     : Appearance.colors.colPrimary
                Behavior on color {
                    enabled: Appearance.animationsEnabled
                    ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }

                opacity: dockDelegate.isDropTarget ? 0.9 : 0

                Behavior on opacity {
                    enabled: Appearance.animationsEnabled
                    NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                }
            }

            // ─── Drag detection: "prime + move" pattern ──────────────
            // 1. Press  → start short timer (180ms)
            // 2. Timer  → silently "prime" (no visual change)
            // 3. Move after primed → drag starts INSTANTLY
            // 4. Release before moving → normal click
            // This feels snappy because the user is usually already
            // moving when the timer fires, so drag begins at ~180ms.
            property real _pressMouseX: 0
            property real _pressMouseY: 0
            property bool _hasPressPos: false
            property bool _dragPrimed: false      // Timer fired, awaiting movement
            property bool _longPressTriggered: false // Drag actually started

            downAction: event => {
                if (!root.dragEnabled || dockDelegate.isSeparator) return
                _longPressTriggered = false
                _dragPrimed = false
                _pressMouseX = event.x
                _pressMouseY = event.y
                _hasPressPos = true
                _dockPrimeTimer.restart()
            }

            moveAction: (event) => {
                // Only track during an active press, not hover
                if (!dockDelegate.down) return

                if (!_hasPressPos) return

                const dx = event.x - _pressMouseX
                const dy = event.y - _pressMouseY
                const dist2 = dx * dx + dy * dy

                // Before primed: cancel if mouse drifts too far (user is swiping, not holding)
                if (_dockPrimeTimer.running && !_dragPrimed) {
                    if (dist2 > root.dragThreshold * root.dragThreshold) {
                        _dockPrimeTimer.stop()
                    }
                    return
                }

                // Priming alone must never consume a click. Start dragging only
                // after the pointer has crossed the same movement threshold
                // measured from the actual press position.
                if (_dragPrimed && !root.dragActive
                        && dist2 > root.dragThreshold * root.dragThreshold) {
                    _longPressTriggered = true
                    const listPos = dockDelegate.mapToItem(listView, _pressMouseX, _pressMouseY)
                    const appId = dockDelegate.appToplevel?.originalAppId
                        ?? dockDelegate.appToplevel?.appId ?? ""
                    root.startDrag(dockDelegate.index, appId, listPos.x, listPos.y)
                    // Fall through to immediately update with current position
                }

                // Forward mouse position during active drag
                if (root.dragActive && root.dragIndex === dockDelegate.index) {
                    const listPos = dockDelegate.mapToItem(listView, event.x, event.y)
                    root.updateDrag(listPos.x, listPos.y)
                }
            }

            releaseAction: () => {
                _dockPrimeTimer.stop()
                _dragPrimed = false
                if (dockDelegate._longPressTriggered) {
                    // Drag was active — end it and suppress the click()
                    // that RippleButton fires right after releaseAction.
                    if (root.dragActive && root.dragIndex === dockDelegate.index) {
                        root.endDrag()
                    }
                    root._suppressNextClick = true
                    // RippleButton follows releaseAction with click() only for
                    // a normal release. MouseArea cancellation calls the same
                    // releaseAction without that click, so expire the guard if
                    // it was not consumed synchronously.
                    Qt.callLater(() => {
                        if (root._suppressNextClick)
                            root._suppressNextClick = false
                    })
                    dockDelegate._longPressTriggered = false
                }
                _hasPressPos = false
            }

            // A layer-surface/input-region update can cancel the MouseArea grab
            // without the pointer ever leaving this icon. Treat that as the
            // click the user made, but never recover a real drag or a pointer
            // that already left the button.
            cancelAction: () => {
                _dockPrimeTimer.stop()
                _dragPrimed = false
                const recoverClick = _hasPressPos
                    && !_longPressTriggered
                    && !root.dragActive
                    && dockDelegate.buttonHovered
                if (_longPressTriggered && root.dragActive && root.dragIndex === dockDelegate.index)
                    root.endDrag()
                _longPressTriggered = false
                _hasPressPos = false
                if (recoverClick)
                    dockDelegate.click()
            }

            Timer {
                id: _dockPrimeTimer
                interval: 180  // Short: just enough to distinguish from a quick click
                onTriggered: {
                    dockDelegate._dragPrimed = true
                    // No visual change yet — drag starts on first movement
                }
            }

            // Connect hover preview signals
            onHoverPreviewRequested: {
                if (!root.dragActive) {
                    root.showPreviewPopup(appToplevel, this)
                }
            }
            onHoverPreviewDismissed: {
                dockPreviewPopup.close()
            }
        }
    }

    // New Waffle-style preview popup
    DockPreview {
        id: dockPreviewPopup
        dockHovered: root.buttonHovered
        dockPosition: root.dockPosition
    }

    Item {
        id: contextMenuAnchor
        x: root.contextMenuAnchorX
        y: root.contextMenuAnchorY
        width: root.contextMenuAnchorWidth
        height: root.contextMenuAnchorHeight
    }

    DockContextMenu {
        id: dockContextMenu
        anchorItem: contextMenuAnchor
        anchorHovered: root.contextMenuSourceButton?.buttonHovered ?? false
        onActiveChanged: {
            if (!active && !root.contextMenuPending) {
                root.pendingContextMenuModel = []
                root.contextMenuSourceButton = null
            }
        }
    }

}
