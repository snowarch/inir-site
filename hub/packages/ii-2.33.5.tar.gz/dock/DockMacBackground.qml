import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import QtQuick
import QtQuick.Effects
import Qt5Compat.GraphicalEffects as GE

// macOS-style "shelf" — single translucent frosted-glass background.
// Color blending is done in Dock.qml (which already has ColorQuantizer +
// AdaptedMaterialScheme) and passed in as the `blendedLayer0` property.
// This component only handles rendering.
Rectangle {
    id: root

    property real   dockHeight:    70
    property bool   vertical:      false
    property string wallpaperUrl:  ""
    property var    dockScreen:    null
    property bool   nativeBlurActive: false
    property string surfaceDialect: "macos"

    // Pre-computed blended color from Dock.qml's dockVisualBackground.blendedColors
    property color  blendedLayer0: Appearance.colors.colLayer0

    readonly property bool zzzEverywhere: surfaceDialect === "zzz"
    readonly property bool angelEverywhere: surfaceDialect === "angel"
    readonly property bool auroraEverywhere: surfaceDialect === "aurora" || angelEverywhere
    readonly property bool inirEverywhere: surfaceDialect === "inir"
    readonly property bool gameModeMinimal:  Appearance.gameModeMinimal
    readonly property bool editorialGlassActive: Appearance.editorialEverywhere
        && Appearance.editorial.glassActive && !gameModeMinimal
    readonly property bool editorialBackdropReady: editorialGlassActive
        && (root.nativeBlurActive || macBlurWall.status === Image.Ready)

    // ─── Shape ───────────────────────────────────────────────────────
    radius: zzzEverywhere   ? Appearance.zzz.panelRadius
          : angelEverywhere ? Appearance.angel.roundingNormal
          : inirEverywhere  ? Appearance.inir.roundingNormal
          :                   Appearance.rounding.large
    Behavior on radius { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementResize.duration; easing.type: Appearance.animation.elementResize.type; easing.bezierCurve: Appearance.animation.elementResize.bezierCurve } }

    // ─── Fill: genuinely translucent for macOS look ──────────────────
    color: editorialGlassActive
        ? (!editorialBackdropReady ? Appearance.editorial.rail
            : root.nativeBlurActive && !Appearance.editorial.paperStack ? Appearance.editorial.glassRail
            : "transparent")
        : Appearance.editorialEverywhere ? Appearance.editorial.rail : zzzEverywhere
        ? Appearance.zzz.bg0
        : auroraEverywhere
        ? ColorUtils.transparentize(blendedLayer0, 0.18)
        : inirEverywhere
            ? ColorUtils.transparentize(Appearance.inir.colLayer1, 0.28)
            : ColorUtils.transparentize(Appearance.colors.colLayer0, 0.22)

    Behavior on color {
        enabled: Appearance.animationsEnabled
        ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }

    // ─── Border ──────────────────────────────────────────────────────
    border.width: zzzEverywhere ? 1 : (angelEverywhere ? Appearance.angel.panelBorderWidth : 1)
    Behavior on border.width {
        enabled: Appearance.animationsEnabled
        NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }
    border.color: Appearance.editorialEverywhere ? Appearance.editorial.rule : zzzEverywhere
        ? Appearance.zzz.borderColor
        : angelEverywhere
        ? Appearance.angel.colPanelBorder
        : inirEverywhere
            ? ColorUtils.transparentize(Appearance.inir.colBorder, 0.4)
            : ColorUtils.transparentize(Appearance.colors.colLayer0Border, 0.5)

    Behavior on border.color {
        enabled: Appearance.animationsEnabled
        ColorAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
    }

    // ─── Drop shadow ─────────────────────────────────────────────────
    StyledRectangularShadow {
        target: root
        visible: root.visible && !gameModeMinimal && !zzzEverywhere
    }

    // ─── Clip + rounded mask so blur respects corners ─────────────────
    clip: true
    layer.enabled: root.visible && !gameModeMinimal
    layer.effect: GE.OpacityMask {
        maskSource: Rectangle {
            width:  root.width
            height: root.height
            radius: root.radius
        }
    }

    // ─── Blurred wallpaper ────────────────────────────────────────────
    Image {
        id: macBlurWall
        readonly property bool requested: root.visible && !root.gameModeMinimal
            && (!Appearance.editorialEverywhere || root.editorialGlassActive)
            && !root.nativeBlurActive
        visible: requested && status === Image.Ready
        source: requested ? root.wallpaperUrl : ""
        fillMode: Image.PreserveAspectCrop
        cache: true
        sourceSize.width: macBlurWall.scrW
        sourceSize.height: macBlurWall.scrH
        asynchronous: true

        readonly property real scrW: root.dockScreen?.width  ?? 1920
        readonly property real scrH: root.dockScreen?.height ?? 1080
        width:  scrW
        height: scrH

        x: root.vertical ? 0 : (-(scrW / 2) + root.width  / 2)
        y: root.vertical
            ? (-(scrH / 2) + root.height / 2)
            : (-(scrH)     + root.height + Appearance.sizes.hyprlandGapsOut)

        // See #159 — skip QML blur when compositor blur covers this layer
        layer.enabled: root.visible && Appearance.effectsEnabled
            && !root.gameModeMinimal && !root.nativeBlurActive
        layer.effect: MultiEffect {
            source: macBlurWall
            anchors.fill: source
            contrast: Appearance.aurora.backdropContrast
            brightness: Appearance.aurora.backdropBrightness
            saturation: root.angelEverywhere
                ? (Appearance.angel.blurSaturation * Appearance.angel.colorStrength)
                : root.editorialGlassActive ? 0.04
                : (Appearance.effectsEnabled ? (Appearance.auroraEverywhere ? Appearance.aurora.backdropSaturation : 0.35) : 0)
            blurEnabled: Appearance.effectsEnabled
            blurMax: 64
            blur: Appearance.effectsEnabled
                ? (root.angelEverywhere ? Appearance.angel.blurIntensity
                    : root.editorialGlassActive ? Appearance.editorial.glassBlur : 0.9)
                : 0
        }

        // Tinted overlay — lighter than the standard panel
        Rectangle {
            anchors.fill: parent
            color: root.angelEverywhere
                ? ColorUtils.transparentize(
                      root.blendedLayer0,
                      Appearance.angel.overlayOpacity * Appearance.angel.panelTransparentize * 0.7)
                : root.editorialGlassActive
                    ? (Appearance.editorial.paperStack ? "transparent" : Appearance.editorial.glassRail)
                : ColorUtils.transparentize(
                      root.blendedLayer0,
                      (Appearance.aurora.overlayTransparentize ?? 0.5) * 0.65)
        }
    }

    EditorialPaperStack {
        anchors.fill: parent
        faceColor: Appearance.editorial.rail
        radius: root.radius
        materialOpacity: root.editorialBackdropReady ? Appearance.editorial.glassOpacity : 1
        backingOpacity: root.editorialBackdropReady ? Appearance.editorial.glassBackingOpacity : 1
    }

    // ─── Angel partial border highlight ──────────────────────────────
    AngelPartialBorder {
        visible: angelEverywhere
        targetRadius: root.radius
    }
}
