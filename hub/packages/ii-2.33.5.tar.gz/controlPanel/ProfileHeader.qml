pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Qt5Compat.GraphicalEffects as GE
import qs
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions

Item {
    id: root
    implicitHeight: 56
    Layout.fillWidth: true
    
    readonly property bool inirEverywhere: Appearance.inirEverywhere
    readonly property bool auroraEverywhere: Appearance.auroraEverywhere

    readonly property string greeting: {
        const hour = DateTime.clock.hours
        if (hour < 5) return Translation.tr("Good Night")
        if (hour < 12) return Translation.tr("Good Morning")
        if (hour < 18) return Translation.tr("Good Afternoon")
        return Translation.tr("Good Evening")
    }

    function openAccountSettings(): void {
        AppLauncher.launch("manageUser")
        GlobalStates.controlPanelOpen = false
    }

    function lockScreen(): void {
        GlobalStates.controlPanelOpen = false
        Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "lock", "activate"])
    }

    RowLayout {
        anchors.fill: parent
        spacing: 12

        // Avatar - themed circle with border using OpacityMask
        Item {
            id: avatarContainer
            Layout.preferredWidth: 48
            Layout.preferredHeight: 48

            // Cookie mode keeps the photo familiar and uses one organic frame,
            // avoiding a second animated mask on the image itself.
            CookieFace {
                anchors.fill: parent
                visible: Appearance.cookieEverywhere
                role: "badge"
                selected: true
                color: Appearance.colors.colPrimaryContainer
            }
            Rectangle {
                anchors.fill: parent
                visible: !Appearance.cookieEverywhere
                radius: width / 2
                color: "transparent"
                border.width: 2
                border.color: Appearance.angelEverywhere ? Appearance.angel.colPrimary
                            : root.inirEverywhere ? Appearance.inir.colPrimary
                            : root.auroraEverywhere ? Appearance.colors.colPrimary
                            : Appearance.colors.colPrimary
            }

            // Avatar with OpacityMask for proper circular clipping
            Item {
                anchors.centerIn: parent
                width: 42
                height: 42

                Rectangle {
                    id: avatarMask
                    anchors.fill: parent
                    radius: width / 2
                    visible: false
                }

                Image {
                    id: avatarImg
                    anchors.fill: parent
                    source: profileAvatarResolver.resolvedSource
                    fillMode: Image.PreserveAspectCrop
                    asynchronous: true
                    cache: true
                    smooth: true
                    mipmap: true
                    sourceSize.width: 84
                    sourceSize.height: 84
                    opacity: status === Image.Ready ? 1 : 0
                    visible: opacity > 0
                    Behavior on opacity {
                        enabled: Appearance.animationsEnabled
                        NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                    }
                    layer.enabled: status === Image.Ready
                    layer.effect: GE.OpacityMask {
                        maskSource: avatarMask
                    }
                }

                // Reactive avatar resolver — retries fallback paths without breaking bindings
                QtObject {
                    id: profileAvatarResolver
                    property int avatarIndex: 0
                    readonly property string resolvedSource: Directories.avatarSourceAt(avatarIndex)

                    readonly property string primaryWatch: Directories.userAvatarSourcePrimary
                    onPrimaryWatchChanged: avatarIndex = 0

                    readonly property int imgStatus: avatarImg.status
                    onImgStatusChanged: {
                        if (imgStatus === Image.Error) {
                            const nextIdx = avatarIndex + 1
                            if (nextIdx < Directories.userAvatarPaths.length)
                                avatarIndex = nextIdx
                        }
                    }
                }
                
                // Fallback
                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                    color: Appearance.angelEverywhere ? Appearance.angel.colGlassCard
                         : root.inirEverywhere ? Appearance.inir.colLayer2 
                         : root.auroraEverywhere ? Appearance.aurora.colSubSurface
                         : Appearance.colors.colLayer2
                    opacity: avatarImg.status !== Image.Ready ? 1 : 0
                    visible: opacity > 0
                    Behavior on opacity {
                        enabled: Appearance.animationsEnabled
                        NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Appearance.animation.elementMoveFast.type; easing.bezierCurve: Appearance.animation.elementMoveFast.bezierCurve }
                    }

                    MaterialSymbol {
                        anchors.centerIn: parent
                        text: "person"
                        iconSize: 22
                        color: Appearance.angelEverywhere ? Appearance.angel.colPrimary
                             : root.inirEverywhere ? Appearance.inir.colPrimary 
                             : root.auroraEverywhere ? Appearance.colors.colPrimary
                             : Appearance.colors.colPrimary
                    }
                }
            }
        }

        // Text
        ColumnLayout {
            spacing: 0
            StyledText {
                text: root.greeting
                font.pixelSize: Appearance.font.pixelSize.smaller
                color: Appearance.angelEverywhere ? Appearance.angel.colPrimary
                     : root.inirEverywhere ? Appearance.inir.colPrimary 
                     : root.auroraEverywhere ? Appearance.colors.colPrimary
                     : Appearance.colors.colPrimary
            }
            StyledText {
                text: SystemInfo.displayName || SystemInfo.username
                font.pixelSize: Appearance.font.pixelSize.normal
                font.weight: Font.Medium
                font.capitalization: Font.Capitalize
                color: Appearance.angelEverywhere ? Appearance.angel.colText
                     : root.inirEverywhere ? Appearance.inir.colText 
                     : root.auroraEverywhere ? Appearance.colors.colOnSurface
                     : Appearance.colors.colOnLayer0
            }
        }

        Item { Layout.fillWidth: true }

        // Action Buttons
        RowLayout {
            spacing: 4

            RippleButton {
                implicitWidth: 32
                implicitHeight: 32
                buttonRadius: Appearance.angelEverywhere ? Appearance.angel.roundingSmall
                            : root.inirEverywhere ? Appearance.inir.roundingSmall : Appearance.rounding.full
                colBackground: "transparent"
                colBackgroundHover: Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                                  : root.inirEverywhere ? Appearance.inir.colLayer2Hover 
                                  : root.auroraEverywhere ? Appearance.aurora.colSubSurfaceHover
                                  : Appearance.colors.colLayer2Hover
                onClicked: root.lockScreen()
                contentItem: MaterialSymbol { 
                    anchors.centerIn: parent
                    text: "lock"
                    iconSize: 18
                    color: Appearance.angelEverywhere ? Appearance.angel.colText
                         : root.inirEverywhere ? Appearance.inir.colText 
                         : root.auroraEverywhere ? Appearance.colors.colOnSurface
                         : Appearance.colors.colOnLayer0
                }
                StyledToolTip { text: Translation.tr("Lock") }
            }

            RippleButton {
                implicitWidth: 32
                implicitHeight: 32
                buttonRadius: Appearance.angelEverywhere ? Appearance.angel.roundingSmall
                            : root.inirEverywhere ? Appearance.inir.roundingSmall : Appearance.rounding.full
                colBackground: "transparent"
                colBackgroundHover: Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                                  : root.inirEverywhere ? Appearance.inir.colLayer2Hover 
                                  : root.auroraEverywhere ? Appearance.aurora.colSubSurfaceHover
                                  : Appearance.colors.colLayer2Hover
                onClicked: root.openAccountSettings()
                contentItem: MaterialSymbol {
                    anchors.centerIn: parent
                    text: "manage_accounts"
                    iconSize: 18
                    color: Appearance.angelEverywhere ? Appearance.angel.colText
                         : root.inirEverywhere ? Appearance.inir.colText
                         : root.auroraEverywhere ? Appearance.colors.colOnSurface
                         : Appearance.colors.colOnLayer0
                }
                StyledToolTip { text: Translation.tr("Manage my account") }
            }

            RippleButton {
                implicitWidth: 32
                implicitHeight: 32
                buttonRadius: Appearance.angelEverywhere ? Appearance.angel.roundingSmall
                            : root.inirEverywhere ? Appearance.inir.roundingSmall : Appearance.rounding.full
                colBackground: "transparent"
                colBackgroundHover: Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                                  : root.inirEverywhere ? Appearance.inir.colLayer2Hover 
                                  : root.auroraEverywhere ? Appearance.aurora.colSubSurfaceHover
                                  : Appearance.colors.colLayer2Hover
                onClicked: {
                    GlobalStates.controlPanelOpen = false
                    GlobalStates.sessionOpen = true
                }
                contentItem: MaterialSymbol { 
                    anchors.centerIn: parent
                    text: "power_settings_new"
                    iconSize: 18
                    color: root.inirEverywhere ? Appearance.inir.colError ?? Appearance.colors.colError
                         : root.auroraEverywhere ? Appearance.colors.colError
                         : Appearance.colors.colError 
                }
                StyledToolTip { text: Translation.tr("Power") }
            }
            
            RippleButton {
                implicitWidth: 32
                implicitHeight: 32
                buttonRadius: Appearance.angelEverywhere ? Appearance.angel.roundingSmall
                            : root.inirEverywhere ? Appearance.inir.roundingSmall : Appearance.rounding.full
                colBackground: "transparent"
                colBackgroundHover: Appearance.angelEverywhere ? Appearance.angel.colGlassCardHover
                                  : root.inirEverywhere ? Appearance.inir.colLayer2Hover 
                                  : root.auroraEverywhere ? Appearance.aurora.colSubSurfaceHover
                                  : Appearance.colors.colLayer2Hover
                onClicked: GlobalStates.controlPanelOpen = false
                contentItem: MaterialSymbol { 
                    anchors.centerIn: parent
                    text: "close"
                    iconSize: 18
                    color: Appearance.angelEverywhere ? Appearance.angel.colTextSecondary
                         : root.inirEverywhere ? Appearance.inir.colTextSecondary 
                         : root.auroraEverywhere ? Appearance.colors.colOutline
                         : Appearance.colors.colSubtext
                }
                StyledToolTip { text: Translation.tr("Close") }
            }
        }
    }

}
