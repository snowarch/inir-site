pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import Quickshell
import Quickshell.Services.SystemTray
import Quickshell.Bluetooth
import Quickshell.Widgets
import qs
import qs.services
import qs.services.deferred
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.iris.style
import qs.modules.iris.components
import qs.modules.iris.pieces
import qs.modules.iris.bar
import qs.modules.iris.bar.island
import qs.modules.iris.sidebar
import qs.modules.iris.state

Item {
    id: root

    property string kind: ""
    property string screenName: ""
    property bool contentActive: true
    readonly property real d: IrisStyle.density
    // The card's body (IrisStage sets both): every plate on its edge rounds by what the inset leaves of the body's corner,
    // so the band between them is as wide round the curve as along the sides (DI29).
    property real bodyRadius: IrisStyle.radiusSheet
    property real bodyInset: IrisStyle.cardPad
    readonly property real edgeInset: root.bleeds ? 0 : root.bodyInset
    readonly property real plateRadius: IrisStyle.concentric(root.bodyRadius, root.edgeInset, IrisStyle.radiusRow)
    // The pickers' rows reach 6 px past the content's edge.
    readonly property real listRadius: IrisStyle.concentric(root.bodyRadius, root.edgeInset - 6 * root.d, IrisStyle.radiusRow)
    readonly property bool bleeds: ["weather", "notifications", "media", "visualizer"].includes(root.kind)
        || root.kind === "media" || root.kind === "calendar"
    readonly property real contentHeight: body.item?.implicitHeight ?? 0
    readonly property color light: {
        switch (root.kind) {
        case "weather": return IrisStyle.skyLight(Icons.getWeatherIcon(Weather.data.wCode, Weather.isNightNow()) ?? "")
        case "sound": return IrisStyle.identity.indigo
        case "mic": return IrisStyle.identity.orange
        case "tools": return IrisStyle.secondaryAccent
        case "tray": return IrisStyle.identity.teal
        case "calendar": return IrisStyle.identity.red
        case "media":
        case "visualizer": return "transparent"
        case "network": return IrisStyle.identity.blue
        case "bluetooth": return IrisStyle.identity.sky
        case "vitals": return IrisStyle.identity.teal
        case "workspaces": return IrisStyle.identity.purple
        case "updates": return IrisStyle.secondaryAccent
        case "anime": return IrisStyle.identity.pink
        case "watching": return IrisStyle.identity.pink
        case "shellUpdate": return IrisStyle.secondaryAccent
        case "vpn": return IrisStyle.identity.green
        default: return IrisStyle.wallpaperLight
        }
    }
    signal navigate()
    function close(): void { root.navigate() }

    implicitHeight: root.contentHeight

    Loader {
        id: body
        width: root.width
        active: root.kind.length > 0
        sourceComponent: {
            switch (root.kind) {
            case "weather": return weatherCard
            case "notifications": return notificationsCard
            case "calendar": return calendarCard
            case "sound": return soundCard
            case "mic": return micCard
            case "tools": return toolsCard
            case "tray": return trayCard
            case "media":
            case "visualizer": return mediaCard
            case "network": return networkCard
            case "bluetooth": return bluetoothCard
            case "vitals": return vitalsCard
            case "workspaces": return workspacesCard
            case "updates": return updatesCard
            case "anime": return animeCard
            case "watching": return watchingCard
            case "shellUpdate": return shellUpdateCard
            case "vpn": return vpnCard
            default: return null
            }
        }
    }

    component VpnRow: MouseArea {
        id: vpnRow
        property string label: ""
        property string detail: ""
        property bool on: false
        signal toggled()
        implicitHeight: Math.round(42 * root.d)
        cursorShape: Qt.PointingHandCursor
        hoverEnabled: true
        enabled: !Vpn.busy
        Accessible.role: Accessible.CheckBox
        Accessible.name: vpnRow.label
        Accessible.checked: vpnRow.on
        onClicked: vpnRow.toggled()
        Rectangle {
            anchors.fill: parent
            radius: root.plateRadius
            color: vpnRow.containsMouse ? IrisStyle.fillHover : IrisStyle.fillQuiet
            Behavior on color { ColorAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
        }
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: Math.round(12 * root.d)
            anchors.rightMargin: Math.round(10 * root.d)
            spacing: 10 * root.d
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 0
                IrisText {
                    Layout.fillWidth: true
                    text: vpnRow.label
                    elide: Text.ElideRight
                    // On, the connection's name reads first; off, it steps back (SYSTEM.md §4). Green stays on the switch.
                    color: vpnRow.on ? IrisStyle.text : IrisStyle.textSecondary
                    font.pixelSize: IrisStyle.typeLabel
                    font.weight: IrisStyle.weight(vpnRow.on ? Font.DemiBold : Font.Medium)
                }
                IrisText {
                    Layout.fillWidth: true
                    visible: vpnRow.detail.length > 0
                    text: vpnRow.detail
                    color: IrisStyle.textSecondary
                    elide: Text.ElideRight
                    font.pixelSize: IrisStyle.typeFootnote
                }
            }
            Rectangle {
                implicitWidth: Math.round(38 * root.d)
                implicitHeight: Math.round(22 * root.d)
                radius: IrisStyle.capsule(height)
                color: vpnRow.on ? IrisStyle.identity.green : IrisStyle.fillHover
                Behavior on color { ColorAnimation { duration: IrisStyle.duration(140); easing.type: IrisStyle.feedbackEasing } }
                Rectangle {
                    y: Math.round(3 * root.d)
                    x: vpnRow.on ? parent.width - width - Math.round(3 * root.d) : Math.round(3 * root.d)
                    width: parent.height - Math.round(6 * root.d)
                    height: width
                    radius: IrisStyle.capsule(width)
                    color: IrisStyle.onTint
                    Behavior on x { NumberAnimation { duration: IrisStyle.duration(140); easing.type: IrisStyle.feedbackEasing } }
                }
            }
        }
    }

    // One fact of a connection: its name quiet on the left, the value on the right; a tap copies it.
    component VpnFact: MouseArea {
        id: fact
        property string label: ""
        property string value: ""
        property string shown: fact.value
        property string glyph: "content_copy"
        signal copy(string value)
        implicitHeight: Math.round(28 * root.d)
        hoverEnabled: true
        cursorShape: fact.value.length > 0 ? Qt.PointingHandCursor : Qt.ArrowCursor
        visible: fact.value.length > 0
        onClicked: fact.copy(fact.value)
        Accessible.role: Accessible.Button
        Accessible.name: fact.label + " " + fact.shown
        Rectangle {
            anchors.fill: parent
            radius: IrisStyle.concentric(root.plateRadius, 4 * root.d, IrisStyle.radiusChip)
            color: fact.containsMouse ? IrisStyle.fillHover : ColorUtils.applyAlpha(IrisStyle.fillHover, 0)
            Behavior on color { ColorAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
        }
        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: Math.round(10 * root.d)
            anchors.rightMargin: Math.round(8 * root.d)
            spacing: Math.round(8 * root.d)
            IrisText {
                text: fact.label
                color: IrisStyle.muted
                font.pixelSize: IrisStyle.typeMeta
            }
            IrisText {
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignRight
                text: fact.shown
                elide: Text.ElideMiddle
                font.pixelSize: IrisStyle.typeMeta
                font.features: ({ "tnum": 1 })
            }
            MaterialSymbol {
                visible: fact.glyph.length > 0
                text: fact.glyph
                iconSize: Math.round(14 * root.d)
                color: IrisStyle.muted
                opacity: fact.containsMouse ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
            }
        }
    }
    // A connection's facts rest on one quiet fill under its row.
    component VpnFacts: Rectangle {
        default property alias facts: factColumn.data
        implicitHeight: factColumn.implicitHeight + Math.round(8 * root.d)
        radius: root.plateRadius
        color: IrisStyle.fillQuiet
        ColumnLayout {
            id: factColumn
            anchors.fill: parent
            anchors.margins: Math.round(4 * root.d)
            spacing: 0
        }
    }

    component SectionCard: IrisSidebarSection {
        bare: true
        plateRadius: root.plateRadius
        expanded: true
        contentActive: root.contentActive
        onNavigate: root.close()
    }


    readonly property var cardOptions: Config.options?.iris?.appearance?.surfaces?.cards ?? ({})
    component LevelCard: ColumnLayout {
        id: level
        property bool input: false
        readonly property bool muted: level.input ? Audio.micMuted : (Audio.sink?.audio?.muted ?? false)
        readonly property real value: Math.min(1, (level.input ? Audio.micVolume : Audio.value) ?? 0)
        spacing: 12 * root.d
        CardHeader {
            visible: root.cardOptions?.header ?? true
            glyph: level.input ? "mic" : "volume_up"
            tint: level.input ? IrisStyle.identity.orange : IrisStyle.identity.indigo
            title: level.input ? Translation.tr("Microphone") : Translation.tr("Sound")
            detail: Audio.friendlyDeviceName(level.input ? Audio.source : Audio.defaultSink)
            IrisNumber {
                text: Math.round(level.value * 100) + "%"
                // The level is the head's figure: it reads before the device under the title.
                color: level.muted ? IrisStyle.textTertiary : IrisStyle.text
                pixelSize: IrisStyle.typeHeadline
                weight: IrisStyle.figureWeight
            }
        }
        IrisCapsuleSlider {
            Layout.fillWidth: true
            implicitHeight: Math.round(48 * root.d)
            muted: level.muted
            icon: level.input ? (level.muted ? "mic_off" : "mic")
                : level.muted ? "volume_off" : level.value < 0.34 ? "volume_mute" : level.value < 0.67 ? "volume_down" : "volume_up"
            value: level.value
            Accessible.name: level.input ? Translation.tr("Microphone") : Translation.tr("Volume")
            onMoved: next => level.input ? Audio.setSourceVolume(next) : Audio.setSinkVolume(next)
            onIconClicked: level.input ? Audio.toggleMicMute() : Audio.toggleMute()
        }
        IrisDeviceList {
            rowRadius: root.listRadius
            visible: root.cardOptions?.devices ?? true
            Layout.fillWidth: true
            Layout.leftMargin: -6 * root.d
            Layout.rightMargin: -6 * root.d
            outputs: !level.input
            inputs: level.input
        }
    }

    Component {
        id: weatherCard
        SectionCard { kind: "weather" }
    }
    Component {
        id: notificationsCard
        SectionCard { kind: "notifications" }
    }
    Component {
        id: calendarCard
        SectionCard { kind: "calendar" }
    }
    Component {
        id: soundCard
        ColumnLayout {
            spacing: 6 * root.d
            LevelCard { Layout.fillWidth: true }
            SectionCard {
                visible: root.cardOptions?.mixer ?? true
                Layout.fillWidth: true
                Layout.leftMargin: -14 * root.d
                Layout.rightMargin: -14 * root.d
                plateRadius: IrisStyle.concentric(root.bodyRadius, root.edgeInset - 14 * root.d, IrisStyle.radiusRow)
                kind: "mixer"
            }
        }
    }
    Component {
        id: micCard
        LevelCard { input: true }
    }
    Component {
        id: toolsCard
        ColumnLayout {
            spacing: 14 * root.d
            CardHeader {
                glyph: "timer"
                tint: IrisStyle.identity.orange
                title: Translation.tr("Timers")
                detail: TimerService.countdownRunning || TimerService.pomodoroRunning || TimerService.stopwatchRunning
                    ? Translation.tr("Running") : Translation.tr("Tap a dial to start, scroll to adjust")
            }
            IrisTools {
                Layout.fillWidth: true
                onActivityRequested: { root.close(); IrisState.islandPageRequest = "activity" }
            }
        }
    }
    Component {
        id: trayCard
        ColumnLayout {
            id: tray
            readonly property var items: SystemTray.items.values.filter(item => item && item.id
                && (!(Config.options?.iris?.tray?.hidePassive ?? false) || item.status !== Status.Passive))
            spacing: 12 * root.d
            CardHeader {
                glyph: "apps"
                tint: IrisStyle.identity.teal
                title: Translation.tr("Tray")
                detail: tray.items.length > 0 ? Translation.tr("%1 background apps").arg(tray.items.length) : Translation.tr("Background apps")
            }
            IrisTray { Layout.fillWidth: true; showHeader: false; items: tray.items }
        }
    }

    Component {
        id: networkCard
        ColumnLayout {
            spacing: 10 * root.d
            CardHeader {
                glyph: Network.ethernet ? "lan" : Network.wifiEnabled ? "wifi" : "wifi_off"
                tint: IrisStyle.identity.blue
                title: Translation.tr("Network")
                detail: Network.ethernet ? Translation.tr("Ethernet")
                    : !Network.wifiEnabled ? Translation.tr("Wi-Fi off")
                    : Network.networkName.length > 0 ? Network.networkName : Translation.tr("Not connected")
                IrisIconButton {
                    materialIcon: "refresh"
                    enabled: Network.wifiEnabled
                    Accessible.name: Translation.tr("Scan for networks")
                    onClicked: Network.rescanWifi()
                }
                IrisIconButton {
                    materialIcon: Network.wifiEnabled ? "wifi" : "wifi_off"
                    selected: Network.wifiEnabled
                    Accessible.name: Translation.tr("Wi-Fi")
                    onClicked: Network.toggleWifi()
                }
            }
            IrisNetworkList {
                rowRadius: root.listRadius
                Layout.fillWidth: true
                Layout.leftMargin: -6 * root.d
                Layout.rightMargin: -6 * root.d
            }
        }
    }
    Component {
        id: bluetoothCard
        ColumnLayout {
            spacing: 10 * root.d
            CardHeader {
                glyph: BluetoothStatus.enabled ? "bluetooth" : "bluetooth_disabled"
                tint: IrisStyle.identity.sky
                title: Translation.tr("Bluetooth")
                detail: BluetoothStatus.activeDeviceSummary() || (BluetoothStatus.enabled
                    ? Translation.tr("Nothing connected") : Translation.tr("Off"))
                IrisIconButton {
                    materialIcon: BluetoothStatus.enabled ? "bluetooth" : "bluetooth_disabled"
                    selected: BluetoothStatus.enabled
                    enabled: BluetoothStatus.available
                    Accessible.name: Translation.tr("Bluetooth")
                    onClicked: if (Bluetooth.defaultAdapter) Bluetooth.defaultAdapter.enabled = !Bluetooth.defaultAdapter.enabled
                }
            }
            // What is connected and has a battery, as a headset's controllers show theirs: an open gauge each, the
            // device inside it, its charge in figures under it, red once it runs low.
            RowLayout {
                id: charges
                readonly property var devices: (Bluetooth.devices?.values ?? []).filter(device => device?.connected && device?.batteryAvailable).slice(0, 4)
                function glyphOf(icon: string): string {
                    return /headset|headphone|audio-card|earbud/i.test(icon) ? "headphones"
                        : /mouse/i.test(icon) ? "mouse" : /keyboard/i.test(icon) ? "keyboard"
                        : /phone/i.test(icon) ? "smartphone" : /gaming|joystick|gamepad/i.test(icon) ? "sports_esports"
                        : /watch/i.test(icon) ? "watch" : /speaker/i.test(icon) ? "speaker" : "bluetooth"
                }
                visible: charges.devices.length > 0
                Layout.fillWidth: true
                Layout.topMargin: 2 * root.d
                spacing: 8 * root.d
                Repeater {
                    model: charges.devices
                    ColumnLayout {
                        id: charge
                        required property var modelData
                        readonly property real level: Math.max(0, Math.min(1, Number(charge.modelData.battery) || 0))
                        readonly property color tint: charge.level <= 0.2 ? IrisStyle.danger : IrisStyle.identity.purple
                        Layout.fillWidth: true
                        spacing: 2 * root.d
                        Accessible.name: String(charge.modelData.name ?? "") + ", " + Math.round(charge.level * 100) + "%"
                        ProgressRing {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.preferredWidth: Math.round(66 * root.d)
                            Layout.preferredHeight: Layout.preferredWidth
                            sweep: 270
                            stroke: Math.max(4, 6 * root.d)
                            tint: charge.tint
                            progress: charge.level
                            Behavior on progress { NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.OutCubic } }
                            MaterialSymbol {
                                anchors.centerIn: parent
                                text: charges.glyphOf(String(charge.modelData.icon ?? ""))
                                fill: 1
                                iconSize: Math.round(26 * root.d)
                                color: IrisStyle.text
                            }
                        }
                        Metric {
                            Layout.alignment: Qt.AlignHCenter
                            Layout.topMargin: -12 * root.d
                            value: Math.round(charge.level * 100)
                            unit: "%"
                            pixelSize: IrisStyle.typeHeadline
                            weight: IrisStyle.figureWeight
                            color: IrisStyle.text
                        }
                        IrisText {
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            text: String(charge.modelData.name ?? "")
                            color: IrisStyle.textTertiary
                            font.pixelSize: IrisStyle.typeFootnote
                            elide: Text.ElideRight
                        }
                    }
                }
            }
            IrisBluetoothList {
                rowRadius: root.listRadius
                Layout.fillWidth: true
                Layout.leftMargin: -6 * root.d
                Layout.rightMargin: -6 * root.d
            }
        }
    }
    Component {
        id: vitalsCard
        ColumnLayout {
            id: vitalsBody
            spacing: 10 * root.d
            ResourceUsageMonitor { target: vitalsBody; active: root.contentActive }
            CardHeader {
                glyph: "monitoring"
                tint: IrisStyle.identity.teal
                title: Translation.tr("Vitals")
                detail: Translation.tr("What this machine is doing")
            }
            // Four open rings, staggered like a streak's (the Apple Watch way): each its glyph inside, its reading under
            // it in its colour; a reading past its warning turns the ring red.
            Item {
                id: rings
                readonly property var vitals: [
                    { label: Translation.tr("Processor"), glyph: "memory", level: ResourceUsage.cpuUsage, value: Math.round(ResourceUsage.cpuUsage * 100), unit: "%", warn: 0.85, tint: IrisStyle.identity.green },
                    { label: Translation.tr("Memory"), glyph: "memory_alt", level: ResourceUsage.memoryUsedPercentage, value: Math.round(ResourceUsage.memoryUsedPercentage * 100), unit: "%", warn: 0.85, tint: IrisStyle.identity.yellow },
                    { label: Translation.tr("Heat"), glyph: "device_thermostat", level: ResourceUsage.tempPercentage, value: ResourceUsage.maxTemp, unit: "°", warn: ResourceUsage.tempWarningThreshold / 100, tint: IrisStyle.identity.orange },
                    { label: Translation.tr("Disk"), glyph: "hard_drive", level: ResourceUsage.diskUsedPercentage, value: Math.round(ResourceUsage.diskUsedPercentage * 100), unit: "%", warn: 0.9, tint: IrisStyle.identity.blue }
                ]
                readonly property real size: Math.round(58 * root.d)
                readonly property real drop: Math.round(26 * root.d)
                Layout.fillWidth: true
                implicitHeight: rings.size + rings.drop + Math.round(20 * root.d)
                Repeater {
                    model: rings.vitals
                    Item {
                        id: vital
                        required property var modelData
                        required property int index
                        readonly property real level: Math.max(0, Math.min(1, Number(vital.modelData.level) || 0))
                        readonly property color tint: vital.level >= vital.modelData.warn ? IrisStyle.danger : vital.modelData.tint
                        readonly property real step: (rings.width - rings.size) / Math.max(1, rings.vitals.length - 1)
                        x: Math.round(vital.index * vital.step)
                        y: vital.index % 2 === 1 ? rings.drop : 0
                        width: rings.size
                        height: rings.size + Math.round(20 * root.d)
                        Accessible.name: vital.modelData.label + ", " + vital.modelData.value + vital.modelData.unit
                        ProgressRing {
                            width: rings.size
                            height: rings.size
                            sweep: 270
                            stroke: Math.max(4, 7 * root.d)
                            tint: vital.tint
                            progress: vital.level
                            Behavior on progress { NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.moveCurve } }
                            MaterialSymbol {
                                anchors.centerIn: parent
                                text: vital.modelData.glyph
                                fill: 1
                                iconSize: Math.round(22 * root.d)
                                color: vital.tint
                            }
                        }
                        Tabular {
                            anchors.horizontalCenter: parent.horizontalCenter
                            y: rings.size - Math.round(8 * root.d)
                            text: vital.modelData.value + vital.modelData.unit
                            color: vital.tint
                            font.pixelSize: IrisStyle.typeMeta
                            font.weight: IrisStyle.weight(Font.Bold)
                        }
                    }
                }
            }
            // The processor over the last minute as a market chart: the figure, how far it moved, the line over its
            // own glow, the average dashed under it.
            Item {
                id: chart
                readonly property var history: Array.from(ResourceUsage.cpuUsageHistory ?? [])
                readonly property real now: Math.round(ResourceUsage.cpuUsage * 100)
                readonly property real before: chart.history.length > 1 ? Math.round(chart.history[0] * 100) : chart.now
                readonly property real average: chart.history.length > 0 ? chart.history.reduce((a, b) => a + b, 0) / chart.history.length : 0
                readonly property color ink: chart.now >= chart.before ? IrisStyle.identity.green : IrisStyle.identity.red
                visible: chart.history.length > 2
                Layout.fillWidth: true
                Layout.topMargin: 4 * root.d
                implicitHeight: Math.round(112 * root.d)
                RowLayout {
                    id: chartHead
                    width: parent.width
                    spacing: 8 * root.d
                    Tabular {
                        text: chart.now + "%"
                        color: IrisStyle.text
                        font.pixelSize: IrisStyle.typeHero
                        font.weight: IrisStyle.weight(Font.Medium)
                    }
                    ColumnLayout {
                        Layout.alignment: Qt.AlignVCenter
                        spacing: 0
                        Tabular {
                            text: (chart.now >= chart.before ? "+" : "") + (chart.now - chart.before) + "%"
                            color: chart.ink
                            font.pixelSize: IrisStyle.typeFootnote
                            font.weight: IrisStyle.weight(Font.DemiBold)
                        }
                        IrisText {
                            text: Translation.tr("Processor")
                            color: IrisStyle.textTertiary
                            font.pixelSize: IrisStyle.typeFootnote
                        }
                    }
                    Item { Layout.fillWidth: true }
                }
                Shape {
                    id: line
                    anchors.top: chartHead.bottom
                    anchors.topMargin: 4 * root.d
                    width: parent.width
                    height: parent.height - chartHead.height - 4 * root.d
                    preferredRendererType: Shape.CurveRenderer
                    function px(i: int): real { return i / Math.max(1, chart.history.length - 1) * line.width }
                    function py(v: real): real { return line.height * (1 - Math.max(0, Math.min(1, v))) * 0.9 + 2 }
                    readonly property string trace: {
                        let d = ""
                        for (let i = 0; i < chart.history.length; i++)
                            d += (i === 0 ? "M " : " L ") + line.px(i) + " " + line.py(chart.history[i])
                        return d
                    }
                    ShapePath {
                        strokeColor: "transparent"
                        fillGradient: LinearGradient {
                            x1: 0; y1: 0; x2: 0; y2: line.height
                            GradientStop { position: 0; color: IrisStyle.trackOf(chart.ink) }
                            GradientStop { position: 1; color: ColorUtils.applyAlpha(chart.ink, 0) } // iris-literal: the glow fades to nothing in its own hue
                        }
                        PathSvg { path: line.trace.length > 0 ? line.trace + " L " + line.width + " " + line.height + " L 0 " + line.height + " Z" : "" }
                    }
                    ShapePath {
                        strokeColor: IrisStyle.textTertiary
                        strokeWidth: Math.max(1, 1.5 * root.d)
                        strokeStyle: ShapePath.DashLine
                        dashPattern: [3, 3]
                        fillColor: "transparent"
                        PathMove { x: 0; y: line.py(chart.average) }
                        PathLine { x: line.width; y: line.py(chart.average) }
                    }
                    ShapePath {
                        strokeColor: chart.ink
                        strokeWidth: Math.max(2, 2.5 * root.d)
                        fillColor: "transparent"
                        joinStyle: ShapePath.RoundJoin
                        capStyle: ShapePath.RoundCap
                        PathSvg { path: line.trace }
                    }
                }
            }
        }
    }
    Component {
        id: workspacesCard
        ColumnLayout {
            id: workspaceBody
            readonly property var workspaces: (NiriService.allWorkspaces ?? [])
                .filter(ws => ws.output === root.screenName && !MinimizedWindows.isStashWorkspace(ws.id))
                .slice().sort((a, b) => Number(a.idx ?? 0) - Number(b.idx ?? 0))
            readonly property var windows: (NiriService.windows ?? [])
                .filter(window => workspaceBody.workspaces.some(ws => ws.id === window.workspace_id))
            spacing: 10 * root.d
            CardHeader {
                glyph: "grid_view"
                tint: IrisStyle.identity.purple
                title: Translation.tr("Workspaces")
                detail: Translation.tr("%1 workspaces · %2 windows").arg(workspaceBody.workspaces.length).arg(workspaceBody.windows.length)
                IrisIconButton {
                    materialIcon: "space_dashboard"
                    Accessible.name: Translation.tr("Open overview")
                    onClicked: { root.close(); NiriService.toggleOverview() }
                }
            }
            Repeater {
                model: workspaceBody.workspaces
                RowLayout {
                    id: workspaceRow
                    required property var modelData
                    Layout.fillWidth: true
                    spacing: 8 * root.d
                    Rectangle {
                        Layout.preferredWidth: Math.round(44 * root.d)
                        Layout.preferredHeight: Layout.preferredWidth
                        radius: IrisStyle.tileRadius(width)
                        color: workspaceRow.modelData.is_active ? IrisStyle.tintFill(IrisStyle.accent) : IrisStyle.fillQuiet
                        border.width: workspaceRow.modelData.is_active ? 0 : 1
                        border.color: IrisStyle.border
                        IrisText {
                            anchors.centerIn: parent
                            text: workspaceRow.modelData.idx ?? "–"
                            color: workspaceRow.modelData.is_active ? IrisStyle.accent : IrisStyle.text
                            font.family: IrisStyle.fontNumbers
                            font.features: ({ "tnum": 1 })
                            font.pixelSize: IrisStyle.typeBody
                            font.weight: IrisStyle.weight(Font.Bold)
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                root.close()
                                NiriService.switchToWorkspaceById(workspaceRow.modelData.id)
                            }
                        }
                    }
                    IrisColumnStrip {
                        Layout.fillWidth: true
                        Layout.preferredHeight: Math.round(44 * root.d)
                        workspaceId: workspaceRow.modelData.id
                        windows: workspaceBody.windows
                        outputName: root.screenName
                        active: workspaceRow.modelData.is_active ?? false
                        onWindowActivated: windowId => { root.close(); NiriService.focusWindow(windowId) }
                    }
                }
            }
        }
    }
    Component {
        id: updatesCard
        ColumnLayout {
            spacing: 10 * root.d
            CardHeader {
                glyph: Updates.count > 0 ? "deployed_code_update" : "task_alt"
                tint: Updates.count > 0 ? IrisStyle.secondaryAccent : IrisStyle.identity.green
                title: Translation.tr("Updates")
                detail: Updates.count > 0
                    ? Translation.tr("%1 packages waiting").arg(Updates.count)
                    : Translation.tr("Everything is up to date")
                IrisIconButton {
                    materialIcon: "refresh"
                    Accessible.name: Translation.tr("Check again")
                    onClicked: Updates.refresh()
                }
            }
            IrisNumber {
                Layout.alignment: Qt.AlignHCenter
                text: Updates.count
                // The card's own figure: the hero size, in the highlight only while something waits.
                pixelSize: IrisStyle.typeHero
                weight: IrisStyle.figureWeight
                color: Updates.count > 0 ? IrisStyle.secondaryAccent : IrisStyle.text
            }
            IrisButton {
                Layout.fillWidth: true
                visible: Updates.count > 0
                text: Translation.tr("Update now")
                buttonRadius: root.plateRadius
                implicitHeight: Math.round(38 * root.d)
                onClicked: {
                    root.close()
                    PackageSearch.runConfiguredUpdate()
                }
            }
        }
    }
    Component {
        id: vpnCard
        ColumnLayout {
            id: vpn
            spacing: 8 * root.d
            Component.onCompleted: Vpn.keepAlive()
            Component.onDestruction: Vpn.releaseKeepAlive()
            // Hides addresses and the account for a screenshot; the values still copy whole.
            property bool masked: true
            property bool copied: false
            // A window the card hands off to (a file chooser, NetworkManager's editor, a terminal) opens with the card gone.
            Connections {
                target: Vpn
                function onHandOff(): void { IrisState.bubbleCard = null }
            }
            Timer { id: copiedTimer; interval: 1400; onTriggered: vpn.copied = false }
            function copy(value: string): void {
                Quickshell.clipboardText = value
                vpn.copied = true
                copiedTimer.restart()
            }
            function hide(value: string): string {
                if (!vpn.masked || value.length === 0) return value
                if (/^\d+\.\d+\.\d+\.\d+/.test(value)) return value.replace(/^(\d+\.\d+)\.\d+\.\d+/, "$1.•••.•••")
                if (value.includes("@")) return value.slice(0, 2) + "•••" + value.slice(value.indexOf("@"))
                if (value.includes(":")) return value.split(":")[0] + ":••••:••••"
                return value.split(".")[0] + ".•••"
            }
            function rate(bytes: real): string {
                return bytes >= 1048576 ? (bytes / 1048576).toFixed(1) + " MB/s"
                    : bytes >= 1024 ? (bytes / 1024).toFixed(1) + " KB/s" : Math.round(bytes) + " B/s"
            }
            function traffic(dev: string): string {
                const r = Vpn.rates[dev]
                return r ? "↓ " + vpn.rate(r.down) + "   ↑ " + vpn.rate(r.up) : ""
            }
            CardHeader {
                glyph: Vpn.connected ? "vpn_lock" : "vpn_key_off"
                tint: Vpn.connected ? IrisStyle.identity.green : IrisStyle.muted
                title: Translation.tr("VPN")
                detail: vpn.copied ? Translation.tr("Copied")
                    : Vpn.busy ? Translation.tr("Working…")
                    : Vpn.connected ? Translation.tr("On through %1").arg(Vpn.activeName)
                    : Translation.tr("Not connected")
                IrisIconButton {
                    visible: Vpn.details
                    materialIcon: vpn.masked ? "visibility_off" : "visibility"
                    selected: vpn.masked
                    Accessible.name: vpn.masked ? Translation.tr("Show addresses") : Translation.tr("Hide addresses")
                    onClicked: vpn.masked = !vpn.masked
                }
                IrisIconButton {
                    materialIcon: "info"
                    selected: Vpn.details
                    Accessible.name: Vpn.details ? Translation.tr("Hide details") : Translation.tr("Show details")
                    onClicked: Vpn.setDetails(!Vpn.details)
                }
                IrisIconButton {
                    materialIcon: "refresh"
                    Accessible.name: Translation.tr("Check again")
                    onClicked: Vpn.refresh()
                }
            }
            IrisText {
                Layout.fillWidth: true
                visible: Vpn.profiles.length === 0
                text: Vpn.available
                    ? Translation.tr("OpenVPN and WireGuard profiles you add in NetworkManager show up here too.")
                    : Translation.tr("No VPN yet. Add an OpenVPN or WireGuard profile in NetworkManager, or install Tailscale.")
                color: IrisStyle.textSecondary
                wrapMode: Text.WordWrap
                font.pixelSize: IrisStyle.typeMeta
            }
            VpnRow {
                Layout.fillWidth: true
                visible: Vpn.tailscaleInstalled
                label: "Tailscale"
                detail: Vpn.tailscaleUp ? vpn.hide(Vpn.tailscaleAddress)
                    : Vpn.tailscaleSignedOut ? Translation.tr("Signed out") : Translation.tr("Off")
                on: Vpn.tailscaleUp
                onToggled: Vpn.toggleTailscale()
            }
            IrisButton {
                Layout.fillWidth: true
                visible: Vpn.tailscaleSignedOut
                enabled: !Vpn.signingIn
                emphasized: true
                text: Vpn.signingIn ? Translation.tr("Finish in your browser…") : Translation.tr("Sign in to Tailscale")
                buttonRadius: root.plateRadius
                implicitHeight: Math.round(34 * root.d)
                onClicked: Vpn.signInTailscale()
            }
            VpnFacts {
                Layout.fillWidth: true
                visible: Vpn.details && Vpn.tailscaleInstalled && Vpn.tailscaleAddress.length > 0
                VpnFact { Layout.fillWidth: true; label: Translation.tr("IPv4"); value: Vpn.tailscaleAddress; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                VpnFact { Layout.fillWidth: true; label: Translation.tr("IPv6"); value: Vpn.tailscaleAddress6; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                VpnFact { Layout.fillWidth: true; label: Translation.tr("Name"); value: Vpn.tailscaleDns; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                VpnFact { Layout.fillWidth: true; label: Translation.tr("Account"); value: Vpn.tailscaleAccount; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                VpnFact { Layout.fillWidth: true; label: Translation.tr("Exit node"); value: Vpn.tailscaleExitName.length > 0 ? Vpn.tailscaleExitName : Translation.tr("None, direct"); onCopy: value => vpn.copy(value) }
                VpnFact { Layout.fillWidth: true; label: Translation.tr("Traffic"); value: Vpn.tailscaleUp ? vpn.traffic("tailscale0") : ""; onCopy: value => vpn.copy(value) }
            }
            ColumnLayout {
                Layout.fillWidth: true
                visible: Vpn.details && Vpn.tailscaleDevices.length > 0
                spacing: Math.round(2 * root.d)
                IrisText {
                    Layout.leftMargin: Math.round(4 * root.d)
                    Layout.topMargin: Math.round(4 * root.d)
                    text: Translation.tr("Devices · %1 of %2 online").arg(Vpn.tailscaleOnline).arg(Vpn.tailscaleDevices.length)
                    color: IrisStyle.muted
                    font.pixelSize: IrisStyle.typeFootnote
                    font.weight: IrisStyle.weight(Font.Medium)
                }
                Repeater {
                    model: Vpn.tailscaleDevices.slice(0, 6)
                    MouseArea {
                        id: device
                        required property var modelData
                        Layout.fillWidth: true
                        implicitHeight: Math.round(36 * root.d)
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: vpn.copy(device.modelData.address)
                        Accessible.role: Accessible.Button
                        Accessible.name: device.modelData.name
                        Rectangle {
                            anchors.fill: parent
                            radius: root.plateRadius
                            color: device.containsMouse ? IrisStyle.fillHover : ColorUtils.applyAlpha(IrisStyle.fillHover, 0)
                            Behavior on color { ColorAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
                        }
                        RowLayout {
                            anchors.fill: parent
                            anchors.leftMargin: Math.round(10 * root.d)
                            anchors.rightMargin: Math.round(8 * root.d)
                            spacing: Math.round(10 * root.d)
                            Rectangle {
                                implicitWidth: Math.round(8 * root.d)
                                implicitHeight: implicitWidth
                                radius: IrisStyle.capsule(width)
                                color: device.modelData.online ? IrisStyle.identity.green : IrisStyle.fillActive
                            }
                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 0
                                IrisText {
                                    Layout.fillWidth: true
                                    text: device.modelData.name
                                    elide: Text.ElideRight
                                    font.pixelSize: IrisStyle.typeLabel
                                    color: device.modelData.online ? IrisStyle.text : IrisStyle.textSecondary
                                }
                                IrisText {
                                    Layout.fillWidth: true
                                    text: [vpn.hide(device.modelData.address), device.modelData.os].filter(part => part.length > 0).join(" · ")
                                    elide: Text.ElideRight
                                    color: IrisStyle.muted
                                    font.pixelSize: IrisStyle.typeFootnote
                                    font.features: ({ "tnum": 1 })
                                }
                            }
                            IrisChip {
                                visible: Vpn.tailscaleUp && (device.modelData.exitOption || device.modelData.exitNode)
                                selected: device.modelData.exitNode
                                glyph: "logout"
                                label: device.modelData.exitNode ? Translation.tr("Exit node") : Translation.tr("Use as exit")
                                Accessible.name: device.modelData.exitNode ? Translation.tr("Stop using %1 as exit node").arg(device.modelData.name)
                                    : Translation.tr("Send traffic through %1").arg(device.modelData.name)
                                onClicked: Vpn.setExitNode(device.modelData.exitNode ? "" : device.modelData.address)
                            }
                        }
                    }
                }
                IrisText {
                    Layout.leftMargin: Math.round(10 * root.d)
                    visible: Vpn.tailscaleDevices.length > 6
                    text: Translation.tr("+%1 more").arg(Vpn.tailscaleDevices.length - 6)
                    color: IrisStyle.muted
                    font.pixelSize: IrisStyle.typeFootnote
                }
            }
            Repeater {
                model: Vpn.profiles
                ColumnLayout {
                    id: profile
                    required property var modelData
                    readonly property var facts: Vpn.profileDetails[profile.modelData.uuid] ?? null
                    Layout.fillWidth: true
                    spacing: Math.round(4 * root.d)
                    VpnRow {
                        Layout.fillWidth: true
                        label: profile.modelData.name
                        detail: profile.modelData.active && profile.facts?.address ? profile.modelData.type + " · " + vpn.hide(profile.facts.address) : profile.modelData.type
                        on: profile.modelData.active
                        onToggled: Vpn.toggleProfile(profile.modelData.uuid)
                    }
                    VpnFacts {
                        Layout.fillWidth: true
                        visible: Vpn.details && profile.modelData.active && profile.facts !== null
                        VpnFact { Layout.fillWidth: true; label: Translation.tr("Address"); value: profile.facts?.address ?? ""; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                        VpnFact { Layout.fillWidth: true; label: Translation.tr("Gateway"); value: profile.facts?.gateway ?? ""; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                        VpnFact { Layout.fillWidth: true; label: Translation.tr("DNS"); value: profile.facts?.dns ?? ""; shown: vpn.hide(value); onCopy: value => vpn.copy(value) }
                        VpnFact { Layout.fillWidth: true; label: Translation.tr("Interface"); value: profile.facts?.device ?? ""; onCopy: value => vpn.copy(value) }
                        VpnFact { Layout.fillWidth: true; label: Translation.tr("Traffic"); value: vpn.traffic(profile.facts?.device ?? ""); onCopy: value => vpn.copy(value) }
                    }
                    VpnFacts {
                        Layout.fillWidth: true
                        visible: Vpn.details
                        VpnFact {
                            Layout.fillWidth: true
                            label: Translation.tr("Connect automatically")
                            glyph: ""
                            value: profile.modelData.autoconnect ? Translation.tr("On") : Translation.tr("Off")
                            onCopy: Vpn.setAutoconnect(profile.modelData.uuid, !profile.modelData.autoconnect)
                        }
                        VpnFact {
                            Layout.fillWidth: true
                            visible: Vpn.canCreate
                            label: Translation.tr("Settings")
                            glyph: "open_in_new"
                            value: Vpn.hasEditor ? Translation.tr("NetworkManager") : "nmtui"
                            onCopy: Vpn.editProfile(profile.modelData.uuid)
                        }
                    }
                }
            }
            IrisText {
                Layout.fillWidth: true
                visible: Vpn.errorText.length > 0
                text: Vpn.errorText
                color: IrisStyle.danger
                wrapMode: Text.WordWrap
                maximumLineCount: 3
                elide: Text.ElideRight
                font.pixelSize: IrisStyle.typeMeta
            }
            IrisText {
                Layout.fillWidth: true
                visible: Vpn.hasNmcli && !Vpn.canCreate
                text: Vpn.missingEditorText
                color: IrisStyle.muted
                wrapMode: Text.WordWrap
                font.pixelSize: IrisStyle.typeMeta
            }
            IrisActionRow {
                Layout.fillWidth: true
                visible: Vpn.hasNmcli
                spacing: Math.round(6 * root.d)
                IrisButton {
                    Layout.fillWidth: true
                    visible: Vpn.canCreate
                    enabled: !Vpn.busy
                    text: Vpn.hasEditor ? Translation.tr("New WireGuard…") : Translation.tr("New VPN…")
                    buttonRadius: root.plateRadius
                    onClicked: Vpn.newProfile("wireguard")
                }
                IrisButton {
                    Layout.fillWidth: true
                    visible: Vpn.hasEditor && Vpn.hasVpnPlugins
                    enabled: !Vpn.busy
                    text: Translation.tr("Other VPN…")
                    buttonRadius: root.plateRadius
                    onClicked: Vpn.newProfile("vpn")
                }
                IrisButton {
                    Layout.fillWidth: true
                    enabled: !Vpn.busy
                    text: Translation.tr("Import a file…")
                    buttonRadius: root.plateRadius
                    onClicked: Vpn.chooseProfileFile()
                }
            }
            IrisButton {
                Layout.fillWidth: true
                visible: Vpn.needsTailscaleOperator
                enabled: !Vpn.busy
                text: Translation.tr("Let me control Tailscale")
                buttonRadius: root.plateRadius
                implicitHeight: Math.round(34 * root.d)
                onClicked: Vpn.fixTailscaleOperator()
            }
        }
    }
    Component {
        id: shellUpdateCard
        ColumnLayout {
            id: updateCard
            readonly property var changes: ShellUpdates.commitLog.split("\n").filter(l => l.length > 0)
                .map(l => l.split("|")[1] ?? l)
            spacing: 10 * root.d
            CardHeader {
                glyph: "rocket_launch"
                tint: IrisStyle.secondaryAccent
                title: ShellUpdates.remoteVersion.length > 0
                    ? Translation.tr("iNiR %1").arg(ShellUpdates.remoteVersion) : Translation.tr("New iNiR")
                detail: ShellUpdates.repoDiverged
                    ? Translation.tr("Upstream history changed; your local work is kept")
                    : ShellUpdates.commitsBehind > 0
                        ? Translation.tr("%1 commits behind").arg(ShellUpdates.commitsBehind)
                        : Translation.tr("Ready to update")
            }
            IrisText {
                Layout.fillWidth: true
                visible: text.length > 0
                text: updateCard.changes.length > 0
                    ? updateCard.changes.slice(0, 5).map(s => "• " + s).join("\n")
                        + (updateCard.changes.length > 5 ? "\n" + Translation.tr("+%1 more").arg(updateCard.changes.length - 5) : "")
                    : ShellUpdates.latestMessage
                color: IrisStyle.subtext
                wrapMode: Text.WordWrap
                maximumLineCount: 9
                elide: Text.ElideRight
                font.pixelSize: IrisStyle.typeMeta
            }
            IrisButton {
                Layout.fillWidth: true
                visible: ShellUpdates.selfUpdateSupported
                enabled: !ShellUpdates.isUpdating
                text: ShellUpdates.isUpdating ? Translation.tr("Updating…")
                    : ShellUpdates.repoDiverged ? Translation.tr("Repair & Update") : Translation.tr("Update now")
                buttonRadius: root.plateRadius
                implicitHeight: Math.round(38 * root.d)
                onClicked: { root.close(); ShellUpdates.performUpdate() }
            }
            IrisButton {
                Layout.fillWidth: true
                quiet: true
                text: Translation.tr("Not now")
                buttonRadius: root.plateRadius
                implicitHeight: Math.round(32 * root.d)
                onClicked: { root.close(); ShellUpdates.dismiss() }
            }
        }
    }
    Component {
        id: animeCard
        ColumnLayout {
            id: airing
            readonly property var shows: IrisPieces.animeUpcoming.slice(0,
                Math.max(3, Math.min(8, Number(Config.options?.iris?.anime?.shows ?? 5))))
            readonly property var next: IrisPieces.animeNext
            spacing: 8 * root.d
            Component.onCompleted: AnimeService.fetchTopAiring()
            CardHeader {
                glyph: IrisPieces.glyphOf("anime", "")
                tint: IrisStyle.identity.pink
                title: Translation.tr("Airing")
                detail: airing.next
                    ? Translation.tr("Ep %1 in %2").arg(airing.next.nextEpisode).arg(IrisPieces.animeWait(airing.next.airingAt))
                    : !Network.online ? Network.offlineReason
                    : AnimeService.lastError.length > 0 && !AnimeService.loading ? Translation.tr("AniList didn't answer (´・ω・`)")
                    : Translation.tr("Nothing scheduled yet")
                IrisIconButton {
                    enabled: Network.online
                    materialIcon: "refresh"
                    Accessible.name: Translation.tr("Check again")
                    onClicked: { AnimeService.invalidateTopCache(); AnimeService.fetchTopAiring() }
                }
            }
            Repeater {
                model: airing.shows
                MouseArea {
                    id: showRow
                    required property var modelData
                    readonly property bool followed: IrisPieces.animeFollows(showRow.modelData.id)
                    Layout.fillWidth: true
                    implicitHeight: Math.round(46 * root.d)
                    cursorShape: Qt.PointingHandCursor
                    hoverEnabled: true
                    Accessible.role: Accessible.CheckBox
                    Accessible.checked: showRow.followed
                    Accessible.name: Translation.tr("Follow %1").arg(showRow.modelData.title)
                    onClicked: IrisPieces.animeToggleFollow(showRow.modelData.id)
                    Rectangle {
                        anchors.fill: parent
                        radius: root.plateRadius
                        color: showRow.containsMouse ? IrisStyle.fillHover : "transparent"
                        Behavior on color { ColorAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
                    }
                    RowLayout {
                        anchors.fill: parent
                        anchors.leftMargin: Math.round(6 * root.d)
                        anchors.rightMargin: Math.round(8 * root.d)
                        spacing: 10 * root.d
                        ClippingRectangle {
                            implicitWidth: Math.round(28 * root.d)
                            implicitHeight: Math.round(38 * root.d)
                            radius: IrisStyle.tileRadius(width)
                            color: IrisStyle.fillQuiet
                            IrisImage {
                                anchors.fill: parent
                                source: String(showRow.modelData.imageSmall ?? showRow.modelData.image ?? "")
                            }
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 0
                            IrisText {
                                Layout.fillWidth: true
                                text: showRow.modelData.title
                                elide: Text.ElideRight
                                font.pixelSize: IrisStyle.typeLabel
                                font.weight: showRow.followed ? IrisStyle.weight(Font.DemiBold) : IrisStyle.weight(Font.Normal)
                            }
                            IrisText {
                                Layout.fillWidth: true
                                text: Translation.tr("Ep %1").arg(showRow.modelData.nextEpisode)
                                color: IrisStyle.muted
                                elide: Text.ElideRight
                                font.pixelSize: IrisStyle.typeFootnote
                            }
                        }
                        IrisText {
                            text: IrisPieces.animeWait(showRow.modelData.airingAt)
                            color: showRow.followed ? IrisStyle.identity.pink : IrisStyle.subtext
                            font.family: IrisStyle.fontNumbers
                            font.features: ({ "tnum": 1 })
                            font.pixelSize: IrisStyle.typeMeta
                            font.weight: IrisStyle.weight(Font.DemiBold)
                        }
                        MaterialSymbol {
                            opacity: showRow.followed ? 1 : showRow.containsMouse ? 0.5 : 0
                            text: "bookmark"
                            fill: showRow.followed ? 1 : 0
                            iconSize: Math.round(15 * root.d)
                            color: showRow.followed ? IrisStyle.identity.pink : IrisStyle.subtext
                            Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(120); easing.type: IrisStyle.feedbackEasing } }
                        }
                    }
                }
            }
            IrisText {
                Layout.fillWidth: true
                visible: airing.shows.length > 0
                text: IrisPieces.animeFollowing.length > 0
                    ? Translation.tr("The bubble shows what you follow first")
                    : Translation.tr("Tap a show to follow it")
                color: IrisStyle.muted
                font.pixelSize: IrisStyle.typeMeta
                horizontalAlignment: Text.AlignHCenter
            }
        }
    }
    Component {
        id: watchingCard
        IrisWatchingCard {
            plateRadius: root.plateRadius
            onCloseRequested: root.close()
        }
    }
    Component {
        id: mediaCard
        Item {
            id: player
            ColorQuantizer {
                id: tintQuantizer
                source: MediaArtwork.displaySource
                depth: 2
                rescaleSize: 48
            }
            readonly property color tint: IrisStyle.artTintOf(tintQuantizer.colors)
            // The artwork is the card's material, edge to edge in its own contour; the player sits on it at the card's margin.
            readonly property real inset: Math.max(0, IrisStyle.cardPad - Math.round(14 * root.d))
            // Without artwork the card's own body is the material (solid, glass or blur, one silhouette when it joins the
            // Island): a lighter plate here was a second material, a seam against the Island and the frame.
            implicitHeight: card.implicitHeight + player.inset * 2
            Loader {
                id: artLoader
                anchors.fill: parent
                active: (Config.options?.iris?.player?.artworkBackground ?? true)
                    && MediaArtwork.displaySource.length > 0
                sourceComponent: Item {
                    IrisMediaBackdrop { anchors.fill: parent; source: MediaArtwork.displaySource; strength: 0.9 }
                    Rectangle {
                        anchors.fill: parent
                        gradient: Gradient {
                            orientation: Gradient.Horizontal
                            GradientStop { position: 0; color: IrisStyle.tintFill(player.tint) }
                            GradientStop { position: 1; color: "transparent" }
                        }
                    }
                }
            }
            IrisMediaCard {
                id: card
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.margins: player.inset
                showBackground: false
                active: root.contentActive
                tint: player.tint
            }
        }
    }
}
