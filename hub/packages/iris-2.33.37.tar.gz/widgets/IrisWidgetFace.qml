pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Effects
import Quickshell
import Quickshell.Widgets
import qs
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.iris.components
import qs.modules.iris.field
import qs.modules.iris.style

Item {
    id: root
    // The place a look is worn by (`iris.appearance.places.widgets`).
    readonly property string irisPlace: "widgets"

    required property var widget
    property color light: "transparent"
    // A Design that prints this widget (`IrisDesign.skin`): its part draws the whole face, stock included, from this
    // face's state (`face: root`), and the plate, shadow, glass and leak below step aside for it.
    property string designFace: ""
    readonly property bool designed: root.designFace.length > 0
    // A Design that dresses every widget it does not print whole (`widgetStock`): its stock replaces the plate, shadow,
    // glass and leak, and the face's ink is the stock's.
    readonly property string stockSkin: root.designed ? "" : IrisDesign.skin("widgetStock")
    readonly property bool stocked: root.stockSkin.length > 0
    readonly property bool ownPlate: root.designed || root.stocked
    // Content clears the corner (DI29): a chip in the corner keeps a concentric curve only while the padding is at least
    // the card's radius less the chip's (10), so a rounder card pushes its content in. A fixed 16 left the weather's
    // icon touching a 30 px corner.
    readonly property real edgePad: Math.max(root.dp(16), Math.round(root.radius - root.dp(10)))
    property real padding: root.edgePad
    default property alias content: body.data

    readonly property string size: root.widget.sizeClass
    readonly property bool small: root.size === "small"
    readonly property bool medium: root.size === "medium"
    readonly property bool large: root.size === "large"
    readonly property real k: IrisStyle.density * root.widget.scaleFactor
    readonly property real t: IrisStyle.typeScale * root.widget.scaleFactor
    readonly property real radius: root.widget.cornerRadiusOverride >= 0
        ? root.widget.cornerRadiusOverride : Math.round(root.widget.widgetCardRadius * root.widget.scaleFactor)
    readonly property real innerRadius: Math.max(root.dp(6), root.radius - root.padding)
    readonly property real gap: root.dp(10)
    readonly property real contentWidth: root.width - root.padding * 2
    readonly property bool live: root.widget.powerActive && root.widget.visible
    // Seen: the desktop under the face is showing. Seconds, positions and ticking data follow this, not `live`:
    // behind windows each tick redraws the whole desktop window for nobody (rules/background.md).
    readonly property bool moving: root.live && root.widget.motionActive

    readonly property string material: root.widget.look.material(root.widget)
    readonly property bool glass: root.material === "glass"
    readonly property bool clear: root.material === "clear"
    readonly property bool opaque: !root.glass && !root.clear
    readonly property real strength: root.widget.look.surfaceOpacity(root.widget)
    // Glass and transparent faces over a light region turn over: frost and near-black ink instead of
    // a veil darkened until the glass is gone. An opaque plate keeps its own polarity.
    // In the light scheme a plate is light, so its ink is the dark one; a bare widget still follows the wallpaper.
    // A glass face is the shell's material in every scheme, veiled as reading needs: turning it white over a bright region
    // left white cards among a dark shell. Only a transparent face, which has no material, follows the wallpaper.
    readonly property bool lightBackdrop: IrisStyle.light && !root.clear ? true : root.clear ? root.widget.inkOnLight
        : root.widget.forceDarkInk
    readonly property bool ownInk: root.lightBackdrop || (IrisStyle.light && root.clear) || root.stockInk
    // A paper scheme's face is the shell's paper with the shell's own ink and accents, as the quick-controls sheet is;
    // the light-backdrop path (white frost, accents deepened to 0.3-0.4 lightness) turned orange brown there.
    readonly property bool paper: IrisStyle.light && !root.clear
    readonly property real textShadow: root.clear ? 1
        : root.glass && !root.widget.legibleAlways ? Math.min(1, (1 - root.strength) * 1.4) : 0
    // Background off means no plate, Lume on every widget or not: there it only deepens the text's shadow (10-25).
    readonly property real veil: root.opaque ? root.strength
        : root.clear ? 0
        : (root.paper ? IrisStyle.legibleVeil(root.readMaterial, root.frostLevel, root.readSpread, 1)
            : root.lightBackdrop ? IrisStyle.legibleFrost(root.readMaterial, root.frostLevel, root.readSpread, 1)
            : IrisStyle.legibleVeil(root.readMaterial, root.readLevel, root.readSpread, 1))
            * (root.widget.legibleAlways ? 1 : root.paperGlass ? 0.52 + 0.48 * root.strength : root.strength)
    // On paper, Surface opacity thins a frost; it never turns the face into clear glass lit by the wallpaper's colour.
    readonly property bool paperGlass: root.paper && root.glass
    // Lume on every widget: the veil (light ink) is solved as if the region were bright and busy, the frost
    // (dark ink) as if it were dim and busy.
    readonly property real readLevel: root.widget.legibleAlways ? Math.max(0.72, root.widget.regionBrightness) : root.widget.regionBrightness
    // ...and to the contrast of a reading panel (7:1), so Transparent and Glass both carry a real backing.
    readonly property string readMaterial: root.widget.legibleAlways ? "panel" : root.material
    readonly property real frostLevel: root.widget.legibleAlways ? Math.min(0.5, root.widget.regionBrightness) : root.widget.regionBrightness
    readonly property real readSpread: root.widget.legibleAlways ? Math.max(0.24, root.widget.regionBrightnessSpread) : root.widget.regionBrightnessSpread

    // One palette: the widget's data colours and the shell's status colours. Only a face that is not paper and sits over a
    // light region (a transparent face, or forced dark ink), or a light scheme's bare face over a dark one (its accents are
    // deep for paper), solves them again, against what Lume read behind it.
    readonly property bool resolvesMarks: root.lightBackdrop ? !root.paper : IrisStyle.light && root.clear
    readonly property real seenLevel: root.clear ? root.widget.regionBrightness
        : root.widget.regionBrightness * (1 - root.veil) + Math.pow(ColorUtils.relativeLuminance(IrisStyle.frost), 1 / 2.2) * root.veil
    function mark(seed: color): color {
        return root.resolvesMarks ? Lume.mark(seed, root.seenLevel, root.clear ? root.readSpread : 0, root.lightBackdrop, 3) : seed
    }
    // A Design's stock brings its own pigments for the data.
    readonly property bool stockInk: root.stocked && !root.clear && stockLoader.item !== null
    // Nothing worn on the desktop (DESIGN.md S1-S2): a monochrome face, ink levels for the data, the signal for the one
    // value that is live or wants you, mono caps for labels. A Design that prints or dresses the face keeps its own.
    readonly property bool nothing: IrisStyle.nothingAt("widgets") && !root.designed && !root.stocked
    // As text it must read (4.5:1 on the face), as a mark the pure red is enough; one token keeps both legible.
    readonly property color signal: root.mark(IrisStyle.signalInk)
    function inked(seed: color): color { return root.nothing ? root.ink : seed }
    // A heading in the highlight; under Nothing it is ink, so the signal is left for the face's one live value.
    readonly property color heading: root.nothing ? root.ink : root.highlight
    readonly property color accent: root.nothing ? root.ink : root.stockInk ? stockLoader.item.accent : root.mark(root.widget.look.accent)
    readonly property color highlight: root.nothing ? root.signal : root.stockInk ? stockLoader.item.ink : root.mark(root.widget.look.accent3)
    readonly property color accent2: root.nothing ? root.inkSecondary : root.stockInk ? stockLoader.item.accent2 : root.mark(root.widget.look.accent2)
    readonly property color warm: root.nothing ? root.ink : root.mark(IrisStyle.secondaryAccent)
    readonly property color danger: root.nothing ? root.signal : root.mark(IrisStyle.danger)
    readonly property color ink: root.stockInk ? stockLoader.item.ink : root.paper ? IrisStyle.text : root.lightBackdrop ? IrisStyle.inkOnLight : IrisStyle.light ? IrisStyle.inkOnDark : IrisStyle.text
    readonly property color inkSecondary: IrisStyle.secondaryOf(root.ink)
    readonly property color inkTertiary: IrisStyle.tertiaryOf(root.ink)
    readonly property color fillQuiet: root.ownInk ? IrisStyle.fillQuietOf(root.ink) : IrisStyle.fillQuiet
    readonly property color fill: root.ownInk ? IrisStyle.fillOf(root.ink) : IrisStyle.fill
    readonly property color fillHover: root.ownInk ? IrisStyle.fillHoverOf(root.ink) : IrisStyle.fillHover
    readonly property color fillActive: root.ownInk ? IrisStyle.fillActiveOf(root.ink) : IrisStyle.fillActive
    readonly property color hairline: root.ownInk ? IrisStyle.hairlineOf(root.ink) : IrisStyle.hairline
    // Ink on a filled accent: light on the deep accents of a light face, the Island's dark otherwise.
    function onFill(tint: color): color { return IrisStyle.onTintFor(tint) }
    readonly property int figureWeight: root.widget.widgetTitleWeight
    readonly property string fontMain: IrisStyle.fontMain
    readonly property string fontNumbers: IrisStyle.fontNumbers
    readonly property string fontLabel: IrisStyle.fontLabel
    // Outline: Auto follows the shell's outline and leaves Transparent bare. Arranging draws its own selection outline
    // around the widget, so the widget's own stays as set (forced on while arranging, it read as the outline changing).
    readonly property bool rimShown: root.widget.look.outline(root.widget) === "always"
        || (root.widget.look.outline(root.widget) === "auto" && (!root.clear || root.widget.look.rim))
    readonly property bool glassEdge: (root.glass || IrisStyle.edgeLit) && !root.lightBackdrop
        && (IrisStyle.glassEdgeLight > 0 || IrisStyle.glassEdgeLine > 0)
    readonly property bool flatRim: root.rimShown && !root.glassEdge
        && !(root.glass && !root.lightBackdrop && root.widget.look.outline(root.widget) === "auto")
    readonly property color plateColor: ColorUtils.applyAlpha(root.opaque ? root.widget.look.plate(root.widget)
        : root.lightBackdrop && !root.paper ? IrisStyle.frost : IrisStyle.surface, root.veil)
    readonly property color knockout: root.opaque ? root.plateColor : root.lightBackdrop && !root.paper ? IrisStyle.frost : IrisStyle.surface

    // In a stack the plate stays and the pages' contents slide over it (DesktopWidgetStacks).
    readonly property bool stacked: root.widget.stacked
    readonly property real slide: root.widget.stackPos
    readonly property bool plated: !root.stacked || root.widget.stackShown

    function dp(value: real): real { return Math.round(value * root.k) }
    function px(value: real): real { return Math.round(value * root.t) }

    // A shadow under glass shows through it: the body darkens toward its middle and its top edge reads as a glow.
    RectangularShadow {
        anchors.fill: parent
        visible: root.opaque && root.plated
        radius: root.radius
        blur: root.dp(28)
        spread: -root.dp(4)
        offset.y: root.dp(8)
        color: root.glass ? IrisStyle.glassShadow : IrisStyle.plateShadow
    }

    // Under a Design's own plate the blur is lent to it (`frost`), cut by its die: AIRISU's clear lacquer read as a film
    // over the raw wall, no glass at all.
    readonly property Item frost: glassLoader.item?.frost ?? null
    Loader {
        id: glassLoader
        anchors.fill: parent
        active: root.glass
        visible: root.plated
        sourceComponent: ClippingRectangle {
            id: glassPane
            // The desktop's own wallpaper layer, parallax included, no second decoder. It is copied again only when
            // the layer or this widget moved: copying it every frame the desktop redraws (music playing, a clock)
            // cost the shell 17 % CPU with Afterglow against 6 % for solid widgets.
            readonly property var host: root.QsWindow?.window ?? null
            readonly property Item desktopLayer: glassPane.host?.wallpaperLayer ?? null
            readonly property int layerRevision: glassPane.host?.wallpaperLayerRevision ?? 0
            readonly property bool moving: settling.running || GlobalStates.widgetEditMode
                || Boolean(glassPane.host?.wallpaperLayerAnimating)
            readonly property point at: {
                void (root.widget.x + root.widget.y + (root.widget.parent?.x ?? 0) + (root.widget.parent?.y ?? 0))
                return glassPane.desktopLayer ? root.mapToItem(glassPane.desktopLayer, 0, 0) : Qt.point(root.widget.x, root.widget.y)
            }
            // Parallax and Afterglow's fade run up to about a second after the bump that announced them.
            Timer { id: settling; interval: 1500 }
            onLayerRevisionChanged: settling.restart()
            onAtChanged: crop.scheduleUpdate()
            onWidthChanged: crop.scheduleUpdate()
            onHeightChanged: crop.scheduleUpdate()
            visible: glassPane.desktopLayer !== null || wallpaper.status === Image.Ready
            radius: root.radius
            color: "transparent"
            readonly property Item frost: frostLoader.item?.texture ?? null
            // the blur as an item of its own: a layered item hands out its source, never its effect
            Loader {
                id: frostLoader
                active: root.ownPlate
                x: crop.x
                y: crop.y
                width: crop.width
                height: crop.height
                sourceComponent: Item {
                    readonly property Item texture: frostSource
                    MultiEffect {
                        id: frostBlur
                        anchors.fill: parent
                        source: crop
                        blurEnabled: true
                        blur: IrisStyle.glassBlurAmount
                        blurMax: IrisStyle.glassBlurMax
                        saturation: IrisStyle.widgetGlassSaturation
                    }
                    ShaderEffectSource {
                        id: frostSource
                        visible: false
                        width: root.width
                        height: root.height
                        sourceItem: frostBlur
                        hideSource: true
                        sourceRect: Qt.rect(glassPane.margin, glassPane.margin, root.width, root.height)
                        live: true
                    }
                }
            }
            // Wide enough for the blur to find picture all round: a narrower margin blurred the edge into transparent
            // and the face darkened toward its rim.
            readonly property real margin: Math.ceil(2 * IrisStyle.glassBlurMax * IrisStyle.glassBlurAmount) + root.dp(8)

            Image {
                id: wallpaper
                visible: false
                width: root.widget.screenWidth
                height: root.widget.screenHeight
                source: glassPane.desktopLayer ? "" : WallpaperListener.wallpaperUrlForScreen(root.QsWindow?.window?.screen ?? null)
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                cache: true
                sourceSize.width: Math.round(root.widget.screenWidth / 2)
                sourceSize.height: Math.round(root.widget.screenHeight / 2)
                onStatusChanged: crop.scheduleUpdate()
            }

            ShaderEffectSource {
                id: crop
                x: -glassPane.margin
                y: -glassPane.margin
                width: root.width + glassPane.margin * 2
                height: root.height + glassPane.margin * 2
                sourceItem: glassPane.desktopLayer ?? wallpaper
                live: glassPane.moving
                sourceRect: Qt.rect(glassPane.at.x - glassPane.margin, glassPane.at.y - glassPane.margin, crop.width, crop.height)
                textureSize: Qt.size(Math.max(1, Math.round(crop.width / 2)), Math.max(1, Math.round(crop.height / 2)))
                smooth: true
                visible: !root.ownPlate
                // The field's recipe: blurred at half resolution, so blurMax reaches as far on screen as the field's
                // glass does (at full size it reached half as far and the face read as clear, not frosted).
                layer.enabled: !root.ownPlate
                layer.textureSize: crop.textureSize
                layer.effect: MultiEffect {
                    blurEnabled: true
                    blur: IrisStyle.glassBlurAmount
                    blurMax: IrisStyle.glassBlurMax
                    saturation: IrisStyle.widgetGlassSaturation
                }
            }
        }
    }

    Loader {
        id: stockLoader
        anchors.fill: parent
        active: root.stocked && root.plated && !root.clear
        source: root.stockSkin
        onLoaded: item.face = root
    }

    IrisPlate {
        anchors.fill: parent
        visible: root.plated && !root.ownPlate
        radius: root.radius
        color: root.plateColor
        border.width: root.flatRim ? 1 : 0
        border.color: root.lightBackdrop ? root.hairline : root.clear || IrisStyle.rim.a === 0 ? IrisStyle.clearRim : IrisStyle.rim
        Behavior on color { ColorAnimation { duration: IrisStyle.revealDuration; easing.type: IrisStyle.feedbackEasing } }
        Behavior on border.width { NumberAnimation { duration: IrisStyle.revealDuration; easing.type: IrisStyle.feedbackEasing } }
    }
    IrisBodyLight {
        anchors.fill: parent
        visible: !IrisStyle.selfLit && root.plated && !root.clear
        radius: root.radius
    }

    // Light leak: the plate is film exposed by the shell's one light, as the field's bodies are. It replaces the plate's
    // flat colour (and its outline: an edge the light reaches burns instead) and keeps its opacity.
    Loader {
        anchors.fill: parent
        active: IrisStyle.leak && root.plated && !root.clear && !root.ownPlate
        sourceComponent: IrisLeakPlate {
            strength: IrisStyle.leakWidgets
            at: {
                void (root.widget.x + root.widget.y + (root.widget.parent?.x ?? 0) + (root.widget.parent?.y ?? 0) + root.width + root.height)
                return root.mapToItem(null, 0, 0)
            }
            output: Qt.size(root.widget.screenWidth, root.widget.screenHeight)
            radius: root.radius
            base: root.plateColor
        }
    }
    // Light streak: the field's aurora and streak laid over the plate.
    Loader {
        anchors.fill: parent
        active: IrisStyle.streak && root.plated && !root.clear && !root.ownPlate
        sourceComponent: IrisStreakPlate {
            at: {
                void (root.widget.x + root.widget.y + (root.widget.parent?.x ?? 0) + (root.widget.parent?.y ?? 0) + root.width + root.height)
                return root.mapToItem(null, 0, 0)
            }
            output: Qt.size(root.widget.screenWidth, root.widget.screenHeight)
            radius: root.radius
            base: root.plateColor
        }
    }

    IrisGlassEdge {
        anchors.fill: parent
        visible: root.glassEdge && root.rimShown && root.plated && !root.ownPlate
        radius: root.radius
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        visible: !root.clear && root.light.a > 0 && !root.ownPlate
        opacity: (root.glass ? IrisStyle.glassWash : 1) * (1 - Math.min(1, Math.abs(root.slide)))
        radius: Math.max(0, root.radius - 1)
        gradient: Gradient {
            GradientStop { position: 0; color: IrisStyle.skyWash(root.light) }
            GradientStop { position: 1; color: IrisStyle.skyWashFade(root.light) }
        }
    }

    // Pages slide inside the plate's box and are cut at its edge while they move.
    Item {
        id: viewport
        anchors.fill: parent
        clip: root.stacked && root.slide !== 0

        Item {
            id: slider
            width: viewport.width
            height: viewport.height
            // The page travels half its height while it fades, so two pages cross instead of one pushing the other out.
            y: Math.round(root.slide * root.height * 0.5)
            opacity: 1 - Math.pow(Math.min(1, Math.abs(root.slide)), 1.5)

            // What casts the text's shadow: the face that shows. A copy renders its source hidden or not, so under a
            // Design the stock body (Apple's Day: sunrise, the sun's path) cast a ghost behind AIRISU's print, white on
            // a light wallpaper and black on a dark one. A Design's print casts it only bare: on its own plate the
            // plate's outline would cast one too.
            readonly property Item shadowed: root.designed ? (root.clear ? designPrint : null) : body
            ShaderEffectSource {
                id: bodyCopy
                anchors.fill: slider.shadowed ?? body
                sourceItem: root.textShadow > 0.05 ? slider.shadowed : null
                hideSource: false
                visible: false
            }
            // The shadow comes from a copy behind the body: a layered body would resample its text.
            MultiEffect {
                x: bodyCopy.x
                y: bodyCopy.y + 1
                width: bodyCopy.width
                height: bodyCopy.height
                visible: root.textShadow > 0.05 && slider.shadowed !== null
                source: bodyCopy
                brightness: root.lightBackdrop ? 1 : -1
                colorization: IrisStyle.glow > 0 && !root.lightBackdrop ? 1 : 0
                colorizationColor: Qt.rgba(IrisStyle.plateShadow.r, IrisStyle.plateShadow.g, IrisStyle.plateShadow.b, 1)
                blurEnabled: true
                blur: 0.5
                autoPaddingEnabled: true
                opacity: (root.lightBackdrop ? IrisStyle.frostShadow : IrisStyle.plateShadow.a) * root.textShadow
            }

            Loader {
                id: designPrint
                anchors.fill: parent
                active: root.designed
                source: root.designFace
                onLoaded: item.face = root
            }

            Item {
                id: body
                anchors.fill: parent
                anchors.margins: root.padding
                visible: !root.designed
            }
        }
    }

    // Carried over by another widget: this is where it will land.
    Rectangle {
        z: 140
        anchors.fill: parent
        radius: root.radius
        visible: opacity > 0
        opacity: root.widget.stackDropHint ? 1 : 0
        color: IrisStyle.tintFill(root.accent)
        border.width: 2
        border.color: root.accent
        Behavior on opacity { NumberAnimation { duration: IrisStyle.feedbackDuration; easing.type: IrisStyle.feedbackEasing } }

        Rectangle {
            anchors.centerIn: parent
            width: root.dp(44)
            height: width
            radius: IrisStyle.iconRadius(width)
            scale: root.widget.stackDropHint ? 1 : 0.8
            Behavior on scale { NumberAnimation { duration: IrisStyle.feedbackDuration; easing.type: IrisStyle.feedbackEasing } }
            gradient: Gradient {
                GradientStop { position: 0; color: IrisStyle.tileTop(root.accent) }
                GradientStop { position: 1; color: root.accent }
            }
            MaterialSymbol {
                anchors.centerIn: parent
                text: "stacks"
                fill: 1
                iconSize: root.dp(24)
                color: root.onFill(root.accent)
            }
        }
    }

    Loader {
        active: root.stacked
        z: 150
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        visible: active && root.widget.stackShown
        sourceComponent: IrisStackDots { face: root }
    }

    // Wheel over a stack turns its page, one per gesture: a touchpad's tail is held off until the page has settled.
    property real _wheel: 0
    Timer { id: wheelHold; interval: 360 }
    Timer { id: wheelReset; interval: 260; onTriggered: root._wheel = 0 }
    WheelHandler {
        enabled: root.stacked && root.widget.stackShown
        acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
        onWheel: event => {
            if (wheelHold.running)
                return
            root._wheel += event.angleDelta.y
            wheelReset.restart()
            if (Math.abs(root._wheel) < 120)
                return
            const forward = root._wheel < 0
            root._wheel = 0
            wheelHold.restart()
            DesktopWidgetStacks.step(root.widget.outputName, root.widget.stack.id, forward ? 1 : -1)
        }
    }

    // A stack holds its page while the pointer is on it or the widget is being carried.
    HoverHandler {
        id: stackHover
        enabled: root.stacked
    }
    readonly property bool _holding: root.stacked && root.widget.stackShown && (stackHover.hovered || root.widget.containsPress)
    on_HoldingChanged: if (root.stacked) DesktopWidgetStacks.setHovered(root.widget.stack.id, root._holding)
}
