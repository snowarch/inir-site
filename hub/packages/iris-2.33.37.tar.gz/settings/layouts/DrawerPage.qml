pragma ComponentBehavior: Bound
import QtQuick
import Quickshell
import QtQuick.Controls
import qs
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.iris.style
import qs.modules.iris.components
import qs.modules.iris.preview
import qs.modules.iris.settings

// One area as Drawer lays it, built once and kept by Drawer's AreaPool: its title, sentence and live stage on a plate to
// the left (Home: the welcome), its groups set across as many columns as the drawer is wide. The groups are dealt to
// the columns in reading order, each column about as long as the others, and the columns scroll together.
Item {
    id: page
    required property string area
    property Item host

    readonly property real d: Number(page.host?.d ?? IrisStyle.settingsDensity)
    function u(n: real): int { return Math.round(n * page.d) }
    readonly property var entry: IrisOptions.sectionById(page.area) ?? ({})
    readonly property bool home: page.area === "general"
    readonly property bool live: page.visible && page.area === String(page.host?.section ?? "")

    // ── The plate: the area's name, its sentence and its stage; Home's is the welcome.
    Column {
        id: plate
        // The words and the stage on the plates' line, under the head's search (IrisSettings owns it).
        x: Number(page.host?.sheetPad ?? page.u(8))
        // Home's welcome needs a little more than a stage to say who and how long up.
        width: Math.round(page.home ? Math.max(page.u(380), Math.min(page.u(440), page.width * 0.26))
            : Math.max(page.u(280), Math.min(page.u(360), page.width * 0.22)))
        spacing: page.u(10)
        IrisText {
            visible: !page.home
            width: parent.width
            elide: Text.ElideRight
            text: Translation.tr(String(page.entry.title ?? ""))
            color: IrisStyle.text
            font.family: IrisStyle.fontTitle
            font.pixelSize: page.u(40)
            fontSizeMode: Text.HorizontalFit
            minimumPixelSize: page.u(24)
            font.weight: IrisStyle.weight(Font.Bold)
            font.letterSpacing: -Math.round(page.u(40) * 0.015)
        }
        IrisText {
            visible: !page.home
            width: parent.width
            wrapMode: Text.WordWrap
            maximumLineCount: 2
            elide: Text.ElideRight
            text: Translation.tr(String(page.entry.subtitle ?? ""))
            color: IrisStyle.muted
            font.pixelSize: IrisStyle.typeBody
        }
        Loader {
            active: page.home
            visible: active
            width: parent.width
            sourceComponent: IrisWallpaperCard { width: plate.width; screen: page.QsWindow.window?.screen ?? GlobalStates.focusedScreen }
        }
        StagePlate {
            id: stagePlate
            readonly property bool shows: !page.home && stagePlate.staged
            visible: stagePlate.shows
            width: parent.width
            height: stagePlate.shows ? implicitHeight : 0
            host: page.host
            ratio: 0.6
            // What the drawer leaves under the words: the stage never pushes the actions out of the plate.
            most: page.height - stagePlate.y - page.u(56)
            area: page.home ? "" : page.area
            group: ""
            playing: page.live && stagePlate.shows
        }
        Flow {
            width: parent.width
            spacing: page.u(6)
            Repeater {
                model: page.live && !page.home ? (page.host?.pageActions ?? []) : []
                MouseArea {
                    id: act
                    required property var modelData
                    width: actRow.implicitWidth + page.u(22)
                    height: page.u(32)
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    Accessible.role: Accessible.Button
                    Accessible.name: String(act.modelData.label ?? "")
                    onClicked: act.modelData.clicked()
                    Rectangle { anchors.fill: parent; radius: IrisStyle.capsule(height); color: act.containsMouse ? IrisStyle.fillHover : IrisStyle.fillQuiet }
                    Row {
                        id: actRow
                        anchors.centerIn: parent
                        spacing: page.u(6)
                        MaterialSymbol { anchors.verticalCenter: parent.verticalCenter; text: String(act.modelData.glyph ?? ""); iconSize: page.u(16); color: IrisStyle.text }
                        IrisText { anchors.verticalCenter: parent.verticalCenter; text: String(act.modelData.label ?? ""); color: IrisStyle.text; font.pixelSize: IrisStyle.typeMeta }
                    }
                }
            }
        }
    }

    // ── The columns.
    readonly property int gap: page.u(28)
    readonly property int columns: Math.max(1, Math.floor((cols.width + page.gap) / (page.u(340) + page.gap)))
    // The area's groups dealt to the columns in order, each closing once it holds its share of what is left.
    property var split: []
    function plan(): void {
        const groups = []
        for (const spec of IrisOptions.settings) {
            if (spec.section !== page.area || !IrisOptions.shown(spec)) continue
            const key = String(spec.group ?? "")
            let group = groups.find(entry => entry.key === key)
            if (!group) { group = { key: key, weight: 1.4, rest: true }; groups.push(group) }
            group.rest = group.rest && IrisOptions.foldsAway(spec)
            group.weight += IrisOptions.foldsAway(spec) ? 0.15 : spec.description ? 1.5 : 1
        }
        // Groups that are all fine-tuning go to the last column, so the area has one Fine-tune at its foot, not one per column.
        const resting = groups.filter(group => group.rest)
        const dealt = resting.length < groups.length ? groups.filter(group => !group.rest) : groups
        const count = Math.min(page.columns, Math.max(1, dealt.length))
        const out = []
        let column = [], held = 0, left = dealt.reduce((sum, group) => sum + group.weight, 0)
        for (const group of dealt) {
            const share = left / (count - out.length)
            if (column.length > 0 && count - out.length > 1 && held + group.weight / 2 > share) {
                out.push(column)
                left -= held
                column = []
                held = 0
            }
            column.push(group.key)
            held += group.weight
        }
        if (column.length > 0) out.push(column)
        if (dealt !== groups) out[out.length - 1] = out[out.length - 1].concat(resting.map(group => group.key))
        page.split = out
    }
    onColumnsChanged: Qt.callLater(page.plan)
    Component.onCompleted: page.plan()

    // Whole once every column is: the pool turns to the page only then.
    property bool whole: false
    function weigh(): void {
        // An area with nothing shown is whole as it stands.
        let built = columnRepeater.count === page.split.length
        for (let i = 0; built && i < columnRepeater.count; i++) built = columnRepeater.itemAt(i)?.whole === true
        page.whole = built
    }
    onSplitChanged: Qt.callLater(page.weigh)

    Rectangle {
        id: cols
        x: plate.x + plate.width + page.u(24)
        width: page.width - x
        height: page.height
        radius: Number(page.host?.paneRadius ?? IrisStyle.radiusSheet)
        color: IrisStyle.glassy ? IrisStyle.readingSidebar : "transparent"
        Flickable {
            IrisScrollFeel {}
            id: flick
            anchors.fill: parent
            anchors.margins: IrisStyle.glassy ? Number(page.host?.sheetPad ?? page.u(8)) : 0
            contentHeight: columnRow.implicitHeight + page.u(16)
            clip: true
            ScrollBar.vertical: IrisScrollBar {}
            Row {
                id: columnRow
                spacing: page.gap
                Repeater {
                    id: columnRepeater
                    model: page.split
                    onCountChanged: Qt.callLater(page.weigh)
                    AreaRows {
                        required property var modelData
                        required property int index
                        width: Math.floor((flick.width - page.gap * (page.split.length - 1)) / Math.max(1, page.split.length))
                        section: page.area
                        host: page.host
                        voice: "drawer"
                        live: page.live
                        welcome: false
                        only: modelData
                        extras: index === page.split.length - 1
                        groupFill: IrisStyle.formPlate
                        // a column shows all it holds: Home's groups stay open across the columns
                        foldHome: false
                        onWholeChanged: Qt.callLater(page.weigh)
                        onReveal: row => page.reveal(row)
                    }
                }
            }
        }
    }

    function targets(): var {
        let out = []
        for (let i = 0; i < columnRepeater.count; i++) out = out.concat(columnRepeater.itemAt(i)?.targets() ?? [])
        return out
    }
    // Asked from outside (a link, the CLI): the column scrolls the group's head to its top.
    function showGroup(wanted: string): void {
        showAgain.tries = 0
        page.seek(wanted)
    }
    function seek(wanted: string): void {
        const lower = wanted.toLowerCase()
        const target = page.targets().find(entry => entry.key === wanted || entry.key.toLowerCase() === lower
            || Translation.tr(entry.key).toLowerCase() === lower)
        // Asked while the columns still build, the group may not be there yet, or the glide is held short by a
        // content height that is still growing: the page stayed at its top (10-29: Faces left under the drawer's edge).
        if (target) {
            const y = target.item.mapToItem(flick.contentItem, 0, 0).y - page.u(8)
            page.glideTo(y)
            if (y <= flick.contentHeight - flick.height + 1 || showAgain.tries >= 8) return
            showAgain.tries++
            showAgain.wanted = wanted
            showAgain.restart()
            return
        }
        // A group waiting under its column's Fine-tune opens it, then shows once built.
        for (let i = 0; i < columnRepeater.count; i++) {
            const column = columnRepeater.itemAt(i)
            column?.openRest(wanted)
        }
        if (showAgain.tries >= 8) return
        showAgain.tries++
        showAgain.wanted = wanted
        showAgain.restart()
    }
    Timer { id: showAgain; property string wanted: ""; property int tries: 0; interval: 200; onTriggered: page.seek(showAgain.wanted) }
    function reveal(row: Item): void { page.glideTo(row.mapToItem(flick.contentItem, 0, 0).y - flick.height * 0.3) }
    function glideTo(y: real): void {
        const to = Math.max(0, Math.min(Math.max(0, flick.contentHeight - flick.height), y))
        if (Math.abs(to - flick.contentY) < 1) return
        glider.from = flick.contentY
        glider.to = to
        glider.restart()
    }
    NumberAnimation { id: glider; target: flick; property: "contentY"; duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve }
}
