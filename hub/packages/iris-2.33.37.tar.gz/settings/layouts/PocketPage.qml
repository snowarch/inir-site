pragma ComponentBehavior: Bound
import QtQuick
import Quickshell
import QtQuick.Controls
import qs
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.iris.style
import qs.modules.iris.components
import qs.modules.iris.preview
import qs.modules.iris.settings

// One area as Pocket holds it, built once and kept by Pocket's AreaPool: its title large over its live stage, then its
// groups as cards down one column scrolling under them.
Item {
    id: page
    required property string area
    property Item host

    readonly property real d: Number(page.host?.d ?? IrisStyle.settingsDensity)
    function u(n: real): int { return Math.round(n * page.d) }
    // The plates' line every layout shares (IrisSettings owns it).
    readonly property int pad: Number(page.host?.plateInset ?? page.u(16))
    readonly property var entry: IrisOptions.sectionById(page.area) ?? ({})
    // The page in front: only then do writes reach its rows and its stage plays.
    readonly property bool live: page.visible && (page.area === String(page.host?.section ?? "") || page.area === "general")
    readonly property bool whole: rows.whole
    readonly property bool staged: page.area !== "general" && stage.staged

    // The title and the stage hold still at the top and the groups scroll under them: the stage shows what a row
    // changes while that row is in reach (his 10-30: it scrolled away with the title).
    // Scrolled, the large title folds into a bar title and the sentence and actions go (iOS large title): the stage
    // keeps the room.
    readonly property real fold: Math.max(0, Math.min(1, flick.contentY / page.u(72)))
    Column {
        id: head
        x: page.pad
        width: page.width - 2 * page.pad
        spacing: page.u(12)
        Column {
            width: parent.width
            topPadding: page.u(4)
            spacing: page.u(2)
            IrisText {
                width: parent.width
                elide: Text.ElideRight
                // Home's own groups read as General: Home is the column you came from.
                text: page.area === "general" ? Translation.tr("General") : Translation.tr(String(page.entry.title ?? ""))
                color: IrisStyle.text
                font.family: IrisStyle.fontTitle
                font.pixelSize: Math.round(page.u(30) - page.u(12) * page.fold)
                font.weight: IrisStyle.weight(Font.Bold)
                font.letterSpacing: -Math.round(page.u(30) * 0.01)
            }
            IrisText {
                width: parent.width
                height: implicitHeight * (1 - page.fold)
                opacity: 1 - page.fold
                visible: opacity > 0
                wrapMode: Text.WordWrap
                maximumLineCount: 2
                elide: Text.ElideRight
                text: page.area === "general" ? Translation.tr("Language, time, startup and the shell itself")
                    : Translation.tr(String(page.entry.subtitle ?? ""))
                color: IrisStyle.muted
                font.pixelSize: IrisStyle.typeBody
            }
        }
        StagePlate {
            id: stage
            width: parent.width
            height: implicitHeight
            host: page.host
            ratio: 0.56
            most: page.u(230)
            area: page.area === "general" ? "" : page.area
            group: page.stageGroup
            playing: page.live && page.staged
        }
        // What can be done to the area (rehearse, customize, restore) as capsules under its stage.
        Flow {
            width: parent.width
            spacing: page.u(6)
            height: implicitHeight * (1 - page.fold)
            opacity: 1 - page.fold
            clip: true
            visible: actions.count > 0 && opacity > 0
            Repeater {
                id: actions
                model: page.live && page.area !== "general" ? (page.host?.pageActions ?? []) : []
                MouseArea {
                    id: act
                    required property var modelData
                    width: actRow.implicitWidth + page.u(22)
                    height: page.u(32)
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    Accessible.role: Accessible.Button
                    Accessible.name: String(act.modelData.label ?? "")
                    onClicked: act.modelData.clicked()
                    Rectangle { anchors.fill: parent; radius: IrisStyle.capsule(height); color: act.containsMouse ? IrisStyle.fillHover : IrisStyle.fillQuiet }
                    Row {
                        id: actRow
                        anchors.centerIn: parent
                        spacing: page.u(6)
                        MaterialSymbol { anchors.verticalCenter: parent.verticalCenter; text: String(act.modelData.glyph ?? ""); iconSize: page.u(16); color: IrisStyle.text }
                        IrisText { anchors.verticalCenter: parent.verticalCenter; text: String(act.modelData.label ?? ""); color: IrisStyle.text; font.pixelSize: IrisStyle.typeMeta }
                    }
                }
            }
        }
    }

    Flickable {
        IrisScrollFeel {}
        id: flick
        anchors.fill: parent
        anchors.topMargin: head.height + page.u(12)
        contentHeight: column.implicitHeight + page.u(28)
        clip: true
        ScrollBar.vertical: IrisScrollBar {}
        onContentYChanged: spyPace.restart()

        Column {
            id: column
            x: page.pad
            width: page.width - 2 * page.pad
            spacing: page.u(12)
            AreaRows {
                id: rows
                width: parent.width
                section: page.area
                host: page.host
                voice: "pocket"
                groupFill: IrisStyle.formPlate
                live: page.live
                reading: page.reading
                // Home's pinned rows and welcome lead Home itself; General's page holds the rest.
                welcome: false
                skip: page.area === "general" ? ["Every day"] : []
                onReveal: row => page.reveal(row)
                onBring: item => page.bring(item)
            }
        }
    }

    // ── The group being read: the head that has reached the upper fifth, for the stage to point at.
    property string reading: ""
    // Peers answer for the one open; any other page for the group being read.
    // An open island answers for the stage, as peers do; otherwise the group being read.
    readonly property string stageWanted: rows.peers || (rows.islands && rows.openGroup.length > 0 && !rows.openGroup.startsWith("pin:"))
        ? rows.openGroup : page.reading
    readonly property string stageGroup: page.stageWanted.length > 0 && stage.stage.sceneFor(page.area, page.stageWanted).length > 0 ? page.stageWanted : ""
    Timer { id: spyPace; interval: 90; onTriggered: page.spy() }
    function spy(): void {
        const targets = rows.targets()
        if (targets.length === 0) { page.reading = ""; return }
        let found = targets[0].key
        if (flick.contentY >= 1) {
            for (const target of targets) {
                const top = target.item.mapToItem(flick.contentItem, 0, 0).y - flick.contentY
                if (top > flick.height * 0.25) break
                found = target.key
            }
        }
        page.reading = found
    }
    onLiveChanged: if (page.live) spyPace.restart()

    // Asked from outside (a link, the CLI): put a group's head at the top, or a row a third down, with one glide.
    function showGroup(wanted: string): void {
        showAgain.tries = 0
        page.seek(wanted)
    }
    function seek(wanted: string): void {
        const lower = wanted.toLowerCase()
        const target = rows.targets().find(entry => entry.key === wanted || entry.key.toLowerCase() === lower
            || Translation.tr(entry.key).toLowerCase() === lower)
        // Asked while the rows still build, the group may not be there yet, or the glide is held short by a content
        // height that is still growing: the page stayed at its top (10-29, as in Drawer).
        if (target) {
            // An island asked for opens where it stands.
            if (rows.islands) rows.openRest(wanted)
            const y = target.item.mapToItem(flick.contentItem, 0, 0).y - page.u(8)
            page.glideTo(y)
            if (y <= flick.contentHeight - flick.height + 1) return
        } else {
            // A group resting under a tile (or the area's Fine-tune) opens, then shows once built.
            rows.openRest(wanted)
        }
        if (showAgain.tries >= 8) return
        showAgain.tries++
        showAgain.wanted = wanted
        showAgain.restart()
    }
    Timer { id: showAgain; property string wanted: ""; property int tries: 0; interval: 200; onTriggered: page.seek(showAgain.wanted) }
    // Scrolls only as far as the item needs to stand whole in view, its top kept in sight when it is taller than the page.
    function bring(item: Item): void {
        const top = item.mapToItem(flick.contentItem, 0, 0).y
        const air = page.u(24)
        const to = Math.min(top - air, top + item.height + air - flick.height)
        if (to > flick.contentY) page.glideTo(to)
    }
    function reveal(row: Item): void { page.glideTo(row.mapToItem(flick.contentItem, 0, 0).y - flick.height * 0.3) }
    function glideTo(y: real): void {
        const to = Math.max(0, Math.min(Math.max(0, flick.contentHeight - flick.height), y))
        if (Math.abs(to - flick.contentY) < 1) return
        glider.from = flick.contentY
        glider.to = to
        glider.restart()
    }
    NumberAnimation { id: glider; target: flick; property: "contentY"; duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve }
}
