pragma ComponentBehavior: Bound
import QtQuick
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.iris.style
import qs.modules.iris.field as Field

FloatingWindow {
    id: root
    // Untranslated, like Material's and Waffle's: niri's rule that opens it at two thirds of the screen matches this
    // title, and "Configuración de iNiR" opened it at half, where every layout falls back to Classic's page.
    title: "iNiR Settings"
    visible: GlobalStates.settingsOverlayOpen
    // Blur turns this window see-through while it is open. Quickshell keeps the alpha it was shown with (an opaque
    // window stays opaque, black where the body leaves it clear), so it is always made with alpha.
    surfaceFormat: ({ opaque: false })
    color: body.frame.material === "compositor" || body.windowField ? "transparent" : IrisStyle.surface
    implicitWidth: Math.round(1180 * IrisStyle.density)
    implicitHeight: Math.round(820 * IrisStyle.density)
    minimumSize: Qt.size(Math.round(560 * IrisStyle.density), Math.round(420 * IrisStyle.density))
    onClosed: GlobalStates.settingsOverlayOpen = false

    readonly property var niriWindow: {
        const list = NiriService.windows ?? []
        return list.find(w => w.title === root.title && w.pid === Quickshell.processId) ?? null
    }
    Binding {
        target: GlobalStates
        property: "settingsWindowBehind"
        value: root.visible && root.niriWindow !== null && !root.niriWindow.is_focused
    }
    // Opened over IPC it carries no activation token, so Niri maps it without focus.
    property bool focusedOnce: false
    onNiriWindowChanged: if (root.niriWindow && !root.focusedOnce) {
        root.focusedOnce = true
        NiriService.focusWindow(root.niriWindow.id)
    }
    onVisibleChanged: if (!root.visible) root.focusedOnce = false
    Component.onDestruction: GlobalStates.settingsWindowBehind = false
    Connections {
        target: GlobalStates
        function onSettingsRaiseRequestChanged(): void {
            if (root.niriWindow) NiriService.focusWindow(root.niriWindow.id)
        }
    }

    Field.IrisBlurRegion {
        window: root
        shapes: body.frame.blurShapes
        windowWidth: root.width
        windowHeight: root.height
    }

    IrisSettings {
        id: body
        anchors.fill: parent
        windowed: true
    }
}
