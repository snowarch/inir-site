pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Layouts
import qs.services
import qs.modules.common.widgets
import qs.modules.iris.style
import qs.modules.iris.bar.island

// The day as the sun's path: where the sun is now, the next sunrise or sunset as the figure, the rest as facts.
// A ring, its percentage and the time left all said the same value three times.
IrisWidgetFace {
    id: root
    designFace: IrisDesign.skin("widgetDay")

    readonly property real fraction: root.widget.dayFraction
    readonly property real sunriseAt: IrisFaceData.dayShare(Weather.data?.sunrise)
    readonly property real sunsetAt: IrisFaceData.dayShare(Weather.data?.sunset)
    readonly property bool sunKnown: root.sunriseAt >= 0 && root.sunsetAt > root.sunriseAt
    readonly property real sunrise: root.sunKnown ? root.sunriseAt : 6 / 24
    readonly property real sunset: root.sunKnown ? root.sunsetAt : 19 / 24
    readonly property bool daytime: root.fraction >= root.sunrise && root.fraction < root.sunset

    readonly property var sunriseFact: ({ name: Translation.tr("Sunrise"), time: String(Weather.data?.sunrise ?? ""), glyph: "wb_twilight" })
    readonly property var sunsetFact: ({ name: Translation.tr("Sunset"), time: String(Weather.data?.sunset ?? ""), glyph: "wb_twilight" })
    readonly property var next: root.daytime ? root.sunsetFact : root.sunriseFact
    readonly property var other: root.daytime ? root.sunriseFact : root.sunsetFact

    function span(minutes: int): string {
        const hours = Math.floor(minutes / 60)
        return hours > 0 ? Translation.tr("%1 h %2 min").arg(hours).arg(minutes % 60) : Translation.tr("%1 min").arg(minutes)
    }
    readonly property string daylight: root.span(Math.round((root.sunset - root.sunrise) * 1440))
    // Without sun times the figure is the time left: the path still shows where the day is.
    readonly property string figure: root.sunKnown ? root.next.time : root.span(Math.max(0, Math.round((1 - root.fraction) * 1440)))
    readonly property string figureName: root.sunKnown ? root.next.name : Translation.tr("Until midnight")

    readonly property var figureParts: IrisFaceData.timeParts(root.figure)

    // The sun's path through the day (Prism's Day draws it too).
    component SunPath: FaceSunPath { face: root }

    component Lead: Row {
        property real figureSize: 30
        spacing: root.dp(6)
        FaceFigure {
            id: leadFigure
            face: root
            text: root.figureParts.main
            size: parent.figureSize
        }
        FaceText {
            face: root
            visible: root.figureParts.suffix.length > 0
            anchors.baseline: leadFigure.baseline
            text: root.figureParts.suffix
            color: root.inkSecondary
            size: Math.round(parent.figureSize * 0.45)
            weight: Font.DemiBold
        }
        FaceText {
            face: root
            visible: !root.small
            anchors.baseline: leadFigure.baseline
            text: root.figureName
            color: root.inkSecondary
            size: 14
        }
    }

    // The other sun time under the path: its name, then the time in the figure's face.
    component Other: Row {
        id: other
        property real timeSize: 17
        readonly property var parts: IrisFaceData.timeParts(root.other.time)
        spacing: root.dp(5)
        FaceText {
            face: root
            anchors.baseline: otherTime.baseline
            text: root.other.name
            color: root.inkSecondary
            size: 12.5
            weight: Font.DemiBold
        }
        FaceFigure {
            id: otherTime
            face: root
            text: other.parts.main
            size: other.timeSize
        }
        FaceText {
            face: root
            visible: other.parts.suffix.length > 0
            anchors.baseline: otherTime.baseline
            text: other.parts.suffix
            color: root.inkSecondary
            size: Math.round(other.timeSize * 0.55)
            weight: Font.DemiBold
        }
    }

    ColumnLayout {
        visible: root.small
        anchors.fill: parent
        spacing: root.dp(2)
        FaceHeader {
            face: root
            Layout.fillWidth: true
            glyph: root.sunKnown ? root.next.glyph : "timelapse"
            text: root.sunKnown ? root.next.name : Translation.tr("Until midnight")
            tint: root.warm
        }
        Lead { figureSize: 30 }
        SunPath {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.topMargin: root.dp(6)
        }
        Other {
            visible: root.sunKnown
            Layout.topMargin: root.dp(6)
        }
    }

    ColumnLayout {
        visible: !root.small
        anchors.fill: parent
        spacing: root.dp(2)
        FaceHeader {
            face: root
            Layout.fillWidth: true
            glyph: root.daytime ? "light_mode" : "bedtime"
            text: IrisFaceData.capitalized(Translation.locale.toString(DateTime.clock.date, "dddd d"))
            tint: root.warm
        }
        RowLayout {
            Layout.fillHeight: false
            Layout.fillWidth: true
            spacing: root.dp(10)
            Lead { figureSize: root.large ? 44 : 38 }
            Item { Layout.fillWidth: true }
            // Medium keeps its facts beside the figure; large lists them under the path.
            ColumnLayout {
                visible: root.medium && root.sunKnown
                Layout.alignment: Qt.AlignBottom
                Layout.bottomMargin: root.dp(4)
                spacing: 0
                Other {
                    Layout.alignment: Qt.AlignRight
                    timeSize: 16
                }
                FaceText {
                    face: root
                    Layout.alignment: Qt.AlignRight
                    text: Translation.tr("Daylight") + " " + root.daylight
                    color: root.inkTertiary
                    size: 12
                }
            }
        }
        SunPath {
            Layout.fillWidth: true
            Layout.fillHeight: true
            Layout.topMargin: root.dp(6)
        }
        FaceHours { face: root; Layout.fillWidth: true; Layout.topMargin: root.dp(2) }
        ColumnLayout {
            Layout.fillHeight: false
            visible: root.large
            Layout.fillWidth: true
            Layout.topMargin: root.dp(12)
            spacing: root.dp(8)
            FaceFact {
                face: root
                tint: root.warm
                visible: root.sunKnown
                Layout.fillWidth: true
                glyph: root.other.glyph
                label: root.other.name
                value: root.other.time
            }
            FaceFact {
                face: root
                tint: root.warm
                visible: root.sunKnown
                Layout.fillWidth: true
                glyph: "light_mode"
                label: Translation.tr("Daylight")
                value: root.daylight
            }
            FaceFact {
                face: root
                tint: root.warm
                Layout.fillWidth: true
                glyph: "dark_mode"
                label: Translation.tr("Moon")
                value: Weather.moonPhaseName
            }
        }
    }
}
