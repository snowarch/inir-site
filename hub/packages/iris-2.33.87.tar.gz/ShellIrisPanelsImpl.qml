pragma ComponentBehavior: Bound

import QtQuick
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.iris.notificationPopup
import qs.modules.iris.onScreenDisplay
import qs.modules.iris.session
import qs.modules.iris.polkit
import qs.modules.iris.style
import qs.modules.iris.pieces
import qs.modules.iris.settings
import qs.modules.iris.studio
import qs.modules.iris.lock
import qs.modules.iris.sidebar
import qs.modules.iris.orbit
import qs.modules.iris.osk
import qs.modules.shared.background
import qs.modules.shared.background.widgets
import qs.modules.shared.lock
import qs.modules.shared.overlay
import qs.modules.iris.state
import qs.modules.iris.frame
import qs.modules.iris.prism

Item {
    id: root

    component PanelLoader: LazyLoader {
        required property string identifier
        property bool extraCondition: true
        readonly property bool enabledPanel: Config.ready && IrisGate.official
            && (Config.options?.enabledPanels ?? []).includes(identifier)
            && extraCondition
        loading: enabledPanel
        activeAsync: enabledPanel
    }

    component DeferredPanelLoader: LazyLoader {
        required property string identifier
        property bool extraCondition: true
        readonly property bool enabledPanel: Config.ready && IrisGate.official
            && (Config.options?.enabledPanels ?? []).includes(identifier)
            && extraCondition
        loading: enabledPanel && GlobalStates.shellEntryReady
        activeAsync: enabledPanel && GlobalStates.deferredPanelsReady
    }

    component OnDemandPanelLoader: LazyLoader {
        id: loader
        required property string identifier
        required property bool open
        property bool extraCondition: true
        property bool requireEnabledPanel: true
        property int closeGraceMs: IrisStyle.revealDuration + 30
        // A panel is built when it opens and let go a while after it closes: reopened within `keepMs` it only shows
        // again. Built at idle and kept for good (10-26), Settings, both sidebars and the overlay held ~16k objects and
        // ~160 MB from start on a shell that never opened them.
        property bool keep: false
        property int keepMs: 60000
        property bool resident: open
        property Timer closeGrace: Timer {
            interval: loader.keep ? Math.max(loader.closeGraceMs, loader.keepMs) : loader.closeGraceMs
            onTriggered: loader.resident = loader.open
        }
        readonly property bool enabledPanel: Config.ready && IrisGate.official
            && (!requireEnabledPanel || (Config.options?.enabledPanels ?? []).includes(identifier))
            && extraCondition

        onOpenChanged: {
            if (open) {
                closeGrace.stop()
                resident = true
            } else {
                closeGrace.restart()
            }
        }

        loading: enabledPanel && resident
        activeAsync: enabledPanel && GlobalStates.deferredPanelsReady && resident

        // A background load that completes after the panel was closed hands the loader a live window nobody will
        // close (a quick open and close stranded the lock rehearsal over the whole screen, holding the keyboard).
        // Whatever the loader holds once the panel is no longer wanted is let go. `active` is read, never `item`,
        // which would force a pending load to finish.
        property Timer strandGuard: Timer {
            interval: 0
            // Only a panel nobody wants any more: while a reload rebuilds Config and the gate, `enabledPanel` is false
            // for a moment, and releasing on it dropped an open Settings and left its reloaded copy behind it.
            onTriggered: if (loader.active && !loader.resident) loader.active = false
        }
        onItemChanged: loader.strandGuard.restart()
        onResidentChanged: if (!loader.resident) loader.strandGuard.restart()
    }

    IrisAppsSync {}

    // A Design that decides the widgets' design wears it over the person's pick; it counts only while iRiS is the active
    // family, so leaving iRiS gives theirs back with nothing written on the way out.
    Binding {
        target: DesktopWidgetDesign
        property: "worn"
        value: ({ family: "iris", design: IrisDesign.widgets })
        restoreMode: Binding.RestoreNone
    }

    // Orbit's hot corner: a few pixels in one screen corner, on Top, only while it is on and something can use it.
    LazyLoader {
        active: IrisGate.official && (Config.options?.iris?.orbit?.enable ?? false) && (Config.options?.iris?.orbit?.hotCorner ?? true)
        component: IrisOrbitCorner {}
    }

    // The spectrum around the screens for a moment when something starts listening through the microphone.
    LazyLoader {
        id: edgeGlow
        property bool lit: false
        active: IrisGate.official && edgeGlow.lit && !GameMode.active
        component: IrisEdgeGlow {}
        property Connections listens: Connections {
            target: Privacy
            function onMicActiveChanged(): void {
                if (!Privacy.micActive || Config.options?.iris?.bar?.activities?.micGlow !== true) return
                edgeGlow.lit = true
                edgeGlowHold.restart()
            }
        }
        property Timer hold: Timer { id: edgeGlowHold; interval: 3300; onTriggered: edgeGlow.lit = false }
    }

    LazyLoader {
        active: IrisGate.official
        component: IrisSidebarEdge { side: "left" }
    }
    LazyLoader {
        active: IrisGate.official
        component: IrisSidebarEdge { side: "right" }
    }

    OnDemandPanelLoader {
        identifier: "irisSidebarLeft"
        requireEnabledPanel: false
        open: GlobalStates.sidebarLeftOpen
        extraCondition: Config.options?.iris?.sidebars?.left?.enable ?? true
        keep: true
        component: IrisSidebar { side: "left" }
    }

    OnDemandPanelLoader {
        identifier: "irisSidebarRight"
        requireEnabledPanel: false
        open: GlobalStates.sidebarRightOpen
        extraCondition: Config.options?.iris?.sidebars?.right?.enable ?? true
        keep: true
        component: IrisSidebar { side: "right" }
    }

    OnDemandPanelLoader {
        identifier: "irisNotificationPopup"
        open: (Notifications.popupList?.length ?? 0) > 0
        closeGraceMs: IrisStyle.settleDuration * 2 + 160
        extraCondition: (Config.options?.iris?.modules?.notificationPopup ?? true)
            && (!(Config.options?.enabledPanels ?? []).includes("irisBar")
                || (CompositorService.isNiri && GameMode.hasFullscreenOnOutput(GlobalStates.focusedScreen?.name ?? "") && !NiriService.inOverview
                    && (Config.options?.iris?.notifications?.fullscreen ?? true)))
        component: IrisNotificationPopup {}
    }

    OnDemandPanelLoader {
        identifier: "irisStudio"
        requireEnabledPanel: false
        open: IrisState.studioOpen
        closeGraceMs: IrisStyle.settleDuration + 120
        component: IrisStudio {}
    }

    // Settings is come back to: let go after a minute it was rebuilt on almost every visit (the wait he felt, 11-11).
    readonly property int settingsKeepMs: 600000
    // Prism, iRiS's Settings since 11-06: every area of iRiS Settings is a page of it.
    readonly property bool prismOn: (Config.options?.iris?.appearance?.settingsPanel ?? "prism") === "prism"
    OnDemandPanelLoader {
        identifier: "irisPrism"
        requireEnabledPanel: false
        open: GlobalStates.settingsOverlayOpen
        extraCondition: root.prismOn && !root.settingsWindowed
        keep: true
        keepMs: root.settingsKeepMs
        closeGraceMs: 0
        component: PrismWindow {}
    }
    // Prism as a window of its own; only the host in use is built.
    OnDemandPanelLoader {
        identifier: "irisPrismWindow"
        requireEnabledPanel: false
        open: GlobalStates.settingsOverlayOpen
        extraCondition: root.prismOn && root.settingsWindowed
        keep: true
        keepMs: root.settingsKeepMs
        closeGraceMs: 0
        component: PrismFloating {}
    }

    OnDemandPanelLoader {
        identifier: "irisSettings"
        requireEnabledPanel: false
        open: GlobalStates.settingsOverlayOpen
        // Only the host in use is kept: switching hosts builds the other once.
        extraCondition: !root.prismOn && !root.settingsWindowed
        keep: true
        keepMs: root.settingsKeepMs
        closeGraceMs: 0
        component: IrisSettingsOverlay {}
    }

    readonly property bool settingsWindowed: (Config.options?.iris?.appearance?.settingsHost ?? "overlay") === "window"
    OnDemandPanelLoader {
        identifier: "irisSettingsWindow"
        requireEnabledPanel: false
        open: GlobalStates.settingsOverlayOpen
        extraCondition: !root.prismOn && root.settingsWindowed
        keep: true
        keepMs: root.settingsKeepMs
        closeGraceMs: 0
        component: IrisSettingsWindow {}
    }

    // The source comes the first time it's wanted and stays: a LazyLoader compiles its source as soon as it has one,
    // and dropping it would delete the component under a load still running.
    LazyLoader {
        id: backdropLoader
        readonly property bool wanted: Config.ready && IrisGate.official && GlobalStates.deferredPanelsReady
            && CompositorService.isNiri && (Config.options?.background?.backdrop?.enable ?? false)
        property bool used: false
        onWantedChanged: if (backdropLoader.wanted) backdropLoader.used = true
        Component.onCompleted: backdropLoader.used = backdropLoader.used || backdropLoader.wanted
        source: backdropLoader.used ? Plugins.baseUrl("modules/shared/background/Backdrop.qml") : ""
        activeAsync: backdropLoader.wanted && backdropLoader.source !== ""
    }

    LazyLoader {
        activeAsync: Config.ready && IrisGate.official && GlobalStates.deferredPanelsReady
            && (Config.options?.enabledPanels ?? []).includes("irisBackground")
            && (Config.options?.iris?.modules?.desktopWidgets ?? true)
        component: Background { family: "iris" }
    }

    PanelLoader {
        identifier: "irisOnScreenDisplay"
        extraCondition: (Config.options?.iris?.modules?.osd ?? true)
            && (!GlobalStates.barOpen
                || (CompositorService.isNiri && GameMode.hasFullscreenOnOutput(GlobalStates.focusedScreen?.name ?? "") && !NiriService.inOverview)
                || !(Config.options?.enabledPanels ?? []).includes("irisBar")
                || ((Config.options?.iris?.bar?.screenList ?? []).length > 0
                    && !(Config.options.iris.bar.screenList).includes(GlobalStates.focusedScreen?.name ?? "")))
        component: IrisOSD {}
    }

    OnDemandPanelLoader {
        identifier: "irisSessionScreen"
        open: GlobalStates.sessionOpen
        extraCondition: Config.options?.iris?.modules?.sessionScreen ?? true
        component: IrisSessionScreen {}
    }

    DeferredPanelLoader {
        identifier: "irisLock"
        extraCondition: Config.options?.iris?.modules?.lock ?? true
        component: Lock {}
    }

    DeferredPanelLoader {
        identifier: "irisPolkit"
        extraCondition: Config.options?.iris?.modules?.polkit ?? true
        component: IrisPolkit {}
    }

    OnDemandPanelLoader {
        identifier: "irisOverlay"
        // A base before the bench has no `wanted`.
        open: OverlayContext.wanted ?? (GlobalStates.overlayOpen || OverlayContext.hasPinnedWidgets || OverlayContext.nativeDialogOpen)
        requireEnabledPanel: false
        keep: true
        source: Plugins.baseUrl("modules/shared/overlay/Overlay.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisCheatsheet"
        open: GlobalStates.cheatsheetOpen
        requireEnabledPanel: false
        source: Plugins.baseUrl("modules/shared/cheatsheet/Cheatsheet.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisOnScreenKeyboard"
        open: GlobalStates.oskOpen
        requireEnabledPanel: false
        closeGraceMs: IrisStyle.settleDuration + 80
        component: IrisOnScreenKeyboard {}
    }

    OnDemandPanelLoader {
        identifier: "irisRegionSelector"
        open: GlobalStates.regionSelectorOpen || GlobalStates.annotationEditorOpen
        requireEnabledPanel: false
        source: Plugins.baseUrl("modules/shared/regionSelector/RegionSelector.qml")
    }


    OnDemandPanelLoader {
        identifier: "irisLockRehearsal"
        open: IrisState.lockEdit
        requireEnabledPanel: false
        component: IrisLockRehearsal {}
    }

    // Material's pickers, when Settings › Desktop › Picker names one. Whatever opens the gallery directly (Island,
    // pieces, Settings) lands on the chosen one: the grid answers wallpaperSelectorOpen, the other two take it over.
    readonly property bool materialPicker: String(Config.options?.iris?.wallpaper?.picker ?? "iris") === "material"
    readonly property bool galleryAsked: GlobalStates.wallpaperSelectorOpen
    onGalleryAskedChanged: {
        if (!root.galleryAsked || !root.materialPicker) return
        const style = String(Config.options?.wallpaperSelector?.style ?? "grid")
        if (style !== "coverflow" && style !== "launcher") return
        GlobalStates.wallpaperSelectorOpen = false
        if (style === "coverflow") GlobalStates.coverflowSelectorOpen = true
        else GlobalStates.wallpaperLauncherOpen = true
    }

    OnDemandPanelLoader {
        identifier: "irisMaterialWallpaperSelector"
        open: root.materialPicker && GlobalStates.wallpaperSelectorOpen
        requireEnabledPanel: false
        closeGraceMs: 250
        source: Plugins.baseUrl("modules/shared/wallpaperSelector/WallpaperSelector.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisWallpaperLauncher"
        open: GlobalStates.wallpaperLauncherOpen
        requireEnabledPanel: false
        source: Plugins.baseUrl("modules/shared/wallpaperLauncher/WallpaperLauncher.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisCoverflowSelector"
        open: GlobalStates.coverflowSelectorOpen
        requireEnabledPanel: false
        source: Plugins.baseUrl("modules/shared/wallpaperSelector/WallpaperCoverflow.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisRecordingOsd"
        open: RecorderStatus.isRecording
        requireEnabledPanel: false
        extraCondition: !(GlobalStates.barOpen
            && (Config.options?.enabledPanels ?? []).includes("irisBar"))
        source: Plugins.baseUrl("modules/shared/recordingOsd/RecordingOsd.qml")
    }

    OnDemandPanelLoader {
        identifier: "irisTilingOverlay"
        open: GlobalStates.tilingOverlayPickerOpen || GlobalStates.tilingOverlayOsdOpen
        requireEnabledPanel: false
        source: Plugins.baseUrl("modules/shared/tilingOverlay/TilingOverlay.qml")
    }
}
