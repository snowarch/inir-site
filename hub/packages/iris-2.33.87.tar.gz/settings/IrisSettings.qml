pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Effects
import QtQuick.Layouts
import QtQuick.Shapes
import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import qs
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.iris.frame
import qs.modules.iris.components
import qs.modules.iris.style
import qs.modules.iris.field as Field
import qs.modules.iris.pieces
import qs.modules.iris.sidebar
import qs.modules.iris.preview
import qs.modules.iris.settings.layouts as Layouts // in Quickshell's import graph: the page loads them by url
import qs.modules.iris.widgets
import qs.modules.iris.state

Item {
    id: root
    // The place a look is worn by (`iris.appearance.places.settings`).
    readonly property string irisPlace: "settings"
    // Hosted by IrisSettingsOverlay (a layer over the desktop) or IrisSettingsWindow (a Niri window).
    property bool windowed: false
    readonly property alias frame: frame
    readonly property var screen: root.QsWindow.window?.screen ?? null
    property string section: "general"
    // The main-list row that holds the selection, for the travelling wash in the sidebar.
    property Item travelRow: null
    property int advancedPage: -1
    property string query: ""
    property string group: ""
    property var backStack: []
    property var forwardStack: []
    property string requestedSection: ""
    property bool placed: false
    readonly property real d: IrisStyle.settingsDensity
    // The page's geometry, one owner for every layout (Classic, Folio): each reads these and none
    // keeps its own. They once read 8, 12, 14, 16, 20 and 28 from the window's edge and ended out of line (his 10-31).
    // A pane (sidebar, index, sheet) stands one air off the window's edges and off its neighbour, concentric with the window.
    readonly property int paneInset: Math.round(8 * root.d)
    readonly property int paneRadius: IrisStyle.concentric(frame.radius, root.paneInset, IrisStyle.radiusTile)
    // What a pane's words keep from its edge (the sidebar's list, the index's keys).
    readonly property int panePad: IrisStyle.concentricPad(root.paneRadius, 10 * root.d)
    // Form and stage plates on a sheet: concentric with it, so they round as `radiusTile` a sheet's pad in.
    readonly property int plateRadius: IrisStyle.radiusTile
    readonly property int sheetPad: Math.max(Math.round(4 * root.d), root.paneRadius - root.plateRadius)
    // Where the plates stand from the window's side and the head's keys end: the same line top to bottom. A layout
    // with no sheet (solid) keeps its plates there too.
    readonly property int plateInset: root.paneInset + root.sheetPad
    // The head's keys sit on the line of the sidebar's search (its centre), in every layout.
    readonly property int headLine: root.paneInset + root.panePad + Math.round(16 * root.d)
    // Past this a label sits too far from its control to aim at.
    readonly property real rowsMost: Math.round(880 * root.d)
    // A section about hardware this machine lacks is not offered (Battery on a desktop); `inir battery simulate` brings it back.
    // Home leads every layout: the rows it was given and a few shortcuts (Customize › On Home picks them).
    readonly property var sections: IrisOptions.sections.filter(section => section.id !== "battery" || Battery.available)
    // Sources and the Community Hub sit in a footer under the list, always in view.
    readonly property int footerCluster: 4
    readonly property var specifications: IrisOptions.settings
    readonly property var currentSection: IrisOptions.sectionById(root.section)
    // Every area is a row of the sidebar (DI49g); each group of areas opens under its name (his 10-30: parted by air
    // alone, the list read as one run in no order).
    readonly property var sideSections: {
        const out = root.sections.filter(section => section.id === "general").map(section => ({ id: section.id, title: section.title, icon: section.icon, cluster: section.cluster }))
        IrisOptions.categories.filter(category => !category.foot).forEach((category, at) => {
            category.sections.map(id => root.sections.find(section => section.id === id)).filter(section => !!section)
                // Its plain fields only: copying ran the area's tint getter here and rebuilt the whole sidebar on every colour
                // change. A row reads the tint itself (SectionRow.tint).
                .forEach(section => out.push({ id: section.id, title: section.title, icon: section.icon, cluster: at, caption: category.title }))
        })
        return out
    }
    // An area's colour as ink: lifted toward the text so a chosen name reads on its wash in dark and light.
    function tintInk(tint: color): color {
        const ink = IrisStyle.text
        return Qt.rgba(tint.r * 0.72 + ink.r * 0.28, tint.g * 0.72 + ink.g * 0.28, tint.b * 0.72 + ink.b * 0.28, 1)
    }
    readonly property bool searching: root.query.length > 0
    // A Design may lay the whole page out its own way (DESIGNS.md › Composiciones): its `settingsPage` draws the areas,
    // the head and the foot, and holds this file's search, scene, rows and shared pages in its slots. The model, the
    // history and every row stay here.
    // iRiS lays the page in the layout chosen in Settings (Folio); a Design with its own page keeps it.
    // Only layouts whose page exists: a missing one would leave the body waiting for its scene forever.
    readonly property var layouts: ({ folio: "Folio" })
    // Classic is the engine's own page (the sidebar and its pages, as before the layouts): no layout file.
    readonly property string chosenLayout: {
        const wanted = String(Config.options?.iris?.appearance?.settingsLayout ?? "classic")
        return wanted === "classic" || root.layouts[wanted] ? wanted : "classic"
    }
    readonly property string layout: IrisDesign.skin("settingsPage").length > 0 || root.chosenLayout === "classic" ? "" : root.chosenLayout
    // A layout gives way to another as a picture (SekaiPop's phone moves): the page is shot, the body glides to its new box
    // with the shot riding it, the new layout builds off screen at its final size and rises once it stands. Re-laying
    // the whole page on every frame of the glide froze the shell for the length of it.
    property string pendingLayout: ""
    property bool switching: false
    readonly property bool layoutStands: !root.sceneDesigned || root.sceneDrawn || pageScene.status === Loader.Error
    function setLayout(name: string): void {
        if ((name !== "classic" && !root.layouts[name]) || name === root.chosenLayout || shotTaken.running) return
        root.pendingLayout = name
        layoutShot.from = Qt.size(frame.width, frame.height)
        layoutShot.opacity = 1
        layoutShot.scheduleUpdate()
        shotTaken.restart()
    }
    function endSwitch(): void {
        if (!root.switching || reshape.running || shotTaken.running || !root.layoutStands) return
        root.switching = false
    }
    onLayoutStandsChanged: Qt.callLater(root.endSwitch)
    // Two frames for the shot to hold the page before the write rebuilds it.
    Timer {
        id: shotTaken
        interval: 34
        onTriggered: {
            root.switching = true
            reshape.restart()
            switchGuard.restart()
            shotFade.restart()
            Config.setNestedValue("iris.appearance.settingsLayout", root.pendingLayout)
        }
    }
    Timer { id: reshape; interval: IrisStyle.morphDuration + 60; onTriggered: root.endSwitch() }
    // However the new layout's build went, it shows: a switch left waiting kept the body at opacity 0 (10-25, Folio blank).
    Timer { id: switchGuard; interval: 1200; onTriggered: { root.switching = false; layoutShot.opacity = 0 } }
    // The voice the layout gives its rows' controls and group heads.
    readonly property string voice: root.sceneDrawn ? String(root.scene.voice ?? "") : ""
    // An auto-hidden Island or Dock that stays up on an empty workspace keeps its edge out of the room.
    readonly property bool workspaceEmpty: {
        const out = root.screen?.name ?? ""
        if (root.windowed || out === "" || !CompositorService.isNiri) return false
        const active = (NiriService.allWorkspaces ?? []).find(ws => ws.output === out && ws.is_active)
        return active !== undefined && !(NiriService.windows ?? []).some(w => w.workspace_id === active.id)
    }
    // The overlay's free box: clear of the band, the Island, the Dock and the pieces on their edges.
    readonly property var room: {
        const gap = Math.round(14 * root.d)
        const side = edge => Math.max(0, IrisFrame.safeInset(edge, root.screen?.name ?? "") - IrisFrame.band,
            root.workspaceEmpty ? IrisFrame.emptyDepth(edge) + IrisFrame.musicReach(edge) : 0) + gap
        const left = side("left"), right = side("right"), top = side("top"), bottom = side("bottom")
        return { x: left, y: top, width: Math.max(0, root.width - left - right), height: Math.max(0, root.height - top - bottom) }
    }
    // The clusters the areas are kept in, named for a layout that prints them (Folio's ruler).
    readonly property var clusterNames: ["Look", "Desktop", "Tools", "System", "More"]
    // Every area's notes (IrisOptions.notesBySection), taken when Settings has opened and after each config change.
    property var notes: ({})
    readonly property var noteCounts: { const out = {}; for (const id in root.notes) out[id] = root.notes[id].length; return out }
    readonly property var notesHere: root.notes[root.section] ?? []
    Timer { id: notesLater; interval: 300; onTriggered: root.notes = IrisOptions.notesBySection() }
    Connections { target: Config; function onRevisionChanged(): void { notesLater.restart() } }
    // Read once the body has landed: a 30 ms pass mid-morph is a dropped frame.
    // the body has finished opening: a layout holds its extras until then
    readonly property bool bodySettled: frame.settled
    Connections { target: frame; function onSettledChanged(): void { if (frame.settled) root.notes = IrisOptions.notesBySection() } }
    // Takes you to the first note of the area, or of the next area that has one.
    function openNote(): void {
        const here = root.notesHere
        if (here.length > 0) { root.showGroup(Translation.tr(here[0].group)); return }
        const next = root.sections.find(entry => (root.noteCounts[entry.id] ?? 0) > 0)
        if (next) root.selectSection(next.id)
    }
    readonly property Item scene: pageScene.item
    readonly property bool sceneDrawn: root.scene !== null
    // Narrower than this a Design's page squeezes its sheet: the engine's page is used. Frame width, never the page's.
    readonly property bool sceneFits: frame.width >= Math.round(960 * root.d)
    // A Design that draws the page is known before its scene arrives: the engine's own chrome is then never built, and the
    // body waits for the scene instead of showing that chrome for the frames the scene takes to load.
    readonly property bool sceneDesigned: pageScene.url.length > 0
    readonly property bool sceneWanted: root.layout.length > 0 || IrisDesign.skin("settingsPage").length > 0
    // How tall the rows a scene holds are, so it can end their sheet where they end; -1 while a shared page fills the slot.
    readonly property real rowsExtent: settingsFlick.visible
        ? settingsFlick.anchors.topMargin + settingsFlick.contentHeight + settingsFlick.anchors.bottomMargin : -1
    // A section with a single group has nothing to choose between: it opens on that group.
    readonly property string openGroup: root.searching ? ""
        : root.group.length > 0 ? root.group
        : root.groups.length === 1 ? root.groups[0].title : ""
    readonly property real pageWidth: root.sceneDrawn ? Number(root.scene.pageWidth ?? frame.width) : frame.width - root.sidebarFull
    readonly property real sidebarNeed: root.sceneDrawn ? Number(root.scene.need ?? 0) : sidebarLayout.implicitHeight + 2 * sidebar.pad + Math.round(4 * root.d)
    // The sidebar keeps its width on every section: it never narrows to a rail (2026-10-15). It is as wide as the longest
    // area name prints bold (the one you are on), within a third of the window: a translated name never elides.
    readonly property real sidebarFull: Math.round(Math.min(Math.max(272 * root.d, root.longestArea + 88 * root.d), frame.width * 0.3))
    // Reads the metrics' font so it measures again once the font's bindings land (first measured at the default weight).
    readonly property real longestArea: areaMetrics.font.pixelSize > 0 ? root.sections.reduce((widest, section) => Math.max(widest,
        areaMetrics.advanceWidth(Translation.tr(String(section.title ?? "")))), 0) : 0
    FontMetrics {
        id: areaMetrics
        font.family: IrisStyle.fontRead
        font.pixelSize: IrisStyle.typeBody
        font.letterSpacing: IrisStyle.tracking(IrisStyle.typeBody)
        font.weight: IrisStyle.weight(Font.Bold)
    }
    readonly property bool wideEnough: root.pageWidth >= Math.round(720 * root.d)
    // The Hub is a section of its own: its page fills the pane.
    readonly property bool pageInPane: root.advancedPage >= 0 && root.wideEnough && root.morePages.some(entry => root.pageIndexOf(entry.key) === root.advancedPage)
    readonly property bool paneable: (root.advancedPage < 0 || root.pageInPane) && root.wideEnough
    // A Design's page lays the rows on its own sheet.
    readonly property bool split: root.sceneDrawn && root.paneable && !root.searching
    // A group asked for by name (a link, the CLI, history) is a place on the area's page: it glides there once built.
    function showGroup(title: string): void {
        root.group = ""
        if (title.length > 0) root.scrollToGroup(title)
    }
    readonly property bool browsing: !root.searching && root.openGroup.length === 0 && root.advancedPage < 0
    function shown(spec: var): bool { return IrisOptions.shown(spec) }

    readonly property int searchLimit: 24
    // Every row's words by where they sit (translated and English), built the first time a search runs after the rows or
    // the language changed. As a binding it was rebuilt with the rows on every colour change, Settings closed or not.
    // Filled in place, never reassigned: a write here would wake the very binding (matches) that asked for it.
    readonly property var searchCache: ({ rows: null, language: "", index: [], areaWords: new Set() })
    function searchIndex(): var {
        const rows = root.specifications, language = Translation.languageCode
        if (root.searchCache.rows === rows && root.searchCache.language === language) return root.searchCache.index
        const index = rows.filter(spec => !spec.mirror).map(spec => {
            const section = IrisOptions.sectionById(spec.section)
            const sectionTitle = Translation.tr(section.title)
            const words = text => IrisSearch.tokens(text)
            return { spec: spec,
                fields: { label: words(Translation.tr(spec.label) + " " + spec.label), keys: words((spec.keywords ?? []).join(" ")),
                    group: words(Translation.tr(spec.group ?? "") + " " + (spec.group ?? "")), section: words(sectionTitle + " " + section.title),
                    desc: words(Translation.tr(spec.description ?? "") + " " + (spec.description ?? "")) },
                loose: IrisSearch.prepare({ name: Translation.tr(spec.label), english: spec.label, detail: Translation.tr(spec.group ?? ""), areaName: sectionTitle,
                    words: [spec.group ?? ""].concat(spec.keywords ?? []).join(" ") }) }
        })
        // Every word an area's title is made of: a query that names an area keeps the rows of other areas behind its own.
        const areaWords = new Set()
        for (const entry of index) for (const word of entry.fields.section) areaWords.add(word)
        Object.assign(root.searchCache, { rows: rows, language: language, index: index, areaWords: areaWords })
        return index
    }
    // What people mean first (IrisSearch.intent: filler words out, the words Settings uses for theirs, the area they
    // name); only when that finds nothing, what the forgiving match reads through a typo, initials or letters in order.
    readonly property var matches: {
        Config.revision
        const q = IrisSearch.intent(root.query)
        if (q.hard.length === 0 && q.soft.length === 0) return []
        const index = root.searchIndex()
        q.asksArea = q.hard.some(term => root.searchCache.areaWords.has(term.word))
        const shown = hit => root.shown(hit.spec) && root.sections.some(section => section.id === hit.spec.section)
        let hits = index
            .map((entry, order) => ({ spec: entry.spec, order: order, score: IrisSearch.settingScore(q, entry.fields, entry.spec) }))
            .filter(hit => hit.score > 0 && shown(hit))
        if (hits.length === 0)
            hits = index
                .map((entry, order) => ({ spec: entry.spec, order: order, score: IrisSearch.score(root.query, entry.loose) }))
                .filter(hit => hit.score >= 0.6 && shown(hit))
        return hits.sort((a, b) => b.score - a.score || a.order - b.order).map(hit => hit.spec)
    }
    readonly property var matchedSections: {
        const ids = new Set(root.matches.map(spec => spec.section))
        return ids
    }
    // A layout that draws an area's rows on its own pages (Folio) gets nothing from here but a search or
    // a shared page: the engine reads no area for it, so a turn costs it nothing.
    readonly property bool layoutRows: ((root.scene?.drawsRows ?? false) || root.classicRows) && !root.searching && root.advancedPage < 0
    // Classic shows an area as Folio does (stage, its contents, the groups open with each control in its row), from
    // its own pool beside the sidebar: one page in every layout.
    // The Community Hub area is its links (the Hub, About, Shortcuts) and stays the engine's.
    readonly property bool classicRows: !root.sceneDrawn && !root.searching && root.advancedPage < 0 && root.section !== "system"
    readonly property var entries: {
        Config.revision
        if (root.layoutRows) return []
        return root.searching ? root.matches.slice(0, root.searchLimit)
            : root.specifications.filter(spec => spec.section === root.section && root.shown(spec))
    }
    readonly property var groups: {
        const out = []
        for (const spec of root.entries) {
            // A result names where it lives, section and group, so the path is learned while searching.
            const sectionTitle = Translation.tr(IrisOptions.sectionById(spec.section).title)
            const groupTitle = Translation.tr(spec.group ?? "")
            const title = !root.searching ? groupTitle
                : groupTitle.length > 0 && groupTitle !== sectionTitle ? sectionTitle + "  ›  " + groupTitle : sectionTitle
            let group = out.find(entry => entry.title === title)
            if (!group) { group = { title: title, key: String(spec.group ?? ""), rows: [] }; out.push(group) }
            group.rows.push(spec)
        }
        return out
    }
    // The engine draws groups only for a search; an area is its layout's page.
    readonly property var shownGroups: root.searching ? root.groups : []
    // A page's groups arrive one per frame: building a long page's rows at once (Appearance, Lock) froze the whole
    // shell for a quarter second on every switch. The first comes at once, so the top of the page is there on the
    // first frame; a search or a link to a row gets every group at once, so it can scroll to it.
    readonly property string pageKey: root.section + "/" + root.openGroup + "/" + root.advancedPage
    // Read fresh where the turn's other bindings are still settling: `pageKey` may hold the area being left there
    // (an area's groups were filed under the previous one, and an empty page kept the last area's rows on screen).
    function keyNow(): string { return root.section + "/" + root.openGroup + "/" + root.advancedPage }
    property string fedPage: ""
    property int blocksShown: 1
    // The page has arrived whole: a block built later (another block of a long area) comes in at once, never by trimming
    // the ones already there.
    property bool fedAll: false
    readonly property var fedGroups: {
        // A layout that draws an area's rows itself only takes the engine's for a search or a page.
        if (root.layoutRows) return []
        if (root.searching || root.landingPath.length > 0) return root.shownGroups
        const key = root.keyNow()
        if (root.fedAll && root.fedPage === key) return root.shownGroups
        const shown = root.fedPage === key ? root.blocksShown : 1
        return shown >= root.shownGroups.length ? root.shownGroups : root.shownGroups.slice(0, shown)
    }
    // The page is still building (blocks fed a frame apart, each built in slices): it waits unseen, then rises whole.
    property int blockTick: 0
    property real rowsReveal: 1
    onRowsPendingChanged: if (!root.rowsPending && frame.settled && IrisStyle.motionEnabled) rowsIn.restart()
    NumberAnimation { id: rowsIn; target: root; property: "rowsReveal"; from: 0; to: 1; duration: IrisStyle.duration(200); easing.type: Easing.OutCubic }
    readonly property bool rowsPending: {
        root.blockTick
        if (root.searching || !root.browsing || root.shownGroups.length === 0) return false
        const standing = root.blockRepeater
        if (standing.count >= root.shownGroups.length && Array.from({ length: standing.count }, (_, i) => standing.itemAt(i)).every(b => b && b.status === Loader.Ready)) return false
        if (root.shownGroups.length > 1 && !(root.fedAll && root.fedPage === root.keyNow())) return true
        // Fed before the Repeater made its loaders (the layout still loading): nothing built yet is still pending.
        if (root.blockRepeater.count < root.fedGroups.length) return true
        for (let i = 0; i < root.blockRepeater.count; i++) {
            const block = root.blockRepeater.itemAt(i)
            if (!block || block.status !== Loader.Ready) return true
        }
        return false
    }
    // Four sets of blocks, one per recent page: an area seen before is shown again as it stood, nothing rebuilt (every
    // turn used to tear down the page and build the next one, ~2400 rows' objects). A new page builds in the set used
    // longest ago, its first block in the background, unseen until it stands.
    readonly property int slots: 4
    property int building: 0
    property bool holding: false
    property var bufs: [[], [], [], []]
    property var bufPages: ["", "", "", ""]
    property var bufUsed: [0, 0, 0, 0]
    property int bufClock: 0
    readonly property string bufPage: root.bufPages[root.building]
    readonly property Repeater blockRepeater: [blocks0, blocks1, blocks2, blocks3][root.building]
    onFedGroupsChanged: root.refeed()
    function refeed(): void {
        const pages = root.bufPages.slice(), used = root.bufUsed.slice(), bufs = root.bufs.slice()
        const key = root.keyNow()
        let slot = pages.indexOf(key)
        if (slot < 0) {
            slot = 0
            for (let i = 1; i < root.slots; i++) if (used[i] < used[slot]) slot = i
            const onScreen = bufs[root.building]
            root.holding = onScreen.length > 0 && root.fedGroups.length > 0 && !root.searching && root.landingPath.length === 0 && frame.settled
            if (root.holding) holdLimit.restart()
            pages[slot] = key
            bufs[slot] = []
        } else if (slot !== root.building) root.holding = false
        // Fed again from its first group: a page already standing keeps the blocks it has. Never a search: every query
        // shares one key, and a narrower one (or none at all) kept the last query's results under it.
        const have = bufs[slot], fed = root.fedGroups
        const prefix = !root.searching && fed.length > 0 && fed.length < have.length && fed.every((g, i) => g?.title === have[i]?.title)
        if (!prefix) bufs[slot] = fed
        used[slot] = ++root.bufClock
        root.bufPages = pages
        root.bufUsed = used
        root.bufs = bufs
        root.building = slot
        root.letGoOfOld()
    }
    function letGoOfOld(): void {
        if (!root.holding) return
        const first = root.blockRepeater.itemAt(0)
        if (root.fedGroups.length > 0 && !(first && first.status === Loader.Ready)) return
        root.holding = false
    }
    onBlockTickChanged: root.letGoOfOld()
    Timer { id: holdLimit; interval: 700; onTriggered: root.holding = false }
    function feedPage(): void {
        root.fedPage = root.keyNow()
        root.fedAll = false
        root.blocksShown = 1
        blockFeed.restart()
        // A page with nothing to feed (a list of its groups) leaves `fedGroups` the same empty array: no change
        // signal, so the set on screen would stay the last area's.
        root.refeed()
    }
    Timer {
        id: blockFeed
        interval: 16
        repeat: true
        onTriggered: {
            if (root.blocksShown >= root.shownGroups.length) { stop(); root.fedAll = true }
            else root.blocksShown += 1
        }
    }
    // Puts a row in view and lights it, as a search result lands.
    function landOn(path: string): void {
        root.landingPath = path
        landingClear.restart()
    }
    // The pages iRiS keeps beside its sections, asked for by name ("about", "shortcuts", "hub"). Each scrolls itself.
    readonly property var pages: [
        { key: "about", component: Qt.resolvedUrl("IrisAboutPage.qml") },
        { key: "shortcuts", component: Qt.resolvedUrl("IrisShortcutsPage.qml") },
        { key: "hub", component: Qt.resolvedUrl("IrisHubPage.qml") }
    ]
    property var unfolded: ({})
    // Every Fine-tune fold on the page at once (`inir iris settings tune:open`); a section change folds them again.
    property bool tuneAll: false
    function fold(key: string): void {
        const next = Object.assign({}, root.unfolded)
        next[key] = !next[key]
        root.unfolded = next
    }
    IrisGroupPreview { id: sceneProbe; visible: false; section: ""; group: "" }
    // The wallpaper every scene is drawn on, decoded once in each of the two sizes a scene asks for (IrisGroupPreview
    // `decodeFor`) while Settings is open: a scene arriving takes it from the image cache in the same frame. Measured: the
    // scene drew in 40 ms and its wallpaper landed 150-220 ms later, decoded again at each width the page passed through
    // while it settled.
    Repeater {
        model: [1, 1024]
        IrisWallpaperView {
            required property int modelData
            visible: false
            live: false
            screen: GlobalStates.focusedScreen
            provideTexture: true
            decodeSize: sceneProbe.decodeFor(modelData)
        }
    }
    readonly property var morePages: IrisOptions.morePages.filter(entry => root.pages.some(page => page.key === entry.key))
    readonly property var moreGroups: [...new Set(root.morePages.map(entry => Translation.tr(entry.group)))]
    // iRiS's own pages (General's links) are found by search as the shared ones are.
    readonly property var ownPages: [
        { key: "about", home: "general", label: "About iNiR", detail: "Version, updates and the people behind it", icon: "info",
            get tint() { return IrisStyle.identity.lavender }, keywords: ["about", "version", "update", "credits", "acerca"] },
        { key: "shortcuts", home: "general", label: "Keyboard shortcuts", detail: "Every keybind, searchable", icon: "keyboard",
            get tint() { return IrisStyle.identity.indigo }, keywords: ["shortcuts", "keybinds", "hotkeys", "binds", "atajos"] }
    ].filter(entry => root.pages.some(page => page.key === entry.key))
    readonly property var pageMatches: {
        const terms = root.query.toLowerCase().split(/\s+/).filter(term => term.length > 0)
        if (terms.length === 0) return []
        return root.ownPages.concat(root.morePages).filter(entry => {
            // The English names too: "about" finds Acerca de in any language, as rows do through `english`.
            const text = [Translation.tr(entry.label), Translation.tr(entry.detail), entry.label, entry.detail, ...(entry.keywords ?? [])].join(" ").toLowerCase()
            return terms.every(term => text.includes(term))
        })
    }
    // A page leads when every word typed starts a word of its name ("shortcuts" → Keyboard shortcuts, "colour themes").
    readonly property bool pagesFirst: {
        const terms = root.query.trim().toLowerCase().split(/\s+/).filter(term => term.length > 0)
        return terms.length > 0 && root.pageMatches.some(entry => [Translation.tr(entry.label), entry.label]
            .some(name => { const words = name.toLowerCase().split(/\s+/); return terms.every(term => words.some(word => word.startsWith(term))) }))
    }
    function openFirstResult(): void {
        if (root.pageMatches.length > 0 && (root.pagesFirst || root.matches.length === 0)) {
            root.moreLink(root.pageMatches[0]).action()
            return
        }
        const spec = root.matches[0]
        if (spec) root.openResult(spec, true)
    }
    // Where a result is shown: its area's page, the row scrolled into view and glowing once, so the eye lands on it.
    property string landingPath: ""
    function scrollToGroup(wanted: string): void {
        if (root.classicRows) classicPool.showGroup(wanted)
        else if (typeof root.scene?.showGroup === "function") root.scene.showGroup(wanted)
    }
    function openResult(spec: var, land: bool): void {
        searchField.text = ""
        root.landingPath = land ? String(spec.path ?? "") : ""
        landingClear.restart()
        root.go({ section: spec.section, group: "", advancedPage: -1 })
    }
    function reveal(row: Item): void {
        const top = row.mapToItem(settingsRows, 0, 0).y
        const end = Math.max(0, settingsFlick.contentHeight - settingsFlick.height)
        revealMotion.to = Math.max(0, Math.min(end, top - settingsFlick.height * 0.3))
        revealMotion.restart()
    }
    Timer { id: landingClear; interval: 2400; onTriggered: root.landingPath = "" }
    function pageIndexOf(key: string): int { return root.pages.findIndex(page => page.key === key) }
    function moreLink(entry: var): var {
        return { label: Translation.tr(entry.label), value: Translation.tr(entry.detail), icon: entry.icon, tint: entry.tint,
            action: () => { searchField.text = ""; root.go({ section: entry.home ?? "system", group: "", advancedPage: root.pageIndexOf(entry.key) }) } }
    }
    function pageTitle(index: int): string {
        const entry = root.ownPages.concat(IrisOptions.morePages).find(candidate => candidate.key === root.pages[index]?.key)
        return entry ? Translation.tr(entry.label) : ""
    }
    // What a Design's page offers at its foot, and its name for the page: the toolbar's, as this layout reads them.
    readonly property var pageActions: [rehearseAction, customizeAction, restoreAction].filter(action => action.shown)
    readonly property string titleText: pageTitle.text
    function close(): void { GlobalStates.settingsOverlayOpen = false }
    readonly property var editTargets: ({ bar: "island", player: "bodies", bubbles: "pieces", dock: "dock", appearance: "material", colour: "colour",
        motion: "motion", desktop: "desktop", sidebars: "places", spotlight: "places", controlCenter: "bodies" })
    readonly property var studioTargets: ({ bar: "island", bubbles: "pieces", dock: "dock", appearance: "material", colour: "colour", motion: "motion",
        desktop: "desktop", sidebars: "places", controlCenter: "bodies", spotlight: "places", sound: "transients", notifications: "transients", player: "bodies" })

    function here(): var { return { section: root.section, group: root.group, advancedPage: root.advancedPage } }
    function same(a: var, b: var): bool {
        return a.section === b.section && a.group === b.group && a.advancedPage === b.advancedPage
    }
    function arrive(place: var): void {
        root.section = place.section
        root.advancedPage = root.landingPage(place.section, place.advancedPage)
        if (searchField.text.length > 0) searchField.text = ""
        root.showGroup(place.group)
    }
    // The Hub opens on its page, never on an empty pane.
    function landingPage(section: string, page: int): int {
        return section === "system" && page < 0 && root.wideEnough && root.morePages.length > 0 ? root.pageIndexOf(root.morePages[0].key) : page
    }
    function go(place: var, direction: var): void {
        const now = root.here()
        if (root.same(now, place) && !root.searching) return
        root.backStack = root.backStack.concat([now]).slice(-40)
        root.forwardStack = []
        root.arrive(place)
    }
    function goBack(): void {
        if (root.backStack.length === 0) return
        const place = root.backStack[root.backStack.length - 1]
        root.forwardStack = root.forwardStack.concat([root.here()])
        root.backStack = root.backStack.slice(0, -1)
        root.arrive(place)
    }
    function goForward(): void {
        if (root.forwardStack.length === 0) return
        const place = root.forwardStack[root.forwardStack.length - 1]
        root.backStack = root.backStack.concat([root.here()])
        root.forwardStack = root.forwardStack.slice(0, -1)
        root.arrive(place)
    }
    function selectSection(id: string): void { root.go({ section: id, group: "", advancedPage: -1 }) }
    function openGroupNamed(title: string): void { root.go({ section: root.section, group: title, advancedPage: -1 }) }
    function leaveGroup(): void {
        if (root.group.length > 0) root.go({ section: root.section, group: "", advancedPage: -1 })
    }

    property string requestedGroup: ""
    Timer {
        id: groupRequest
        property int tries: 0
        interval: 60
        repeat: true
        onRunningChanged: if (running) tries = 0
        onTriggered: {
            // Opened by the request, the layout's page loads a moment after: asked before it stood, the group went to
            // Classic's pool stayed at its top (10-29, "appearance/Faces").
            if (!root.layoutStands && ++tries <= 40) return
            // A layout that draws its own rows knows its groups; the engine has none to match (the jump never came).
            if (root.layoutRows) {
                stop()
                root.scrollToGroup(root.requestedGroup)
                root.requestedGroup = ""
                return
            }
            const wanted = root.requestedGroup.toLowerCase()
            const match = root.groups.find(group => group.title.toLowerCase() === wanted || group.key.toLowerCase() === wanted)
            if (match || ++tries > 20) {
                stop()
                root.requestedGroup = ""
                if (match) root.showGroup(match.title)
            }
        }
    }
    // A link written before a topic got its own section (appearance/Accent, lock/Login screen, desktop/Wallpaper gallery)
    // still lands: a group asked for where it no longer is opens in the section that holds it now.
    readonly property var renamedGroups: ({ "appearance/wallpaper": "Wallpaper tint", "player/on the edges": "Frame music", "player/finish": "Frame finish" })
    // A section folded into a sister keeps its old links: Frame Music lives in Now Playing.
    readonly property var renamedSections: ({ frameMusic: "player", home: "general" })
    function followMovedGroup(): void {
        let wanted = root.requestedGroup.toLowerCase()
        if (wanted.length === 0) return
        const holds = (section, name) => root.specifications.some(spec => spec.section === section && String(spec.group ?? "").toLowerCase() === name)
        if (holds(root.requestedSection, wanted)) return
        const renamed = String(root.renamedGroups[root.requestedSection + "/" + wanted] ?? "")
        if (renamed.length > 0) { root.requestedGroup = renamed; wanted = renamed.toLowerCase() }
        const home = root.specifications.find(spec => String(spec.group ?? "").toLowerCase() === wanted)
        if (home) root.requestedSection = home.section
    }
    function runCommand(verb: string): bool {
        if (verb === "back") root.goBack()
        else if (verb === "forward") root.goForward()
        else if (verb === "next") root.stepSection(1)
        else if (verb === "prev") root.stepSection(-1)
        else if (verb.startsWith("search:")) { searchField.text = verb.slice(7); root.query = searchField.text }
        else if (verb === "open") root.openFirstResult()
        else if (verb === "tune:open" || verb === "tune:close") root.tuneAll = verb === "tune:open"
        // `list:<row label>` opens that row's choices in place on the current page; `list:` closes it.
        else if (verb.startsWith("list:")) {
            const name = verb.slice(5).toLowerCase()
            const spec = root.entries.find(entry => String(entry.label ?? "").toLowerCase() === name)
            IrisOptions.openList = spec ? String(spec.path ?? "") + "|" + String(spec.section ?? "") + "|" + String(spec.label ?? "") : ""
        }
        else return false
        return true
    }
    // Material's pages iRiS draws in its own sections: a request for one (the desktop's "Widget settings") lands there.
    readonly property var nativePages: ({
        widgets: asked => asked === "Organic edge" ? "player/Edge wave" : "widgets",
        wallpaper: () => "wallpaper",
        tools: () => "capture",
        advanced: () => "colour/App colours",
        monitors: () => "display/Screens",
        themes: () => "colour/Colour theme",
        autostart: () => "general/Apps & login",
        services: () => "sources/Calendar",
        orbit: () => "orbit",
        dock: () => "dock",
        sidebars: () => "sidebars"
    })
    // A request names a page: "iris" (or any page iRiS has no copy of) opens its sections, at the place or verb the
    // section part carries; one of its own pages opens that page.
    function applyRequest(): void {
        // Switching hosts, the one leaving still hears the request and took it: the other opened on General.
        if (!root.hostHere) return
        let key = String(GlobalStates.settingsOverlayRequestedKey ?? "")
        let asked = String(GlobalStates.settingsOverlayRequestedSection ?? "")
        // The instance going away on close can take a request meant for the one opening: this one then stood on General.
        const last = IrisState.settingsLastRequest
        if (key.length === 0) {
            if (root.placed || !last) return
            key = last.key
            asked = last.asked
        }
        const landing = root.nativePages[key]
        if (landing) { asked = landing(asked); key = "iris" }
        GlobalStates.settingsOverlayCurrentPage = GlobalStates.settingsPageKeys.indexOf(key)
        GlobalStates.settingsOverlayRequestedSection = ""
        GlobalStates.settingsOverlayRequestedPage = -1
        GlobalStates.settingsOverlayRequestedKey = ""
        if (key === "iris" && root.runCommand(asked)) return
        IrisState.settingsLastRequest = { key: key, asked: asked }
        root.placed = true
        root.group = ""
        const request = asked.split("/")
        root.requestedSection = root.renamedSections[request[0] ?? ""] ?? (request[0] ?? "")
        if (request.length > 1) {
            root.requestedGroup = request.slice(1).join("/")
            groupRequest.restart()
        } else if (request[0].length > 0) {
            // A new place without a group drops a group still waiting from the last request.
            groupRequest.stop()
            root.requestedGroup = ""
        }
        root.followMovedGroup()
        root.requestedSection = IrisOptions.retiredAreas[root.requestedSection] ?? root.requestedSection
        // The place is worked out first and set once: every write to section or advancedPage rebuilds the page, and
        // setting "general" on the way to the asked section built General's page on each request.
        const own = root.pageIndexOf(key)
        let section = own >= 0 ? String(root.ownPages.concat(root.morePages).find(entry => entry.key === key)?.home ?? "system")
            : "general"
        // An area asked for by the name it shows ("style" is Style, "screenshots" Screenshots & Recording).
        const asked0 = root.requestedSection.toLowerCase()
        const titled = asked0.length > 0 && !root.sections.some(s => s.id === root.requestedSection)
            ? root.sections.find(s => [String(s.title), Translation.tr(String(s.title))].some(t => t.toLowerCase() === asked0 || t.toLowerCase().split(/\s+/)[0] === asked0)) : null
        if (titled) root.requestedSection = titled.id
        if (own < 0 && root.sections.some(s => s.id === root.requestedSection)) section = root.requestedSection
        // A place asked for by name is where you want to be, not a filter over it.
        if (searchField.text.length > 0) searchField.text = ""
        // A category's name (`inir iris settings look`, links from before DI49g) opens its first area.
        const named = own < 0 && !root.sections.some(s => s.id === root.requestedSection)
            ? IrisOptions.categories.find(category => category.id === root.requestedSection) : null
        if (named) section = named.sections.find(id => root.sections.some(s => s.id === id)) ?? section
        const known = own >= 0 || !!named || root.sections.some(s => s.id === root.requestedSection)
        root.advancedPage = root.landingPage(section, own)
        root.section = section
        root.backStack = []
        root.forwardStack = []
        // A name that is no area is searched for: it stood on General without a word.
        if (!known && asked0.length > 0) { searchField.text = asked.split("/").join(" "); root.query = searchField.text }
    }
    Component.onCompleted: {
        CompositorConfig.ensure()
        IrisOptions.settle()
        if (GlobalStates.settingsOverlayOpen) root.applyRequest()
        // The window host is built on open: the page takes the keys then, or ↑ ↓ and typing reached nothing (DI49a).
        if (root.windowed) root.forceActiveFocus()
        else takeKeys.restart()
    }
    Connections {
        target: GlobalStates
        function onSettingsOverlayRequestedKeyChanged(): void { Qt.callLater(root.applyRequest) }
        function onSettingsOverlayOpenChanged(): void {
            if (!GlobalStates.settingsOverlayOpen) return
            // A visit's history starts with it: an Undo never reaches back into a change made days ago.
            IrisOptions.forget()
            CompositorConfig.ensure()
            IrisOptions.settle()
            root.applyRequest()
            if (!searchField.activeFocus) root.forceActiveFocus()
            takeKeys.restart()
        }
    }
    // The overlay's surface gets the keyboard a beat after it maps: focus taken on open alone landed nowhere, and the
    // arrows and typing reached nothing until the search was clicked.
    Timer { id: takeKeys; interval: 160; onTriggered: if (!searchField.activeFocus && GlobalStates.settingsOverlayOpen) root.forceActiveFocus() }
    // A Design's scene sets its own page; the engine's slide would only move chrome nobody sees.
    onSectionChanged: { IrisOptions.settle(); settingsFlick.contentY = 0; root.tuneAll = false; IrisOptions.openList = "" }
    onPageKeyChanged: Qt.callLater(root.feedPage)
    onOpenGroupChanged: settingsFlick.contentY = 0

    Shortcut {
        sequence: "Escape"
        enabled: GlobalStates.settingsOverlayOpen
        onActivated: {
            // An open list of choices closes first, as a menu would (DI49a: Esc left it open).
            if (root.scene?.release && root.scene.release()) return
            if (IrisOptions.homeEditing) IrisOptions.homeEditing = false
            else if (IrisOptions.openList.length > 0) IrisOptions.openList = ""
            else if (root.searching) searchField.text = ""
            else if (root.group.length > 0 && !root.split) root.leaveGroup()
            else if (root.advancedPage >= 0 && !root.pageInPane) root.go({ section: root.section, group: "", advancedPage: -1 })
            else if (!root.windowed) GlobalStates.settingsOverlayOpen = false
        }
    }
    Shortcut { sequence: "Ctrl+F"; enabled: GlobalStates.settingsOverlayOpen; onActivated: searchField.forceActiveFocus() }
    // The history of this visit: a field with focus keeps its own Ctrl+Z (it takes the shortcut first).
    Shortcut { sequences: ["Ctrl+Z"]; enabled: GlobalStates.settingsOverlayOpen && IrisOptions.canUndo; onActivated: IrisOptions.undo() }
    Shortcut { sequences: ["Ctrl+Shift+Z", "Ctrl+Y"]; enabled: GlobalStates.settingsOverlayOpen && IrisOptions.canRedo; onActivated: IrisOptions.redo() }
    // Typing anywhere on the page searches: a letter no control takes reaches the page and goes to the field.
    // ↑ and ↓ walk the sidebar's areas when nothing on the page holds the keys (DI49a: they did nothing).
    // From a control on the page they go to the control above or below instead, as in a list of preferences: jumping to
    // another area from a focused switch lost the place.
    Keys.onUpPressed: event => {
        if (event.modifiers !== Qt.NoModifier) event.accepted = false
        else if (!root.stepFocus(root.Window.activeFocusItem, false)) root.stepSection(-1)
    }
    Keys.onDownPressed: event => {
        if (event.modifiers !== Qt.NoModifier) event.accepted = false
        else if (!root.stepFocus(root.Window.activeFocusItem, true)) root.stepSection(1)
    }
    Keys.onPressed: event => typeAhead.take(event)
    // The page a control scrolls in (any mode's own Flickable), null for the head and the sidebar.
    function pageScroller(item: Item): Item {
        for (let p = item?.parent ?? null; p && p !== root; p = p.parent)
            if (p === sidebarFlick) return null
            else if (p.contentItem !== undefined && p.contentY !== undefined && p.flickableDirection !== undefined) return p
        return null
    }
    function stepFocus(item: Item, forward: bool): bool {
        const scroller = root.pageScroller(item)
        if (!scroller) return false
        const next = item.nextItemInFocusChain(forward)
        if (next && next !== item && root.pageScroller(next) === scroller)
            next.forceActiveFocus(forward ? Qt.TabFocusReason : Qt.BacktabFocusReason)
        return true
    }
    // The page follows the keyboard: a control Tab reaches below the fold scrolls into view with some air.
    readonly property Item keyed: root.Window.activeFocusItem
    onKeyedChanged: if (root.keyed) Qt.callLater(root.followFocus, root.keyed)
    function followFocus(item: Item): void {
        const scroller = root.pageScroller(item)
        if (!scroller || !item.visible || scroller.contentHeight <= scroller.height) return
        const top = item.mapToItem(scroller.contentItem, 0, 0).y
        const air = 32 * root.d
        if (top - air < scroller.contentY) scroller.contentY = Math.max(0, top - air)
        else if (top + item.height + air > scroller.contentY + scroller.height)
            scroller.contentY = Math.min(scroller.contentHeight - scroller.height, top + item.height + air - scroller.height)
    }
    IrisTypeAhead { id: typeAhead; field: searchField }
    // The other host opens where this one stands.
    readonly property bool hostHere: root.windowed === ((Config.options?.iris?.appearance?.settingsHost ?? "overlay") === "window")
    function switchHost(): void {
        GlobalStates.settingsOverlayRequestedSection = root.advancedPage < 0 ? root.section + (root.group.length > 0 ? "/" + root.group : "") : ""
        GlobalStates.settingsOverlayRequestedKey = root.advancedPage < 0 ? "iris" : root.pages[root.advancedPage].key
        Config.setNestedValue("iris.appearance.settingsHost", root.windowed ? "overlay" : "window")
    }
    function stepSection(delta: int): void {
        const index = root.sections.findIndex(section => section.id === root.section)
        const next = root.sections[Math.max(0, Math.min(root.sections.length - 1, index + delta))]
        if (next) root.selectSection(next.id)
    }
    Shortcut { sequence: "Ctrl+Down"; enabled: GlobalStates.settingsOverlayOpen; onActivated: root.stepSection(1) }
    Shortcut { sequence: "Ctrl+Up"; enabled: GlobalStates.settingsOverlayOpen; onActivated: root.stepSection(-1) }
    Shortcut { sequences: ["Alt+Left", "Ctrl+["]; enabled: GlobalStates.settingsOverlayOpen; onActivated: root.goBack() }
    Shortcut { sequences: ["Alt+Right", "Ctrl+]"]; enabled: GlobalStates.settingsOverlayOpen; onActivated: root.goForward() }
    MouseArea { anchors.fill: parent; enabled: !root.windowed; onClicked: GlobalStates.settingsOverlayOpen = false }


    // A textured material (Afterglow's bevel, Light leak's lit rim) must follow the corners Niri clips the window to: its
    // radius is Niri's, so the squircle stays inside the clip.
    readonly property bool windowField: root.windowed && IrisStyle.textured
    onWindowFieldChanged: if (root.windowField) CompositorConfig.reload(["window-rules"])
    // In a window Niri owns the shape, the corners and the open motion: the body fills it, already open.
    IrisMorphSurface {
        motionSurface: "settings"
        settles: true
        // There and gone at once (10-25, he: no open or close motion at all); kept built between opens, so it is.
        instant: true
        windowOffset: Qt.point(IrisFrame.band, IrisFrame.band)
        ownField: !root.windowed || root.windowField
        overlay: !root.windowed
        chassisKey: "settings"
        // Over the desktop it draws its own field, never the band's: from another window the body and the page landed
        // a frame apart and it flickered on every open.
        // A window cannot know where it sits on screen, so it never samples the wallpaper: Blur asks Niri, else solid.
        glass: !root.windowed || IrisStyle.glassCompositor
        id: frame
        compositorBlurred: true
        energy: root.windowed && GlobalStates.settingsWindowBehind ? 0 : 1
        // A layout's page grows with the body: armed while the frame still measured 0 the scene was not even asked for, and
        // the body opened empty for half a second on llvmpipe.
        contentReady: root.sceneDrawn || !root.sceneWanted || (frame.width > 0 && !root.sceneFits) || pageScene.status === Loader.Error
        open: root.windowed || (GlobalStates.settingsOverlayOpen && root.hostHere)
        color: IrisStyle.surface
        light: IrisStyle.surfaceLight("settings", IrisStyle.wallpaperLight)
        radius: root.windowField ? Number(CompositorConfig.value({ comp: "window-rules", key: "corner-radius", fallback: 16 }))
            : root.windowed ? 0 : IrisStyle.surfaceRadius("settings", IrisStyle.radiusPanel)
        onClosed: IrisState.morphOwner = ""
        // Whole pixels: a body centred on a half pixel draws every line of its text soft.
        // A layout's body sits in the room the Island and the Dock leave: Folio as a sheet in the middle of it.
        readonly property bool laid: root.layout.length > 0 && !root.windowed
        Behavior on x { enabled: root.switching; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
        Behavior on y { enabled: root.switching; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
        Behavior on width { enabled: root.switching; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
        Behavior on height { enabled: root.switching; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
        readonly property real goalX: root.windowed ? 0
            : Math.round(root.room.x + (root.room.width - width) / 2)
        readonly property real goalY: root.windowed ? 0
            : Math.round(root.room.y + (root.room.height - height) / 2)
        readonly property real goalW: root.windowed ? parent.width
            : frame.laid ? Math.round(Math.min(root.room.width, 1480 * root.d))
            // The sidebar and the rows at their measure; Settings sits on the desktop, it does not replace it.
            : Math.round(Math.min(root.room.width, 1240 * root.d))
        readonly property real goalH: root.windowed ? parent.height
            : frame.laid ? Math.round(Math.min(root.room.height, 900 * root.d))
            // As tall as the sidebar's list asks, inside the room the Island and the Dock leave (his 10-30: measured on
            // the screen it ran over both); a short room scrolls the list. Measured by the list alone, ten categories
            // once left a 640 px strip that cut every page at its second row.
            : Math.round(Math.min(root.room.height, Math.max(720 * root.d, root.sidebarNeed)))
        x: frame.goalX
        y: frame.goalY
        width: frame.goalW
        height: frame.goalH
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.LeftButton | Qt.BackButton | Qt.ForwardButton
            onPressed: mouse => {
                if (mouse.button === Qt.BackButton) root.goBack()
                else if (mouse.button === Qt.ForwardButton) root.goForward()
            }
        }


        IrisSkin {
            id: pageScene
            part: "settingsPage"
            wanted: root.sceneFits
            host: root
            fallback: root.layout.length > 0 ? Qt.resolvedUrl("layouts/" + root.layouts[root.layout] + ".qml") : ""
            asynchronous: root.switching
            anchors.fill: undefined
            width: frame.goalW
            height: frame.goalH
            opacity: root.switching ? 0 : 1
            scale: root.switching ? 0.97 : 1
            Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(220); easing.type: IrisStyle.feedbackEasing } }
            Behavior on scale { NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
        }
        RowLayout {
            width: frame.goalW
            height: frame.goalH
            visible: !root.sceneDesigned
            opacity: root.switching ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(220); easing.type: IrisStyle.feedbackEasing } }
            spacing: 0

            Item {
                id: sidebarSlot
                z: 2
                Layout.fillHeight: true
                Layout.preferredWidth: root.sidebarFull
            Rectangle {
                id: sidebar
                // A pane of its own floating inside the window (macOS 26): inset on three sides, concentric with the
                // window's corners, its edge a hairline all round instead of a rule between it and the page.
                readonly property int inset: root.paneInset
                readonly property int pad: root.panePad
                x: sidebar.inset
                y: sidebar.inset
                height: parent.height - 2 * sidebar.inset
                width: sidebarSlot.width - sidebar.inset
                clip: true
                radius: root.paneRadius
                color: IrisStyle.readingSidebar
                border.width: 1
                border.color: IrisStyle.hairline
                Rectangle {
                    visible: false
                    anchors.right: parent.right
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    width: 1
                    color: IrisStyle.hairline
                }
                ColumnLayout {
                    id: sidebarLayout
                    anchors.left: parent.left
                    anchors.top: parent.top
                    anchors.bottom: parent.bottom
                    anchors.leftMargin: sidebar.pad
                    anchors.topMargin: sidebar.pad
                    anchors.bottomMargin: sidebar.pad
                    // Even on both sides of the pane: sized from the slot it ran pad - inset short of the right edge (10-25).
                    width: sidebar.width - 2 * sidebar.pad
                    spacing: 0

                    Item {
                        id: sideSearchSlot
                        visible: !root.sceneDrawn
                        Layout.fillWidth: true
                        Layout.bottomMargin: 6 * root.d
                        implicitHeight: Math.round(32 * root.d)
                    }
                    // One search field: in the sidebar when there is one, in the header otherwise.
                    Rectangle {
                        id: searchPlate
                        // What a Design's skin draws the field from; the input, its keys and its focus stay here.
                        readonly property bool focused: searchField.activeFocus
                        readonly property bool hovered: searchHover.hovered
                        readonly property bool skinned: searchSkin.active
                        parent: root.sceneDrawn ? root.scene.searchSlot : sideSearchSlot
                        anchors.left: parent.left
                        anchors.top: parent.top
                        anchors.bottom: parent.bottom
                        width: parent.width
                        radius: Math.min(height / 2, Math.max(IrisStyle.radiusRow, frame.radius - sidebar.pad))
                        color: searchPlate.skinned ? "transparent" : searchField.activeFocus ? IrisStyle.fill : IrisStyle.fillQuiet
                        border.width: searchField.activeFocus && !searchPlate.skinned ? 1 : 0
                        border.color: IrisStyle.tintBorder(IrisStyle.accent)
                        HoverHandler { id: searchHover; cursorShape: Qt.IBeamCursor }
                        TapHandler { onTapped: searchField.forceActiveFocus() }
                        IrisSkin { id: searchSkin; part: "settingsSearch"; host: searchPlate }
                        MaterialSymbol {
                            id: searchGlyph
                            anchors.left: parent.left
                            anchors.leftMargin: 10 * root.d
                            anchors.verticalCenter: parent.verticalCenter
                            text: "search"
                            iconSize: Math.round(16 * root.d)
                            color: searchSkin.item?.glyphColour ?? IrisStyle.muted
                        }
                        TextInput {
                            cursorDelegate: TextCursor { accent: IrisStyle.accent }
                            id: searchField
                            anchors.left: searchGlyph.right
                            anchors.leftMargin: 6 * root.d
                            anchors.right: clearSearch.left
                            anchors.rightMargin: 4 * root.d
                            anchors.verticalCenter: parent.verticalCenter
                            color: IrisStyle.text
                            selectionColor: searchSkin.item?.selectionColour ?? IrisStyle.accentContainer
                            selectedTextColor: searchSkin.item?.selectedTextColour ?? IrisStyle.inkOnAccentContainer
                            font.family: IrisStyle.fontMain
                            font.pixelSize: IrisStyle.typeLabel
                            clip: true
                            onTextChanged: {
                                if (text.length === 0) { searchDelay.stop(); root.query = ""; return }
                                root.advancedPage = -1
                                searchDelay.restart()
                            }
                            Keys.onReturnPressed: root.openFirstResult()
                            // The field holds the keys while Settings is open: with nothing typed, ↑ ↓ walk the areas from here too.
                            // An empty field hands the arrows to the areas.
                            Keys.onUpPressed: event => { if (text.length > 0) event.accepted = false; else root.stepSection(-1) }
                            Keys.onDownPressed: event => { if (text.length > 0) event.accepted = false; else root.stepSection(1) }
                            Timer { id: searchDelay; interval: 160; onTriggered: root.query = searchField.text }
                            IrisText {
                                anchors.verticalCenter: parent.verticalCenter
                                width: parent.width
                                elide: Text.ElideRight
                                visible: searchField.text.length === 0
                                text: String(root.scene?.searchHint ?? "") || Translation.tr("Search settings")
                                color: searchSkin.item?.placeholderColour ?? IrisStyle.muted
                                font.pixelSize: searchField.font.pixelSize
                            }
                        }
                        MaterialSymbol {
                            id: clearSearch
                            anchors.right: parent.right
                            anchors.rightMargin: 8 * root.d
                            anchors.verticalCenter: parent.verticalCenter
                            visible: searchField.text.length > 0
                            width: visible ? implicitWidth : 0
                            text: "cancel"
                            fill: 1
                            iconSize: Math.round(15 * root.d)
                            color: IrisStyle.muted
                            MouseArea { anchors.fill: parent; anchors.margins: -4; cursorShape: Qt.PointingHandCursor; onClicked: searchField.text = "" }
                        }
                    }

                    Flickable {
                        IrisScrollFeel {}
                        id: sidebarFlick
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        // As tall as the list, so the foot follows it instead of leaving a hole above itself (DI38); a short
                        // window still scrolls it.
                        Layout.maximumHeight: sidebarColumn.implicitHeight
                        clip: true
                        contentHeight: sidebarColumn.implicitHeight
                        // What the list asks for: the window's height comes from it (`root.sidebarNeed`).
                        implicitHeight: sidebarColumn.implicitHeight
                        ScrollBar.vertical: IrisScrollBar {}
                        // The list itself fades under the footer: a gradient painted over it read as a square
                        // shadow on glass.
                        layer.enabled: sidebarEdge.active
                        layer.effect: MultiEffect {
                            maskEnabled: true
                            maskSource: sidebarEdge.mask
                            maskThresholdMin: 0.5
                            maskSpreadAtMin: 1
                        }

                        // Where you are travels from row to row on the morph curve (the gallery's ring does the same) instead of
                        // fading out on one row and in on the next. Under the rows; the footer keeps its own wash.
                        Rectangle {
                            id: travelWash
                            readonly property Item row: root.travelRow
                            readonly property bool shown: travelWash.row !== null && travelWash.row.selected
                            property bool travels: false
                            x: sidebarColumn.x
                            width: sidebarColumn.width
                            y: travelWash.row ? sidebarColumn.y + travelWash.row.y + travelWash.row.washY : 0
                            height: travelWash.row ? travelWash.row.rowHeight : 0
                            radius: travelWash.row ? travelWash.row.washRadius : 0
                            // A plate-selection Design (AIRISU) puts where you are on the solid plate of the accent.
                            readonly property color wash: IrisStyle.tintFillHover(travelWash.row?.own ?? IrisStyle.accent)
                            color: IrisStyle.plateSelection ? IrisStyle.selectionFill : "transparent"
                            opacity: travelWash.shown ? 1 : 0
                            // Where you are fades in from the left, strongest at the right (his 10-30): a flat block of tint read as a heavy bar (his 10-30).
                            Rectangle {
                                anchors.fill: parent
                                visible: !IrisStyle.plateSelection
                                radius: parent.radius
                                gradient: Gradient {
                                    orientation: Gradient.Horizontal
                                    GradientStop { position: 0; color: ColorUtils.applyAlpha(travelWash.wash, 0) }
                                    GradientStop { position: 1; color: travelWash.wash }
                                }
                            }
                            // It lands where it first appears and travels from then on. Moving the selection hides it for a
                            // moment (the old row lets go before the new one takes it): only a hide that lasts stops the travel.
                            onShownChanged: if (travelWash.shown) { washDisarm.stop(); if (!travelWash.travels) washArm.restart() }
                                else washDisarm.restart()
                            Timer { id: washArm; interval: 0; onTriggered: travelWash.travels = IrisStyle.motionEnabled }
                            Timer { id: washDisarm; interval: 150; onTriggered: if (!travelWash.shown) travelWash.travels = false }
                            Behavior on y { enabled: travelWash.travels; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
                            Behavior on height { enabled: travelWash.travels; NumberAnimation { duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve } }
                            Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(110); easing.type: IrisStyle.feedbackEasing } }
                            Behavior on color { ColorAnimation { duration: IrisStyle.duration(110); easing.type: IrisStyle.feedbackEasing } }
                        }

                        // Where you are stays in the list: a section opened from search, a link or the CLI below the fold
                        // scrolls its row into view, with a row of air past it.
                        onHeightChanged: sideFollow.restart()
                        onContentHeightChanged: sideFollow.restart()
                        Connections {
                            target: root
                            function onTravelRowChanged(): void { sideFollow.restart() }
                        }
                        Timer {
                            id: sideFollow
                            interval: 0
                            onTriggered: {
                                const row = root.travelRow
                                if (!row || !row.selected) return
                                const top = sidebarColumn.y + row.y + row.height - 2 * row.rowHeight
                                const bottom = sidebarColumn.y + row.y + row.height + row.rowHeight
                                const end = Math.max(0, sidebarFlick.contentHeight - sidebarFlick.height)
                                // The first block keeps the profile above it in view.
                                const to = top < sidebarFlick.contentY ? (row.modelData.cluster === root.sections[0]?.cluster ? 0 : top)
                                    : bottom > sidebarFlick.contentY + sidebarFlick.height ? bottom - sidebarFlick.height : sidebarFlick.contentY
                                sideScroll.to = Math.max(0, Math.min(end, to))
                                if (sideScroll.to !== sidebarFlick.contentY) sideScroll.restart()
                            }
                        }
                        NumberAnimation { id: sideScroll; target: sidebarFlick; property: "contentY"; duration: IrisStyle.morphDuration; easing.type: Easing.BezierSpline; easing.bezierCurve: IrisStyle.morphCurve }

                        Column {
                            id: sidebarColumn
                            width: sidebarFlick.width - 4 * root.d
                            spacing: 0

                            Repeater {
                                model: root.sceneDesigned ? [] : root.sideSections
                                SectionRow { list: root.sideSections }
                            }
                        }

                        IrisScrollEdge {
                            id: sidebarEdge
                            parent: sidebarFlick
                            flick: sidebarFlick
                            anchors.fill: parent
                            // Inside the masked list a blurred band would be masked away with it: the fade alone.
                            blurs: false
                            reach: Math.round(28 * root.d)
                        }
                    }

                    Rectangle {
                        Layout.preferredWidth: sidebarLayout.width - 4 * root.d
                        Layout.topMargin: 4 * root.d
                        Layout.bottomMargin: 4 * root.d
                        implicitHeight: 1
                        color: IrisStyle.hairline
                    }

                    Column {
                        Layout.fillWidth: true
                        Layout.rightMargin: 4 * root.d
                        spacing: 0
                        Repeater {
                            model: root.sceneDesigned ? [] : root.sections.filter(section => section.cluster >= root.footerCluster)
                            SectionRow { list: []; gapAbove: false }
                        }
                    }
                    Item { Layout.fillHeight: true }
                }
            }
            }

            ColumnLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                spacing: 0

                RowLayout {
                    id: headRow
                    Layout.fillWidth: true
                    // The back key over the plates' edge, the close key over their right edge, the keys on the sidebar
                    // search's line.
                    Layout.leftMargin: root.plateInset
                    Layout.rightMargin: root.plateInset
                    Layout.topMargin: root.headLine - Math.round(26 * root.d)
                    Layout.preferredHeight: Math.round(52 * root.d)
                    spacing: 4 * root.d
                    // What the name and the actions share: the row less every fixed control in it. Measured from the
                    // row, never from the name or the actions, whose widths move with the folding (that loop froze the shell).
                    readonly property real sharedRoom: {
                        let fixed = 0
                        for (const child of headRow.children)
                            if (child.visible && child !== titleColumn && child !== toolbarActions) fixed += child.width + headRow.spacing
                        return headRow.width - fixed - headRow.spacing - 6 * root.d
                    }
                    IrisIconButton {
                        materialIcon: "chevron_left"
                        enabled: root.backStack.length > 0
                        opacity: enabled ? 1 : 0.35
                        onClicked: root.goBack()
                        Accessible.name: Translation.tr("Back")
                    }
                    IrisIconButton {
                        materialIcon: "chevron_right"
                        enabled: root.forwardStack.length > 0
                        opacity: enabled ? 1 : 0.35
                        onClicked: root.goForward()
                        Accessible.name: Translation.tr("Forward")
                    }
                    ColumnLayout {
                        id: titleColumn
                        Layout.fillWidth: true
                        Layout.leftMargin: 6 * root.d
                        spacing: 0
                        IrisText {
                            id: pageTitle
                            Layout.fillWidth: true
                            text: root.searching ? Translation.tr("Results for “%1”").arg(root.query)
                                : root.advancedPage >= 0 ? root.pageTitle(root.advancedPage)
                                : root.openGroup.length > 0 ? root.openGroup
                                : Translation.tr(root.currentSection.title)
                            font.family: IrisStyle.fontTitle
                            font.pixelSize: IrisStyle.lowerTitles ? IrisStyle.typeDisplay : IrisStyle.typeTitleLarge
                            font.weight: IrisStyle.lowerTitles ? IrisStyle.weight(Font.ExtraBold) : IrisStyle.weight(Font.Bold)
                            font.capitalization: IrisStyle.lowerTitles && !root.searching ? Font.AllLowercase : Font.MixedCase
                            font.letterSpacing: IrisStyle.lowerTitles ? -Math.round(IrisStyle.typeDisplay * 0.03) : 0
                            elide: Text.ElideRight
                        }
                        IrisText {
                            Layout.fillWidth: true
                            visible: !root.searching && root.advancedPage < 0
                                && root.openGroup.length > 0 && root.openGroup !== Translation.tr(root.currentSection.title)
                            text: Translation.tr(root.currentSection.title)
                            color: IrisStyle.muted
                            font.pixelSize: IrisStyle.typeMeta
                            elide: Text.ElideRight
                        }
                    }
                    // The actions keep their words while the page's name still reads whole beside them (up to 260·d of
                    // it); measured in the language on screen, never a fixed window width.
                    RowLayout {
                        id: toolbarActions
                        spacing: 4 * root.d
                        // Fold one at a time, the least used first, only as many as the name needs.
                        readonly property var foldOrder: [restoreAction, customizeAction, rehearseAction].filter(action => action.shown)
                        readonly property var folded: {
                            const room = headRow.sharedRoom - Math.min(pageTitle.implicitWidth, 260 * root.d)
                            let need = toolbarActions.foldOrder.reduce((sum, action) => sum + action.fullWidth, 0)
                                + Math.max(0, toolbarActions.foldOrder.length - 1) * spacing
                            const out = []
                            for (const action of toolbarActions.foldOrder) {
                                if (need <= room) break
                                need -= action.fullWidth - action.implicitHeight
                                out.push(action)
                            }
                            return out
                        }
                    ToolbarAction {
                        id: rehearseAction
                        readonly property bool rehearses: root.section === "lock"
                        readonly property bool arranges: root.section === "controlCenter"
                        shown: !root.searching && root.advancedPage < 0 && (rehearses || arranges)
                        glyph: rehearses ? "visibility" : "dashboard_customize"
                        label: rehearses ? Translation.tr("Rehearse it") : Translation.tr("Arrange it")
                        onClicked: {
                            GlobalStates.settingsOverlayOpen = false
                            if (rehearses) { IrisState.lockEdit = true; return }
                            IrisState.morphOwner = ""
                            GlobalStates.controlPanelOpen = true
                            IrisState.controlEdit = true
                        }
                    }
                    ToolbarAction {
                        id: customizeAction
                        readonly property string studioTarget: root.studioTargets[root.section] ?? ""
                        readonly property string target: studioTarget.length > 0 ? studioTarget : (root.editTargets[root.section] ?? "")
                        shown: !root.searching && root.advancedPage < 0 && target.length > 0
                        glyph: "edit"
                        label: Translation.tr("Customize")
                        onClicked: {
                            GlobalStates.settingsOverlayOpen = false
                            IrisState.openCustomize(target)
                        }
                    }
                    ToolbarAction {
                        id: restoreAction
                        readonly property var resettable: (root.openGroup.length > 0 ? (root.shownGroups[0]?.rows ?? []) : root.specifications
                            .filter(spec => spec.section === root.section)).filter(spec => String(spec.path).startsWith("iris."))
                        readonly property bool modified: {
                            Config.revision
                            return resettable.some(spec => IrisOptions.modified(spec))
                        }
                        shown: !root.searching && root.advancedPage < 0 && modified
                        glyph: "restart_alt"
                        label: Translation.tr("Restore defaults")
                        // Act first, one Undo on the island for the lot (no confirm).
                        onClicked: IrisOptions.restore(resettable)
                    }
                    }
                    // Classic's way back to the layouts.
                    Layouts.LayoutSwitch {
                        visible: !root.sceneDesigned
                        host: root
                        voice: ""
                        compact: true
                    }
                    // The design key: one press between today's Settings and v2.33's, every page and option kept.
                    IrisIconButton {
                        objectName: "settingsDesignKey"
                        visible: !root.sceneDesigned && IrisDesign.skin("settingsPage").length === 0
                        materialIcon: "history"
                        selected: IrisStyle.settingsOriginal
                        onClicked: Config.setNestedValue("iris.appearance.settingsOriginal", !IrisStyle.settingsOriginal)
                        Accessible.name: IrisStyle.settingsOriginal ? Translation.tr("Use the current design") : Translation.tr("Use the original design (v2.33)")
                    }
                    IrisIconButton {
                        materialIcon: root.windowed ? "layers" : "web_asset"
                        onClicked: root.switchHost()
                        Accessible.name: root.windowed ? Translation.tr("Open over the desktop") : Translation.tr("Open as a window")
                    }
                    IrisIconButton {
                        materialIcon: "close"
                        onClicked: GlobalStates.settingsOverlayOpen = false
                        Accessible.name: Translation.tr("Close settings")
                    }
                }

                Item {
                    id: pageArea
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true



                    // Classic's page: the area's sheet (FolioPage) one air off the sidebar and the window, as the
                    // sidebar stands off it. A layout's scene takes the body into its own slot.
                    Item {
                        id: detailPane
                        anchors.fill: parent

                        Item {
                            id: detailBody
                            parent: root.sceneDrawn ? root.scene.rowsSlot : detailPane
                            anchors.fill: parent



                            Layouts.AreaPool {
                                id: classicPool
                                anchors.fill: parent
                                anchors.leftMargin: root.paneInset
                                anchors.rightMargin: root.paneInset
                                anchors.bottomMargin: root.paneInset
                                visible: !root.sceneDrawn
                                // A search or a shared page borrows the body; the area under it stays as it was.
                                current: root.sceneDrawn ? "" : root.classicRows ? root.section : classicPool.shown
                                hidden: !root.classicRows
                                settled: root.bodySettled
                                urlFor: id => Qt.resolvedUrl("layouts/FolioPage.qml")
                                propsFor: id => ({ host: root, titled: false, actions: false })
                                property string wanted: ""
                                // A jump waits for its own area only: leaving first drops it.
                                onCurrentChanged: classicPool.wanted = ""
                                function showGroup(key: string): void {
                                    if (classicPool.shown === root.section && classicPool.shownItem) classicPool.shownItem.showGroup(key)
                                    else classicPool.wanted = key
                                }
                                onArrived: id => {
                                    if (classicPool.wanted.length > 0 && id === root.section) {
                                        classicPool.shownItem?.showGroup?.(classicPool.wanted)
                                        classicPool.wanted = ""
                                    }
                                }
                            }

                            NumberAnimation {
                                id: revealMotion
                                target: settingsFlick
                                property: "contentY"
                                duration: IrisStyle.morphDuration
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: IrisStyle.morphCurve
                            }
                            Flickable {
                                IrisScrollFeel {}
                                id: settingsFlick
                                anchors.fill: parent
                                // The pane's corners stay its own: the last rows stop short of the curve.
                                anchors.bottomMargin: root.split ? Math.round(root.paneRadius / 2) : 0
                                // Rows pass under the pinned head, never over it.
                                clip: root.split || root.sceneDrawn
                                // and soften into the air under it instead of ending on a cut (IrisScrollEdge), and so does the
                                // pane's foot with rows past it.
                                layer.enabled: (root.split || root.sceneDrawn) && rowsEdge.active
                                layer.effect: MultiEffect {
                                    maskEnabled: true
                                    maskSource: rowsEdge.mask
                                    maskThresholdMin: 0.5
                                    maskSpreadAtMin: 1
                                }
                                visible: root.advancedPage < 0 && !root.classicRows
                                // Rows laid after the section changed (a Place opening, a fold) move every head: the reading is taken again.
                                contentHeight: settingsRows.implicitHeight + 32 * root.d
                                ScrollBar.vertical: IrisScrollBar {}

                                ColumnLayout {
                                    id: settingsRows
                                    // a page still building waits unseen and rises whole once its last group stands
                                    y: 6 * root.d + Math.round((1 - root.rowsReveal) * 10 * root.d)
                                    opacity: root.rowsPending ? 0 : root.rowsReveal
                                    // In the pane the rows run its width (their own inset keeps the text off its edge).
                                    width: root.split ? settingsFlick.width - Math.round(16 * root.d) : Math.min(settingsFlick.width - 56 * root.d, root.rowsMost)
                                    x: Math.round((settingsFlick.width - width) / 2)
                                    spacing: 18 * root.d



                                    IrisText {
                                        visible: root.searching && root.entries.length === 0 && root.pageMatches.length === 0
                                        Layout.topMargin: 24 * root.d
                                        Layout.alignment: Qt.AlignHCenter
                                        text: Voice.miss(Translation.tr("No matching settings"), root.query)
                                        color: IrisStyle.muted
                                    }


                                    Repeater {
                                        model: root.searching && root.pagesFirst ? [Translation.tr("Pages")] : []
                                        MoreGroup {}
                                    }

                                    BlockBuffer { id: blocks0; slot: 0 }
                                    BlockBuffer { id: blocks1; slot: 1 }
                                    BlockBuffer { id: blocks2; slot: 2 }
                                    BlockBuffer { id: blocks3; slot: 3 }

                                    IrisText {
                                        visible: root.searching && root.matches.length > root.entries.length
                                        Layout.alignment: Qt.AlignHCenter
                                        Layout.topMargin: 4 * root.d
                                        text: Translation.tr("%1 more — keep typing to narrow the results").arg(root.matches.length - root.entries.length)
                                        color: IrisStyle.muted
                                        font.pixelSize: IrisStyle.typeMeta
                                    }





                                    Repeater {
                                        model: root.browsing && root.section === "system" ? root.moreGroups : root.searching && root.pageMatches.length > 0 && !root.pagesFirst ? [Translation.tr("Pages")] : []
                                        MoreGroup {}
                                    }
                                }
                            }
                            IrisScrollEdge {
                                id: rowsEdge
                                flick: settingsFlick
                                anchors.fill: settingsFlick
                                visible: settingsFlick.visible && (root.split || root.sceneDrawn)
                                reach: Math.round(28 * root.d)
                            }

                        }
                    }


                    // One of iRiS's own pages (About, Shortcuts, Hub): loaded while it is shown, gone when you leave it.
                    Loader {
                        id: pageHost
                        parent: root.sceneDrawn ? root.scene.rowsSlot : pageArea
                        // Classic's shared pages stand where its sheet stands.
                        x: root.sceneDrawn ? 0 : root.paneInset
                        y: 0
                        width: root.sceneDrawn ? parent.width : pageArea.width - 2 * root.paneInset
                        height: root.sceneDrawn ? parent.height : pageArea.height - root.paneInset
                        visible: root.advancedPage >= 0
                        active: visible
                        source: String(root.pages[root.advancedPage]?.component ?? "")
                    }
                }
            }
        }
    }
    // The page as it stood when a layout was picked: it rides the body's glide and fades as the new layout builds.
    ShaderEffectSource {
        id: layoutShot
        property size from: Qt.size(1, 1)
        readonly property real fit: Math.min(frame.width / Math.max(1, layoutShot.from.width), frame.height / Math.max(1, layoutShot.from.height))
        width: layoutShot.from.width
        height: layoutShot.from.height
        x: frame.x + (frame.width - width) / 2
        y: frame.y + (frame.height - height) / 2
        scale: layoutShot.fit
        sourceItem: layoutShot.opacity > 0 ? frame : null
        live: false
        smooth: true
        opacity: 0
        visible: layoutShot.opacity > 0
        NumberAnimation on opacity { id: shotFade; running: false; to: 0; duration: IrisStyle.morphDuration; easing.type: IrisStyle.feedbackEasing }
    }

    // What Home holds, edited over the body (Home › Customize › Edit). Built only while it shows: ~380 objects otherwise
    // kept with every Settings.
    Loader {
        id: homeEditorHost
        // Kept while the sheet fades out. Read from the item's signal, never in `active`'s binding: that read the item
        // `active` makes and looped on every open.
        property bool fading: false
        active: IrisOptions.homeEditing || fading
        x: frame.x
        y: frame.y
        width: frame.width
        height: frame.height
        sourceComponent: IrisHomeEditor { d: root.d; bodyRadius: frame.radius }
        Connections {
            target: homeEditorHost.item
            function onVisibleChanged() { homeEditorHost.fading = homeEditorHost.item.visible }
        }
    }

    // A display change waiting for Keep, at the body's foot over the rows in every layout (IrisSettingsIsland).
    IrisSettingsIsland {
        id: liveIsland
        d: root.d
        room: frame.width
        allowed: frame.open && !IrisOptions.homeEditing && !root.switching
        x: Math.round(frame.x + (frame.width - width) / 2)
        y: Math.round(frame.y + frame.height - height - Math.max(Math.round(16 * root.d), frame.radius * 0.6))
        z: 20
    }

    // The toolbar's actions: one anatomy, a quiet capsule with its glyph. None of them is the page's answer, so none
    // wears the accent; a change in Settings applies as it is made.
    FontMetrics {
        id: toolbarMetrics
        // Measures the label as it is drawn: a mono-captions Design sets it in spaced capitals.
        font.family: IrisStyle.monoCaptions ? IrisStyle.fontMono : IrisStyle.fontMain
        font.capitalization: IrisStyle.monoCaptions ? Font.AllUppercase : Font.MixedCase
        font.letterSpacing: IrisStyle.monoCaptions ? Math.round(IrisStyle.typeMeta * 0.12) : 0
        font.pixelSize: IrisStyle.monoCaptions ? IrisStyle.typeMeta : IrisStyle.typeLabel
        font.weight: IrisStyle.weight(Font.Medium)
    }
    component ToolbarAction: IrisButton {
        id: action
        property string glyph: ""
        property string label: ""
        property bool shown: true
        visible: action.shown
        // When the page's name would lose its room, actions fold to their glyphs one at a time (toolbarActions.folded).
        readonly property bool folded: toolbarActions.folded.includes(action)
        readonly property real fullWidth: Math.ceil(toolbarMetrics.advanceWidth(action.label)) + Math.round((16 + 6 + 24) * root.d)
        buttonRadius: IrisStyle.capsule(height)
        // Under a Design's skin the plate is the skin's (AIRISU: a blade-cut outline): no capsule under it.
        colBackground: action.skinned ? "transparent" : IrisStyle.controlPlated ? IrisStyle.plateFillFor(IrisStyle.controlPlate) : IrisStyle.fill
        IrisGlassPlate {
            anchors.fill: parent
            z: -1
            visible: !action.skinned && IrisStyle.controlPlate === "glass"
            radius: action.buttonRadius
        }
        colBackgroundHover: action.skinned ? "transparent" : IrisStyle.fillHover
        implicitHeight: Math.round(30 * root.d)
        implicitWidth: action.folded ? implicitHeight : actionRow.implicitWidth + Math.round(24 * root.d)
        Accessible.name: action.label
        Row {
            id: actionRow
            anchors.centerIn: parent
            spacing: Math.round(6 * root.d)
            MaterialSymbol {
                anchors.verticalCenter: parent.verticalCenter
                text: action.glyph
                iconSize: Math.round(16 * root.d)
                color: IrisStyle.subtext
            }
            IrisText {
                visible: !action.folded
                anchors.verticalCenter: parent.verticalCenter
                text: action.label
                font.family: IrisStyle.monoCaptions ? IrisStyle.fontMono : IrisStyle.fontMain
                font.capitalization: IrisStyle.monoCaptions ? Font.AllUppercase : Font.MixedCase
                font.letterSpacing: IrisStyle.monoCaptions ? Math.round(IrisStyle.typeMeta * 0.12) : 0
                font.pixelSize: IrisStyle.monoCaptions ? IrisStyle.typeMeta : IrisStyle.typeLabel
                font.weight: IrisStyle.weight(Font.Medium)
            }
        }
    }


    component SectionRow: MouseArea {
        id: sectionRow
        readonly property real d: IrisStyle.settingsDensity
        required property var modelData
        required property int index
        property var list: root.sections
        property bool gapAbove: true
        readonly property bool clusterStart: sectionRow.gapAbove && sectionRow.index > 0
            && sectionRow.list[sectionRow.index - 1]?.cluster !== sectionRow.modelData.cluster
        readonly property bool selected: !root.searching && root.section === sectionRow.modelData.id
        // Main-list rows hand their selection to the travelling wash (travelWash); footer rows paint their own.
        readonly property bool travels: sectionRow.gapAbove
        // Where you are speaks one colour, the area's own: its glyph fills, the wash under it takes a tint of it and so
        // does its name, a step heavier (DI49i: the chosen row reads at a glance, not only by its wash).
        readonly property color tint: IrisOptions.sectionById(sectionRow.modelData.id).tint
        readonly property color own: IrisStyle.iconColour === "area" ? sectionRow.tint : IrisStyle.accent
        readonly property real washRadius: Math.min(sectionRow.rowHeight / 2, IrisStyle.tileRadius(sectionMark.width) + sectionMark.x)
        onSelectedChanged: if (sectionRow.selected && sectionRow.travels) root.travelRow = sectionRow
        Component.onCompleted: if (sectionRow.selected && sectionRow.travels) root.travelRow = sectionRow
        Component.onDestruction: if (root.travelRow === sectionRow) root.travelRow = null
        readonly property bool dimmed: root.searching && !root.matchedSections.has(sectionRow.modelData.id)
        readonly property real rowHeight: Math.round(26 * sectionRow.d * Math.max(1, IrisStyle.typeScale))
        // Original (v2.33) names no cluster: the air between them is the grouping.
        readonly property string caption: sectionRow.clusterStart && !IrisStyle.settingsOriginal ? Translation.tr(String(sectionRow.modelData.caption ?? "")) : ""
        readonly property real washY: sectionRow.caption.length > 0 ? Math.round(9 * sectionRow.d) + captionText.implicitHeight + Math.round(2 * sectionRow.d)
            : sectionRow.clusterStart ? Math.round(8 * sectionRow.d) : 0
        width: parent ? parent.width : 0
        height: sectionRow.washY + sectionRow.rowHeight
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        Accessible.role: Accessible.Button
        Accessible.name: Translation.tr(sectionRow.modelData.title)
        onClicked: root.selectSection(sectionRow.modelData.id)
        opacity: sectionRow.dimmed ? 0.4 : 1
        Behavior on opacity { NumberAnimation { duration: IrisStyle.duration(140); easing.type: IrisStyle.feedbackEasing } }
        IrisText {
            id: captionText
            visible: sectionRow.caption.length > 0
            x: Math.round(6 * sectionRow.d)
            y: Math.round(9 * sectionRow.d)
            width: sectionRow.width - x
            text: sectionRow.caption
            // Each cluster is signed in the accent, lifted toward the ink so it reads on any scheme (his 10-30).
            color: IrisStyle.plateSelection ? IrisStyle.textSecondary : root.tintInk(IrisStyle.accent)
            font.pixelSize: IrisStyle.typeFootnote
            font.weight: IrisStyle.weight(Font.Bold)
            elide: Text.ElideRight
        }
        Rectangle {
            id: rowPlate
            anchors.left: parent.left
            y: sectionRow.washY
            width: parent.width
            height: sectionRow.rowHeight
            // Concentric with the mark it holds; where you are is a wash of the area's colour, as light as a hover, never a
            // solid block heavier than the buttons around it.
            radius: sectionRow.washRadius
            color: sectionRow.selected && !sectionRow.travels ? (IrisStyle.plateSelection ? IrisStyle.selectionFill : "transparent")
                : sectionRow.selected ? "transparent"
                : sectionRow.containsMouse ? IrisStyle.fillQuiet : "transparent"
            Behavior on color { ColorAnimation { duration: IrisStyle.duration(110); easing.type: IrisStyle.feedbackEasing } }
            Rectangle {
                anchors.fill: parent
                visible: sectionRow.selected && !sectionRow.travels && !IrisStyle.plateSelection
                radius: parent.radius
                gradient: Gradient {
                    orientation: Gradient.Horizontal
                    GradientStop { position: 0; color: ColorUtils.applyAlpha(IrisStyle.tintFillHover(sectionRow.own), 0) }
                    GradientStop { position: 1; color: IrisStyle.tintFillHover(sectionRow.own) }
                }
            }
            // Vivid tiles: the colour is how the eye finds an area, whatever material sits behind.
            Item {
                id: sectionMark
                // An indexed Design numbers the areas instead (a parts catalogue).
                readonly property bool numbered: IrisStyle.indexed
                x: Math.round(5 * sectionRow.d)
                anchors.verticalCenter: parent.verticalCenter
                width: Math.round(22 * sectionRow.d)
                height: width
                IrisSquircle {
                    plain: IrisStyle.settingsPlainMarks
                    visible: !sectionMark.numbered
                    anchors.fill: parent
                    tint: sectionRow.tint
                    glyph: sectionRow.modelData.icon
                    reversed: sectionRow.selected && IrisStyle.plateSelection
                }
            }
            IrisText {
                visible: sectionMark.numbered
                anchors.centerIn: sectionMark
                // The folio runs on through the footer, as a catalogue's pages do: Sources follows the last area.
                text: IrisStyle.indexLabel(sectionRow.gapAbove ? sectionRow.index : root.sideSections.length + sectionRow.index)
                color: sectionRow.selected && IrisStyle.plateSelection ? IrisStyle.selectionDetail : IrisStyle.textTertiary
                font.family: IrisStyle.fontMono
                font.pixelSize: IrisStyle.typeFootnote
                font.weight: IrisStyle.weight(Font.Medium)
            }
            IrisText {
                x: sectionMark.x + sectionMark.width + Math.round(10 * sectionRow.d)
                width: sectionRow.width - x - Math.round(8 * sectionRow.d)
                anchors.verticalCenter: parent.verticalCenter
                role: IrisText.Name
                text: Translation.tr(sectionRow.modelData.title)
                // Where you are takes the area's colour, lifted to read on the wash; on a plate (AIRISU) the plate's ink.
                color: sectionRow.selected && IrisStyle.plateSelection ? IrisStyle.selectionLabel
                    : sectionRow.selected ? root.tintInk(sectionRow.own) : IrisStyle.text
                Behavior on color { ColorAnimation { duration: IrisStyle.duration(140); easing.type: IrisStyle.feedbackEasing } }
                font.weight: IrisStyle.weight(sectionRow.selected ? Font.Bold : Font.DemiBold)
                elide: Text.ElideRight
            }
        }
    }




    component MoreGroup: ColumnLayout {
        id: moreGroup
        required property string modelData
        readonly property var links: (root.searching ? root.pageMatches : root.morePages.filter(entry => Translation.tr(entry.group) === moreGroup.modelData)).map(entry => root.moreLink(entry))
        Layout.fillWidth: true
        spacing: 6 * root.d
        IrisText {
            Layout.leftMargin: 16 * root.d
            text: moreGroup.modelData
            color: IrisStyle.label
            font.family: IrisStyle.fontTitle
            font.pixelSize: IrisStyle.typeMeta
            font.weight: IrisStyle.weight(Font.DemiBold)
        }
        IrisLinkCard { tinted: true; links: moreGroup.links }
    }

    // One set of a page's blocks (see `building`). A block is built by the incubator in slices of a frame: one block of a
    // heavy Design (AIRISU's lacquered rows) took up to 400 ms built at once. A search or a link to a row builds at once,
    // since it scrolls to what it built; so does a page's first block when nothing is on screen to hold its place.
    // A block shows the frame it is built: no fade, no beat (a stalled fade once left a body empty).
    component BlockBuffer: Repeater {
        id: buffer
        required property int slot
        // The page being left hides at once (its rows under the new area's title read as the wrong area); it is only
        // torn down once the new one stands, so the turn's frame builds and destroys nothing.
        readonly property bool shown: root.building === buffer.slot
        model: ScriptModel { objectProp: "title"; values: root.bufs[buffer.slot] }
        Loader {
            id: blockLoader
            required property var modelData
            required property int index
            visible: buffer.shown
            Layout.fillWidth: true
            asynchronous: !root.searching && root.landingPath.length === 0 && (blockLoader.index > 0 || !frame.settled || root.holding)
            sourceComponent: GroupBlock { modelData: blockLoader.modelData }
            onStatusChanged: root.blockTick++
        }
        Component.onCompleted: if (buffer.slot === 0) root.refeed()
    }
    component GroupBlock: ColumnLayout {
        id: group
        required property var modelData
        Layout.fillWidth: true
        spacing: 6 * root.d
        MouseArea {
            id: resultSection
            readonly property var section: IrisOptions.sectionById(String(group.modelData.rows[0]?.section ?? ""))
            visible: root.searching
            Layout.leftMargin: 14 * root.d
            implicitWidth: resultCaption.implicitWidth
            implicitHeight: resultCaption.implicitHeight
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            Accessible.role: Accessible.Link
            Accessible.name: group.modelData.title
            onClicked: root.openResult(group.modelData.rows[0], false)
            Row {
                id: resultCaption
                spacing: 8 * root.d
                IrisSquircle {
                    plain: IrisStyle.settingsPlainMarks
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.round(18 * root.d)
                    height: width
                    tint: resultSection.section.tint ?? IrisStyle.identity.gray
                    glyph: resultSection.section.icon ?? "settings"
                }
                IrisText {
                    anchors.verticalCenter: parent.verticalCenter
                    text: group.modelData.title
                    // A Design whose marks are plain glyphs tells a section by its words, never by a hue of its own.
                    color: resultSection.containsMouse ? IrisStyle.text : IrisStyle.iconColour === "mono" ? IrisStyle.label : IrisStyle.iconHue(resultSection.section.tint ?? IrisStyle.label)
                    font.family: IrisStyle.fontTitle
                    font.pixelSize: IrisStyle.typeMeta
                    font.weight: IrisStyle.weight(Font.DemiBold)
                }
                MaterialSymbol {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "chevron_right"
                    iconSize: Math.round(14 * root.d)
                    color: IrisStyle.label
                    opacity: resultSection.containsMouse ? 1 : 0
                }
            }
        }
        // A long group reads as captioned cards, one per `part` its rows name; search shows one card. Keyed by caption,
        // so a write (a slider mid-drag) never rebuilds a card under the pointer.
        function partOf(spec: var): string { return root.searching ? "" : String(spec.part ?? "") }
        // Essentials first: the group's fine-tuning (IrisOptions.fineTune) waits behind one row at its foot that names
        // what it holds. Only worth it with two or more such rows; a group that is all fine-tuning (Spotlight's prefixes)
        // is its caption over that one row. A search shows everything, and a row you changed stays out where you left it.
        readonly property string tuneKey: "tune:" + root.section + "/" + String(group.modelData.key ?? group.modelData.title)
        readonly property var tuned: root.searching ? [] : group.modelData.rows.filter(spec => IrisOptions.foldsAway(spec))
        readonly property bool folds: group.tuned.length >= 2
        readonly property bool tuneOpen: group.folds && (root.tuneAll || (root.unfolded[group.tuneKey] ?? false))
        readonly property var shownRows: group.folds && !group.tuneOpen ? group.modelData.rows.filter(spec => !group.tuned.includes(spec)) : group.modelData.rows
        // A search result or a link to a folded row opens the fold first, so the row can glow where it lives.
        readonly property bool landsInFold: root.landingPath.length > 0 && group.tuned.some(spec => String(spec.path ?? "") === root.landingPath)
        onLandsInFoldChanged: if (group.landsInFold && !group.tuneOpen) root.fold(group.tuneKey)
        // A group that is all fine-tuning still has one card: its Fine-tune row.
        readonly property var parts: group.shownRows.length === 0 ? [""] : [...new Set(group.shownRows.map(spec => group.partOf(spec)))]
        Repeater {
            model: ScriptModel { values: group.parts }
            ColumnLayout {
                id: part
                required property string modelData
                required property int index
                readonly property var rows: group.shownRows.filter(spec => group.partOf(spec) === part.modelData)
                readonly property bool lastPart: part.index === group.parts.length - 1
                Layout.fillWidth: true
                Layout.topMargin: part.index > 0 ? 12 * root.d : 0
                spacing: 6 * root.d
                IrisText {
                    visible: text.length > 0
                    Layout.leftMargin: 16 * root.d
                    text: part.modelData.length > 0 ? Translation.tr(part.modelData) : ""
                    color: IrisStyle.monoCaptions ? IrisStyle.textTertiary : IrisStyle.label
                    font.family: IrisStyle.monoCaptions ? IrisStyle.fontMono : IrisStyle.fontTitle
                    font.pixelSize: IrisStyle.monoCaptions ? IrisStyle.typeCaption : IrisStyle.typeMeta
                    font.weight: IrisStyle.monoCaptions ? IrisStyle.weight(Font.Medium) : IrisStyle.weight(Font.DemiBold)
                    font.capitalization: IrisStyle.monoCaptions ? Font.AllUppercase : Font.MixedCase
                    font.letterSpacing: IrisStyle.monoCaptions ? Math.round(IrisStyle.typeCaption * 0.16) : 0
                }
                IrisPlate {
                    Layout.fillWidth: true
                    implicitHeight: groupRows.implicitHeight
                    radius: IrisStyle.radiusTile
                    // A search or a shared page groups its rows on the same form plates as an area's page (10-29).
                    color: root.sceneDrawn && root.scene.groupFill !== undefined ? root.scene.groupFill
                        : IrisStyle.formPlate
                    ColumnLayout {
                        id: groupRows
                        anchors.left: parent.left
                        anchors.right: parent.right
                        spacing: 0
                        Repeater {
                            model: ScriptModel { objectProp: "modelKey"; values: part.rows }
                            IrisSetting {
                                id: settingRow
                                required property var modelData
                                required property int index
                                Layout.fillWidth: true
                                spec: modelData
                                voice: root.voice
                                highlight: root.query
                                last: index === part.rows.length - 1 && !(part.lastPart && group.folds)
                                landing: root.landingPath.length > 0 && String(modelData.path ?? "") === root.landingPath
                                onLandingChanged: if (landing) landingReveal.restart()
                                // A row unfolded under the pointer arrives softly; one created already landed still glows.
                                Component.onCompleted: {
                                    if (landing) landingReveal.restart()
                                    if (group.tuned.includes(modelData) && group.tuneOpen) arrive.restart()
                                }
                                NumberAnimation { id: arrive; target: settingRow; property: "opacity"; from: 0; to: 1; duration: IrisStyle.duration(220); easing.type: IrisStyle.feedbackEasing }
                                Timer { id: landingReveal; interval: 120; onTriggered: root.reveal(settingRow) }
                            }
                        }
                        Layouts.FineTune {
                            visible: part.lastPart && group.folds
                            Layout.fillWidth: true
                            open: group.tuneOpen
                            names: group.tuned.map(spec => Translation.tr(String(spec.label ?? "")))
                            onClicked: root.fold(group.tuneKey)
                        }
                    }
                }
            }
        }
    }

}
