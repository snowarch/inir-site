import QtQuick
import QtQuick.Layouts
import Quickshell
import org.kde.kirigami as Kirigami
import qs
import qs.services
import qs.modules.common
import qs.modules.waffle.looks
import qs.modules.waffle.state

AppButton {
    id: root

    iconName: (down && !checked) ? "task-view-pressed" : "task-view"
    pressedScale: checked ? 5/6 : 1
    separateLightDark: true

    checked: WaffleState.taskViewOpen
    onClicked: {
        // Use IPC to toggle TaskView - this triggers preview capture before opening
        Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "taskview", "toggle"])
    }

    BarToolTip {
        barExtraVisibleCondition: root.shouldShowTooltip
        text: Translation.tr("Task View")
    }
}
