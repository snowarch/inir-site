pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.waffle.looks

// Keybind row with search registration
Item {
    id: root
    
    property var mods: []
    property string keyName: ""
    property string action: ""
    property var keySubstitutions: ({})
    
    // Search registration
    property int settingsPageIndex: -1
    property string settingsPageName: ""
    property string settingsSection: ""
    property int settingsSearchOptionId: -1
    
    Layout.fillWidth: true
    implicitHeight: Math.max(Looks.dp(40), keybindRow.implicitHeight + Looks.dp(8))
    
    // Highlight animation for search focus
    Behavior on opacity {
        enabled: Looks.transition?.opacity !== undefined
        animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.normal : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
    }
    Behavior on scale {
        enabled: Looks.transition?.resize !== undefined
        animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
    }
    
    function focusFromSettingsSearch(): void {
        // Find parent Flickable
        var flick = null;
        var p = root.parent;
        while (p) {
            if (p.hasOwnProperty("contentY") && p.hasOwnProperty("contentHeight")) {
                flick = p;
                break;
            }
            p = p.parent;
        }
        
        if (flick) {
            var y = 0;
            var n = root;
            while (n && n !== flick) {
                y += n.y || 0;
                n = n.parent;
            }
            var centerOffset = (flick.height - root.height) / 2;
            var maxY = Math.max(0, flick.contentHeight - flick.height);
            flick.contentY = Math.max(0, Math.min(y - centerOffset, maxY));
        }
        
        highlightAnim.stop();
        root.scale = 1.0;
        highlightOverlay.opacity = 0;
        highlightAnim.start();
    }
    
    Component.onCompleted: {
        if (typeof SettingsSearchRegistry === "undefined") return;
        if (!root.action) return;
        
        // Build key combo string for keywords
        var keyCombo = root.mods.concat(root.keyName ? [root.keyName] : []).join("+").toLowerCase();
        
        settingsSearchOptionId = SettingsSearchRegistry.registerOption({
            control: root,
            pageIndex: root.settingsPageIndex,
            pageName: root.settingsPageName,
            section: root.settingsSection,
            label: root.action,
            description: keyCombo,
            keywords: [keyCombo, "shortcut", "keybind", "hotkey"].concat(root.mods.map(m => m.toLowerCase()))
        });
    }
    
    Component.onDestruction: {
        if (typeof SettingsSearchRegistry !== "undefined") {
            SettingsSearchRegistry.unregisterControl(root);
        }
    }
    
    Rectangle {
        anchors.fill: parent
        radius: Looks.radius.medium
        color: rowMouse.containsMouse ? Looks.settings.tileHover : "transparent"
    }
    
    Rectangle {
        id: highlightOverlay
        anchors.fill: parent
        radius: Looks.radius.medium
        color: Looks.colors.accent
        opacity: 0
    }
    
    MouseArea {
        id: rowMouse
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.NoButton
    }
    
    RowLayout {
        id: keybindRow
        anchors.fill: parent
        anchors.leftMargin: Looks.dp(12)
        anchors.rightMargin: Looks.dp(12)
        spacing: Looks.dp(12)

        // The action leads and the keys answer at the right, as every card does: people arrive with "how do I ...".
        WText {
            Layout.fillWidth: true
            text: root.action
            font.pixelSize: Looks.font.pixelSize.normal
            elide: Text.ElideRight
        }

        // Keys
        Row {
            Layout.alignment: Qt.AlignRight | Qt.AlignVCenter
            spacing: Looks.dp(4)
            
            Repeater {
                model: root.mods
                delegate: Rectangle {
                    required property var modelData
                    implicitWidth: Math.max(keyText.implicitWidth + Looks.dp(10), Looks.dp(26))
                    implicitHeight: Math.max(Looks.dp(24), keyText.implicitHeight + Looks.dp(4))
                    radius: Looks.radius.small
                    color: Looks.colors.bg2
                    border.width: 1
                    border.color: Looks.settings.stroke
                    
                    WText {
                        id: keyText
                        anchors.centerIn: parent
                        text: root.keySubstitutions[modelData] ?? modelData
                        font.pixelSize: Looks.font.pixelSize.small
                        font.family: Looks.font.family.monospace
                    }
                }
            }
            
            WText {
                visible: root.mods.length > 0 && root.keyName.length > 0
                text: "+"
                color: Looks.colors.subfg
                font.pixelSize: Looks.font.pixelSize.small
                anchors.verticalCenter: parent.verticalCenter
            }
            
            Rectangle {
                visible: root.keyName.length > 0
                implicitWidth: Math.max(mainKeyText.implicitWidth + Looks.dp(10), Looks.dp(26))
                implicitHeight: Math.max(Looks.dp(24), mainKeyText.implicitHeight + Looks.dp(4))
                radius: Looks.radius.small
                color: Looks.colors.bg2
                border.width: 1
                border.color: Looks.settings.stroke
                
                WText {
                    id: mainKeyText
                    anchors.centerIn: parent
                    text: root.keySubstitutions[root.keyName] ?? root.keyName
                    font.pixelSize: Looks.font.pixelSize.small
                    font.family: Looks.font.family.monospace
                }
            }
        }
    }
}
