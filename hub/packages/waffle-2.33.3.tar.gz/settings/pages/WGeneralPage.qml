pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs.services
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.waffle.looks
import qs.modules.waffle.settings

WSettingsPage {
    id: root
    settingsPageIndex: 1
    pageTitle: Translation.tr("General")
    pageIcon: "settings"
    pageDescription: Translation.tr("System behavior and preferences")
    
    WSettingsCard {
        section: Translation.tr("Audio")
        collapsible: true
        expanded: false
        title: Translation.tr("Volume protection")
        icon: "speaker-mute"
        description: Translation.tr("Limit volume to prevent hearing damage")
        toggle: true
        checked: Config.options?.audio?.protection?.enable ?? false
        onToggled: on => Config.setNestedValue("audio.protection.enable", on)

        WSettingsSpinBox {
            label: Translation.tr("Maximum volume")
            icon: "speaker-1"
            suffix: "%"
            from: 50; to: 150; stepSize: 5
            value: Config.options?.audio?.protection?.maxAllowed ?? 99
            onValueChanged: Config.setNestedValue("audio.protection.maxAllowed", value)
        }
        WSettingsSpinBox {
            label: Translation.tr("Max increase per step")
            icon: "speaker-settings"
            description: Translation.tr("Maximum volume increase per key press")
            suffix: "%"
            from: 1; to: 20; stepSize: 1
            value: Config.options?.audio?.protection?.maxAllowedIncrease ?? 10
            onValueChanged: Config.setNestedValue("audio.protection.maxAllowedIncrease", value)
        }
    }
    
    WSettingsCard {
        title: Translation.tr("Battery")
        icon: "battery-full"
        
        WSettingsSpinBox {
            label: Translation.tr("Low battery warning")
            icon: "battery-warning"
            suffix: "%"
            from: 5; to: 50; stepSize: 5
            value: Config.options?.battery?.low ?? 20
            onValueChanged: Config.setNestedValue("battery.low", value)
        }
        
        WSettingsSpinBox {
            label: Translation.tr("Critical battery")
            icon: "battery-0"
            description: Translation.tr("Auto-suspend threshold")
            suffix: "%"
            from: 1; to: 20; stepSize: 1
            value: Config.options?.battery?.critical ?? 5
            onValueChanged: Config.setNestedValue("battery.critical", value)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Full battery notification")
            icon: "battery-charge"
            checked: Config.options?.battery?.notifyFull ?? true
            onCheckedChanged: Config.setNestedValue("battery.notifyFull", checked)
        }

        WSettingsSwitch {
            property bool _ready: false
            label: Translation.tr("Charge limit")
            icon: "battery-saver"
            description: !Battery.chargeLimitSupported
                ? Translation.tr("Not supported on this device")
                : Battery.chargeLimitAdjustable
                    ? Translation.tr("Limit maximum charge to preserve battery health")
                    : Translation.tr("Use your device's built-in battery conservation mode (requires polkit)")
            enabled: Battery.chargeLimitSupported
            checked: Config.options?.battery?.chargeLimit?.enable ?? false
            Component.onCompleted: _ready = true
            onCheckedChanged: {
                if (_ready && checked !== (Config.options?.battery?.chargeLimit?.enable ?? false))
                    Config.setNestedValue("battery.chargeLimit.enable", checked)
            }
        }

        WSettingsSpinBox {
            property bool _ready: false
            visible: Battery.chargeLimitAdjustable
            enabled: Config.options?.battery?.chargeLimit?.enable ?? false
            label: Translation.tr("Charge limit threshold")
            icon: "battery-8"
            suffix: "%"
            from: 20; to: 100; stepSize: 5
            value: Config.options?.battery?.chargeLimit?.threshold ?? 80
            Component.onCompleted: _ready = true
            onValueChanged: {
                if (_ready && value !== (Config.options?.battery?.chargeLimit?.threshold ?? 80))
                    Config.setNestedValue("battery.chargeLimit.threshold", value)
            }
        }
    }
    
    WSettingsCard {
        title: Translation.tr("Time & Language")
        icon: "globe-search"
        
        WSettingsSwitch {
            label: Translation.tr("Show seconds")
            icon: "timer"
            description: Translation.tr("Display seconds in clock")
            checked: Config.options?.time?.secondPrecision ?? false
            onCheckedChanged: Config.setNestedValue("time.secondPrecision", checked)
        }

        WSettingsTextField {
            label: Translation.tr("Long date format")
            icon: "schedule"
            description: Translation.tr("Used by clocks and full date labels. Example: dddd, MMMM dd")
            placeholderText: Translation.tr("e.g. dddd, MMMM dd")
            text: Config.options?.time?.dateFormat ?? "ddd, dd/MM"
            onTextEdited: newText => Config.setNestedValue("time.dateFormat", newText)
        }

        WSettingsTextField {
            label: Translation.tr("Short date format")
            icon: "schedule"
            description: Translation.tr("Used by compact date surfaces. Example: dd/MM")
            placeholderText: Translation.tr("e.g. dd/MM")
            text: Config.options?.time?.shortDateFormat ?? "dd/MM"
            onTextEdited: newText => Config.setNestedValue("time.shortDateFormat", newText)
        }
        
        WSettingsDropdown {
            label: Translation.tr("Language")
            icon: "globe-search"
            currentValue: Config.options?.language?.ui ?? "auto"
            options: [
                { value: "auto", displayName: Translation.tr("Auto") },
                ...Translation.allAvailableLanguages.map(lang => ({
                    value: lang,
                    displayName: Translation.languageDisplayName(lang)
                }))
            ]
            onSelected: newValue => Config.setNestedValue("language.ui", newValue)
        }
    }

    WSettingsCard {
        section: Translation.tr("Keyboard indicators")
        collapsible: true
        expanded: false
        title: Translation.tr("Keyboard popups")
        icon: "keyboard"
        description: Translation.tr("Show a popup when Caps Lock, Num Lock, or the keyboard layout changes")
        toggle: true
        checked: Config.options?.keyboardIndicators?.showPopup ?? true
        onToggled: on => Config.setNestedValue("keyboardIndicators.showPopup", on)

        WSettingsSwitch {
            label: Translation.tr("Layout popup")
            checked: Config.options?.keyboardIndicators?.popup?.layout ?? true
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.popup.layout", checked)
        }
        WSettingsSwitch {
            label: Translation.tr("Caps Lock popup")
            checked: Config.options?.keyboardIndicators?.popup?.caps ?? true
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.popup.caps", checked)
        }
        WSettingsSwitch {
            label: Translation.tr("Num Lock popup")
            checked: Config.options?.keyboardIndicators?.popup?.num ?? false
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.popup.num", checked)
        }
    }

    WSettingsCard {
        collapsible: true
        expanded: false
        title: Translation.tr("Keyboard panel indicators")
        icon: "keyboard-dock"
        description: Translation.tr("Show layout and lock state indicators in the bar or taskbar")
        toggle: true
        checked: Config.options?.keyboardIndicators?.showPanel ?? true
        onToggled: on => Config.setNestedValue("keyboardIndicators.showPanel", on)

        WSettingsSwitch {
            label: Translation.tr("Layout indicator")
            checked: Config.options?.keyboardIndicators?.panel?.layout ?? true
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.panel.layout", checked)
        }
        WSettingsSwitch {
            label: Translation.tr("Caps Lock indicator")
            checked: Config.options?.keyboardIndicators?.panel?.caps ?? true
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.panel.caps", checked)
        }
        WSettingsSwitch {
            label: Translation.tr("Num Lock indicator")
            checked: Config.options?.keyboardIndicators?.panel?.num ?? false
            onCheckedChanged: Config.setNestedValue("keyboardIndicators.panel.num", checked)
        }
    }

    WSettingsCard {
        visible: CompositorService.isNiri
        title: Translation.tr("Window animations")
        icon: "wand"

        WSettingsRow {
            icon: "play"
            label: Translation.tr("Animation style")
            description: Translation.tr("How windows open, close and slide between columns")
        }

        WNiriAnimationPresets {}
    }

    WSettingsCard {
        title: Translation.tr("Windows & Sounds")
        icon: "app-generic"
        
        WSettingsSwitch {
            label: Translation.tr("Show reload notifications")
            icon: "alert"
            description: Translation.tr("Toast when Quickshell or Niri config reloads")
            checked: Config.options?.reloadToasts?.enable ?? true
            onCheckedChanged: Config.setNestedValue("reloadToasts.enable", checked)
        }
        WSettingsSwitch {
            visible: CompositorService.isNiri
            label: Translation.tr("Confirm before closing")
            icon: "shield"
            description: Translation.tr("Show dialog when closing windows with Super+Q")
            checked: Config.options?.closeConfirm?.enabled ?? false
            onCheckedChanged: Config.setNestedValue("closeConfirm.enabled", checked)
        }

        WSettingsSwitch {
            visible: CompositorService.isNiri
            label: Translation.tr("Auto-expand a single tiling window")
            icon: "auto"
            description: Translation.tr("Automatically maximizes a single tiling window to fill the screen. When a second window appears, the first is restored to its normal width.")
            checked: Config.options?.compositor?.autoExpandSingleTilingWindow ?? false
            onCheckedChanged: Config.setNestedValue("compositor.autoExpandSingleTilingWindow", checked)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Battery sounds")
            icon: "speaker"
            checked: Config.options?.sounds?.battery ?? false
            onCheckedChanged: Config.setNestedValue("sounds.battery", checked)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Notification sounds")
            icon: "music-note-2"
            checked: Config.options?.sounds?.notifications ?? true
            onCheckedChanged: Config.setNestedValue("sounds.notifications", checked)
        }

        WSettingsSpinBox {
            label: Translation.tr("Sound volume")
            icon: "speaker-1"
            suffix: "%"
            from: 0; to: 100; stepSize: 5
            value: Math.round((Config.options?.sounds?.volume ?? 0.5) * 100)
            onValueChanged: Config.setNestedValue("sounds.volume", value / 100)
        }
    }

    WSettingsCard {
        id: eventSoundsCard
        title: Translation.tr("Event sounds")
        icon: "music-note-2"

        // One row per shell sound event (keys match Audio.soundEvents)
        readonly property var soundEventRows: [
            { key: "notification", label: Translation.tr("Notification") },
            { key: "notificationCritical", label: Translation.tr("Critical notification") },
            { key: "batteryLow", label: Translation.tr("Battery low") },
            { key: "batteryCritical", label: Translation.tr("Battery critical") },
            { key: "batteryFull", label: Translation.tr("Battery full") },
            { key: "powerPlug", label: Translation.tr("Power plugged in") },
            { key: "powerUnplug", label: Translation.tr("Power unplugged") },
            { key: "pomodoroDone", label: Translation.tr("Pomodoro ends") },
            { key: "timerDone", label: Translation.tr("Timer ends") }
        ]

        Repeater {
            model: eventSoundsCard.soundEventRows
            delegate: SoundPicker {
                required property var modelData
                Layout.fillWidth: true
                label: modelData.label
                eventId: modelData.key
            }
        }
    }
    
    WSettingsCard {
        title: Translation.tr("Idle & Sleep")
        icon: "weather-moon"
        
        WSettingsSpinBox {
            label: Translation.tr("Screen off timeout")
            icon: "flash-off"
            description: Translation.tr("Turn off screen after inactivity (0 = never)")
            suffix: "s"
            from: 0; to: 1800; stepSize: 30
            value: Config.options?.idle?.screenOffTimeout ?? 300
            onValueChanged: Config.setNestedValue("idle.screenOffTimeout", value)
        }
        
        WSettingsSpinBox {
            label: Translation.tr("Lock timeout")
            icon: "lock-closed"
            description: Translation.tr("Lock screen after inactivity (0 = never)")
            suffix: "s"
            from: 0; to: 3600; stepSize: 60
            value: Config.options?.idle?.lockTimeout ?? 600
            onValueChanged: Config.setNestedValue("idle.lockTimeout", value)
        }
        
        WSettingsSpinBox {
            label: Translation.tr("Suspend timeout")
            icon: "weather-moon"
            description: Translation.tr("Suspend after inactivity (0 = never)")
            suffix: "s"
            from: 0; to: 7200; stepSize: 60
            value: Config.options?.idle?.suspendTimeout ?? 0
            onValueChanged: Config.setNestedValue("idle.suspendTimeout", value)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Lock before sleep")
            icon: "lock-closed"
            description: Translation.tr("Lock screen before suspending")
            checked: Config.options?.idle?.lockBeforeSleep ?? true
            onCheckedChanged: Config.setNestedValue("idle.lockBeforeSleep", checked)
        }
    }

    WSettingsCard {
        collapsible: true
        expanded: false
        title: Translation.tr("Separate timeouts on battery")
        icon: "battery-5"
        description: Translation.tr("Use shorter idle timeouts while unplugged")
        toggle: true
        checked: Config.options?.idle?.onBattery?.enable ?? false
        onToggled: on => Config.setNestedValue("idle.onBattery.enable", on)

        WSettingsSpinBox {
            visible: Battery.available
            label: Translation.tr("Battery: screen off")
            icon: "desktop"
            suffix: "s"
            from: 0; to: 3600; stepSize: 30
            value: Config.options?.idle?.onBattery?.screenOffTimeout ?? 120
            onValueChanged: Config.setNestedValue("idle.onBattery.screenOffTimeout", value)
        }
        WSettingsSpinBox {
            visible: Battery.available
            label: Translation.tr("Battery: lock")
            icon: "lock-closed"
            suffix: "s"
            from: 0; to: 7200; stepSize: 30
            value: Config.options?.idle?.onBattery?.lockTimeout ?? 300
            onValueChanged: Config.setNestedValue("idle.onBattery.lockTimeout", value)
        }
        WSettingsSpinBox {
            visible: Battery.available
            label: Translation.tr("Battery: suspend")
            icon: "weather-moon"
            suffix: "s"
            from: 0; to: 7200; stepSize: 60
            value: Config.options?.idle?.onBattery?.suspendTimeout ?? 600
            onValueChanged: Config.setNestedValue("idle.onBattery.suspendTimeout", value)
        }
    }
    
    WSettingsCard {
        title: Translation.tr("Game Mode")
        icon: "games"
        
        WSettingsSwitch {
            label: Translation.tr("Auto-detect fullscreen")
            icon: "eye"
            description: Translation.tr("Enable game mode when apps go fullscreen")
            checked: Config.options?.gameMode?.autoDetect ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.autoDetect", checked)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Disable animations")
            icon: "wand"
            description: Translation.tr("Turn off UI animations in game mode")
            checked: Config.options?.gameMode?.disableAnimations ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableAnimations", checked)
        }
        
        WSettingsSwitch {
            label: Translation.tr("Disable effects")
            icon: "eye-off"
            description: Translation.tr("Turn off blur and shadows in game mode")
            checked: Config.options?.gameMode?.disableEffects ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableEffects", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Disable audio visualizers")
            icon: "music-note-2"
            description: Translation.tr("Stop Cava and hide audio visualizers while game mode is active")
            checked: Config.options?.gameMode?.disableVisualizers ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableVisualizers", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Disable Niri animations")
            icon: "pulse"
            description: Translation.tr("Turn off compositor animations in game mode")
            checked: Config.options?.gameMode?.disableNiriAnimations ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableNiriAnimations", checked)
        }

        WSettingsSwitch {
            visible: GameMode.discoverOverlayInstalled
            label: Translation.tr("Disable Discover overlay")
            icon: "headphones"
            description: Translation.tr("Stop discover-overlay while game mode is active")
            checked: Config.options?.gameMode?.disableDiscoverOverlay ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableDiscoverOverlay", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Minimal mode")
            icon: "leaf-two"
            description: Translation.tr("Make shell surfaces lighter while game mode is active")
            checked: Config.options?.gameMode?.minimalMode ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.minimalMode", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Suppress notifications")
            icon: "alert-off"
            description: Translation.tr("Hide notification popups while game mode is active")
            checked: Config.options?.gameMode?.suppressNotifications ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.suppressNotifications", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Hide reload toasts")
            icon: "alert-snooze"
            description: Translation.tr("Suppress reload notifications when Game Mode is active")
            checked: Config.options?.gameMode?.disableReloadToasts ?? true
            onCheckedChanged: Config.setNestedValue("gameMode.disableReloadToasts", checked)
        }
    }

    WSettingsCard {
        title: Translation.tr("Hotspot")
        icon: "wifi-tethering"

        WSettingsTextField {
            label: Translation.tr("Network name (SSID)")
            icon: "wifi-tethering"
            description: Translation.tr("The name your hotspot will broadcast")
            text: Config.options?.hotspot?.ssid ?? "iNiR Hotspot"
            onTextEdited: (newText) => Config.setNestedValue("hotspot.ssid", newText)
        }

        WSettingsTextField {
            label: Translation.tr("Password")
            icon: "key"
            description: Translation.tr("WPA2 passphrase for the hotspot")
            text: Config.options?.hotspot?.password ?? ""
            onTextEdited: (newText) => Config.setNestedValue("hotspot.password", newText)
        }

        WSettingsSwitch {
            label: Translation.tr("Use 5 GHz band")
            icon: "pulse"
            description: Translation.tr("Use 5 GHz (802.11a) instead of 2.4 GHz. Requires adapter support.")
            checked: (Config.options?.hotspot?.band ?? "bg") === "a"
            onCheckedChanged: Config.setNestedValue("hotspot.band", checked ? "a" : "bg")
        }
    }

    WSettingsCard {
        title: Translation.tr("Calendar")
        icon: "schedule"

        WSettingsSwitch {
            label: Translation.tr("External calendar sync")
            icon: "arrow-sync"
            description: Translation.tr("Sync events from external ICS/iCal URLs (Google Calendar, Outlook, etc.)")
            checked: Config.options?.calendar?.externalSync?.enable ?? false
            onCheckedChanged: Config.setNestedValue("calendar.externalSync.enable", checked)
        }

        WSettingsSpinBox {
            label: Translation.tr("Refresh interval")
            icon: "arrow-clockwise"
            description: Translation.tr("Minutes between calendar fetches")
            value: Config.options?.calendar?.externalSync?.refreshMinutes ?? 15
            from: 5
            to: 120
            stepSize: 5
            onValueChanged: Config.setNestedValue("calendar.externalSync.refreshMinutes", value)
            enabled: Config.options?.calendar?.externalSync?.enable ?? false
        }

        WSettingsSwitch {
            label: Translation.tr("Show upcoming events")
            icon: "list"
            description: Translation.tr("Display upcoming events below the calendar")
            checked: Config.options?.calendar?.showUpcoming ?? true
            onCheckedChanged: Config.setNestedValue("calendar.showUpcoming", checked)
        }

        WSettingsSpinBox {
            label: Translation.tr("Upcoming days")
            icon: "timer"
            description: Translation.tr("How many days ahead to show")
            value: Config.options?.calendar?.upcomingDays ?? 3
            from: 1
            to: 14
            stepSize: 1
            onValueChanged: Config.setNestedValue("calendar.upcomingDays", value)
        }
    }
}
