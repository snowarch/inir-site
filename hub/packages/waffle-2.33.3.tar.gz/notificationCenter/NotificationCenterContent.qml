pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.waffle.looks

WBarAttachedPanelContent {
    id: root

    readonly property bool barAtBottom: Config.options?.waffles?.bar?.bottom ?? false
    revealFromSides: true
    revealFromLeft: false

    property bool collapsed: false
    readonly property int notificationCount: Notifications.list.length
    readonly property bool hasNotifications: notificationCount > 0

    contentItem: ColumnLayout {
        id: contentLayout
        spacing: Looks.dp(12)

        // Notification area
        Item {
            id: notificationArea
            Layout.fillWidth: true
            Layout.preferredHeight: Math.min(Looks.dp(560), notificationPane.implicitHeight)
            implicitWidth: notificationPane.implicitWidth

            WPane {
                id: notificationPane
                anchors.fill: parent
                screenX: root.panelScreenX + root.visualMargin
                screenY: root.panelScreenY + root.visualMargin
                screenWidth: root._screenW
                screenHeight: root._screenH
                contentItem: NotificationPaneContent {
                    implicitWidth: calendarColumnLayout.implicitWidth
                }
            }
        }

        // Calendar pane
        WPane {
            id: calendarPane
            Layout.fillWidth: true
            screenX: root.panelScreenX + root.visualMargin
            screenY: root.panelScreenY + root.visualMargin + notificationArea.height + Looks.dp(12)
            screenWidth: root._screenW
            screenHeight: root._screenH
            contentItem: WPanelPageColumn {
                id: calendarColumnLayout
                DateHeader {
                    Layout.fillWidth: true
                    collapsed: root.collapsed
                    onCollapsedChanged: if (collapsed !== root.collapsed) root.collapsed = collapsed
                }

                WPanelSeparator {
                    visible: !root.collapsed
                }

                CalendarWidget {
                    Layout.fillWidth: true
                    collapsed: root.collapsed
                    onCollapsedChanged: if (collapsed !== root.collapsed) root.collapsed = collapsed
                }

                WPanelSeparator {}

                FocusFooter {
                    Layout.fillWidth: true
                }
            }
        }
    }

    // Keyboard shortcuts
    Keys.onPressed: event => {
        if (event.key === Qt.Key_Escape) {
            root.close()
            event.accepted = true
        } else if (event.key === Qt.Key_Delete && root.hasNotifications) {
            // Delete key clears all notifications
            Notifications.discardAllNotifications()
            event.accepted = true
        } else if (event.key === Qt.Key_D && (event.modifiers & Qt.ControlModifier)) {
            // Ctrl+D toggles Do Not Disturb
            Notifications.silent = !Notifications.silent
            event.accepted = true
        }
    }
}
