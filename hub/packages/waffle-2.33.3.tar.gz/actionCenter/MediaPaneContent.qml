pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import Qt5Compat.GraphicalEffects
import Quickshell
import Quickshell.Widgets
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.waffle.looks

Rectangle {
    id: root
    implicitHeight: Looks.dp(136)
    implicitWidth: Looks.dp(358)
    color: Looks.colors.bgPanelBody

    readonly property var activePlayer: MprisController.activePlayer
    readonly property string effectiveTitle: MprisController.isYtMusicActive ? YtMusic.currentTitle : (MprisController.titleOf(activePlayer) ?? "")
    readonly property string effectiveArtist: MprisController.isYtMusicActive ? YtMusic.currentArtist : (MprisController.artistOf(activePlayer) ?? "")
    readonly property real effectivePosition: MprisController.isYtMusicActive
        ? YtMusic.currentPosition : MprisController.positionOf(activePlayer)
    readonly property real effectiveLength: MprisController.isYtMusicActive
        ? YtMusic.currentDuration
        : ((activePlayer?.lengthSupported ?? false) ? activePlayer.length : 0)
    readonly property bool effectiveCanSeek: MprisController.isYtMusicActive
        ? YtMusic.canSeek
        : ((activePlayer?.canSeek ?? false)
            && (activePlayer?.positionSupported ?? false))
    readonly property real effectiveVolume: MprisController.getVolume()

    function formatTime(seconds: real): string {
        if (!Number.isFinite(seconds) || seconds < 0)
            return "0:00"
        const whole = Math.floor(seconds)
        return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, "0")}`
    }

    Timer {
        running: (root.QsWindow?.window?.visible ?? false)
            && !MprisController.isYtMusicActive
            && (root.activePlayer?.isPlaying ?? false)
        interval: 1000
        repeat: true
        onTriggered: root.activePlayer?.positionChanged()
    }

    // Volume feedback overlay
    Rectangle {
        id: volumeOverlay
        anchors.centerIn: parent
        width: 80
        height: 80
        radius: Looks.radius.medium
        color: ColorUtils.transparentize(Looks.colors.bg0, 0.15)
        opacity: 0
        visible: opacity > 0
        z: 100

        ColumnLayout {
            anchors.centerIn: parent
            spacing: 4

            FluentIcon {
                Layout.alignment: Qt.AlignHCenter
                icon: root.effectiveVolume > 0 ? "speaker" : "speaker-mute"
                implicitSize: 24
            }

            WText {
                Layout.alignment: Qt.AlignHCenter
                text: Math.round(root.effectiveVolume * 100) + "%"
                font.pixelSize: Looks.font.pixelSize.normal
                font.weight: Font.DemiBold
            }
        }

        Behavior on opacity {
            NumberAnimation {
                duration: Looks.transition.enabled ? Looks.transition.duration.normal : 0
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
            }
        }

        Timer {
            id: volumeHideTimer
            interval: 1000
            onTriggered: volumeOverlay.opacity = 0
        }
    }

    // Scroll to change player volume
    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.NoButton
        onWheel: wheel => {
            if (!MprisController.canChangeVolume) return
            const step = 0.05
            const current = MprisController.getVolume()
            if (wheel.angleDelta.y > 0)
                MprisController.setVolume(Math.min(1, current + step))
            else if (wheel.angleDelta.y < 0)
                MprisController.setVolume(Math.max(0, current - step))
            
            // Show volume feedback
            volumeOverlay.opacity = 1
            volumeHideTimer.restart()
        }
    }

    RowLayout {
        anchors.fill: parent
        anchors.margins: Looks.dp(16)
        spacing: Looks.dp(14)

        // Album art
        Rectangle {
            Layout.preferredWidth: Looks.dp(104)
            Layout.preferredHeight: Looks.dp(104)
            radius: Looks.radius.medium
            color: Looks.colors.bg1Base
            clip: true

            StyledImage {
                id: artImage
                anchors.fill: parent
                source: MediaArtwork.displaySource
                fillMode: Image.PreserveAspectCrop
                cache: false
                sourceSize: Qt.size(width * 2, height * 2)
            }

            FluentIcon {
                anchors.centerIn: parent
                icon: "music-note-2"
                implicitSize: 32
                visible: !MediaArtwork.ready || artImage.status !== Image.Ready
            }
        }

        // Info + controls
        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: Looks.dp(4)

            // Track info
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 8

                    WText {
                        Layout.fillWidth: true
                        text: StringUtils.cleanMusicTitle(root.effectiveTitle)
                            || Translation.tr("Not playing")
                        font.pixelSize: Looks.font.pixelSize.normal
                        font.weight: Font.DemiBold
                        elide: Text.ElideRight
                    }

                    // Player app icon
                    IconImage {
                        id: playerIcon
                        Layout.preferredWidth: 20
                        Layout.preferredHeight: 20
                        source: {
                            const de = root.activePlayer?.desktopEntry ?? "";
                            const identity = (root.activePlayer?.identity ?? "").toLowerCase();
                            
                            // Special cases for common players
                            if (identity.includes("spotify")) return Quickshell.iconPath("spotify", "");
                            if (identity.includes("firefox")) return Quickshell.iconPath("firefox", "");
                            if (identity.includes("chrome")) return Quickshell.iconPath("google-chrome", "");
                            if (identity.includes("chromium")) return Quickshell.iconPath("chromium", "");
                            if (identity.includes("vlc")) return Quickshell.iconPath("vlc", "");
                            if (identity.includes("mpv")) return Quickshell.iconPath("mpv", "");
                            if (identity.includes("youtube")) return Quickshell.iconPath("youtube", "");
                            
                            // Try desktop entry icon
                            const entry = DesktopEntries.byId(de) ?? DesktopEntries.heuristicLookup(de);
                            if (entry?.icon) return AppSearch.resolveIcon(entry.icon, "");
                            
                            // Fallback to identity as icon name
                            if (identity) return Quickshell.iconPath(identity, "");
                            
                            return "";
                        }
                        // Only show if loaded successfully
                        visible: status === Image.Ready
                    }
                }

                WText {
                    Layout.fillWidth: true
                    text: root.effectiveArtist
                    font.pixelSize: Looks.font.pixelSize.small
                    color: Looks.colors.fg1
                    elide: Text.ElideRight
                    visible: text !== ""
                }
            }

            RowLayout {
                Layout.fillWidth: true
                visible: root.effectiveCanSeek && root.effectiveLength > 0
                spacing: Looks.dp(6)

                WText {
                    text: root.formatTime(root.effectivePosition)
                    color: Looks.colors.subfg
                    font.pixelSize: Looks.font.pixelSize.tiny
                }

                WSlider {
                    id: seekSlider
                    Layout.fillWidth: true
                    from: 0
                    to: Math.max(1, root.effectiveLength)
                    property real modelValue: root.effectivePosition
                    Binding {
                        target: seekSlider
                        property: "value"
                        value: seekSlider.modelValue
                        when: !seekSlider.pressed && !seekSlider._userInteracting
                    }
                    onMoved: {
                        if (MprisController.isYtMusicActive && root.effectiveCanSeek)
                            YtMusic.seek(value)
                        else if (root.activePlayer && root.effectiveCanSeek)
                            MprisController.seek(root.activePlayer, value)
                    }
                }

                WText {
                    text: root.formatTime(root.effectiveLength)
                    color: Looks.colors.subfg
                    font.pixelSize: Looks.font.pixelSize.tiny
                }
            }

            Item { Layout.fillHeight: true }

            // Controls
            RowLayout {
                Layout.fillWidth: true
                spacing: Looks.dp(4)

                MediaBtn {
                    iconName: "previous"
                    enabled: MprisController.canGoPrevious
                    onClicked: MprisController.previous()
                }
                MediaBtn {
                    iconName: MprisController.isPlaying ? "pause" : "play"
                    size: 36
                    iconSize: 18
                    onClicked: MprisController.togglePlaying()
                }
                MediaBtn {
                    iconName: "next"
                    enabled: MprisController.canGoNext
                    onClicked: MprisController.next()
                }
                Item { Layout.fillWidth: true }
                MediaBtn {
                    iconName: root.effectiveVolume > 0
                        ? "speaker" : "speaker-mute"
                    enabled: MprisController.canChangeVolume
                    onClicked: {
                        volumeOverlay.opacity = 1
                        volumeHideTimer.restart()
                    }
                }
            }
        }
    }

    component MediaBtn: WBorderlessButton {
        property string iconName
        property int size: Looks.dp(32)
        property int iconSize: Looks.dp(14)
        implicitWidth: size
        implicitHeight: size
        contentItem: FluentIcon {
            anchors.centerIn: parent
            icon: parent.iconName
            implicitSize: parent.iconSize
        }
    }
}
