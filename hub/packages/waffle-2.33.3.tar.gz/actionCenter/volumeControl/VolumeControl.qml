import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs
import qs.services
import qs.services.deferred
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.waffle.looks
import qs.modules.waffle.actionCenter
import qs.modules.waffle.state

Item {
    id: root
    property bool output: true

    WPanelPageColumn {
        anchors.fill: parent

        BodyRectangle {
            implicitHeight: 400
            implicitWidth: 50

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 4
                spacing: 4

                HeaderRow {
                    Layout.fillWidth: true
                    title: root.output ? Translation.tr("Sound output") : Translation.tr("Sound input")
                }

                StyledFlickable {
                    id: flickable
                    Layout.fillHeight: true
                    Layout.fillWidth: true
                    contentHeight: contentLoader.item?.implicitHeight ?? 0
                    contentWidth: width
                    clip: true

                    Loader {
                        id: contentLoader
                        width: flickable.width
                        active: true
                        asynchronous: true
                        sourceComponent: AudioChoicesComponent {}
                    }
                }
            }
        }

        WPanelSeparator {}

        FooterRectangle {
            FooterMoreButton {
                anchors {
                    verticalCenter: parent.verticalCenter
                    left: parent.left
                }
                text: Translation.tr("More volume settings")
                onClicked: {
                    WaffleState.actionCenterOpen = false
                    AppLauncher.launch("volumeMixer")
                }
            }
        }
    }

    component AudioChoicesComponent: ColumnLayout {
        spacing: 4

        SectionText {
            text: root.output ? Translation.tr("Output device") : Translation.tr("Input device")
        }

        Repeater {
            model: root.output ? Audio.outputDevices : Audio.inputDevices
            delegate: WChoiceButton {
                required property var modelData
                icon.name: WIcons.audioDeviceIcon(modelData)
                text: Audio.friendlyDeviceName(modelData)
                checked: modelData.id === (root.output ? Audio.sink : Audio.source)?.id
                onClicked: {
                    if (root.output) Audio.setDefaultSink(modelData);
                    else Audio.setDefaultSource(modelData);
                }
            }
        }

        WPanelSeparator {
            visible: EasyEffects.available && root.output
            color: Looks.colors.bg2Hover
        }

        SectionText {
            visible: EasyEffects.available && root.output
            text: Translation.tr("Sound effects")
        }

        WChoiceButton {
            visible: EasyEffects.available && root.output
            text: Translation.tr("Off")
            checked: !EasyEffects.active
            onClicked: EasyEffects.disable()
        }

        WChoiceButton {
            visible: EasyEffects.available && root.output
            text: Translation.tr("EasyEffects")
            checked: EasyEffects.active
            onClicked: EasyEffects.enable()
        }

        WPanelSeparator {
            color: Looks.colors.bg2Hover
        }

        SectionText {
            text: Translation.tr("Volume mixer")
        }

        VolumeEntry {
            node: root.output ? Audio.sink : Audio.source
            icon: root.output ? "speaker" : "mic-on"
            monochrome: true
        }

        Repeater {
            model: root.output ? MprisController.mixerAppNodes : Audio.inputAppNodes
            delegate: VolumeEntry {
                required property var modelData
                node: modelData
            }
        }
    }
}
