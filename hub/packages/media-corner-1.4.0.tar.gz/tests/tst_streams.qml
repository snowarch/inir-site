import QtQuick
import QtTest
import "../state/streams.js" as Streams

// Run with: QT_QPA_PLATFORM=offscreen /usr/lib/qt6/bin/qmltestrunner -input components/media-corner/tests/tst_streams.qml
TestCase {
    function test_playbackTracks() {
        const tracks = Streams.playbackTracks([
            {id: 1, type: "audio", lang: "EN", title: "<b>unsafe</b>"},
            {id: 2, type: "sub", lang: "<img>"},
            {id: 3, type: "video"}, {id: "4", type: "audio"}, {id: -1, type: "sub"}
        ])
        compare(tracks.length, 2)
        compare(tracks[0].id, 1)
        compare(tracks[0].lang, "en")
        compare(tracks[1].lang, "")
        compare(tracks[0].title, undefined)
        compare(Streams.playbackTracks(null).length, 0)
    }
    name: "Streams"

    function test_baseOf() {
        compare(Streams.baseOf("https://a.example.com/x/manifest.json"), "https://a.example.com/x")
        compare(Streams.baseOf("stremio://a.example.com/manifest.json"), "https://a.example.com")
        compare(Streams.baseOf("http://a.example.com/manifest.json"), "")
        compare(Streams.baseOf("https://a.example.com/x"), "")
        compare(Streams.baseOf("https://a.example.com/manifest.json --script=x"), "")
    }
    function test_hostHidesTheToken() {
        compare(Streams.hostOf("https://user:pass@a.example.com/secret/manifest.json"), "a.example.com")
    }
    function test_addonResponseLimits() {
        const stream = { url: "https://example.com/video" }
        const subtitle = { url: "https://example.com/subtitle", lang: "en" }
        compare(Streams.streamsFrom({ streams: Array(300).fill(stream) }).length, 256)
        compare(Streams.subtitlesFrom({ subtitles: Array(300).fill(subtitle) }).length, 256)
        const info = Streams.manifestInfo({ resources: ["stream"], types: Array(200).fill("x".repeat(300)), idPrefixes: Array(200).fill("id") })
        compare(info.types.length, 128)
        compare(info.types[0].length, 256)
        compare(info.prefixes.length, 128)
        verify(!Streams.mediaUrl("https://example.com/" + "x".repeat(8192)))
    }
    function test_mediaDestinationsRejectLocalAddresses() {
        const local = ["localhost", "media.localhost", "127.0.0.1", "10.1.2.3", "169.254.1.2", "172.16.0.1", "192.168.1.1", "2130706433", "[::1]", "[fc00::1]", "[fe80::1]", "[::ffff:7f00:1]", "0x7f.0.0.1", "0x7f.1", "0177.0.0.1", "127.1", "[::ffff:127.0.0.1]"]
        for (const host of local) {
            const url = "https://" + host + "/video"
            verify(!Streams.mediaUrl(url), host)
            compare(Streams.streamsFrom({ streams: [{ url }] }).length, 0, host)
            compare(Streams.subtitlesFrom({ subtitles: [{ url, lang: "en" }] }).length, 0, host)
        }
        verify(Streams.mediaUrl("https://example.com/video"))
        verify(Streams.mediaUrl("https://public.example.com/video"))
        verify(Streams.mediaUrl("https://[2001:db8::1]/video"))
    }
    function test_httpsUrlRejectsMalformedOrNonHttpsDestinations() {
        verify(Streams.httpsUrl("https://media.example.com/video.m3u8?token=a%2Fb"))
        verify(Streams.httpsUrl("https://media.example.com:8443/subtitles/file.srt"))
        verify(Streams.httpsUrl("https://[2001:db8::1]/video.mkv"))
        verify(!Streams.httpsUrl("http://media.example.com/video"))
        verify(!Streams.httpsUrl("https://"))
        verify(!Streams.httpsUrl("https://user:pass@media.example.com/video"))
        verify(!Streams.httpsUrl("https://media.example.com:0/video"))
        verify(!Streams.httpsUrl("https://media.example.com:65536/video"))
        verify(!Streams.httpsUrl("https://media.example.com\\\\video"))
        verify(!Streams.httpsUrl("https://media.example.com/%2Gvideo"))
        verify(!Streams.httpsUrl("https://a..example.com/video"))
        verify(!Streams.httpsUrl("https://a.-b.example.com/video"))
        compare(Streams.streamsFrom({ streams: [{ url: "https://a..example.com/x.mp4" }, { url: "https://media.example.com:65536/x.mp4" }] }).length, 0)
        compare(Streams.subtitlesFrom({ subtitles: [{ lang: "en", url: "https://a..example.com/x.srt" }] }).length, 0)
    }
    function test_manifest() {
        compare(Streams.manifestInfo({ resources: ["catalog"] }), null)
        const plain = Streams.manifestInfo({ name: "A", resources: ["stream"], types: ["movie"], idPrefixes: ["tt"] })
        compare(plain.prefixes, ["tt"])
        const inner = Streams.manifestInfo({ resources: [{ name: "stream", types: ["series"], idPrefixes: ["kitsu"] }] })
        compare(inner.types, ["series"])
        compare(inner.prefixes, ["kitsu"])
        const mixed = Streams.manifestInfo({ resources: [
            { name: "stream", types: ["series"], idPrefixes: ["kitsu"] },
            { name: "subtitles", types: ["movie"], idPrefixes: ["tt"] }
        ] })
        compare(Streams.pathFor(mixed, { kind: "movie", id: "tt123" }, null, ""), "")
        compare(Streams.pathFor(mixed, { kind: "movie", id: "tt123" }, null, "", "subtitles"), "movie/tt123")
        compare(Streams.pathFor(mixed, { kind: "anime", id: 5 }, { episode: 7 }, "9"), "series/kitsu:9:7")
        compare(Streams.pathFor(mixed, { kind: "anime", id: 5 }, { episode: 7 }, "9", "subtitles"), "")
    }
    function test_subtitles() {
        const info = Streams.manifestInfo({ resources: ["subtitles"] })
        verify(info.hasSubtitles)
        verify(!info.hasStreams)
        const result = Streams.subtitlesFrom({subtitles: [
            {lang:"eng", url:"https://example.com/a.srt", label:"English"},
            {lang:"en", url:"file:///etc/passwd"},
            {lang:"../", url:"https://example.com/a.srt"}
        ]})
        compare(result.length, 1)
        compare(result[0].name, "English")
    }
    function test_onlyHttpsPlays() {
        const found = Streams.streamsFrom({ streams: [
            { infoHash: "abc" },
            { externalUrl: "https://a.example.com/page" },
            { url: "http://a.example.com/v.mp4" },
            { url: "https://a.example.com/v x.mp4" },
            { url: "edl://a" },
            { url: "https://a.example.com/v.mp4", name: "1080p\nmore", behaviorHints: { proxyHeaders: { request: { Referer: "https://b.example.com/" } } } },
            { url: "https://a.example.com/w.mp4", behaviorHints: { proxyHeaders: { request: { Referer: "--script=x" } } } }
        ] })
        compare(found.length, 2)
        compare(found[0].name, "1080p")
        compare(found[0].referer, "https://b.example.com/")
        compare(found[1].name, "Stream")
        compare(found[1].referer, "")
        compare(Streams.streamsFrom(null).length, 0)
    }
    function test_paths() {
        const any = { types: [], prefixes: [] }
        compare(Streams.pathFor(any, { kind: "movie", id: "tt123" }, null, ""), "movie/tt123")
        compare(Streams.pathFor(any, { kind: "series", id: "tt123" }, { season: 2, episode: 3 }, ""), "series/tt123:2:3")
        compare(Streams.pathFor(any, { kind: "movie", id: "../x" }, null, ""), "")
        compare(Streams.pathFor(any, { kind: "anime", id: 5 }, { episode: 7 }, ""), "")
        compare(Streams.pathFor(any, { kind: "anime", id: 5 }, { episode: 7 }, "9"), "series/kitsu:9:7")
        compare(Streams.pathFor({ types: ["anime"], prefixes: ["kitsu"] }, { kind: "anime", id: 5 }, { episode: 7 }, "9"), "anime/kitsu:9:7")
        compare(Streams.pathFor({ types: ["movie"], prefixes: ["tt"] }, { kind: "anime", id: 5, film: true }, null, "9"), "")
        compare(Streams.pathFor({ types: ["series"], prefixes: ["tt"] }, { kind: "movie", id: "tt1" }, null, ""), "")
    }
    function test_web() {
        verify(Streams.validTemplate("https://a.example.com/s?q=%s"))
        verify(!Streams.validTemplate("https://a.example.com/s"))
        verify(!Streams.validTemplate("javascript:alert(%s)"))
        compare(Streams.webUrl("https://a.example.com/s?q=%s", "a&b $1"), "https://a.example.com/s?q=a%26b%20%241")
    }
    function test_status() {
        compare(Streams.statusFrom("@@POS  1.400000 no"), null)
        compare(Streams.statusFrom("Cannot seek in this stream."), null)
        compare(Streams.statusFrom("@@POS 0.200000 1.600000 no").duration, 1.6)
        compare(Streams.statusFrom("@@POS 0.200000 1.600000 no").window, false)
        compare(Streams.statusFrom("@@POS 12.5  yes").position, 12.5)
        compare(Streams.statusFrom("@@POS 12.5  yes").duration, 0)
        compare(Streams.statusFrom("@@POS 12.5  yes").window, true)
    }
    function test_keysAndClock() {
        compare(Streams.watchKey({ id: "tt1" }, null), "tt1")
        compare(Streams.watchKey({ id: "tt1" }, { season: 1, episode: 2 }), "tt1:1:2")
        compare(Streams.watchKey({ id: 5 }, { episode: 2 }), "5:2")
        compare(Streams.clock(65), "1:05")
        compare(Streams.clock(3725), "1:02:05")
    }
    function test_kitsu() {
        compare(Streams.kitsuIdFrom({ included: [{ type: "anime", id: "12" }] }), "12")
        compare(Streams.kitsuIdFrom({ included: [{ type: "manga", id: "12" }] }), "")
    }
}
