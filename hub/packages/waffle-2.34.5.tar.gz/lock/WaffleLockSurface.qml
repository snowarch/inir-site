pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Layouts
import QtMultimedia
import Qt5Compat.GraphicalEffects
import Quickshell.Services.UPower
import Quickshell.Services.Mpris
import qs
import qs.services
import qs.services.deferred
import qs.modules.common
import qs.modules.common.widgets
import qs.modules.common.functions
import qs.modules.shared.lock
import qs.modules.waffle.looks
import qs.modules.shared.background.widgets.clock as BackgroundClock
import Quickshell
import Quickshell.Widgets

MouseArea {
    id: root
    required property LockContext context
    
    // States: "lock" (clock view) or "login" (password entry)
    property string currentView: "lock"
    property bool showLoginView: currentView === "login"
    readonly property bool requirePasswordToPower: Config.options?.lock?.security?.requirePasswordToPower ?? true
    
    // Track if we've attempted unlock at least once (to prevent shake on load)
    property bool hasAttemptedUnlock: false
    property bool oskVisible: false
    
    // Windows 11 Lock Screen Design Tokens (from Looks.qml)
    readonly property color textColor: Looks.colors.fg
    readonly property color textShadowColor: Looks.colors.shadow
    readonly property real clockFontSize: 96 * Looks.fontScale
    readonly property real dateFontSize: 20 * Looks.fontScale
    readonly property real blurRadius: Config.options?.waffles?.lock?.blur?.radius ?? 64
    readonly property bool blurEnabled: Config.options?.waffles?.lock?.blur?.enable ?? true

    readonly property bool effectsSafe: !CompositorService.isNiri
    readonly property bool enableAnimation: Config.options?.lock?.enableAnimation ?? false

    // Widget visibility
    readonly property bool showWeather: Config.options?.waffles?.lock?.widgets?.weather ?? true
    readonly property bool showMedia: Config.options?.waffles?.lock?.widgets?.media ?? true
    readonly property bool showPowerButtons: Config.options?.waffles?.lock?.widgets?.powerButtons ?? true
    readonly property bool showHintText: Config.options?.waffles?.lock?.widgets?.hintText ?? true

    function safeLockNotificationImage(source): string {
        const value = String(source ?? "")
        return value.startsWith("image://qsimage/") ? "" : value
    }
    
    // Smoke material (Windows 11 - dimming overlay)
    readonly property color smokeColor: ColorUtils.transparentize(Looks.colors.bg0Opaque, 0.5)
    
    // Media player reference
    readonly property MprisPlayer activePlayer: MprisController.activePlayer

    // Safe fallback background color (prevents issues on errors)
    Rectangle {
        anchors.fill: parent
        color: Looks.colors.bg0
        z: -1
    }

    // Resolve wallpaper path: waffle-specific if configured, otherwise main
    readonly property string _wallpaperSource: {
        const wBg = Config.options?.waffles?.background
        if (wBg?.useMainWallpaper ?? true) return Config.options?.background?.wallpaperPath ?? ""
        return wBg?.wallpaperPath ?? Config.options?.background?.wallpaperPath ?? ""
    }
    
    // The file itself, or a video's still frame
    readonly property string _wallpaperPath: Wallpapers.stillUrlFor(_wallpaperSource)
    
    readonly property bool wallpaperIsVideo: {
        const lowerPath = _wallpaperSource.toLowerCase();
        return lowerPath.endsWith(".mp4") || lowerPath.endsWith(".webm") || lowerPath.endsWith(".mkv") || lowerPath.endsWith(".avi") || lowerPath.endsWith(".mov");
    }
    
    readonly property bool wallpaperIsGif: {
        return _wallpaperSource.toLowerCase().endsWith(".gif");
    }

    // Background wallpaper with Acrylic blur effect
    // Static Image (for non-animated wallpapers)
    Image {
        id: backgroundWallpaper
        anchors.fill: parent
        source: root._wallpaperPath && !root.wallpaperIsGif ? root._wallpaperPath : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false // Don't retain in QPixmapCache after lock surface destroys (#163)
        // A lock surface is no QsWindow: the item's own screen gives the scale.
        sourceSize: Qt.size(Math.ceil(root.width * Screen.devicePixelRatio), Math.ceil(root.height * Screen.devicePixelRatio))
        visible: !root.wallpaperIsGif
        
        layer.enabled: root.blurEnabled && root.effectsSafe
        layer.effect: FastBlur {
            radius: root.blurRadius
        }
        
        // Slight zoom to hide blur edges
        transform: Scale {
            origin.x: backgroundWallpaper.width / 2
            origin.y: backgroundWallpaper.height / 2
            xScale: root.blurEnabled ? 1.1 : 1
            yScale: root.blurEnabled ? 1.1 : 1
        }
    }
    
    // Animated GIF support — shows first frame when enableAnimation is false
    AnimatedImage {
        id: gifBackgroundWallpaper
        anchors.fill: parent
        source: root.wallpaperIsGif ? root._wallpaperSource : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false // Don't retain in QPixmapCache after lock surface destroys (#163)
        visible: root.wallpaperIsGif
        playing: visible && root.enableAnimation
        
        layer.enabled: root.blurEnabled && root.effectsSafe
        layer.effect: FastBlur {
            radius: root.blurRadius
        }
        
        // Slight zoom to hide blur edges
        transform: Scale {
            origin.x: gifBackgroundWallpaper.width / 2
            origin.y: gifBackgroundWallpaper.height / 2
            xScale: root.blurEnabled ? 1.1 : 1
            yScale: root.blurEnabled ? 1.1 : 1
        }
    }
    
    // Video wallpaper — shows first frame (paused) when enableAnimation is false
    Video {
        id: videoWallpaper
        anchors.fill: parent
        visible: root.wallpaperIsVideo
        source: {
            if (!root.wallpaperIsVideo || !root._wallpaperSource) return "";
            const path = root._wallpaperSource;
            return path.startsWith("file://") ? path : ("file://" + path);
        }
        fillMode: VideoOutput.PreserveAspectCrop
        loops: MediaPlayer.Infinite
        muted: true
        autoPlay: true

        readonly property bool shouldPlay: root.enableAnimation

        function pauseAndShowFirstFrame() {
            pause()
            seek(0)
        }

        onPlaybackStateChanged: {
            if (playbackState === MediaPlayer.PlayingState && !shouldPlay)
                pauseAndShowFirstFrame()
            if (playbackState === MediaPlayer.StoppedState && visible && shouldPlay)
                play()
        }

        onShouldPlayChanged: {
            if (visible && root.wallpaperIsVideo) {
                if (shouldPlay) play()
                else pauseAndShowFirstFrame()
            }
        }
        
        onVisibleChanged: {
            if (visible && root.wallpaperIsVideo) {
                if (shouldPlay) play()
                else pauseAndShowFirstFrame()
            } else {
                pause()
            }
        }
        
        layer.enabled: root.blurEnabled && root.effectsSafe
        layer.effect: FastBlur {
            radius: root.blurRadius
        }
        
        transform: Scale {
            origin.x: videoWallpaper.width / 2
            origin.y: videoWallpaper.height / 2
            xScale: root.blurEnabled ? 1.1 : 1
            yScale: root.blurEnabled ? 1.1 : 1
        }
    }
    
    // Smoke overlay for login view (Windows 11 modal dimming - always black per Fluent spec)
    Rectangle {
        id: smokeOverlay
        anchors.fill: parent
        color: root.smokeColor
        opacity: root.showLoginView ? 1 : 0
        Behavior on opacity {
            animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.panel : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate }
        }
    }

    // Wallpaper dim overlay
    Rectangle {
        anchors.fill: parent
        color: "#000000"
        opacity: (Config.options?.waffles?.lock?.dim?.enable ?? false) ? (Config.options?.waffles?.lock?.dim?.opacity ?? 0.3) : 0
        z: 0

        Behavior on opacity {
            NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.normal : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate }
        }
    }

    // ===== LOCK VIEW (Clock) =====
    Item {
        id: lockView
        anchors.fill: parent
        opacity: root.showLoginView ? 0 : 1
        visible: opacity > 0
        scale: root.showLoginView ? 0.95 : 1

        Behavior on opacity {
            animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.panel : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate }
        }
        Behavior on scale {
            NumberAnimation {
                duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate
            }
        }
        
        // Config-driven clock properties
        readonly property string clockStyle: Config.options?.waffles?.lock?.clock?.style ?? "default"
        readonly property string clockPosition: Config.options?.waffles?.lock?.clock?.position ?? "center"
        readonly property bool statusEnabled: Config.options?.waffles?.lock?.status?.enable ?? true

        // Status row - compact indicators at top
        Loader {
            active: lockView.statusEnabled
            anchors {
                top: parent.top
                topMargin: 24
                horizontalCenter: parent.horizontalCenter
            }

            sourceComponent: Row {
                spacing: 16

                // WiFi
                Row {
                    spacing: 4
                    visible: Network.ethernet || Network.wifiEnabled

                    MaterialSymbol {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Network.materialSymbol ?? "signal_wifi_off"
                        iconSize: 16
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Network.ethernet ? Translation.tr("Ethernet") : (Network.networkName ?? "")
                        visible: text.length > 0 && text.length < 16
                        font.pixelSize: Looks.font.pixelSize.small
                        font.family: Looks.font.family.ui
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }
                }

                // Bluetooth
                MaterialSymbol {
                    visible: BluetoothStatus.enabled
                    anchors.verticalCenter: parent.verticalCenter
                    text: BluetoothStatus.connected ? "bluetooth_connected" : "bluetooth"
                    iconSize: 16
                    color: root.textColor

                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                        color: root.textShadowColor
                    }
                }

                // Volume
                Row {
                    spacing: 4

                    MaterialSymbol {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Audio.value <= 0 ? "volume_off"
                            : Audio.value < 0.33 ? "volume_mute"
                            : Audio.value < 0.66 ? "volume_down"
                            : "volume_up"
                        iconSize: 16
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Math.round(Audio.value * 100) + "%"
                        font.pixelSize: Looks.font.pixelSize.small
                        font.family: Looks.font.family.ui
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }
                }

                // Battery
                Row {
                    spacing: 4
                    visible: UPower.displayDevice?.isPresent ?? false

                    MaterialSymbol {
                        anchors.verticalCenter: parent.verticalCenter
                        text: {
                            const pct = UPower.displayDevice?.percentage ?? 0
                            const charging = UPower.displayDevice?.state === UPowerDeviceState.Charging
                            if (charging) return "battery_charging_full"
                            if (pct <= 10) return "battery_alert"
                            if (pct <= 30) return "battery_2_bar"
                            if (pct <= 60) return "battery_4_bar"
                            if (pct <= 80) return "battery_5_bar"
                            return "battery_full"
                        }
                        iconSize: 16
                        color: {
                            const pct = UPower.displayDevice?.percentage ?? 0
                            return pct <= 15 ? Looks.colors.danger : root.textColor
                        }

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Math.round(UPower.displayDevice?.percentage ?? 0) + "%"
                        font.pixelSize: Looks.font.pixelSize.small
                        font.family: Looks.font.family.ui
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }
                    }
                }
            }
        }

        // Clock container - position-aware
        Item {
            id: wClockContainer
            width: wClockContent.implicitWidth
            height: wClockContent.implicitHeight

            states: [
                State {
                    name: "center"; when: lockView.clockPosition === "center"
                    AnchorChanges {
                        target: wClockContainer
                        anchors.horizontalCenter: lockView.horizontalCenter
                        anchors.verticalCenter: lockView.verticalCenter
                    }
                    PropertyChanges { target: wClockContainer; anchors.verticalCenterOffset: -60 }
                },
                State {
                    name: "topLeft"; when: lockView.clockPosition === "topLeft"
                    AnchorChanges {
                        target: wClockContainer
                        anchors.left: lockView.left
                        anchors.top: lockView.top
                    }
                    PropertyChanges { target: wClockContainer; anchors.leftMargin: 48; anchors.topMargin: 80 }
                },
                State {
                    name: "bottomLeft"; when: lockView.clockPosition === "bottomLeft"
                    AnchorChanges {
                        target: wClockContainer
                        anchors.left: lockView.left
                        anchors.bottom: lockView.bottom
                    }
                    PropertyChanges { target: wClockContainer; anchors.leftMargin: 48; anchors.bottomMargin: 140 }
                }
            ]

            // Default digital clock
            ColumnLayout {
                id: wClockContent
                visible: lockView.clockStyle !== "analog"
                spacing: 4

                Text {
                    id: clockText
                    Layout.alignment: lockView.clockPosition === "center" ? Qt.AlignHCenter : Qt.AlignLeft
                    text: DateTime.time
                    font.pixelSize: lockView.clockStyle === "minimal" ? Math.round(72 * Looks.fontScale) : root.clockFontSize
                    font.weight: Looks.font.weight.thin
                    font.family: Looks.font.family.ui
                    color: root.textColor

                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 2
                        radius: 8
                        samples: 17
                        color: root.textShadowColor
                    }
                }

                Text {
                    id: dateText
                    Layout.alignment: lockView.clockPosition === "center" ? Qt.AlignHCenter : Qt.AlignLeft
                    text: Translation.locale.toString(new Date(), "dddd, MMMM d")
                    font.pixelSize: lockView.clockStyle === "minimal" ? Math.round(14 * Looks.fontScale) : root.dateFontSize
                    font.weight: Looks.font.weight.regular
                    font.family: Looks.font.family.ui
                    color: root.textColor
                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 1
                        radius: 4
                        samples: 9
                        color: root.textShadowColor
                    }

                    Timer {
                        interval: 60000
                        running: true
                        repeat: true
                        onTriggered: dateText.text = Translation.locale.toString(new Date(), "dddd, MMMM d")
                    }
                }
            }

            // Analog clock - CookieClock from background widgets
            Loader {
                active: lockView.clockStyle === "analog"
                anchors.centerIn: parent

                sourceComponent: Item {
                    id: wAnalogRoot
                    width: wCookieClock.implicitSize + wDateAnalog.implicitHeight + 20
                    height: width

                    BackgroundClock.CookieClock {
                        id: wCookieClock
                        implicitSize: Math.round(230 * Looks.fontScale)
                        anchors.horizontalCenter: parent.horizontalCenter
                    }

                    Text {
                        id: wDateAnalog
                        anchors {
                            horizontalCenter: parent.horizontalCenter
                            top: wCookieClock.bottom
                            topMargin: 16
                        }
                        text: Translation.locale.toString(new Date(), "dddd, MMMM d")
                        font.pixelSize: Math.round(14 * Looks.fontScale)
                        font.weight: Looks.font.weight.regular
                        font.family: Looks.font.family.ui
                        color: root.textColor

                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0; verticalOffset: 1; radius: 4; samples: 9
                            color: root.textShadowColor
                        }

                        Timer {
                            interval: 60000; running: true; repeat: true
                            onTriggered: wDateAnalog.text = Translation.locale.toString(new Date(), "dddd, MMMM d")
                        }
                    }
                }
            }
        }
        
        // Bottom left widgets row (Weather + Media)
        RowLayout {
            id: bottomWidgetsRow
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.bottomMargin: 48
            anchors.leftMargin: 48
            spacing: 24
            
            // Weather widget - Windows 11 style
            Loader {
                active: root.showWeather && Weather.data?.temp && Weather.data.temp.length > 0
                visible: active
                
                sourceComponent: Row {
                    spacing: 12
                    
                    // Weather icon
                    MaterialSymbol {
                        anchors.verticalCenter: parent.verticalCenter
                        text: {
                            const icon = Icons.getWeatherIcon(Weather.data?.wCode ?? "113", Weather.isNightNow())
                            return icon ? icon : "cloud"
                        }
                        iconSize: 48
                        color: root.textColor
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0
                            verticalOffset: 2
                            radius: 6
                            samples: 13
                            color: root.textShadowColor
                        }
                    }
                    
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 0
                        
                        Text {
                            text: Weather.data?.temp ?? ""
                            font.pixelSize: 24 * Looks.fontScale
                            font.weight: Looks.font.weight.thin
                            font.family: Looks.font.family.ui
                            color: root.textColor
                            layer.enabled: root.effectsSafe
                            layer.effect: DropShadow {
                                horizontalOffset: 0
                                verticalOffset: 1
                                radius: 4
                                samples: 9
                                color: root.textShadowColor
                            }
                        }
                        
                        Text {
                            text: Weather.visibleCity
                            visible: Weather.showVisibleCity
                            font.pixelSize: Looks.font.pixelSize.small
                            font.family: Looks.font.family.ui
                            color: Looks.colors.subfg
                            layer.enabled: root.effectsSafe
                            layer.effect: DropShadow {
                                horizontalOffset: 0
                                verticalOffset: 1
                                radius: 2
                                samples: 5
                                color: root.textShadowColor
                            }
                        }
                    }
                }
            }
            
            // Media player widget - Windows 11 style (only show if music is playing or paused)
            Loader {
                active: root.showMedia &&
                        root.activePlayer !== null && 
                        root.activePlayer.playbackState !== MprisPlaybackState.Stopped &&
                        (MprisController.titleOf(root.activePlayer)?.length > 0 ?? false)
                visible: active
                
                sourceComponent: Rectangle {
                    id: mediaWidget
                    width: Math.max(320, mediaRow.implicitWidth + 32)
                    height: 80
                    radius: Looks.radius.xLarge
                    color: ColorUtils.transparentize(Looks.colors.bg1Base, 0.15)
                    border.color: ColorUtils.transparentize(Looks.colors.bg1Border, 0.5)
                    border.width: 1
                    
                    readonly property MprisPlayer player: root.activePlayer
                    readonly property string effectiveArtUrl: MprisController.isYtMusicActive ? YtMusic.currentThumbnail : (MprisController.artUrlOf(player) ?? "")
                    readonly property string effectiveTitle: MprisController.isYtMusicActive ? YtMusic.currentTitle : (MprisController.titleOf(player) ?? "")
                    readonly property string effectiveArtist: MprisController.isYtMusicActive ? YtMusic.currentArtist : (MprisController.artistOf(player) ?? "")

                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 4
                        radius: 16
                        samples: 33
                        color: root.textShadowColor
                    }
                    
                    RowLayout {
                        id: mediaRow
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 16
                        
                        // Album art
                        Rectangle {
                            Layout.preferredWidth: 48
                            Layout.preferredHeight: 48
                            Layout.alignment: Qt.AlignVCenter
                            radius: Looks.radius.medium
                            color: Looks.colors.bg2Base
                            clip: true
                            
                            layer.enabled: root.effectsSafe
                            layer.effect: DropShadow {
                                horizontalOffset: 0
                                verticalOffset: 2
                                radius: 4
                                samples: 9
                                color: Looks.colors.shadow
                            }
                            
                            Image {
                                id: mediaArtImage
                                anchors.fill: parent
                                source: MediaArtwork.displaySource
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: false
                                visible: MediaArtwork.ready && status === Image.Ready
                            }
                            
                            FluentIcon {
                                anchors.centerIn: parent
                                icon: "music-note-2"
                                implicitSize: 24
                                color: Looks.colors.subfg
                                visible: !MediaArtwork.ready || mediaArtImage.status !== Image.Ready
                            }
                        }
                        
                        // Track info
                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.alignment: Qt.AlignVCenter
                            spacing: 4
                            
                            Text {
                                Layout.fillWidth: true
                                text: StringUtils.cleanMusicTitle(MprisController.titleOf(mediaWidget.player) ?? "")
                                font.pixelSize: Looks.font.pixelSize.large
                                font.weight: Looks.font.weight.regular
                                font.family: Looks.font.family.ui
                                color: root.textColor
                                elide: Text.ElideRight
                            }
                            
                            Text {
                                Layout.fillWidth: true
                                text: MprisController.artistOf(mediaWidget.player) ?? ""
                                font.pixelSize: Looks.font.pixelSize.normal
                                font.family: Looks.font.family.ui
                                color: Looks.colors.subfg
                                elide: Text.ElideRight
                                visible: text.length > 0
                            }
                        }
                        
                        // Controls
                        RowLayout {
                            Layout.alignment: Qt.AlignVCenter
                            spacing: 8
                            
                            WaffleLockMediaButton {
                                icon: "previous"
                                enabled: MprisController.canGoPrevious
                                onClicked: MprisController.previous()
                            }
                            
                            WaffleLockMediaButton {
                                icon: mediaWidget.player?.isPlaying ? "pause" : "play"
                                size: 40
                                onClicked: MprisController.togglePlaying()
                            }
                            
                            WaffleLockMediaButton {
                                icon: "next"
                                enabled: MprisController.canGoNext
                                onClicked: MprisController.next()
                            }
                        }
                    }
                }
            }
        }

        // Lock screen notifications - grouped by app, read-only
        Loader {
            id: waffleLockNotificationsLoader
            readonly property bool lockNotifEnabled: Config.options?.waffles?.lock?.notifications?.enable ?? false
            readonly property int lockNotifMaxCount: Config.options?.waffles?.lock?.notifications?.maxCount ?? 3
            readonly property bool lockNotifShowBody: Config.options?.waffles?.lock?.notifications?.showBody ?? true
            readonly property string lockNotifPosition: {
                const pos = Config.options?.waffles?.lock?.notifications?.position ?? "auto"
                return pos === "auto" ? "right" : pos
            }
            active: lockNotifEnabled && Notifications.list.length > 0

            anchors {
                bottom: parent.bottom
                bottomMargin: 100
            }
            width: Math.min(340, parent.width * 0.3)

            states: [
                State {
                    name: "center"; when: waffleLockNotificationsLoader.lockNotifPosition === "center"
                    AnchorChanges {
                        target: waffleLockNotificationsLoader
                        anchors.horizontalCenter: lockView.horizontalCenter
                    }
                },
                State {
                    name: "left"; when: waffleLockNotificationsLoader.lockNotifPosition === "left"
                    AnchorChanges {
                        target: waffleLockNotificationsLoader
                        anchors.left: lockView.left
                    }
                    PropertyChanges { target: waffleLockNotificationsLoader; anchors.leftMargin: 48 }
                },
                State {
                    name: "right"; when: waffleLockNotificationsLoader.lockNotifPosition === "right"
                    AnchorChanges {
                        target: waffleLockNotificationsLoader
                        anchors.right: lockView.right
                    }
                    PropertyChanges { target: waffleLockNotificationsLoader; anchors.rightMargin: 48 }
                }
            ]

            sourceComponent: Column {
                spacing: 6
                clip: true

                Repeater {
                    model: {
                        const apps = Notifications.appNameList
                        const max = waffleLockNotificationsLoader.lockNotifMaxCount
                        return apps.length > max ? apps.slice(0, max) : apps
                    }

                    delegate: Item {
                        id: wGroupDelegate
                        required property var modelData
                        readonly property var group: Notifications.groupsByAppName[modelData] ?? null
                        readonly property var latestNotif: group?.notifications?.[0] ?? null
                        readonly property int groupCount: group?.notifications?.length ?? 0
                        property bool expanded: false

                        width: parent.width
                        height: wGroupCol.implicitHeight
                        visible: latestNotif !== null

                        Column {
                            id: wGroupCol
                            width: parent.width
                            spacing: 3

                            // Main card — clickable to expand
                            Rectangle {
                                id: wGroupCard
                                width: parent.width
                                height: wGroupContent.implicitHeight + 14
                                radius: Looks.radius.large
                                color: wGroupMouse.containsMouse
                                    ? ColorUtils.transparentize(Looks.colors.bg1Hover, 0.06)
                                    : ColorUtils.transparentize(Looks.colors.bg1Base, 0.06)
                                border.color: ColorUtils.transparentize(Looks.colors.bg1Border, 0.5)
                                border.width: 1

                                Behavior on color {
                                    ColorAnimation {
                                        duration: Looks.transition.enabled ? Looks.transition.duration.chromeHover : 0
                                        easing.type: Easing.BezierSpline
                                        easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                                    }
                                }

                                layer.enabled: root.effectsSafe
                                layer.effect: DropShadow {
                                    horizontalOffset: 0
                                    verticalOffset: 2
                                    radius: 8
                                    samples: 17
                                    color: Looks.colors.shadow
                                }

                                MouseArea {
                                    id: wGroupMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: wGroupDelegate.groupCount > 1 ? Qt.PointingHandCursor : Qt.ArrowCursor
                                    onClicked: {
                                        if (wGroupDelegate.groupCount > 1) wGroupDelegate.expanded = !wGroupDelegate.expanded
                                    }
                                }

                                RowLayout {
                                    id: wGroupContent
                                    anchors {
                                        left: parent.left; right: parent.right
                                        verticalCenter: parent.verticalCenter
                                        margins: 10
                                    }
                                    spacing: 10

                                    // App icon
                                    Item {
                                        Layout.alignment: Qt.AlignTop
                                        Layout.preferredWidth: 28
                                        Layout.preferredHeight: 28

                                        Rectangle {
                                            anchors.fill: parent
                                            radius: Looks.radius.medium
                                            color: "transparent"
                                            clip: true

                                            IconImage {
                                                id: wGroupAppIcon
                                                anchors.fill: parent
                                                implicitSize: 28
                                                asynchronous: true
                                                source: {
                                                    const img = root.safeLockNotificationImage(wGroupDelegate.latestNotif?.image)
                                                    const icon = wGroupDelegate.latestNotif?.appIcon ?? ""
                                                    if (img && img !== "") return img
                                                    if (icon && icon !== "") return Quickshell.iconPath(icon, "image-missing")
                                                    return Quickshell.iconPath("preferences-desktop-notification", "image-missing")
                                                }
                                            }

                                            FluentIcon {
                                                anchors.centerIn: parent
                                                icon: "alert"
                                                implicitSize: 16
                                                color: Looks.colors.accentFg
                                                visible: wGroupAppIcon.status === Image.Error || wGroupAppIcon.status === Image.Null
                                            }
                                        }

                                        // Count badge
                                        Rectangle {
                                            visible: wGroupDelegate.groupCount > 1
                                            anchors {
                                                right: parent.right
                                                top: parent.top
                                                rightMargin: -3
                                                topMargin: -3
                                            }
                                            width: Math.max(14, wBadgeText.implicitWidth + 6)
                                            height: 14
                                            radius: 7
                                            color: Looks.colors.accent
                                            z: 1

                                            Text {
                                                id: wBadgeText
                                                anchors.centerIn: parent
                                                text: wGroupDelegate.groupCount
                                                font.pixelSize: 8
                                                font.weight: Font.Bold
                                                font.family: Looks.font.family.ui
                                                color: Looks.colors.accentFg
                                            }
                                        }
                                    }

                                    ColumnLayout {
                                        Layout.fillWidth: true
                                        spacing: 1

                                        RowLayout {
                                            Layout.fillWidth: true

                                            // App name
                                            Text {
                                                Layout.fillWidth: true
                                                text: wGroupDelegate.modelData ?? ""
                                                font.pixelSize: Looks.font.pixelSize.tiny
                                                font.weight: Looks.font.weight.regular
                                                font.family: Looks.font.family.ui
                                                color: Looks.colors.subfg
                                                elide: Text.ElideRight
                                                visible: text.length > 0
                                            }

                                            // Expand indicator
                                            FluentIcon {
                                                visible: wGroupDelegate.groupCount > 1
                                                icon: wGroupDelegate.expanded ? "chevron-up" : "chevron-down"
                                                implicitSize: 12
                                                color: Looks.colors.subfg
                                            }
                                        }

                                        // Latest notification summary
                                        Text {
                                            Layout.fillWidth: true
                                            text: wGroupDelegate.latestNotif?.summary ?? ""
                                            font.pixelSize: Looks.font.pixelSize.small
                                            font.weight: Looks.font.weight.regular
                                            font.family: Looks.font.family.ui
                                            color: root.textColor
                                            elide: Text.ElideRight
                                            maximumLineCount: 1
                                        }

                                        // Body (optional)
                                        Text {
                                            Layout.fillWidth: true
                                            visible: waffleLockNotificationsLoader.lockNotifShowBody && text.length > 0
                                            text: wGroupDelegate.latestNotif?.body ?? ""
                                            font.pixelSize: Looks.font.pixelSize.tiny
                                            font.family: Looks.font.family.ui
                                            color: Looks.colors.subfg
                                            elide: Text.ElideRight
                                            maximumLineCount: 2
                                            wrapMode: Text.WordWrap
                                        }
                                    }
                                }
                            }

                            // Expanded notifications
                            Column {
                                width: parent.width - 12
                                anchors.horizontalCenter: parent.horizontalCenter
                                spacing: 2
                                visible: wGroupDelegate.expanded
                                clip: true

                                Repeater {
                                    model: wGroupDelegate.expanded ? (wGroupDelegate.group?.notifications?.slice(1) ?? []) : []

                                    delegate: Rectangle {
                                        id: wExpandedCard
                                        required property var modelData
                                        width: parent.width
                                        height: wExpandedContent.implicitHeight + 10
                                        radius: Looks.radius.medium
                                        color: ColorUtils.transparentize(Looks.colors.bg1Base, 0.1)
                                        border.color: ColorUtils.transparentize(Looks.colors.bg1Border, 0.6)
                                        border.width: 1

                                        RowLayout {
                                            id: wExpandedContent
                                            anchors {
                                                left: parent.left; right: parent.right
                                                verticalCenter: parent.verticalCenter
                                                margins: 8
                                            }
                                            spacing: 8

                                            IconImage {
                                                Layout.alignment: Qt.AlignTop
                                                Layout.preferredWidth: 20
                                                Layout.preferredHeight: 20
                                                implicitSize: 20
                                                asynchronous: true
                                                source: {
                                                    const icon = wExpandedCard.modelData?.appIcon ?? ""
                                                    if (icon && icon !== "") return Quickshell.iconPath(icon, "image-missing")
                                                    return Quickshell.iconPath("preferences-desktop-notification", "image-missing")
                                                }
                                            }

                                            ColumnLayout {
                                                Layout.fillWidth: true
                                                spacing: 1

                                                Text {
                                                    Layout.fillWidth: true
                                                    text: wExpandedCard.modelData?.summary ?? ""
                                                    font.pixelSize: Looks.font.pixelSize.tiny
                                                    font.weight: Looks.font.weight.regular
                                                    font.family: Looks.font.family.ui
                                                    color: root.textColor
                                                    elide: Text.ElideRight
                                                    maximumLineCount: 1
                                                }

                                                Text {
                                                    Layout.fillWidth: true
                                                    visible: waffleLockNotificationsLoader.lockNotifShowBody && text.length > 0
                                                    text: wExpandedCard.modelData?.body ?? ""
                                                    font.pixelSize: Looks.font.pixelSize.tiny
                                                    font.family: Looks.font.family.ui
                                                    color: Looks.colors.subfg
                                                    elide: Text.ElideRight
                                                    maximumLineCount: 2
                                                    wrapMode: Text.WordWrap
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Overflow indicator for remaining app groups
                Text {
                    visible: Notifications.appNameList.length > waffleLockNotificationsLoader.lockNotifMaxCount
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: "+" + (Notifications.appNameList.length - waffleLockNotificationsLoader.lockNotifMaxCount) + " " + Translation.tr("more")
                    font.pixelSize: Looks.font.pixelSize.tiny
                    font.family: Looks.font.family.ui
                    color: Looks.colors.subfg

                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 1
                        radius: 4
                        samples: 9
                        color: Looks.colors.shadow
                    }
                }
            }
        }
        
        // Bottom hint - Windows 11 style pill
        Rectangle {
            id: hintContainer
            visible: root.showHintText && opacity > 0
            anchors.bottom: parent.bottom
            anchors.bottomMargin: 48
            anchors.horizontalCenter: parent.horizontalCenter
            width: hintText.implicitWidth + 32
            height: 36
            radius: height / 2
            color: ColorUtils.transparentize(Looks.colors.bg1Base, 0.2)
            border.color: Looks.colors.bg1Border
            border.width: 1
            opacity: root.showHintText ? hintOpacity : 0
            
            property real hintOpacity: 1
            
            layer.enabled: root.effectsSafe
            layer.effect: DropShadow {
                horizontalOffset: 0
                verticalOffset: 2
                radius: 8
                samples: 17
                color: root.textShadowColor
            }
            
            Text {
                id: hintText
                anchors.centerIn: parent
                text: Translation.tr("Press any key or click to unlock")
                font.pixelSize: Looks.font.pixelSize.normal
                font.weight: Looks.font.weight.regular
                font.family: Looks.font.family.ui
                color: root.textColor
            }
            
            Timer {
                id: hintFadeTimer
                interval: 4000
                running: lockView.visible
                onTriggered: hintContainer.hintOpacity = 0
            }
            
            // Reset hint when returning to lock view
            Connections {
                target: lockView
                function onVisibleChanged() {
                    if (lockView.visible) {
                        hintContainer.hintOpacity = 1
                        hintFadeTimer.restart()
                    }
                }
            }
            
            Behavior on hintOpacity {
                animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.normal : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
            }
        }
    }

    // ===== LOGIN VIEW =====
    Item {
        id: loginView
        anchors.fill: parent
        opacity: root.showLoginView ? 1 : 0
        visible: opacity > 0
        scale: root.showLoginView ? 1 : 1.05
        
        Behavior on opacity {
            animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.panel : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate }
        }
        Behavior on scale {
            NumberAnimation {
                duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0
                easing.type: Easing.BezierSpline
                easing.bezierCurve: Looks.transition.easing.bezierCurve.decelerate
            }
        }

        // Centered login content
        ColumnLayout {
            anchors.centerIn: parent
            spacing: 16
            
            // User Avatar - Windows 11 style (large circular with shadow)
            Item {
                id: avatarContainer
                Layout.alignment: Qt.AlignHCenter
                width: 120
                height: 120
                
                // Shadow behind avatar
                Rectangle {
                    anchors.centerIn: parent
                    width: parent.width + 4
                    height: parent.height + 4
                    radius: width / 2
                    color: ColorUtils.transparentize(Looks.colors.accent, 1)
                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 4
                        radius: 16
                        samples: 33
                        color: Looks.colors.shadow
                    }
                    
                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 2
                        radius: width / 2
                        color: Looks.colors.accent
                    }
                }
                
                // Avatar circle with image or initial fallback
                Rectangle {
                    id: avatarCircle
                    anchors.fill: parent
                    radius: width / 2
                    color: Looks.colors.accent
                    clip: true
                    
                    // User avatar image - try multiple paths
                    Image {
                        id: avatarImage
                        anchors.fill: parent
                        source: waffleLockAvatarResolver.resolvedSource
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: true
                        smooth: true
                        mipmap: true
                        sourceSize.width: avatarCircle.width * 2
                        sourceSize.height: avatarCircle.height * 2
                        visible: status === Image.Ready
                        onStatusChanged: {
                            if (status === Image.Error)
                                waffleLockAvatarResolver.advanceAfterError()
                        }
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: OpacityMask {
                            maskSource: Rectangle {
                                width: avatarCircle.width
                                height: avatarCircle.height
                                radius: width / 2
                            }
                        }
                    }

                    QtObject {
                        id: waffleLockAvatarResolver
                        property int avatarIndex: 0
                        readonly property string resolvedSource: Directories.avatarSourceAt(avatarIndex)
                        readonly property string primaryWatch: Directories.userAvatarSourcePrimary
                        onPrimaryWatchChanged: avatarIndex = 0

                        function advanceAfterError(): void {
                            const failedIndex = avatarIndex
                            Qt.callLater(() => {
                                if (avatarIndex !== failedIndex || avatarImage.status !== Image.Error)
                                    return
                                const nextIdx = failedIndex + 1
                                if (nextIdx < Directories.userAvatarPaths.length)
                                    avatarIndex = nextIdx
                            })
                        }
                    }
                    
                    // Fallback: initial letter
                    Text {
                        anchors.centerIn: parent
                        text: (SystemInfo.displayName || SystemInfo.username || "?").charAt(0).toUpperCase()
                        font.pixelSize: 48 * Looks.fontScale
                        font.weight: Looks.font.weight.regular
                        font.family: Looks.font.family.ui
                        color: Looks.colors.accentFg
                        visible: avatarImage.status !== Image.Ready
                    }
                }
            }
            
            // Display name
            Text {
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 8
                text: SystemInfo.displayName || SystemInfo.username
                font.pixelSize: 24 * Looks.fontScale
                font.weight: Looks.font.weight.regular
                font.family: Looks.font.family.ui
                color: root.textColor
                layer.enabled: root.effectsSafe
                layer.effect: DropShadow {
                    horizontalOffset: 0
                    verticalOffset: 1
                    radius: 4
                    samples: 9
                    color: root.textShadowColor
                }
            }
            
            // Password field container - Windows 11 Acrylic style
            Rectangle {
                id: passwordContainer
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 8
                width: 280
                height: 40
                radius: Looks.radius.medium
                
                // Acrylic-like background (frosted glass effect)
                color: Looks.colors.inputBg
                border.color: passwordField.activeFocus ? Looks.colors.accent : Looks.colors.accentUnfocused
                border.width: passwordField.activeFocus ? 2 : 1
                
                Behavior on border.color {
                    animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                }
                Behavior on border.width {
                    animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                }
                
                // Bottom accent line when focused (Windows 11 style)
                Rectangle {
                    anchors.bottom: parent.bottom
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: passwordField.activeFocus ? parent.width - 4 : 0
                    height: 2
                    radius: 1
                    color: Looks.colors.accent
                    
                    Behavior on width {
                        animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                    }
                }
                
                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 12
                    anchors.rightMargin: 8
                    spacing: 8
                    
                    // Fingerprint icon (if available)
                    Loader {
                        Layout.alignment: Qt.AlignVCenter
                        active: root.context.fingerprintsConfigured
                        visible: active
                        
                        sourceComponent: FluentIcon {
                            icon: "fingerprint"
                            implicitSize: 20
                            color: Looks.colors.subfg
                        }
                    }
                    
                    TextInput {
                        cursorDelegate: TextCursor { accent: Looks.colors.accent }
                        id: passwordField
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        verticalAlignment: Text.AlignVCenter
                        
                        echoMode: TextInput.Password
                        inputMethodHints: Qt.ImhSensitiveData
                        font.pixelSize: Looks.font.pixelSize.large
                        font.family: Looks.font.family.ui
                        color: root.textColor
                        selectionColor: Looks.colors.selection
                        selectedTextColor: Looks.colors.accentFg
                        
                        enabled: !root.context.unlockInProgress
                        
                        property string placeholder: GlobalStates.screenUnlockFailed 
                            ? Translation.tr("Incorrect password") 
                            : Translation.tr("Password")
                        
                        Text {
                            anchors.fill: parent
                            anchors.leftMargin: 0
                            verticalAlignment: Text.AlignVCenter
                            text: passwordField.placeholder
                            font: passwordField.font
                            color: GlobalStates.screenUnlockFailed ? Looks.colors.danger : Looks.colors.subfg
                            visible: passwordField.text.length === 0
                            
                            layer.enabled: root.effectsSafe
                            layer.effect: DropShadow {
                                horizontalOffset: 0
                                verticalOffset: 1
                                radius: 2
                                samples: 5
                                color: root.textShadowColor
                            }
                        }
                        
                        onTextChanged: root.context.currentText = text
                        onAccepted: {
                            root.hasAttemptedUnlock = true
                            root.context.tryUnlock(root.ctrlHeld)
                        }
                        
                        Connections {
                            target: root.context
                            function onCurrentTextChanged() {
                                passwordField.text = root.context.currentText
                            }
                        }
                        
                        Keys.onPressed: event => {
                            root.context.resetClearTimer()
                        }
                    }
                    
                    // Submit button - Windows 11 accent button
                    Rectangle {
                        id: submitButton
                        Layout.preferredWidth: 28
                        Layout.preferredHeight: 28
                        radius: Looks.radius.medium
                        color: submitMouseArea.pressed 
                            ? Looks.colors.accentActive 
                            : submitMouseArea.containsMouse 
                                ? Looks.colors.accentHover 
                                : Looks.colors.accent
                        
                        Behavior on color {
                            animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                        }
                        
                        FluentIcon {
                            anchors.centerIn: parent
                            icon: {
                                if (root.context.targetAction === LockContext.ActionEnum.Unlock) {
                                    return root.ctrlHeld ? "drink-coffee" : "chevron-right"
                                } else if (root.context.targetAction === LockContext.ActionEnum.Poweroff) {
                                    return "power"
                                } else if (root.context.targetAction === LockContext.ActionEnum.Reboot) {
                                    return "arrow-counterclockwise"
                                }
                                return "chevron-right"
                            }
                            implicitSize: 16
                            color: Looks.colors.accentFg
                        }
                        
                        MouseArea {
                            id: submitMouseArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            enabled: !root.context.unlockInProgress
                            onClicked: {
                                root.hasAttemptedUnlock = true
                                root.context.tryUnlock(root.ctrlHeld)
                            }
                        }
                    }
                }
                
                // Shake animation on wrong password
                property real shakeOffset: 0
                transform: Translate { x: passwordContainer.shakeOffset }
                
                SequentialAnimation {
                    id: wrongPasswordShakeAnim
                    NumberAnimation { target: passwordContainer; property: "shakeOffset"; to: -20; duration: 50 }
                    NumberAnimation { target: passwordContainer; property: "shakeOffset"; to: 20; duration: 50 }
                    NumberAnimation { target: passwordContainer; property: "shakeOffset"; to: -10; duration: 40 }
                    NumberAnimation { target: passwordContainer; property: "shakeOffset"; to: 10; duration: 40 }
                    NumberAnimation { target: passwordContainer; property: "shakeOffset"; to: 0; duration: 30 }
                }
                
                Connections {
                    target: GlobalStates
                    function onScreenUnlockFailedChanged() {
                        // Only shake if we've actually attempted to unlock
                        if (GlobalStates.screenUnlockFailed && root.hasAttemptedUnlock) {
                            wrongPasswordShakeAnim.restart()
                        }
                    }
                }
            }
            
            // Fingerprint hint
            Loader {
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 8
                active: root.context.fingerprintsConfigured && !root.context.unlockInProgress
                visible: active
                
                sourceComponent: Text {
                    text: Translation.tr("Touch sensor to unlock")
                    font.pixelSize: Looks.font.pixelSize.small
                    font.family: Looks.font.family.ui
                    color: Looks.colors.subfg
                    
                    layer.enabled: root.effectsSafe
                    layer.effect: DropShadow {
                        horizontalOffset: 0
                        verticalOffset: 1
                        radius: 2
                        samples: 5
                        color: root.textShadowColor
                    }
                }
            }
            
            // Loading indicator when unlocking
            Loader {
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 8
                active: root.context.unlockInProgress
                visible: active
                
                sourceComponent: WIndeterminateProgressBar {
                    width: 120
                }
            }
        }
        
        // Bottom right: Power options
        RowLayout {
            visible: root.showPowerButtons
            anchors.bottom: parent.bottom
            anchors.right: parent.right
            anchors.bottomMargin: 24
            anchors.rightMargin: 24
            spacing: 8
            
            // Sleep button
            WaffleLockButton {
                icon: "weather-moon"
                tooltip: Translation.tr("Sleep")
                onClicked: Session.suspend()
            }
            
            // Power button
            WaffleLockButton {
                icon: "power"
                tooltip: Translation.tr("Shut down")
                toggled: root.context.targetAction === LockContext.ActionEnum.Poweroff
                onClicked: {
                    if (!root.requirePasswordToPower) {
                        root.context.unlocked(LockContext.ActionEnum.Poweroff)
                        return
                    }
                    if (root.context.targetAction === LockContext.ActionEnum.Poweroff) {
                        root.context.resetTargetAction()
                    } else {
                        root.context.targetAction = LockContext.ActionEnum.Poweroff
                        root.context.shouldReFocus()
                    }
                }
            }
            
            // Restart button
            WaffleLockButton {
                icon: "arrow-counterclockwise"
                tooltip: Translation.tr("Restart")
                toggled: root.context.targetAction === LockContext.ActionEnum.Reboot
                onClicked: {
                    if (!root.requirePasswordToPower) {
                        root.context.unlocked(LockContext.ActionEnum.Reboot)
                        return
                    }
                    if (root.context.targetAction === LockContext.ActionEnum.Reboot) {
                        root.context.resetTargetAction()
                    } else {
                        root.context.targetAction = LockContext.ActionEnum.Reboot
                        root.context.shouldReFocus()
                    }
                }
            }
        }
        
        // Bottom left: Battery & keyboard layout
        Row {
            anchors.bottom: parent.bottom
            anchors.left: parent.left
            anchors.bottomMargin: 24
            anchors.leftMargin: 24
            spacing: 16
            
            // Battery
            Loader {
                active: UPower.displayDevice.isLaptopBattery
                visible: active
                anchors.verticalCenter: parent.verticalCenter
                
                sourceComponent: Row {
                    spacing: 6
                    
                    FluentIcon {
                        anchors.verticalCenter: parent.verticalCenter
                        icon: Battery.isCharging ? "battery-charging" : "battery-full"
                        implicitSize: 20
                        color: (Battery.isLow && !Battery.isCharging) 
                            ? Looks.colors.danger 
                            : root.textColor
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0
                            verticalOffset: 1
                            radius: 3
                            samples: 7
                            color: root.textShadowColor
                        }
                    }
                    
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Math.round(Battery.percentage * 100) + "%"
                        font.pixelSize: Looks.font.pixelSize.normal
                        font.family: Looks.font.family.ui
                        color: (Battery.isLow && !Battery.isCharging) 
                            ? Looks.colors.danger 
                            : root.textColor
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0
                            verticalOffset: 1
                            radius: 3
                            samples: 7
                            color: root.textShadowColor
                        }
                    }
                }
            }
            
            // Keyboard layout
            Loader {
                active: typeof HyprlandXkb !== "undefined" && HyprlandXkb.currentLayoutCode.length > 0
                visible: active
                anchors.verticalCenter: parent.verticalCenter
                
                sourceComponent: Row {
                    spacing: 4
                    
                    FluentIcon {
                        anchors.verticalCenter: parent.verticalCenter
                        icon: "keyboard"
                        implicitSize: 18
                        color: root.textColor
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0
                            verticalOffset: 1
                            radius: 2
                            samples: 5
                            color: root.textShadowColor
                        }
                    }
                    
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: HyprlandXkb.currentLayoutCode.toUpperCase()
                        font.pixelSize: Looks.font.pixelSize.small
                        font.family: Looks.font.family.ui
                        color: root.textColor
                        
                        layer.enabled: root.effectsSafe
                        layer.effect: DropShadow {
                            horizontalOffset: 0
                            verticalOffset: 1
                            radius: 2
                            samples: 5
                            color: root.textShadowColor
                        }
                    }
                }
            }
            
            // On-screen keyboard toggle
            WaffleLockButton {
                icon: "keyboard"
                tooltip: Translation.tr("Virtual keyboard")
                toggled: root.oskVisible
                anchors.verticalCenter: parent.verticalCenter
                onClicked: root.oskVisible = !root.oskVisible
            }
        }
    }

    // On-screen keyboard
    LockKeyboard {
        id: lockKeyboard
        visible: root.oskVisible
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 80
        anchors.horizontalCenter: parent.horizontalCenter
        width: Math.min(parent.width * 0.6, 640)

        // Waffle theme overrides
        themeBgColor: ColorUtils.transparentize(Looks.colors.bg1Base, 0.15)
        themeKeySurfaceColor: ColorUtils.transparentize(Looks.colors.bg2Base, 0.3)
        themeTextColor: root.textColor
        themeSubtextColor: ColorUtils.transparentize(root.textColor, 0.4)
        themeAccentColor: Looks.colors.accent
        themeAccentActiveColor: Qt.darker(Looks.colors.accent, 1.15)
        themeAccentTextColor: Looks.colors.accentFg
        themeRounding: Looks.radius.large
        themeKeyRounding: Looks.radius.medium
        themeAnimDuration: Looks.transition.enabled ? 70 : 0
        themeFontSize: Looks.font.pixelSize.normal
        themeFontSizeLarge: Looks.font.pixelSize.large
        themeFontSizeSmall: Looks.font.pixelSize.small
        themeFontFamily: Looks.font.family.ui

        onKeyClicked: key => {
            passwordField.text += key
            passwordField.forceActiveFocus()
        }
        onBackspaceClicked: {
            if (passwordField.text.length > 0) {
                passwordField.text = passwordField.text.slice(0, -1)
            }
            passwordField.forceActiveFocus()
        }
        onEnterClicked: {
            if (root.context.currentText.length > 0) {
                root.hasAttemptedUnlock = true
                root.context.tryUnlock(root.ctrlHeld)
            }
        }
        onCloseRequested: root.oskVisible = false
    }

    // ===== INPUT HANDLING =====
    
    hoverEnabled: true
    acceptedButtons: Qt.LeftButton
    focus: true
    activeFocusOnTab: true
    
    property bool ctrlHeld: false
    
    function forceFieldFocus(): void {
        if (root.showLoginView && loginView.visible) {
            passwordField.forceActiveFocus()
        }
    }
    
    function switchToLogin(): void {
        root.currentView = "login"
        // Use Qt.callLater to ensure loginView is visible before focusing
        Qt.callLater(() => passwordField.forceActiveFocus())
    }
    
    Connections {
        target: context
        function onShouldReFocus() {
            forceFieldFocus()
        }
    }
    
    onClicked: mouse => {
        if (Brightness.asleep) {
            Brightness.restoreAfterWake()
            return
        }
        if (!root.showLoginView) {
            root.switchToLogin()
        } else {
            root.forceFieldFocus()
        }
    }
    
    onPositionChanged: mouse => {
        if (Brightness.asleep) {
            Brightness.restoreAfterWake()
            return
        }
        if (root.showLoginView) {
            root.forceFieldFocus()
        }
    }
    
    Keys.onPressed: event => {
        if (Brightness.asleep) {
            Brightness.restoreAfterWake()
            event.accepted = true
            return
        }
        root.context.resetClearTimer()
        
        if (event.key === Qt.Key_Control) {
            root.ctrlHeld = true
            return
        }
        
        if (event.key === Qt.Key_Escape) {
            if (root.context.currentText.length > 0) {
                root.context.currentText = ""
            } else if (root.showLoginView && root.currentView === "login") {
                root.currentView = "lock"
            }
            return
        }
        
        // Capture printable character BEFORE switching view
        const isPrintable = event.text.length > 0 && !event.modifiers && event.text.charCodeAt(0) >= 32
        const capturedChar = isPrintable ? event.text : ""
        
        // Switch to login view on any key press
        if (!root.showLoginView) {
            root.currentView = "login"
            // Add captured character after view switch completes
            if (capturedChar.length > 0) {
                Qt.callLater(() => {
                    root.context.currentText += capturedChar
                    passwordField.forceActiveFocus()
                })
                event.accepted = true
            } else {
                Qt.callLater(() => passwordField.forceActiveFocus())
            }
            return
        }
        
        if (event.key === Qt.Key_Return || event.key === Qt.Key_Enter) {
            root.hasAttemptedUnlock = true
            root.context.tryUnlock(root.ctrlHeld)
            event.accepted = true
            return
        }
        
        // Ensure field has focus before accepting input
        if (!passwordField.activeFocus) {
            passwordField.forceActiveFocus()
        }
        
        // Let the TextInput handle the key naturally when it has focus
        if (isPrintable && passwordField.activeFocus) {
            // Don't manually add - let TextInput handle it
            event.accepted = false
        }
    }
    
    Keys.onReleased: event => {
        if (event.key === Qt.Key_Control) {
            root.ctrlHeld = false
        }
        forceFieldFocus()
    }
    
    Component.onCompleted: {
        // Start in lock view, will switch to login on interaction
        root.currentView = "lock"
        GlobalStates.screenUnlockFailed = false
        root.hasAttemptedUnlock = false
        // Force focus to receive keyboard events - use callLater to ensure component is fully ready
        Qt.callLater(() => root.forceActiveFocus())
    }
    
    // Reset state when lock screen is activated
    Connections {
        target: GlobalStates
        function onScreenLockedChanged() {
            if (GlobalStates.screenLocked) {
                root.currentView = "lock"
                root.hasAttemptedUnlock = false
                GlobalStates.screenUnlockFailed = false
                // Force focus when lock activates - delayed to ensure visibility
                Qt.callLater(() => root.forceActiveFocus())
            }
        }
    }
    
    // Ensure focus on first show (workaround for focus issues with Loader)
    Timer {
        id: focusEnsureTimer
        interval: 100
        running: GlobalStates.screenLocked && root.visible
        repeat: false
        onTriggered: {
            if (!root.activeFocus && !passwordField.activeFocus) {
                root.forceActiveFocus()
            }
        }
    }
    
    // Helper component for lock screen buttons - Windows 11 style
    component WaffleLockButton: Rectangle {
        id: lockBtn
        required property string icon
        property string tooltip: ""
        property bool toggled: false
        signal clicked()
        
        width: 40
        height: 40
        radius: Looks.radius.medium
        
        // Acrylic-like button background
        color: {
            if (lockBtn.toggled) return Looks.colors.accent
            if (lockBtnMouse.pressed) return Looks.colors.bg1Active
            if (lockBtnMouse.containsMouse) return Looks.colors.bg1Hover
            return Looks.colors.bg1Base
        }
        
        border.color: Looks.colors.bg1Border
        border.width: 1
        
        Behavior on color {
            animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
        }
        
        FluentIcon {
            anchors.centerIn: parent
            icon: lockBtn.icon
            implicitSize: 20
            color: lockBtn.toggled ? Looks.colors.accentFg : root.textColor
        }
        
        MouseArea {
            id: lockBtnMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: lockBtn.clicked()
        }
        
        WToolTip {
            visible: lockBtnMouse.containsMouse && lockBtn.tooltip.length > 0
            text: lockBtn.tooltip
        }
    }
    
    // Helper component for media control buttons
    component WaffleLockMediaButton: Rectangle {
        id: mediaBtn
        required property string icon
        property bool filled: false
        property real size: 32
        signal clicked()
        
        width: size
        height: size
        radius: filled ? Looks.radius.medium : width / 2
        
        color: {
            if (filled) {
                if (mediaBtnMouse.pressed) return Looks.colors.accentActive
                if (mediaBtnMouse.containsMouse) return Looks.colors.accentHover
                return Looks.colors.accent
            } else {
                if (mediaBtnMouse.pressed) return Looks.colors.bg2Active
                if (mediaBtnMouse.containsMouse) return Looks.colors.bg2Hover
                return Looks.colors.bg2Base
            }
        }
        
        Behavior on color {
            animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
        }
        
        FluentIcon {
            anchors.centerIn: parent
            icon: mediaBtn.icon
            filled: mediaBtn.filled
            implicitSize: mediaBtn.filled ? 20 : 16
            color: mediaBtn.filled ? Looks.colors.accentFg : root.textColor
        }
        
        MouseArea {
            id: mediaBtnMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: mediaBtn.clicked()
        }
    }
}
