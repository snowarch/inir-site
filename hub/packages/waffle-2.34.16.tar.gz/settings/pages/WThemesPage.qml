pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.waffle.looks
import qs.modules.waffle.settings

WSettingsPage {
    id: root
    settingsPageIndex: 4
    pageTitle: Translation.tr("Themes")
    pageIcon: "dark-theme"
    pageDescription: Translation.tr("Color themes and typography")

    property bool cavaControlsReady: false
    Component.onCompleted: Qt.callLater(() => root.cavaControlsReady = true)

    Timer {
        id: cavaConfigDebounce
        interval: 500
        repeat: false
        onTriggered: Quickshell.execDetached([
            Directories.wallpaperSwitchScriptPath, "--noswitch"])
    }

    function setCavaValue(path, value, regenerateStandalone): void {
        if (!root.cavaControlsReady)
            return
        Config.setNestedValue(path, value)
        if (regenerateStandalone)
            cavaConfigDebounce.restart()
    }

    function resetCavaDefaults(): void {
        if (!root.cavaControlsReady)
            return
        Config.setNestedValues({
            "appearance.cava.colorSource": "theme",
            "appearance.cava.gradientCount": 8,
            "appearance.cava.sensitivity": 100,
            "appearance.cava.bars": 0,
            "appearance.cava.framerate": 60,
            "appearance.cava.stereo": true,
            "appearance.cava.waveOpacity": 30,
            "appearance.cava.blockedApps": [],
        })
        cavaConfigDebounce.restart()
    }

    // Active theme preview
    Rectangle {
        Layout.fillWidth: true
        Layout.preferredHeight: 56
        radius: Looks.radius.medium
        color: Looks.colors.bg2

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 12
            spacing: 10

            // Active theme color swatches
            Row {
                spacing: -4

                Repeater {
                    model: {
                        const preset = ThemePresets.getPreset(ThemeService.currentTheme);
                        const c = preset?.colors;
                        return [c?.m3primary ?? Appearance.m3colors.m3primary ?? Looks.colors.accent, c?.m3secondary ?? Appearance.m3colors.m3secondary ?? Looks.colors.bg2, c?.m3tertiary ?? Appearance.m3colors.m3tertiary ?? Looks.colors.bg1, c?.m3background ?? Appearance.m3colors.m3background ?? Looks.colors.bg0];
                    }

                    Rectangle {
                        required property var modelData
                        required property int index
                        width: 20
                        height: 20
                        radius: 10
                        color: modelData
                        border.width: 1
                        border.color: Qt.rgba(0, 0, 0, 0.2)
                        z: 4 - index
                    }
                }
            }

            ColumnLayout {
                Layout.fillWidth: true
                spacing: 1

                WText {
                    text: ThemePresets.getPreset(ThemeService.currentTheme)?.name ?? "Auto"
                    font.pixelSize: Looks.font.pixelSize.normal
                    font.weight: Looks.font.weight.regular
                }

                WText {
                    text: ThemePresets.getPreset(ThemeService.currentTheme)?.description ?? ""
                    font.pixelSize: Looks.font.pixelSize.small
                    color: Looks.colors.subfg
                    elide: Text.ElideRight
                    Layout.fillWidth: true
                }
            }

            FluentIcon {
                icon: "checkmark"
                implicitSize: 14
                color: Looks.colors.accent
            }
        }
    }

    // Color Theme card
    WSettingsCard {
        id: colorThemeCard
        title: Translation.tr("Color Theme")
        icon: "dark-theme"

        property string searchQuery: ""
        property int selectedTab: Persistent.states?.settings?.themeTab ?? 0  // 0=All, 1=Dark, 2=Light
        onSelectedTabChanged: if (Persistent.ready && Persistent.states?.settings)
            Persistent.states.settings.themeTab = selectedTab
        property string selectedTag: Persistent.states?.settings?.themeTag ?? ""
        onSelectedTagChanged: if (Persistent.ready && Persistent.states?.settings)
            Persistent.states.settings.themeTag = selectedTag

        function isDarkTheme(preset) {
            if (preset.id === "auto" || preset.id === "custom")
                return true;
            if (!preset.colors)
                return true;
            const bg = preset.colors.m3background ?? "#000";
            const r = parseInt(bg.slice(1, 3), 16) / 255;
            const g = parseInt(bg.slice(3, 5), 16) / 255;
            const b = parseInt(bg.slice(5, 7), 16) / 255;
            return (0.299 * r + 0.587 * g + 0.114 * b) < 0.5;
        }

        function toggleTag(tagId) {
            selectedTag = (selectedTag === tagId) ? "" : tagId;
        }

        readonly property var filteredPresets: {
            let result = [];
            for (let i = 0; i < ThemePresets.presets.length; i++) {
                const preset = ThemePresets.presets[i];
                if (selectedTab === 1 && !isDarkTheme(preset))
                    continue;
                if (selectedTab === 2 && isDarkTheme(preset))
                    continue;
                if (selectedTag.length > 0) {
                    const presetTags = preset.tags ?? [];
                    if (!presetTags.includes(selectedTag))
                        continue;
                }
                if (searchQuery.length > 0) {
                    const query = searchQuery.toLowerCase();
                    const name = (preset.name ?? "").toLowerCase();
                    const desc = (preset.description ?? "").toLowerCase();
                    if (!name.includes(query) && !desc.includes(query))
                        continue;
                }
                result.push(preset);
            }
            return result;
        }

        // Search + filter row
        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 0
            Layout.rightMargin: 0
            spacing: 8

            // Search field
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 32
                radius: Looks.radius.small
                color: Looks.colors.bg1
                border.width: themeSearchInput.activeFocus ? 1 : 0
                border.color: Looks.colors.accent

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 10
                    anchors.rightMargin: 8
                    spacing: 6

                    FluentIcon {
                        icon: "search"
                        implicitSize: 14
                        color: Looks.colors.subfg
                    }

                    WTextInput {
                        id: themeSearchInput
                        Layout.fillWidth: true
                        Layout.alignment: Qt.AlignVCenter
                        font.pixelSize: Looks.font.pixelSize.small
                        color: Looks.colors.fg
                        clip: true
                        onTextChanged: colorThemeCard.searchQuery = text

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: Translation.tr("Search themes...")
                            font: parent.font
                            color: Looks.colors.subfg
                            opacity: 0.6
                            visible: !parent.text && !parent.activeFocus
                        }
                    }

                    FluentIcon {
                        visible: themeSearchInput.text.length > 0
                        icon: "dismiss"
                        implicitSize: 12
                        color: Looks.colors.subfg

                        MouseArea {
                            anchors.fill: parent
                            anchors.margins: -4
                            cursorShape: Qt.PointingHandCursor
                            onClicked: themeSearchInput.text = ""
                        }
                    }
                }
            }

            // Dark/Light/All segmented tabs
            Row {
                spacing: 2

                Repeater {
                    model: [
                        {
                            label: Translation.tr("All"),
                            icon: "apps"
                        },
                        {
                            label: Translation.tr("Dark"),
                            icon: "weather-moon"
                        },
                        {
                            label: Translation.tr("Light"),
                            icon: "weather-sunny"
                        }
                    ]

                    Rectangle {
                        required property var modelData
                        required property int index

                        readonly property bool isSelected: colorThemeCard.selectedTab === index

                        width: tabLabel.implicitWidth + 24
                        height: 28
                        radius: Looks.radius.medium
                        color: isSelected ? Looks.colors.accent : tabMouseArea.containsMouse ? Looks.colors.bg2Hover : Looks.colors.bg1

                        Behavior on color {
                            animation: ColorAnimation {
                                duration: Looks.transition.enabled ? 70 : 0
                                easing.type: Easing.BezierSpline
                                easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                            }
                        }

                        WText {
                            id: tabLabel
                            anchors.centerIn: parent
                            text: modelData.label
                            font.pixelSize: Looks.font.pixelSize.small
                            font.weight: parent.isSelected ? Looks.font.weight.regular : Looks.font.weight.thin
                            color: parent.isSelected ? Looks.colors.bg0 : Looks.colors.fg
                        }

                        MouseArea {
                            id: tabMouseArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: colorThemeCard.selectedTab = index
                        }
                    }
                }
            }
        }

        // Tag filters
        Flow {
            Layout.fillWidth: true
            Layout.leftMargin: 0
            Layout.rightMargin: 0
            spacing: Looks.dp(6)

            Repeater {
                model: ThemePresets.availableTags.filter(t => t.id !== "dark" && t.id !== "light")

                Rectangle {
                    id: tagChip
                    required property var modelData

                    readonly property bool isActive: colorThemeCard.selectedTag === modelData.id

                    width: tagRowLayout.implicitWidth + Looks.dp(24)
                    height: Looks.dp(28)
                    radius: height / 2
                    color: {
                        if (tagChip.isActive)
                            return Looks.colors.accent
                        if (tagFilterMouse.containsMouse)
                            return Looks.settings.tileHover
                        return Looks.settings.tile
                    }
                    border.width: tagChip.isActive ? 0 : 1
                    border.color: Looks.settings.stroke

                    Behavior on color {
                        animation: ColorAnimation {
                            duration: Looks.transition.enabled ? 70 : 0
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                        }
                    }

                    RowLayout {
                        id: tagRowLayout
                        anchors.centerIn: parent
                        spacing: Looks.dp(4)

                        WText {
                            text: tagChip.modelData.name
                            font.pixelSize: Looks.font.pixelSize.small
                            font.weight: tagChip.isActive ? Looks.font.weight.strong : Looks.font.weight.regular
                            color: tagChip.isActive ? Looks.colors.accentFg : Looks.colors.fg
                        }
                    }

                    MouseArea {
                        id: tagFilterMouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: colorThemeCard.toggleTag(modelData.id)
                    }
                }
            }

            // Clear tag button
            Rectangle {
                visible: colorThemeCard.selectedTag.length > 0
                width: Looks.dp(28)
                height: Looks.dp(28)
                radius: height / 2
                color: clearTagMouse.containsMouse
                    ? Looks.settings.tileHover : Looks.settings.tile
                border.width: 1
                border.color: Looks.settings.stroke

                Behavior on color {
                    animation: ColorAnimation {
                        duration: Looks.transition.enabled ? 70 : 0
                        easing.type: Easing.BezierSpline
                        easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                    }
                }

                FluentIcon {
                    anchors.centerIn: parent
                    icon: "dismiss"
                    implicitSize: 10
                    color: Looks.colors.subfg
                }

                MouseArea {
                    id: clearTagMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: colorThemeCard.selectedTag = ""
                }
            }
        }

        // Theme grid, 3 columns, whole: the search and filters above narrow it. Capped at 300 with its own scroll it
        // trapped the wheel inside the page and cut its next row to a 3 px sliver (10-29); Windows nests no scroll.
        Item {
            Layout.fillWidth: true
            Layout.leftMargin: 0
            Layout.rightMargin: 0
            Layout.bottomMargin: 4
            implicitHeight: themeGridContent.implicitHeight + 12

            Rectangle {
                anchors.fill: parent
                color: Looks.colors.bg0
                radius: Looks.radius.small
                clip: true

                Flickable {
                    id: themeGridFlickable
                    anchors.fill: parent
                    anchors.margins: 6
                    contentHeight: themeGridContent.implicitHeight
                    interactive: false
                    boundsBehavior: Flickable.StopAtBounds

                    Grid {
                        id: themeGridContent
                        width: themeGridFlickable.width
                        // Three across when a name like "Catppuccin Macchiato" fits beside its swatches, two in a
                        // narrow window (a half-screen 1366 px laptop cut it to "Catppuccin Macc…").
                        columns: width >= 3 * Looks.dp(200) + 2 * columnSpacing ? 3 : 2
                        columnSpacing: 4
                        rowSpacing: 4

                        Repeater {
                            model: colorThemeCard.filteredPresets

                            Rectangle {
                                id: themeCard
                                required property var modelData
                                required property int index

                                readonly property bool isActive: ThemeService.currentTheme === modelData.id

                                function getColor(key, fallback) {
                                    if (!modelData.colors)
                                        return Appearance.m3colors[key] ?? fallback;
                                    if (modelData.colors === "custom")
                                        return Config.options?.appearance?.customTheme?.[key] ?? fallback;
                                    return modelData.colors[key] ?? fallback;
                                }

                                width: (themeGridContent.width - themeGridContent.columnSpacing * (themeGridContent.columns - 1)) / themeGridContent.columns
                                height: 36
                                radius: Looks.radius.small
                                color: isActive ? Qt.alpha(Looks.colors.accent, 0.12) : cardMouseArea.containsMouse ? Looks.colors.bg2Hover : Looks.colors.bg2

                                Behavior on color {
                                    animation: ColorAnimation {
                                        duration: Looks.transition.enabled ? 70 : 0
                                        easing.type: Easing.BezierSpline
                                        easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                                    }
                                }

                                border.width: isActive ? 1 : 0
                                border.color: Qt.alpha(Looks.colors.accent, 0.4)

                                MouseArea {
                                    id: cardMouseArea
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: ThemeService.setTheme(themeCard.modelData.id)
                                }

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.leftMargin: 6
                                    anchors.rightMargin: 6
                                    spacing: 6

                                    // Overlapping color circles
                                    Row {
                                        spacing: -4

                                        Repeater {
                                            model: [
                                                {
                                                    key: "m3primary",
                                                    fallback: "#6366f1"
                                                },
                                                {
                                                    key: "m3secondary",
                                                    fallback: "#818cf8"
                                                },
                                                {
                                                    key: "m3tertiary",
                                                    fallback: "#a78bfa"
                                                },
                                                {
                                                    key: "m3background",
                                                    fallback: "#0f0f23"
                                                }
                                            ]

                                            Rectangle {
                                                required property var modelData
                                                required property int index
                                                width: 14
                                                height: 14
                                                radius: 7
                                                color: themeCard.getColor(modelData.key, modelData.fallback)
                                                border.width: 1
                                                border.color: Qt.rgba(0, 0, 0, 0.2)
                                                z: 4 - index
                                            }
                                        }
                                    }

                                    // Theme name
                                    WText {
                                        Layout.fillWidth: true
                                        text: themeCard.modelData.name
                                        font.pixelSize: Looks.font.pixelSize.small
                                        font.weight: themeCard.isActive ? Looks.font.weight.regular : Looks.font.weight.thin
                                        color: themeCard.isActive ? Looks.colors.accent : Looks.colors.fg
                                        elide: Text.ElideRight
                                    }

                                    // Active checkmark
                                    FluentIcon {
                                        visible: themeCard.isActive
                                        icon: "checkmark"
                                        implicitSize: 12
                                        color: Looks.colors.accent
                                    }
                                }

                                WToolTip {
                                    text: themeCard.modelData.description ?? ""
                                    extraVisibleCondition: cardMouseArea.containsMouse
                                }
                            }
                        }
                    }
                }

                // Empty state
                ColumnLayout {
                    visible: colorThemeCard.filteredPresets.length === 0
                    anchors.centerIn: parent
                    spacing: 8

                    FluentIcon {
                        Layout.alignment: Qt.AlignHCenter
                        icon: "search"
                        implicitSize: 32
                        color: Looks.colors.subfg
                        opacity: 0.5
                    }

                    WText {
                        Layout.alignment: Qt.AlignHCenter
                        text: Voice.miss(Translation.tr("No themes found"), colorThemeCard.searchQuery)
                        font.pixelSize: Looks.font.pixelSize.small
                        color: Looks.colors.subfg
                    }
                }
            }
        }
    }

    // Global Style card
    WSettingsCard {
        id: globalStyleCard
        title: Translation.tr("Global Style")
        icon: "eyedropper"

        readonly property bool cardsEverywhere: (Config.options?.material?.dock?.cardStyle ?? false) && (Config.options?.material?.sidebar?.cardStyle ?? false) && (Config.options?.material?.bar?.cornerStyle === 3)

        readonly property string derivedStyle: cardsEverywhere ? "cards" : "material"
        readonly property string currentStyle: (Config.options?.material?.style?.globalStyle ?? "").length > 0 ? Config.options?.material?.style?.globalStyle ?? "material" : derivedStyle

        WSettingsSwitch {
            label: Translation.tr("Take style from Material")
            icon: "link"
            description: Translation.tr("Waffle wears Material's global style and transparency. Off: its own Fluent look.")
            checked: Looks.styleFromMaterial
            onCheckedChanged: if (checked !== Looks.styleFromMaterial) Config.setNestedValue("waffles.theming.styleFromMaterial", checked)
        }

        WSettingsDropdown {
            visible: Looks.styleFromMaterial
            label: Translation.tr("Style")
            icon: "eyedropper"
            description: globalStyleCard.currentStyle === "editorial"
                ? Translation.tr("Choose the visual language used across the shell. Editorial composition is refined in ii Settings → Themes → Style.")
                : Translation.tr("Choose the visual language used across the shell")
            currentValue: globalStyleCard.currentStyle
            options: [
                {
                    value: "material",
                    displayName: Translation.tr("Material")
                },
                {
                    value: "cards",
                    displayName: Translation.tr("Cards")
                },
                {
                    value: "aurora",
                    displayName: Translation.tr("Aurora")
                },
                {
                    value: "inir",
                    displayName: Translation.tr("Inir")
                },
                {
                    value: "angel",
                    displayName: Translation.tr("Angel")
                },
                {
                    value: "regalia",
                    displayName: Translation.tr("Regalia")
                },
                {
                    value: "zzz",
                    displayName: Translation.tr("ZZZ")
                },
                {
                    value: "cookie",
                    displayName: Translation.tr("Cookie Shapes")
                },
                {
                    value: "editorial",
                    displayName: Translation.tr("Editorial")
                }
            ]
            onSelected: newValue => {
                ThemeService.setGlobalStyle(newValue);
            }
        }
    }

    // Appearance card
    WSettingsCard {
        title: Translation.tr("Appearance")
        icon: "weather-moon"

        WSettingsDropdown {
            label: Translation.tr("Mode")
            icon: "weather-moon"
            description: Translation.tr("Light or dark color scheme")
            currentValue: Appearance.m3colors.darkmode ? "dark" : "light"
            options: [
                {
                    value: "light",
                    displayName: Translation.tr("Light")
                },
                {
                    value: "dark",
                    displayName: Translation.tr("Dark")
                }
            ]
            onSelected: newValue => {
                MaterialThemeLoader.setDarkMode(newValue === "dark");
            }
        }

        WSettingsDropdown {
            label: Translation.tr("Palette type")
            icon: "dark-theme"
            description: Translation.tr("How colors are generated from wallpaper")
            currentValue: Config.options?.appearance?.palette?.type ?? "auto"
            options: [
                {
                    value: "auto",
                    displayName: Translation.tr("Auto")
                },
                {
                    value: "scheme-content",
                    displayName: Translation.tr("Content")
                },
                {
                    value: "scheme-expressive",
                    displayName: Translation.tr("Expressive")
                },
                {
                    value: "scheme-fidelity",
                    displayName: Translation.tr("Fidelity")
                },
                {
                    value: "scheme-fruit-salad",
                    displayName: Translation.tr("Fruit Salad")
                },
                {
                    value: "scheme-monochrome",
                    displayName: Translation.tr("Monochrome")
                },
                {
                    value: "scheme-neutral",
                    displayName: Translation.tr("Neutral")
                },
                {
                    value: "scheme-rainbow",
                    displayName: Translation.tr("Rainbow")
                },
                {
                    value: "scheme-tonal-spot",
                    displayName: Translation.tr("Tonal Spot")
                }
            ]
            onSelected: newValue => {
                Config.setNestedValue("appearance.palette.type", newValue);
                if (!ThemeService.isAutoTheme) {
                    // Manual preset: apply variant immediately via MaterialThemeLoader
                    const hex = MaterialThemeLoader.colorToHex(Appearance.m3colors.m3primary);
                    const mode = Appearance.m3colors.darkmode ? "dark" : "light";
                    MaterialThemeLoader.applySchemeVariant(hex, newValue, mode);
                }
            // Auto theme: ThemeService detects palette type change in
            // liveRegenSignature and runs regenerateAutoTheme automatically.
            }
        }

        WSettingsSwitch {
            label: Translation.tr("Invert colors (complementary)")
            icon: "dark-theme"
            description: Translation.tr("Rotate every color 180° on the color wheel. Shell-only: external apps keep their original colors.")
            checked: Config.options?.appearance?.colorInvert ?? false
            onCheckedChanged: Config.setNestedValue("appearance.colorInvert", checked)
        }
    }

    // Theming options
    WSettingsCard {
        title: Translation.tr("Theming")
        icon: "eyedropper"

        WSettingsSwitch {
            label: Translation.tr("Use Material colors")
            icon: "color"
            description: Translation.tr("Apply Material color scheme instead of Windows 11 grey")
            enabled: !Looks.editorialEverywhere
            checked: Looks.editorialEverywhere || (Config.options?.waffles?.theming?.useMaterialColors ?? false)
            onCheckedChanged: {
                if (!Looks.editorialEverywhere) Config.setNestedValue("waffles.theming.useMaterialColors", checked)
            }
        }

        WSettingsSlider {
            label: Translation.tr("Color strength")
            icon: "eyedropper"
            description: Translation.tr("Controls how vivid wallpaper-derived accent colors are")
            from: 60
            to: 180
            stepSize: 5
            suffix: "%"
            value: Math.round((Config.options?.appearance?.wallpaperTheming?.colorStrength ?? 1.0) * 100)
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready)
                    return;
                Config.setNestedValue("appearance.wallpaperTheming.colorStrength", value / 100);
                colorStrengthRegenTimer.restart();
            }
        }

        Timer {
            id: colorStrengthRegenTimer
            interval: 300
            onTriggered: {
                if (ThemeService.isAutoTheme)
                    ThemeService.regenerateAutoTheme();
            }
        }

        WSettingsSwitch {
            label: Translation.tr("Soften colors")
            icon: "paint-bucket"
            description: Translation.tr("Subtly soften theme colors for a more natural look")
            checked: Config.options?.appearance?.softenColors ?? true
            onCheckedChanged: {
                Config.setNestedValue("appearance.softenColors", checked);
                ThemeService.regenerateAutoTheme();
            }
        }

        WSettingsSwitch {
            label: Translation.tr("Auto light/dark from wallpaper")
            icon: "auto"
            description: Translation.tr("Pick the light or dark scheme from each wallpaper's brightness so text stays readable")
            checked: Config.options?.appearance?.wallpaperTheming?.autoDarkLightMode ?? false
            onCheckedChanged: {
                Config.setNestedValue("appearance.wallpaperTheming.autoDarkLightMode", checked);
                ThemeService.regenerateAutoTheme();
            }
        }

        WSettingsSwitch {
            label: Translation.tr("Vesktop/Discord theming")
            icon: "people"
            description: Translation.tr("Generate Discord theme from wallpaper colors")
            checked: Config.options?.appearance?.wallpaperTheming?.enableVesktop ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableVesktop", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Spotify theming")
            icon: "music-note-2"
            description: Translation.tr("Generate and apply Spicetify theme from wallpaper colors")
            checked: Config.options?.appearance?.wallpaperTheming?.enableSpicetify ?? true
            onCheckedChanged: {
                Config.setNestedValue("appearance.wallpaperTheming.enableSpicetify", checked)
                Quickshell.execDetached([Directories.wallpaperSwitchScriptPath, "--noswitch"])
            }
        }

        WSettingsDropdown {
            visible: Config.options?.appearance?.wallpaperTheming?.enableSpicetify ?? true
            label: Translation.tr("Spotify theme")
            icon: "terminal"
            description: Translation.tr("Choose the Spicetify layout while keeping iNiR wallpaper colors")
            currentValue: Config.options?.appearance?.wallpaperTheming?.spicetifyTheme ?? "Inir"
            options: [
                { value: "Inir", displayName: "iNiR" },
                { value: "InirTUI", displayName: Translation.tr("Text (TUI)") }
            ]
            onSelected: newValue => {
                Config.setNestedValue("appearance.wallpaperTheming.spicetifyTheme", newValue)
                Quickshell.execDetached([Directories.wallpaperSwitchScriptPath, "--noswitch"])
            }
        }

        WSettingsSwitch {
            label: Translation.tr("Steam theming")
            icon: "gamepad"
            description: Translation.tr("Apply Material You colors to Steam via Millennium Material-Theme")
            checked: Config.options?.appearance?.wallpaperTheming?.enableSteam ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableSteam", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Pear Desktop (YouTube Music)")
            icon: "music-note-2"
            description: Translation.tr("Apply Material You colors to YouTube Music Desktop App")
            checked: Config.options?.appearance?.wallpaperTheming?.enablePearDesktop ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enablePearDesktop", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("LiMusic")
            icon: "headphones"
            description: Translation.tr("LiMusic follows your wallpaper colours, from the next time it opens")
            checked: Config.options?.appearance?.wallpaperTheming?.enableLimusic ?? false
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableLimusic", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Claude Code")
            icon: "terminal"
            description: Translation.tr("Adds iNiR themes to Claude Code's theme list: two follow your wallpaper, two keep a fixed Monokai palette")
            checked: Config.options?.appearance?.wallpaperTheming?.enableClaudeCode ?? false
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableClaudeCode", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Zed editor")
            icon: "flash-on"
            description: Translation.tr("Generate Zed editor theme from wallpaper colors")
            checked: Config.options?.appearance?.wallpaperTheming?.enableZed ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableZed", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("VSCode editors")
            icon: "window-console"
            description: Translation.tr("Generate theme for VSCode and its forks from wallpaper colors")
            checked: Config.options?.appearance?.wallpaperTheming?.enableVSCode ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableVSCode", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Chrome / Chromium")
            icon: "globe-search"
            description: Translation.tr("Apply wallpaper-derived colors to Chrome and Chromium browser")
            checked: Config.options?.appearance?.wallpaperTheming?.enableChrome ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableChrome", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Firefox")
            icon: "globe-shield"
            description: Translation.tr("Follows the wallpaper from its next launch; LibreWolf, Floorp, Waterfox and Zen too.")
            checked: Config.options?.appearance?.wallpaperTheming?.enableFirefox ?? true
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableFirefox", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("OpenCode")
            icon: "wand"
            description: Translation.tr("Apply wallpaper-derived theme to OpenCode AI editor")
            checked: Config.options?.appearance?.wallpaperTheming?.enableOpenCode ?? false
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableOpenCode", checked)
        }

        WSettingsSwitch {
            label: Translation.tr("Neovim / LazyVim")
            icon: "text-font"
            description: Translation.tr("Generate inir.nvim theme plugin for Neovim/LazyVim from wallpaper colors (writes to ~/.config/nvim/lua/plugins/neovim.lua)")
            checked: Config.options?.appearance?.wallpaperTheming?.enableNeovim ?? false
            onCheckedChanged: Config.setNestedValue("appearance.wallpaperTheming.enableNeovim", checked)
        }

        WSettingsSwitch {
            id: waffleCavaSwitch
            label: Translation.tr("Theme standalone Cava")
            icon: "music-note-2"
            description: Translation.tr("Manage ~/.config/cava/config; internal visualizers always use the options below")
            checked: Config.options?.appearance?.wallpaperTheming?.enableCava ?? true
            onCheckedChanged: root.setCavaValue(
                "appearance.wallpaperTheming.enableCava", checked, true)
        }

        WSettingsSwitch {
            visible: Looks.styleFromMaterial
            label: Translation.tr("Transparency")
            icon: "eye"
            description: Translation.tr("Enable transparent UI elements")
            checked: Config.options?.material?.style?.transparency?.enable ?? false
            onCheckedChanged: Config.setNestedValue("material.style.transparency.enable", checked)
        }
    }

    // Cava visualizer options
    WSettingsCard {
        title: Translation.tr("Cava Options")
        icon: "music-note-2"

        WSettingsDropdown {
            label: Translation.tr("Color source")
            icon: "color"
            description: Translation.tr("Live palette for internal visualizers and standalone cava")
            options: [
                { displayName: Translation.tr("Theme palette"), value: "theme" },
                { displayName: Translation.tr("Vibrant (saturated)"), value: "vibrant" },
                { displayName: Translation.tr("Album cover"), value: "cover" },
            ]
            currentValue: Config.options?.appearance?.cava?.colorSource ?? "theme"
            onSelected: value => root.setCavaValue(
                "appearance.cava.colorSource", value, true)
        }

        RowLayout {
            Layout.fillWidth: true
            spacing: Looks.dp(4)

            Repeater {
                model: CavaTheme.visualizerColors

                Rectangle {
                    required property var modelData
                    Layout.fillWidth: true
                    Layout.preferredHeight: Looks.dp(8)
                    radius: Looks.radius.small
                    color: modelData
                }
            }
        }

        WSettingsSpinBox {
            label: Translation.tr("Gradient colors")
            icon: "paint-bucket"
            description: Translation.tr("One solid color or up to eight gradient stops")
            from: 1
            to: 8
            stepSize: 1
            value: Config.options?.appearance?.cava?.gradientCount ?? 8
            onValueChanged: root.setCavaValue(
                "appearance.cava.gradientCount", value, true)
        }

        WSettingsSlider {
            label: Translation.tr("Sensitivity")
            icon: "speaker"
            description: Translation.tr("Audio sensitivity (higher = more reactive)")
            from: 10
            to: 500
            stepSize: 10
            value: Config.options?.appearance?.cava?.sensitivity ?? 100
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready) return;
                root.setCavaValue("appearance.cava.sensitivity", value, true)
            }
        }

        WSettingsSpinBox {
            label: Translation.tr("Bars")
            icon: "device-eq"
            description: Translation.tr("Number of frequency data points (0 = auto)")
            from: 0
            to: 200
            stepSize: 8
            value: Config.options?.appearance?.cava?.bars ?? 0
            onValueChanged: root.setCavaValue(
                "appearance.cava.bars", value, true)
        }

        WSettingsSpinBox {
            label: Translation.tr("Framerate")
            icon: "video"
            description: Translation.tr("Target refresh rate")
            from: 30
            to: 165
            stepSize: 5
            value: Config.options?.appearance?.cava?.framerate ?? 60
            onValueChanged: root.setCavaValue(
                "appearance.cava.framerate", value, true)
        }

        WSettingsSwitch {
            label: Translation.tr("Stereo")
            icon: "headphones"
            description: Translation.tr("Split visualizer into left/right channels")
            checked: Config.options?.appearance?.cava?.stereo ?? true
            onCheckedChanged: root.setCavaValue(
                "appearance.cava.stereo", checked, true)
        }

        WSettingsSpinBox {
            label: Translation.tr("Wave opacity")
            icon: "eye"
            description: Translation.tr("Fill opacity for shared wave visualizers")
            from: 5
            to: 100
            stepSize: 5
            value: Config.options?.appearance?.cava?.waveOpacity ?? 30
            onValueChanged: root.setCavaValue(
                "appearance.cava.waveOpacity", value, false)
        }

        WSettingsTextField {
            label: Translation.tr("Blocked visualizer apps")
            icon: "music-note-2"
            description: Translation.tr("Comma-separated playback apps to exclude from visualizers. Empty keeps automatic active-player selection.")
            placeholderText: Translation.tr("Spotify, ncspot, ytmusic")
            text: (Config.options?.appearance?.cava?.blockedApps ?? []).join(", ")
            onEditingFinished: newText => {
                const seen = ({})
                const apps = newText.split(",").map(value => value.trim()).filter(value => {
                    const key = value.toLowerCase()
                    if (key.length === 0 || seen[key]) return false
                    seen[key] = true
                    return true
                })
                Config.setNestedValue("appearance.cava.blockedApps", apps)
                Config.flushWrites()
            }
        }

        WSettingsButton {
            label: Translation.tr("Reset to defaults")
            icon: "arrow-reset"
            description: Translation.tr("Restore all cava settings to defaults")
            buttonText: Translation.tr("Reset")
            buttonIcon: "arrow-reset"
            onButtonClicked: root.resetCavaDefaults()
        }
    }

    // Terminal color adjustment
    WSettingsCard {
        title: Translation.tr("Terminal Colors")
        icon: "window-console"

        // Debounce timer for terminal color regeneration
        Timer {
            id: terminalColorDebounce
            interval: 300
            onTriggered: ThemeService.regenerateAutoTheme()
        }

        WSettingsSlider {
            id: termSaturationSlider
            label: Translation.tr("Color saturation")
            icon: "dark-theme"
            description: Translation.tr("How vivid semantic terminal colors are")
            from: 10
            to: 80
            stepSize: 5
            suffix: "%"
            value: Math.round((Config.options?.appearance?.wallpaperTheming?.terminalColorAdjustments?.saturation ?? 0.65) * 100)
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready)
                    return;
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.saturation", value / 100);
                terminalColorDebounce.restart();
            }
        }

        WSettingsSlider {
            id: termBrightnessSlider
            label: Translation.tr("Color brightness")
            icon: "brightness-high"
            description: Translation.tr("Lightness of terminal foreground colors")
            from: 35
            to: 75
            stepSize: 5
            suffix: "%"
            value: Math.round((Config.options?.appearance?.wallpaperTheming?.terminalColorAdjustments?.brightness ?? 0.60) * 100)
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready)
                    return;
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.brightness", value / 100);
                terminalColorDebounce.restart();
            }
        }

        WSettingsSlider {
            id: termHarmonySlider
            label: Translation.tr("Theme harmony")
            icon: "color"
            description: Translation.tr("Shifts terminal hues towards the theme's primary color")
            from: 0
            to: 100
            stepSize: 5
            suffix: "%"
            value: Math.round((Config.options?.appearance?.wallpaperTheming?.terminalColorAdjustments?.harmony ?? 0.40) * 100)
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready)
                    return;
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.harmony", value / 100);
                terminalColorDebounce.restart();
            }
        }

        WSettingsSlider {
            id: termBgBrightnessSlider
            label: Translation.tr("Background brightness")
            icon: "border-none"
            description: Translation.tr("Terminal background darkness — lower is darker, 50% matches shell surfaces")
            from: 10
            to: 90
            stepSize: 5
            suffix: "%"
            value: Math.round((Config.options?.appearance?.wallpaperTheming?.terminalColorAdjustments?.backgroundBrightness ?? 0.50) * 100)
            property bool _ready: false
            Component.onCompleted: _ready = true
            onMoved: {
                if (!_ready)
                    return;
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.backgroundBrightness", value / 100);
                terminalColorDebounce.restart();
            }
        }

        WSettingsButton {
            label: Translation.tr("Reset to defaults")
            icon: "arrow-reset"
            description: Translation.tr("Restore all terminal color settings to defaults")
            buttonText: Translation.tr("Reset")
            buttonIcon: "arrow-reset"
            onButtonClicked: {
                termSaturationSlider.value = 65;
                termBrightnessSlider.value = 60;
                termHarmonySlider.value = 40;
                termBgBrightnessSlider.value = 50;
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.saturation", 0.65);
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.brightness", 0.60);
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.harmony", 0.40);
                Config.setNestedValue("appearance.wallpaperTheming.terminalColorAdjustments.backgroundBrightness", 0.50);
                terminalColorDebounce.restart();
            }
        }
    }

    // Waffle Typography card
    WSettingsCard {
        title: Translation.tr("Waffle Typography")
        icon: "auto"

        WText {
            Layout.fillWidth: true
            Layout.leftMargin: 0
            Layout.rightMargin: 0
            text: Translation.tr("These settings only affect the Windows 11 (Waffle) style panels.")
            font.pixelSize: Looks.font.pixelSize.small
            color: Looks.colors.subfg
            wrapMode: Text.WordWrap
        }

        WSettingsDropdown {
            label: Translation.tr("Font family")
            icon: "auto"
            description: Translation.tr("Font used in Waffle panels")
            currentValue: Config.options?.waffles?.theming?.font?.family ?? "Noto Sans"
            options: [
                {
                    value: "Segoe UI Variable",
                    displayName: "Segoe UI"
                },
                {
                    value: "Inter",
                    displayName: "Inter"
                },
                {
                    value: "Roboto",
                    displayName: "Roboto"
                },
                {
                    value: "Noto Sans",
                    displayName: "Noto Sans"
                },
                {
                    value: "Ubuntu",
                    displayName: "Ubuntu"
                }
            ]
            onSelected: newValue => Config.setNestedValue("waffles.theming.font.family", newValue)
        }

        WSettingsSwitch {
            label: Translation.tr("Apps use this font")
            icon: "apps"
            description: Translation.tr("Your apps' text follows the font the shell shows.")
            checked: Config.options?.appearance?.typography?.syncWithSystem ?? true
            onCheckedChanged: Config.setNestedValue("appearance.typography.syncWithSystem", checked)
        }

        WSettingsSpinBox {
            label: Translation.tr("Font scale")
            icon: "auto"
            description: Translation.tr("Scale all text in Waffle panels")
            suffix: "%"
            from: 80
            to: 150
            stepSize: 5
            value: Math.round((Config.options?.waffles?.theming?.font?.scale ?? 1.0) * 100)
            onValueChanged: Config.setNestedValue("waffles.theming.font.scale", value / 100.0)
        }
    }
}
