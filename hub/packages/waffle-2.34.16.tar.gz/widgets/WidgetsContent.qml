pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import Quickshell.Services.Mpris
import qs
import qs.services
import qs.modules.common
import qs.modules.common.functions
import qs.modules.common.widgets
import qs.modules.waffle.looks
import qs.modules.waffle.state

WBarAttachedPanelContent {
    id: root

    revealFromSides: true
    revealFromLeft: true

    property QtObject resourceMonitor: ResourceUsageMonitor { active: WaffleState.widgetsOpen }

    readonly property bool barAtBottom: Config.options?.waffles?.bar?.bottom ?? false
    readonly property var quickActionDefinitions: [
        { id: "files", icon: "folder", label: Translation.tr("Files"), show: Config.options?.waffles?.widgetsPanel?.showFiles ?? true },
        { id: "terminal", icon: "terminal", label: Translation.tr("Terminal"), show: Config.options?.waffles?.widgetsPanel?.showTerminal ?? true },
        { id: "settings", icon: "settings", label: Translation.tr("Settings"), show: Config.options?.waffles?.widgetsPanel?.showSettings ?? true },
        { id: "wallpaper", icon: "image", label: Translation.tr("Wallpaper"), show: Config.options?.waffles?.widgetsPanel?.showWallpaper ?? true },
        { id: "screenshot", icon: "screenshot", label: Translation.tr("Screenshot"), show: Config.options?.waffles?.widgetsPanel?.showScreenshot ?? true },
        { id: "screenRecord", icon: "record", label: RecorderStatus.isRecording ? Translation.tr("Stop") : Translation.tr("Record"), show: Config.options?.waffles?.widgetsPanel?.showScreenRecord ?? true },
        { id: "session", icon: "power", label: Translation.tr("Session"), show: Config.options?.waffles?.widgetsPanel?.showSession ?? true }
    ]
    readonly property var enabledQuickActions: quickActionDefinitions.filter(action => action.show)

    function runQuickAction(actionId: string): void {
        switch (actionId) {
        case "files":
            ShellExec.execDetachedArgs(["nautilus"], "Launch Files")
            break
        case "terminal":
            AppLauncher.launch("terminal")
            break
        case "settings":
            ShellExec.execDetachedArgs([Quickshell.shellPath("scripts/inir"), "settings"], "Open iNiR settings")
            break
        case "wallpaper": {
            const useMain = Config.options?.waffles?.background?.useMainWallpaper ?? true
            Config.setNestedValue("wallpaperSelector.selectionTarget", useMain ? "main" : "waffle")
            Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "wallpaperSelector", "toggle"])
            break
        }
        case "screenshot":
            // Resolve action/mode explicitly — a bare regionSelectorOpen=true
            // inherits whatever a previous record/lens use left behind.
            GlobalStates.openRegionScreenshot()
            break
        case "screenRecord":
            GlobalActions.runById("screen-record", "")
            break
        case "session":
            GlobalStates.sessionOpen = true
            break
        default:
            return
        }

        WaffleState.widgetsOpen = false
    }

    contentItem: ColumnLayout {
        anchors {
            left: parent.left
            right: parent.right
            top: root.barAtBottom ? undefined : parent.top
            bottom: root.barAtBottom ? parent.bottom : undefined
            margins: root.visualMargin
            bottomMargin: 0
        }
        spacing: Looks.dp(12)

        WPane {
            Layout.fillWidth: true
            screenX: root.panelScreenX + root.visualMargin * 2
            screenY: root.panelScreenY + root.visualMargin * 2
            screenWidth: root._screenW
            screenHeight: root._screenH
            contentItem: WidgetsPaneContent {}
        }
    }

    component WidgetsPaneContent: Rectangle {
        id: paneContent
        implicitWidth: Looks.dp(380)
        implicitHeight: Math.min(Math.max(contentColumn.implicitHeight, 80), root._screenH - 80)
        color: Looks.colors.bgPanelBody
        clip: true

        Flickable {
            anchors.fill: parent
            contentHeight: contentColumn.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds

        ColumnLayout {
            id: contentColumn
            width: parent.width
            spacing: 0

            // Header
            BodyRectangle {
                Layout.fillWidth: true
                implicitHeight: Looks.dp(56)

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: Looks.dp(16)
                    anchors.rightMargin: Looks.dp(16)

                    WText {
                        text: Translation.tr("Widgets")
                        font.pixelSize: Looks.font.pixelSize.larger
                        font.weight: Font.DemiBold
                    }

                    Item { Layout.fillWidth: true }

                    WBorderlessButton {
                        implicitWidth: Looks.dp(32)
                        implicitHeight: Looks.dp(32)
                        contentItem: FluentIcon {
                            anchors.centerIn: parent
                            icon: "settings"
                            implicitSize: Looks.dp(16)
                        }
                        onClicked: {
                            Quickshell.execDetached([Quickshell.shellPath("scripts/inir"), "settings"])
                            WaffleState.widgetsOpen = false
                        }
                    }
                }
            }

            WPanelSeparator { visible: Config.options?.waffles?.widgetsPanel?.showDateTime ?? true }

            // Date & Time widget
            BodyRectangle {
                Layout.fillWidth: true
                implicitHeight: dateTimeContent.implicitHeight + Looks.dp(36)
                visible: Config.options?.waffles?.widgetsPanel?.showDateTime ?? true

                RowLayout {
                    id: dateTimeContent
                    anchors.fill: parent
                    anchors.margins: Looks.dp(18)
                    spacing: Looks.dp(16)

                    ColumnLayout {
                        spacing: Looks.dp(4)
                        WText {
                            text: DateTime.time
                            font.pixelSize: Looks.dp(46)
                            font.weight: Font.DemiBold
                        }
                        WText {
                            text: Qt.locale().toString(DateTime.clock.date, "dddd, MMMM d")
                            font.pixelSize: Looks.font.pixelSize.normal
                            color: Looks.colors.fg1
                        }
                    }

                    Item { Layout.fillWidth: true }

                    ColumnLayout {
                        Layout.alignment: Qt.AlignVCenter
                        spacing: Looks.dp(6)
                        WText {
                            text: Translation.tr("Uptime")
                            font.pixelSize: Looks.font.pixelSize.tiny
                            color: Looks.colors.subfg
                            font.weight: Font.Medium
                        }
                        WText {
                            text: DateTime.uptime || "--"
                            font.pixelSize: Looks.font.pixelSize.large
                            font.weight: Font.DemiBold
                        }
                    }
                }
            }

            WPanelSeparator { visible: (Config.options?.waffles?.widgetsPanel?.showWeather ?? true) && Weather.data.temp !== undefined && Weather.data.temp !== "" }

            // Weather widget
            BodyRectangle {
                Layout.fillWidth: true
                implicitHeight: weatherContent.implicitHeight + Looks.dp(32)
                visible: (Config.options?.waffles?.widgetsPanel?.showWeather ?? true) && Weather.data.temp !== undefined && Weather.data.temp !== ""

                ColumnLayout {
                    id: weatherContent
                    anchors.fill: parent
                    anchors.margins: Looks.dp(16)
                    spacing: Looks.dp(12)

                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(12)

                        FluentIcon {
                            icon: Weather.isNightNow() ? "weather-moon" : "weather-sunny"
                            implicitSize: Looks.dp(48)
                            color: Weather.isNightNow() ? Looks.colors.accent : Looks.colors.fg
                        }

                        ColumnLayout {
                            spacing: Looks.dp(2)
                            WText {
                                text: Weather.data.temp || "--°"
                                font.pixelSize: Looks.dp(32)
                                font.weight: Font.DemiBold
                            }
                            WText {
                                text: Weather.showVisibleCity ? Weather.visibleCity : Translation.tr("Weather")
                                color: Looks.colors.fg1
                            }
                        }

                        Item { Layout.fillWidth: true }

                        ColumnLayout {
                            spacing: Looks.dp(2)
                            WText {
                                text: Translation.tr("Feels ") + (Weather.data.tempFeelsLike || "--")
                                font.pixelSize: Looks.font.pixelSize.small
                                color: Looks.colors.fg1
                            }
                            WText {
                                text: Weather.data.humidity || ""
                                font.pixelSize: Looks.font.pixelSize.small
                                color: Looks.colors.fg1
                            }
                        }
                    }

                    // Detail stat grid
                    GridLayout {
                        Layout.fillWidth: true
                        columns: 4
                        rowSpacing: Looks.dp(12)
                        columnSpacing: Looks.dp(12)

                        WeatherStat { statLabel: Translation.tr("Wind"); statValue: (Weather.data.wind + " " + Weather.data.windDir).trim() }
                        WeatherStat { statLabel: Translation.tr("UV"); statValue: String(Weather.data.uv); visible: String(Weather.data.uv) !== "0" && String(Weather.data.uv) !== "" }
                        WeatherStat { statLabel: Translation.tr("Pressure"); statValue: Weather.data.press }
                        WeatherStat { statLabel: Translation.tr("Visibility"); statValue: Weather.data.visib }
                        WeatherStat { statLabel: Translation.tr("Precip"); statValue: Weather.data.precip }
                        WeatherStat { statLabel: Translation.tr("Sunrise"); statValue: Weather.data.sunrise }
                        WeatherStat { statLabel: Translation.tr("Sunset"); statValue: Weather.data.sunset }
                        WeatherStat { statLabel: Network.online ? Translation.tr("Refreshed") : Translation.tr("Offline, from"); statValue: Weather.updatedLabel }
                    }

                    // Daily forecast with temperature-range bars
                    ColumnLayout {
                        id: waffleForecast
                        Layout.fillWidth: true
                        visible: (Weather.data.forecast ?? []).length > 1
                        spacing: Looks.dp(3)
                        readonly property var fc: Weather.data.forecast ?? []
                        readonly property real wMin: { let m = Infinity; for (const d of fc) if (!isNaN(d.loVal) && d.loVal < m) m = d.loVal; return m === Infinity ? 0 : m }
                        readonly property real wMax: { let m = -Infinity; for (const d of fc) if (!isNaN(d.hiVal) && d.hiVal > m) m = d.hiVal; return m === -Infinity ? 1 : m }

                        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Looks.colors.bg2Border; Layout.bottomMargin: Looks.dp(4) }

                        Repeater {
                            model: waffleForecast.fc
                            delegate: RowLayout {
                                required property var modelData
                                required property int index
                                Layout.fillWidth: true
                                spacing: Looks.dp(10)
                                WText {
                                    Layout.preferredWidth: Looks.dp(38)
                                    text: modelData.dayName
                                    font.pixelSize: Looks.font.pixelSize.small
                                    color: index === 0 ? Looks.colors.fg : Looks.colors.fg1
                                }
                                WText {
                                    Layout.preferredWidth: Looks.dp(34)
                                    horizontalAlignment: Text.AlignRight
                                    text: modelData.lo
                                    font.pixelSize: Looks.font.pixelSize.small
                                    color: Looks.colors.fg1
                                }
                                Rectangle {
                                    Layout.fillWidth: true
                                    Layout.alignment: Qt.AlignVCenter
                                    implicitHeight: Looks.dp(4); radius: Looks.dp(2)
                                    color: Looks.colors.bg1Base
                                    readonly property real span: Math.max(1, waffleForecast.wMax - waffleForecast.wMin)
                                    readonly property real x0: isNaN(modelData.loVal) ? 0 : (modelData.loVal - waffleForecast.wMin) / span
                                    readonly property real x1: isNaN(modelData.hiVal) ? 1 : (modelData.hiVal - waffleForecast.wMin) / span
                                    Rectangle {
                                        x: parent.width * parent.x0
                                        width: Math.max(parent.height, parent.width * (parent.x1 - parent.x0))
                                        height: parent.height; radius: parent.radius
                                        color: Looks.colors.accent
                                    }
                                }
                                WText {
                                    Layout.preferredWidth: Looks.dp(34)
                                    text: modelData.hi
                                    font.pixelSize: Looks.font.pixelSize.small
                                    font.weight: Font.Medium
                                }
                            }
                        }
                    }

                    // Moon phase
                    RowLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(10)
                        FluentIcon {
                            icon: "weather-moon"
                            implicitSize: Looks.dp(18)
                            color: Looks.colors.accent
                        }
                        WText {
                            text: Weather.moonPhaseName
                            font.pixelSize: Looks.font.pixelSize.small
                            font.weight: Font.Medium
                        }
                        Item { Layout.fillWidth: true }
                        WText {
                            text: Translation.tr("%1% lit").arg(Math.round(Weather.moonIllumination * 100))
                            font.pixelSize: Looks.font.pixelSize.small
                            color: Looks.colors.fg1
                        }
                    }

                    // Air quality (only when available)
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(8)
                        visible: Weather.airQuality.available

                        Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: Looks.colors.bg2Border }

                        RowLayout {
                            Layout.fillWidth: true
                            WText {
                                text: Translation.tr("Air Quality")
                                font.pixelSize: Looks.font.pixelSize.small
                                font.weight: Font.Medium
                            }
                            Item { Layout.fillWidth: true }
                            WText {
                                text: Weather.airQuality.aqi + " " + Weather.airQuality.scale + " · " + Weather.airQuality.label
                                font.pixelSize: Looks.font.pixelSize.small
                                color: Looks.colors.accent
                                font.weight: Font.Medium
                            }
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            spacing: Looks.dp(12)
                            WeatherStat { statLabel: "PM2.5"; statValue: Weather.airQuality.pm25 }
                            WeatherStat { statLabel: "PM10"; statValue: Weather.airQuality.pm10 }
                            WeatherStat { statLabel: Translation.tr("Ozone"); statValue: Weather.airQuality.ozone }
                        }
                    }
                }
            }

            WPanelSeparator { visible: Config.options?.waffles?.widgetsPanel?.showSystem ?? true }

            // System Resources widget
            BodyRectangle {
                Layout.fillWidth: true
                implicitHeight: sysContent.implicitHeight + Looks.dp(36)
                visible: Config.options?.waffles?.widgetsPanel?.showSystem ?? true

                ColumnLayout {
                    id: sysContent
                    anchors.fill: parent
                    anchors.margins: Looks.dp(18)
                    spacing: Looks.dp(14)

                    RowLayout {
                        Layout.fillWidth: true
                        WText {
                            text: Translation.tr("System")
                            font.pixelSize: Looks.font.pixelSize.large
                            font.weight: Font.DemiBold
                        }
                        Item { Layout.fillWidth: true }
                        WBorderlessButton {
                            implicitWidth: Looks.dp(28)
                            implicitHeight: Looks.dp(28)
                            contentItem: FluentIcon { anchors.centerIn: parent; icon: "open"; implicitSize: Looks.dp(14) }
                            onClicked: {
                                Session.launchTaskManager()
                                WaffleState.widgetsOpen = false
                            }
                        }
                    }

                    // CPU
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(6)
                        RowLayout {
                            Layout.fillWidth: true
                            WText { text: Translation.tr("CPU"); font.pixelSize: Looks.font.pixelSize.small; font.weight: Font.Medium }
                            Item { Layout.fillWidth: true }
                            WText {
                                text: Math.round(ResourceUsage.cpuUsage * 100) + "%"
                                font.pixelSize: Looks.font.pixelSize.small
                                font.weight: Font.DemiBold
                                color: ResourceUsage.cpuUsage > 0.8 ? Looks.colors.danger : Looks.colors.fg1
                            }
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: Looks.dp(8); radius: 4; color: Looks.colors.bg1Base
                            Rectangle {
                                width: parent.width * Math.min(1, ResourceUsage.cpuUsage); height: parent.height; radius: 4
                                color: ResourceUsage.cpuUsage > 0.8 ? Looks.colors.danger : Looks.colors.accent
                                Behavior on width {
                                    animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                                }
                            }
                        }
                    }

                    // Memory
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(6)
                        RowLayout {
                            Layout.fillWidth: true
                            WText { text: Translation.tr("RAM"); font.pixelSize: Looks.font.pixelSize.small; font.weight: Font.Medium }
                            Item { Layout.fillWidth: true }
                            WText {
                                readonly property string used: (ResourceUsage.memoryUsed / (1024 * 1024)).toFixed(1)
                                readonly property string total: ResourceUsage.maxAvailableMemoryString
                                text: used + " / " + total
                                font.pixelSize: Looks.font.pixelSize.small
                                font.weight: Font.DemiBold
                                color: ResourceUsage.memoryUsedPercentage > 0.9 ? Looks.colors.danger : Looks.colors.fg1
                            }
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: Looks.dp(8); radius: 4; color: Looks.colors.bg1Base
                            Rectangle {
                                width: parent.width * Math.min(1, ResourceUsage.memoryUsedPercentage); height: parent.height; radius: 4
                                color: ResourceUsage.memoryUsedPercentage > 0.9 ? Looks.colors.danger : Looks.colors.accent
                                Behavior on width {
                                    animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                                }
                            }
                        }
                    }

                    // Swap (if available)
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: Looks.dp(6)
                        visible: ResourceUsage.swapTotal > 1
                        RowLayout {
                            Layout.fillWidth: true
                            WText { text: Translation.tr("Swap"); font.pixelSize: Looks.font.pixelSize.small; font.weight: Font.Medium }
                            Item { Layout.fillWidth: true }
                            WText {
                                readonly property string used: (ResourceUsage.swapUsed / (1024 * 1024)).toFixed(1)
                                readonly property string total: ResourceUsage.maxAvailableSwapString
                                text: used + " / " + total
                                font.pixelSize: Looks.font.pixelSize.small
                                font.weight: Font.DemiBold
                                color: ResourceUsage.swapUsedPercentage > 0.8 ? Looks.colors.danger : Looks.colors.fg1
                            }
                        }
                        Rectangle {
                            Layout.fillWidth: true; height: Looks.dp(8); radius: 4; color: Looks.colors.bg1Base
                            Rectangle {
                                width: parent.width * Math.min(1, ResourceUsage.swapUsedPercentage); height: parent.height; radius: 4
                                color: ResourceUsage.swapUsedPercentage > 0.8 ? Looks.colors.danger : Looks.colors.accent
                                Behavior on width {
                                    animation: NumberAnimation { duration: Looks.transition.enabled ? Looks.transition.duration.medium : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard }
                                }
                            }
                        }
                    }
                }
            }

            WPanelSeparator {
                opacity: ((Config.options?.waffles?.widgetsPanel?.showMedia ?? true) && MprisController.activePlayer !== null) ? 1 : 0
                visible: opacity > 0
                Behavior on opacity { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveFast.duration; easing.type: Easing.OutCubic } }
            }

            // Media widget (if playing)
            BodyRectangle {
                id: mediaWidget
                Layout.fillWidth: true
                implicitHeight: ((Config.options?.waffles?.widgetsPanel?.showMedia ?? true) && MprisController.activePlayer !== null) ? mediaContent.implicitHeight : 0
                visible: implicitHeight > 0
                Behavior on implicitHeight { enabled: Appearance.animationsEnabled; NumberAnimation { duration: Appearance.animation.elementMoveEnter.duration; easing.type: Appearance.animation.elementMoveEnter.type; easing.bezierCurve: Appearance.animation.elementMoveEnter.bezierCurve } }
                clip: true
                color: "transparent"

                // Volume feedback overlay
                Rectangle {
                    id: mediaVolumeOverlay
                    anchors.centerIn: parent
                    width: Looks.dp(80)
                    height: Looks.dp(80)
                    radius: Looks.radius.medium
                    color: ColorUtils.transparentize(Looks.colors.bg0, 0.15)
                    opacity: 0
                    visible: opacity > 0
                    z: 100

                    Behavior on opacity {
                        NumberAnimation {
                            duration: Looks.transition.enabled ? Looks.transition.duration.normal : 0
                            easing.type: Easing.BezierSpline
                            easing.bezierCurve: Looks.transition.easing.bezierCurve.standard
                        }
                    }

                    ColumnLayout {
                        anchors.centerIn: parent
                        spacing: Looks.dp(4)

                        FluentIcon {
                            Layout.alignment: Qt.AlignHCenter
                            icon: (MprisController.activePlayer?.volume ?? 0) > 0 ? "speaker" : "speaker-mute"
                            implicitSize: Looks.dp(24)
                        }

                        WText {
                            Layout.alignment: Qt.AlignHCenter
                            text: Math.round((MprisController.activePlayer?.volume ?? 0) * 100) + "%"
                            font.pixelSize: Looks.font.pixelSize.normal
                            font.weight: Font.DemiBold
                        }
                    }

                    Timer {
                        id: mediaVolumeHideTimer
                        interval: 1000
                        onTriggered: mediaVolumeOverlay.opacity = 0
                    }
                }

                // Scroll to change player volume
                MouseArea {
                    anchors.fill: parent
                    acceptedButtons: Qt.NoButton
                    onWheel: wheel => {
                        if (!MprisController.canChangeVolume) return
                        const step = 0.05
                        const current = MprisController.getVolume()
                        if (wheel.angleDelta.y > 0)
                            MprisController.setVolume(Math.min(1, current + step))
                        else if (wheel.angleDelta.y < 0)
                            MprisController.setVolume(Math.max(0, current - step))

                        // Show volume feedback
                        mediaVolumeOverlay.opacity = 1
                        mediaVolumeHideTimer.restart()
                    }
                }

                Rectangle {
                    id: mediaContent
                    anchors.fill: parent
                    implicitHeight: Looks.dp(140)
                    color: Looks.colors.bgPanelBody
                    clip: true

                    readonly property MprisPlayer activePlayer: MprisController.activePlayer
                    readonly property string effectiveArtUrl: MprisController.isYtMusicActive ? YtMusic.currentThumbnail : (MprisController.artUrlOf(activePlayer) ?? "")
                    readonly property string effectiveTitle: MprisController.isYtMusicActive ? YtMusic.currentTitle : (MprisController.titleOf(activePlayer) ?? "")
                    readonly property string effectiveArtist: MprisController.isYtMusicActive ? YtMusic.currentArtist : (MprisController.artistOf(activePlayer) ?? "")

                    Rectangle {
                        anchors.fill: parent
                        color: Looks.colors.bgPanelFooterBase
                        opacity: 0.75
                    }

                    RowLayout {
                        anchors.fill: parent
                        anchors.margins: Looks.dp(16)
                        spacing: Looks.dp(16)

                        // Album art
                        Rectangle {
                            Layout.preferredWidth: Looks.dp(108)
                            Layout.preferredHeight: Looks.dp(108)
                            radius: Looks.radius.xLarge
                            color: Looks.colors.bg1Base
                            clip: true

                            Image {
                                id: mediaArtImage
                                anchors.fill: parent
                                source: MediaArtwork.displaySource
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                cache: false
                                visible: MediaArtwork.ready && status === Image.Ready
                            }
                            FluentIcon {
                                anchors.centerIn: parent
                                icon: "music-note-2"
                                implicitSize: Looks.dp(40)
                                visible: !MediaArtwork.ready || mediaArtImage.status !== Image.Ready
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            spacing: Looks.dp(4)

                            Item { Layout.fillHeight: true }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Looks.dp(8)

                                WText {
                                    Layout.fillWidth: true
                                    text: StringUtils.cleanMusicTitle(MprisController.titleOf(MprisController.activePlayer)) ?? Translation.tr("No media")
                                    font.pixelSize: Looks.font.pixelSize.large
                                    font.weight: Font.DemiBold
                                    elide: Text.ElideRight
                                }

                                // Player app icon
                                IconImage {
                                    id: playerAppIcon
                                    Layout.preferredWidth: Looks.dp(20)
                                    Layout.preferredHeight: Looks.dp(20)
                                    source: {
                                        const de = MprisController.activePlayer?.desktopEntry ?? "";
                                        const identity = (MprisController.activePlayer?.identity ?? "").toLowerCase();

                                        // Special cases for common players
                                        if (identity.includes("spotify")) return Quickshell.iconPath("spotify", "");
                                        if (identity.includes("firefox")) return Quickshell.iconPath("firefox", "");
                                        if (identity.includes("chrome")) return Quickshell.iconPath("google-chrome", "");
                                        if (identity.includes("chromium")) return Quickshell.iconPath("chromium", "");
                                        if (identity.includes("vlc")) return Quickshell.iconPath("vlc", "");
                                        if (identity.includes("mpv")) return Quickshell.iconPath("mpv", "");
                                        if (identity.includes("youtube")) return Quickshell.iconPath("youtube", "");

                                        // Try desktop entry icon
                                        const entry = DesktopEntries.byId(de) ?? DesktopEntries.heuristicLookup(de);
                                        if (entry?.icon) return Quickshell.iconPath(entry.icon, "");

                                        // Fallback to identity as icon name
                                        if (identity) return Quickshell.iconPath(identity, "");

                                        return "";
                                    }
                                    // Only show if loaded successfully
                                    visible: status === Image.Ready
                                }
                            }

                            WText {
                                Layout.fillWidth: true
                                text: MprisController.artistOf(MprisController.activePlayer) ?? ""
                                font.pixelSize: Looks.font.pixelSize.normal
                                color: Looks.colors.fg1
                                elide: Text.ElideRight
                                visible: text !== ""
                            }

                            Item { Layout.fillHeight: true }

                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Looks.dp(4)

                                WBorderlessButton {
                                    implicitWidth: Looks.dp(40)
                                    implicitHeight: Looks.dp(40)
                                    enabled: MprisController.canGoPrevious
                                    contentItem: FluentIcon { anchors.centerIn: parent; icon: "previous"; implicitSize: Looks.dp(18) }
                                    onClicked: MprisController.previous()
                                }
                                WBorderlessButton {
                                    implicitWidth: Looks.dp(48)
                                    implicitHeight: Looks.dp(48)
                                    contentItem: FluentIcon {
                                        anchors.centerIn: parent
                                        icon: MprisController.activePlayer?.isPlaying ? "pause" : "play"
                                        implicitSize: Looks.dp(24)
                                    }
                                    onClicked: MprisController.togglePlaying()
                                }
                                WBorderlessButton {
                                    implicitWidth: Looks.dp(40)
                                    implicitHeight: Looks.dp(40)
                                    enabled: MprisController.canGoNext
                                    contentItem: FluentIcon { anchors.centerIn: parent; icon: "next"; implicitSize: Looks.dp(18) }
                                    onClicked: MprisController.next()
                                }
                            }
                        }
                    }
                }
            }

            // Installed widgets with a Waffle face (widget.json "waffle": { "main": … }), from the Hub or the
            // user's own; each loads on its own, so one that fails leaves no gap and takes nothing else down.
            Repeater {
                model: CustomWidgets.ready && (Config.options?.waffles?.widgetsPanel?.showCustom ?? true)
                    ? CustomWidgets.widgets.filter(widget => String(widget.faces?.waffle?.path ?? "").length > 0) : []

                delegate: ColumnLayout {
                    id: customCard
                    required property var modelData
                    readonly property bool shown: customFace.status === Loader.Ready
                    Layout.fillWidth: true
                    spacing: 0
                    visible: customCard.shown

                    WPanelSeparator {}
                    BodyRectangle {
                        Layout.fillWidth: true
                        implicitHeight: customFace.item?.implicitHeight ?? 0

                        Loader {
                            id: customFace
                            anchors.left: parent.left
                            anchors.right: parent.right
                            source: customCard.modelData.faces?.waffle?.path ?? ""
                            onLoaded: {
                                if (item.hasOwnProperty("waffleSlot"))
                                    item.waffleSlot = "widgets.panel"
                            }
                        }
                    }
                }
            }

            WPanelSeparator { visible: Config.options?.waffles?.widgetsPanel?.showQuickActions ?? true }

            // Quick actions — use Loader to fully unload when disabled
            Loader {
                Layout.fillWidth: true
                active: Config.options?.waffles?.widgetsPanel?.showQuickActions ?? true
                visible: active
                sourceComponent: BodyRectangle {
                    implicitHeight: actionsContent.implicitHeight + Looks.dp(36)

                    ColumnLayout {
                        id: actionsContent
                        anchors.fill: parent
                        anchors.margins: Looks.dp(18)
                        spacing: Looks.dp(14)

                        WText {
                            text: Translation.tr("Quick Actions")
                            font.pixelSize: Looks.font.pixelSize.large
                            font.weight: Font.DemiBold
                        }

                        Grid {
                            Layout.fillWidth: true
                            columns: 3
                            spacing: Looks.dp(10)

                            Repeater {
                                model: root.enabledQuickActions

                                delegate: QuickActionButton {
                                    required property var modelData
                                    width: (parent.width - Looks.dp(16)) / 3
                                    iconName: modelData.icon
                                    label: modelData.label
                                    onClicked: root.runQuickAction(modelData.id)
                                }
                            }
                        }
                    }
                }
            }

            WPanelSeparator { visible: Config.options?.waffles?.widgetsPanel?.showColorScheme ?? true }

            // Scheme variant selector
            Loader {
                Layout.fillWidth: true
                active: Config.options?.waffles?.widgetsPanel?.showColorScheme ?? true
                visible: active
                sourceComponent: BodyRectangle {
                    implicitHeight: schemeContent.implicitHeight + Looks.dp(36)

                    ColumnLayout {
                        id: schemeContent
                        anchors.fill: parent
                        anchors.margins: Looks.dp(18)
                        spacing: Looks.dp(14)

                        WText {
                            text: Translation.tr("Color Scheme")
                            font.pixelSize: Looks.font.pixelSize.large
                            font.weight: Font.DemiBold
                        }

                        ConfigSelectionArray {
                            Layout.fillWidth: true
                            currentValue: Config.options?.appearance?.palette?.type ?? "auto"
                            onSelected: newValue => {
                                Config.setNestedValue("appearance.palette.type", newValue)
                                if (ThemeService.isAutoTheme) {
                                    Quickshell.execDetached(["bash", "-c", `${Directories.wallpaperSwitchScriptPath} --noswitch --type ${newValue}`]);
                                } else {
                                    const hex = MaterialThemeLoader.colorToHex(Appearance.m3colors.m3primary)
                                    const mode = Appearance.m3colors.darkmode ? "dark" : "light"
                                    MaterialThemeLoader.applySchemeVariant(hex, newValue, mode)
                                }
                            }
                            options: [
                                { "value": "auto",                 "displayName": Translation.tr("Auto") },
                                { "value": "scheme-content",       "displayName": Translation.tr("Content") },
                                { "value": "scheme-expressive",    "displayName": Translation.tr("Expressive") },
                                { "value": "scheme-fidelity",      "displayName": Translation.tr("Fidelity") },
                                { "value": "scheme-fruit-salad",   "displayName": Translation.tr("Fruit Salad") },
                                { "value": "scheme-monochrome",    "displayName": Translation.tr("Monochrome") },
                                { "value": "scheme-neutral",       "displayName": Translation.tr("Neutral") },
                                { "value": "scheme-rainbow",       "displayName": Translation.tr("Rainbow") },
                                { "value": "scheme-tonal-spot",    "displayName": Translation.tr("Tonal Spot") }
                            ]
                        }
                    }
                }
            }

            // Bottom padding
            Item { Layout.fillWidth: true; implicitHeight: Looks.dp(8) }
        }
        } // Flickable
    }

    component WeatherStat: ColumnLayout {
        id: stat
        property string statLabel
        property string statValue
        spacing: Looks.dp(2)
        WText {
            text: stat.statLabel
            font.pixelSize: Looks.font.pixelSize.tiny
            color: Looks.colors.fg1
            elide: Text.ElideRight
            Layout.fillWidth: true
        }
        WText {
            text: stat.statValue
            font.pixelSize: Looks.font.pixelSize.small
            font.weight: Font.Medium
            elide: Text.ElideRight
            Layout.fillWidth: true
        }
    }

    component QuickActionButton: Rectangle {
        id: actionBtn
        required property string iconName
        required property string label
        signal clicked()

        implicitHeight: Looks.dp(72)
        radius: Looks.radius.large
        color: actionMa.containsMouse ? Looks.colors.bg2Hover : Looks.colors.bg1Base
        border.width: 1
        border.color: actionMa.containsMouse ? Looks.colors.bg2Border : "transparent"

        scale: actionMa.pressed ? 0.96 : 1.0
        Behavior on scale { animation: NumberAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.OutQuad } }
        Behavior on color { animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard } }

        MouseArea {
            id: actionMa
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: actionBtn.clicked()
        }

        ColumnLayout {
            anchors.centerIn: parent
            spacing: Looks.dp(8)

            FluentIcon {
                Layout.alignment: Qt.AlignHCenter
                icon: actionBtn.iconName
                implicitSize: Looks.dp(20)
                color: actionMa.containsMouse ? Looks.colors.accent : Looks.colors.fg
                Behavior on color { animation: ColorAnimation { duration: Looks.transition.enabled ? 70 : 0; easing.type: Easing.BezierSpline; easing.bezierCurve: Looks.transition.easing.bezierCurve.standard } }
            }

            WText {
                Layout.alignment: Qt.AlignHCenter
                text: actionBtn.label
                font.pixelSize: Looks.font.pixelSize.small
                font.weight: actionMa.containsMouse ? Font.Medium : Font.Normal
                color: actionMa.containsMouse ? Looks.colors.fg : Looks.colors.fg1
            }
        }
    }
}
